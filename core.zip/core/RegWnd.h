// RegWnd.h : header file
//
#ifndef _REGWND
  #define _REGWND

#include "EdListCtrl.h"
/////////////////////////////////////////////////////////////////////////////
// CRegWnd window
#define CBRS_ALIGN_REGWND  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT |CBRS_ALIGN_BOTTOM


class CRegWnd : public CMRCSizeDialogBar
{
// Construction
public:		
	void UpdateAllRegisters();
	BOOL Create( CWnd* pParentWnd ,BOOL visible=TRUE);
	CRegWnd();

// Attributes
public:
  
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CRegWnd();

	// Generated message map functions
protected:	

	CEdListCtrl edlc;
	void Init();
	//{{AFX_MSG(CRegWnd)
	afx_msg void OnSize(UINT nType, int cx, int cy);	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_REGWND
/////////////////////////////////////////////////////////////////////////////
