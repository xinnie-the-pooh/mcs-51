// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "JSTEP.h"
#include "ChildFrm.h"
#include "JSTEPDoc.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs    
	cs.style&=~(LONG)FWS_ADDTOTITLE;
   	return CMDIChildWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers



void CChildFrame::OnSize(UINT nType, int cx, int cy) 
{
  CMDIChildWnd::OnSize(nType, cx, cy);
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pm->pDoc)
  {
	  if(nType==SIZE_MAXIMIZED)
      pm->winmax=TRUE;
    else if(nType==SIZE_RESTORED)
      pm->winmax=FALSE;
  }
}
	
void CChildFrame::SetSharedMenu(CMenu* pmenu)
{
  m_hMenuShared=pmenu->m_hMenu;
  ((CFrameWnd*)AfxGetMainWnd())->OnUpdateFrameMenu(NULL);
}

