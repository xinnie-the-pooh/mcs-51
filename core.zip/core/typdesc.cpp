// Implementierung der Klasse CTypdesc  
#include "stdafx.h"
#include "typdesc.h"

//Konstruktor
CTypdesc::CTypdesc(int type)
{
  tparent=0;         
  typ=type; 
  pref=0;  
  size=0;
  elements=0;
  pmem=0;        
  offset=0;
  pname=0;
  ptag=0;
} 

//Destruktor
CTypdesc::~CTypdesc()
{  
   delete pname; //String l�schen      
   if(!pmem)   
     return;   
   pmem->RemoveAll();
   delete pmem;   //Liste l�schen   
} 

ULONG CTypdesc::GetSizeOfTyp(CTypdesc* pt)
{
CTypdesc* pt1;
POSITION pos;


  if((ULONG)pt<0x1E)
  {      
    switch((ULONG)pt)
    {
      case T_BIT:       return 1;
      case T_SCHAR:     return 1;
      case T_UCHAR:     return 1;
      case T_SINT:      return 2;  
      case T_UINT:      return 2;
      case T_SLONG:     return 4;
      case T_ULONG:     return 4;
      case T_FLOATL:    return 4;
      case T_DOUBLE:    return 8;
      case T_CODELABEL: return 4;
      case T_FLOATB:    return 8;
      default:         return 0;
    }
  }   
  else if(pt->typ<0x1E && pt->pref && (ULONG)pt->pref<0x1E)
  {      
    switch((ULONG)pt->pref)
    {
      case T_BIT:       return 1;
      case T_SCHAR:     return 1;
      case T_UCHAR:     return 1;
      case T_SINT:      return 2;  
      case T_UINT:      return 2;
      case T_SLONG:     return 4;
      case T_ULONG:     return 4;
      case T_FLOATL:    return 4;
      case T_DOUBLE:    return 8;
      case T_CODELABEL: return 4;
      case T_FLOATB:    return 8;
      default:         return 0;
    }
  }   
  else if(pt->typ<0x1E)
  {      
    switch(pt->typ)
    {
      case T_BIT:       return 1;
      case T_SCHAR:     return 1;
      case T_UCHAR:     return 1;
      case T_SINT:      return 2;  
      case T_UINT:      return 2;
      case T_SLONG:     return 4;
      case T_ULONG:     return 4;
      case T_FLOATL:    return 4;
      case T_DOUBLE:    return 8;
      case T_CODELABEL: return 4;
      case T_FLOATB:    return 8;
      default:         return 0;
    }
  }  
  else if(    pt->typ ==T_POINTDESC
           || pt->typ ==T_BITARRDESC
           || pt->typ ==T_SPACEDPTR  
           || pt->typ ==T_GENPTRDESC
           || pt->typ ==T_SDCGENPOINT)           
  {
     if((ULONG)pt->pref<0x1E)
     { 
       if( pt->typ ==T_GENPTRDESC)
         return 3;
       else
         return pt->size;        
     }
     else
       return CTypdesc::GetSizeOfTyp(pt->pref); 
       
  }
  else if( pt->typ==T_ARRAYDESC)
  {
    if(pt->elements)
      return   pt->elements * CTypdesc::GetSizeOfTyp(pt->pref);            
    else
      return   CTypdesc::GetSizeOfTyp(pt->pref); 
  }
  else if( pt->typ==T_STRUCTDESC)
    return   GetSizeOfTyp(pt->pref);
  else if (pt->typ==T_LISTDESC)
  {
    ULONG s=0;
    pos=pt->pmem->GetHeadPosition();
    while(pos)
    {
      pt1=(CTypdesc*)pt->pmem->GetNext(pos);
      s+=CTypdesc::GetSizeOfTyp(pt1);
    }  
    return s;
  }
  else  
    return GetSizeOfTyp(pt->pref);
  return 0; 
}
