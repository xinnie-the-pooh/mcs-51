// LocalWnd.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "watchwnd.h"
#include "moddef.h"
#include "mainfrm.h"
#include "LocalWnd.h"
#include "objinfo.h"
#include "proc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLocalWnd

CLocalWnd::CLocalWnd()
{
  lowaddr=-1;
  highaddr=0;
}

CLocalWnd::~CLocalWnd()
{
}


BEGIN_MESSAGE_MAP(CLocalWnd, CWatchWnd)
	//{{AFX_MSG_MAP(CLocalWnd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CLocalWnd message handlers
BOOL CLocalWnd::Create( CWnd* pParentWnd,BOOL visible)
{
LV_COLUMN lvc;
 
  Created= CMRCSizeDialogBar::Create(pParentWnd,IDD_LOCALS
		        ,CBRS_ALIGN_REGWND|CBRS_SIZE_DYNAMIC
				,IDD_LOCALS);	  
  if(!visible)
     ModifyStyle(WS_VISIBLE,0,SWP_NOACTIVATE);
  if(Created)
  {    
	hlc.SubclassDlgItem(IDC_WATCHLST,this);   
	hlc.Create();
    SetBarStyle( GetBarStyle()			         
							 | CBRS_FLYBY 							 
							 | CBRS_BORDER_ANY 
							 | CBRS_BORDER_3D );	
    SetWindowText(_T("Locals"));
    EnableDocking(CBRS_ALIGN_WATCHWND);		

    lvc.mask=LVCF_TEXT;
    lvc.pszText="Local Variable";
    lvc.iSubItem=0;
    hlc.SetColumn(0,&lvc);  //Spalte 0
    
 	RECT rd;
	GetDesktopWindow()->GetWindowRect(&rd);    		
	CPoint pt;
	pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;	
    m_FloatingPosition=pt; 
  }  
  UpdateLocals();
  return(Created);
}

void CLocalWnd::UpdateLocals()
{
ULONG addr;
POSITION pos;
CPtrArray* ppa;
CString lbl;
int index;
labeldef_t* lp;
CObjInfo* pobjinfo;
CModDef* pm;
  
  pobjinfo=&(((CJSTEPApp*)AfxGetApp())->objinfo);
  addr=prc->GetProgramCounter();
  if(addr>=lowaddr && addr<=highaddr)
    hlc.UpdateWatchWnd();
  else //neue Prozedur
  {
    while(hlc.GetItemCount()>1)
      hlc.DeleteItem(0);
    pactproc=pobjinfo->GetProcFromAddr(addr);
    if(!pactproc)
    { 
      lowaddr=addr;
      highaddr=addr;
      return;    
    }
    lowaddr=pactproc->AnfAddr;
    highaddr=pactproc->EndAddr;
    pm=pobjinfo->GetModuleFromAddress(addr);
    pos=pobjinfo->labels.GetStartPosition();
    while(pos)
    {
      pobjinfo->labels.GetNextAssoc(pos,lbl,ppa);
      index=ppa->GetSize();
      while(index--)
      {
        lp=(labeldef_t*)ppa->GetAt(index);
        if(lp->pproc == pactproc && (ULONG)lp->pTypdesc != T_CODELABEL)
          hlc.AddWatchExpression(lbl,FALSE,pm,pactproc);
      }  
    }
    item_t* pi=(item_t*)hlc.GetItemData(hlc.GetItemCount()-1);
    pi->editable[0]=FALSE;
  }    
}

