// TPEdit.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "TPEdit.h"
#include "jstepdoc.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTPEdit dialog


CTPEdit::CTPEdit(CWnd* pParent /*=NULL*/)
	: CDialog(CTPEdit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTPEdit)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTPEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTPEdit)
    DDX_Control(pDX, IDC_TRACEPOINTLIST, tplist);
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTPEdit, CDialog)
	//{{AFX_MSG_MAP(CTPEdit)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTPEdit message handlers

BOOL CTPEdit::OnInitDialog() 
{
CString* ptxt;
CString txt;


  CDialog::OnInitDialog();
  tplist.Create();
  
  CJSTEPDoc* pdoc=((CMainFrame*)AfxGetMainWnd())->pDoc;
  int s=pdoc->tpt.expressions.GetSize();
  while(s--)
  {
    ptxt=(CString*)(pdoc->tpt.expressions.GetAt(s));
    tplist.InsertItem(0,LPCSTR(*ptxt));
  }
  if(pdoc->tpt.isValid)
  {
    ULONG memsize=prc->GetMemSize();
    switch(memsize)
    {
      case S32:  txt.Format("0x%8.8X",pdoc->tpt.GetAddr());
                 break;
      case S16:  txt.Format("0x%4.4X",pdoc->tpt.GetAddr());
                 break;
      case S8:   txt.Format("0x%4.4X",pdoc->tpt.GetAddr());
                 break;
    }
    SetDlgItemText(IDC_TPADDR,txt);
  }
  else
    SetDlgItemText(IDC_TPADDR,"");
  return TRUE;  
}

void CTPEdit::OnOK() 
{
int n,i;	
CString* ps;
   
  CJSTEPDoc* pdoc=((CMainFrame*)AfxGetMainWnd())->pDoc;
  n=tplist.GetItemCount()-1;
  pdoc->tpt.DeleteAllExpressions();
 	for(i=0;i<n;i++)
  {
    ps=new CString(tplist.GetItemText(i,0));
    pdoc->tpt.expressions.Add(ps);
  }
	CDialog::OnOK();
}

void CTPEdit::OnDelete() 
{
  tplist.edit.ShowWindow(FALSE);  
  tplist.DeleteItem(tplist.edit.act); 
  tplist.edit.act=-1;
}
