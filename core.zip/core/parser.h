#ifndef _PARSER
#define _PARSER

#define ISADDR 1
#define ISNEG  2
//parser Header

typedef struct {
                 unsigned long optyp;
                 unsigned char op[8];
                 unsigned long memspec;
                 unsigned long addr;
                 unsigned long flags;
               } op_t; 

typedef struct {  
                 char* expression;
                 op_t retval;
                 op_t lastop;
               } eval_t;

extern int GetSimpleMemContent(eval_t* p);
extern int eval(eval_t* param);
extern void GetVal(unsigned char* v,ULONG addr,int memspec,ULONG typ);
extern int GetNextOperand(op_t* op,char** pexpression,char* namebuffer);
extern int GetNextOperator(op_t* op, char** pexpression);
extern int ExecOperation(op_t* op1,op_t* op2, op_t* opr ); 
extern int Evaluate(eval_t* param);
extern int GetOperandVal(char* opname,op_t* o);
extern BOOL GetContens(char* op, long* val);
extern BOOL GetLabelVal(LPCSTR opname, op_t* op, labeldef_t* lp);
extern void GetWatchValString(char* txt, eval_t* eval,int txtlen);
extern BOOL BuildKomplement(unsigned long* pval,unsigned long valtyp);
extern int GetArraySize(CTypdesc* pt);

#endif // _PARSER