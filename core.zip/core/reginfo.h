// header der Klassen Cregdef und CRegInfo

#ifndef _CREG
#define _CREG

#include "..\core\proc.h"
//Formate f�r Darstellung der Register

#define BYTE_HEX         0x0001
#define SHORT_HEX        0x0002
#define LONG_HEX         0x0004
#define SHORT_HEX_INVERS 0x0008
#define LONG_HEX_INVERS  0x0010

#define BYTE_BIN         0x0100
#define SHORT_BIN        0x0200
#define LONG_BIN         0x0400

#define BINARY           0x0700 

#define REGVARLOC        0x8000  //die Adresse ist nicht konstant->offset berechnen


class CRegInfo
{
public:	
	CRegInfo();
	~CRegInfo();
	int regno;
	CRegdef* GetReg(int index);  
	void SetReg(int index, ULONG val);	
	void AddReg(LPCSTR name, void* ploc, int fmt); 

protected:	
	int nextindex;
  CPtrList reglist;
};

#endif
