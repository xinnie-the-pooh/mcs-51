// AddrEd.cpp : implementation file
//

#include "stdafx.h"
#include "proc.h"
#include "JSTEP.h"
#include "AddrEd.h"
#include "MemWnd.h"
#include "parser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddrEd

CAddrEd::CAddrEd()
{
}

CAddrEd::~CAddrEd()
{
}


BEGIN_MESSAGE_MAP(CAddrEd, CEdit)
	//{{AFX_MSG_MAP(CAddrEd)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddrEd message handlers


void CAddrEd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
CString txt;

 GetWindowText(txt);
 if( nChar != VK_RETURN || txt==lasttxt )
 {
   CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
   return;
 } 
 OnReturnKey(txt); 
 CEdit::OnKeyDown(nChar, nRepCnt, nFlags); 
}


void CAddrEd::OnReturnKey(CString& txt)
{
int l,l1;
ULONG saddr;
int memspec;
char cstop;
char* csp;
eval_t r;
char buff[80];
CString txtaddr;
 
 CMemWnd* pmd=((CMemWnd*)GetParent());
 cstop=0; 
 csp=&cstop;
 GetWindowText(txt);  	
 txt.TrimLeft();
 txt.TrimRight();
 //if(txt.Left(2)=="0x" || txt.Left(2)=="0X")
 //  txt=txt.Mid(2);
 l=txt.Find('/');
 if(l== -1)
 {
   if(IsDezString(txt))
   {
     saddr=strtoul(LPCSTR(txt),&csp,10);
     goto a2;
   }
   if(IsHexString(txt)) //g�ltiger String
   {
     txt.MakeLower();
     saddr=strtoul(LPCSTR(txt),&csp,16);
a2: 
     pmd->SetStartAddr(saddr,txtaddr,0);
     txt="0x" + txtaddr;
     SetWindowText(txt);
     pmd->startaddr=saddr;
     pmd->memspec=0;     
     pmd->edlc.SetCols(-1,0,saddr);
     pmd->varAddr=FALSE;
   }
   else // vieleicht auch ein Label
   {
     strcpy(buff,txt);
     r.expression=buff;
     r.lastop.op[0]=0;
     int x=Evaluate(&r);
     if(x)
     {
       lasttxt=txt;
       return;  //falsch
     }   
     else
     {
       switch(r.retval.memspec)
       {
         case DATAMEM: memspec='d';
                       break;
         case IDATAMEM:memspec='i';
                       break;
         case XDATAMEM: memspec='x';
                       break;
         case CODEMEM: memspec='c';
                       break;
         default:      memspec=r.retval.memspec;  
       }           
       pmd->SetStartAddr(*(ULONG*)r.retval.op,txt,memspec);
       pmd->edlc.SetCols(-1,memspec,pmd->startaddr);
       pmd->varAddr=TRUE;
     }
   }
 }
 else
 {
   pmd->varAddr=FALSE;
   l1=txt.Find('/');
   memspec=txt.GetAt(l1+1);
   txt=txt.Left(l-1);
   txt.TrimRight();
   txt.TrimLeft();
   if(IsDezString(txt))
   {
     saddr=strtoul(LPCSTR(txt.Left(l-1)),&csp,10);
     goto a1;
   }
   if(IsHexString(txt)) //g�ltiger String
   {
     saddr=strtoul(LPCSTR(txt.Left(l-1)),&csp,16);    
a1:  
     pmd->SetStartAddr(saddr,txtaddr,memspec);
     txt="0x" + txtaddr;
     txt+=" /";
     txt+= (char)memspec;
     SetWindowText(txt);
     pmd->memspec=memspec;
     pmd->edlc.SetCols(-1,memspec,saddr);     
   } 
 } 	
 lasttxt=txt;
}
