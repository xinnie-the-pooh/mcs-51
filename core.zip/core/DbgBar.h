// DbgBar.h : header file
//
#ifndef _DBGBAR
  #define _DBGBAR

#include "CmdBx.h"
#include "FlatToolBar.h"
//#include "ToolBarEx.h" 
/////////////////////////////////////////////////////////////////////////////
// CDbgBar window

class CDbgBar : public CFlatToolBar
//class CDbgBar : public CToolBarEx
{
// Construction
public:
	BOOL Init(CWnd* pParentWnd);
	CCmdBox cmdbox;
	CDbgBar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDbgBar)
	//}}AFX_VIRTUAL
  BOOL Created;

// Implementation
public:
	virtual ~CDbgBar();

	// Generated message map functions
protected:
	
	//{{AFX_MSG(CDbgBar)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //DBGBAR
/////////////////////////////////////////////////////////////////////////////
