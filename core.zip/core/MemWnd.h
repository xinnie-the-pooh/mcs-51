// MemWnd.h : header file
//
#ifndef _MEMWND
 #define _MEMWND

#include "EdMemLstCtrl.h"
#include "addred.h"
/////////////////////////////////////////////////////////////////////////////
// CMemWnd window
#define CBRS_ALIGN_REGWND  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT |CBRS_ALIGN_BOTTOM


class CMemWnd : public CMRCSizeDialogBar
{
// Construction
public:		
	void SetAddress(CString& txt);	
	void GetAddrString(CString& txt);
	BOOL varAddr;
	int memspec;
	void SetViewType(int type);
	ULONG startaddr;
	void SetStartAddr(ULONG addr,CString& saddr, int memspec=0); // default ROM
	void UpdateMem(BOOL redraw=FALSE);
	BOOL Create( CWnd* pParentWnd ,int wndNo);
	CMemWnd(int vtyp=V_BYTE,ULONG addr=0,int mem=M_CODE);
    void Init(ULONG addr=0);

// Attributes
  CEdMemLstCtrl edlc;
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemWnd)
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL
  virtual int OnToolHitTest( CPoint point, TOOLINFO* pTI ) const;

// Implementation
public:
	virtual ~CMemWnd();

	// Generated message map functions
protected:	
	int dright;
	CAddrEd addred;
	int viewtype;	
	
	//{{AFX_MSG(CMemWnd)
	afx_msg void OnSize(UINT nType, int cx, int cy);  
	afx_msg void OnEditPaste();
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
#endif // _MEMWND
