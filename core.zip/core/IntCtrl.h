// IntCtrl.h : header file
//

#ifndef _INTCTRL
#define _INTCTRL
/////////////////////////////////////////////////////////////////////////////
// CIntCtrl window

class CIntCtrl : public CDialogBar
{
// Construction
public:
	void UpdateIntWnd();
	POINT m_FloatingPosition;
	BOOL Created;
	BOOL Create(CWnd* pParent);
	CIntCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIntCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CIntCtrl)
		// NOTE - the ClassWizard will add and remove member functions here.
    void afx_msg OnEnable0();    
    void afx_msg OnEnable1();    
    void afx_msg OnEnable2();    
    void afx_msg OnEnable3();    
    void afx_msg OnEnable4();    
    
    void afx_msg OnPrioInt0();    
    void afx_msg OnPrioInt1();    
    void afx_msg OnPrioInt2();    
    void afx_msg OnPrioInt3();    
    void afx_msg OnPrioInt4();
    
    void afx_msg OnInt0();
    void afx_msg OnUpdateInt0(CCmdUI* pCmdUI);
    void afx_msg OnInt1();
    void afx_msg OnUpdateInt1(CCmdUI* pCmdUI);
    void afx_msg OnInt2();
    void afx_msg OnUpdateInt2(CCmdUI* pCmdUI);
    void afx_msg OnInt3();
    void afx_msg OnUpdateInt3(CCmdUI* pCmdUI);
    void afx_msg OnIntRx4();
    void afx_msg OnUpdateIntRx4(CCmdUI* pCmdUI);
    void afx_msg OnIntTx4();
    void afx_msg OnUpdateIntTx4(CCmdUI* pCmdUI);
    void afx_msg OnIntEnable();
    void afx_msg OnUpdateIntEnable(CCmdUI* pCmdUI);   
	//}}AFX_MSG
    
	DECLARE_MESSAGE_MAP()
};

#endif //_INTCTRL
/////////////////////////////////////////////////////////////////////////////
