// Header f�r globale Funktionen
// globals.h

#ifndef _GLOBALS
#define _GLOBALS

BOOL IsNum(CString& nstr);
BOOL IsHexNum(char* s);
BOOL IsDezNum(char* s);
BOOL IsSignedDezNum(char* s);
void GetBinString(int fmt, void* ploc, CString& s);
BOOL IsHexString(CString& s);
BOOL IsHexString(LPCSTR s);
BOOL IsDezString(CString& s);
BOOL IsDezString(LPCSTR s);
BOOL IsPointInRect(LPPOINT pp, RECT* pr);

#endif




