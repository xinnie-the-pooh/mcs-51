#include "stdafx.h"
#include "proc.h"  
#include "jstep.h"
#include "parser.h"   
#include "objinfo.h" 

static int level;


int Evaluate(eval_t* p)
{   
int err; 
char buffer[200];  //Zwischenpuffer=max.stringl�nge
char* hp;
char* hp1;

  
  strcpy(buffer,p->expression);
  hp=buffer;
  hp1=p->expression;
  while(*hp)            //Leerzeichen entfernen
  {
    if(*hp != ' ')
      *hp1++=*hp;
    hp++;
  } 
  *hp1=0;   
  level=0;
  for(err=0;err<8;err++)
    p->retval.op[err]=0;
  p->retval.optyp=0;     //Ergebnis vorbelegt mit 0  
  p->lastop.optyp=100;   //Operatorlevel mit niedigst vorbelegt 
  
  int l=_strnicmp(p->expression,"{0x",3);
  if(l==0)
  {  
    return (GetSimpleMemContent(p));    
  }

  err= eval(p);          //Einstieg
  if(!err)
     return -1;      //Ausdruck l�sst sich nicht berechnen
  if(level)
     return -2;      //Klammerebenen sind nicht paarig
  return 0;    
}
    
int GetSimpleMemContent(eval_t* p)
{
CString txt;
ULONG addr;
int l;
int memspec;
   
   txt=p->expression;
   l=txt.Find(',');
   if(l==-1)
     memspec=CODEMEM;
   else
   {
     switch(p->expression[l+1])
     {
       case 'D':
       case 'd': memspec=DATAMEM;
                 break;
       default:
       case 'c':
       case 'C': memspec=CODEMEM;
                 break;
       case 'P':
       case 'p': memspec=PDATAMEM;
                 break;
       case 'X':
       case 'x': memspec=XDATAMEM;
                 break;
       case 'I':
       case 'i': memspec=IDATAMEM;
                 break;
     }
   }
   p->retval.memspec=memspec;   
   txt=txt.Mid(3,l-3);
   if(!IsHexString(txt))
     return(-1);
   addr=strtoul(txt,0,16);
   p->retval.addr=addr;
   p->retval.optyp=T_UCHAR;
   l=prc->GetMemFromAddr(addr,(ULONG*)p->retval.op,memspec);
   if(!l)
     return(-1);
   else
     return 0;
}              
                  
//return 1 wenn OK, sonst 0                  
int eval(eval_t* p)
{
char* hp; 
char* hp1;
eval_t p1;
int err;
op_t o1;
op_t z2,z1;  
BOOL b; 
char buff[100]; 
labeldef_t hlb;
ULONG memspec;
CTypdesc* tp;  
  

  o1.flags=0;
  p1.retval.flags=0;
  if( *(p->expression)=='(' )  //der Ausdruck f�ngt mit Klammer an
  { 
    level++;
    p->expression++;
    p1=*p;    
    p1.lastop.op[0]=0;
    err=eval(&p1);  //der Ausdruck wird auf dem n�chsten Level berechnet
    if(!err)
      return(0);
    p1.lastop.op[0]=p->lastop.op[0]; //wiederherstellen
    *p=p1;
  } 
  else if( *(p->expression)=='&' ) //die Adresse des Ausdrucks wird gesucht
  {    
    p->expression++;
    p1=*p;      
    p1.lastop.op[0]='&'; //Merker das Adresse gesucht wurde    
    err=eval(&p1);  //der Ausdruck wird auf dem n�chsten Level berechnet
    if(!err)
      return(0); 
    *((unsigned long*)(p1.retval.op))=p1.retval.addr;   
    p1.retval.flags=ISADDR;    
    *p=p1;
  }
  else if( *(p->expression)=='*' ) //der Inhalt eines Zeigers wird gesucht
  { 
    p->expression++;
    p1=*p;      
    p1.lastop.op[0]='*'; //Merker das Pointerinhalt gesucht wurde
    err=eval(&p1);  //der Ausdruck wird auf dem n�chsten Level berechnet
    if(!err)
      return(0);
    tp=(CTypdesc*)(p1.retval.optyp);
    if( (ULONG)tp >0x1E)
    {
      if(tp->tparent)  //der Zeiger ist Element einer Liste
        tp=tp->pref;   
      if(tp->typ!=T_POINTDESC && tp->typ!=T_GENPTRDESC && tp->typ!=T_SPACEDPTR && tp->typ!=T_SDCGENPOINT)
        return 0; 
      if((ULONG)tp->pref < 0x1E )
      {
        p1.retval.addr=*(ULONG*)p1.retval.op;
        GetVal(p1.retval.op,*(ULONG*)p1.retval.op,(int)p1.retval.memspec,(ULONG)tp->pref);
        p1.retval.optyp=(ULONG)tp->pref;
      }      
      *p=p1;    
    }
  }
  else if (*(p->expression)=='~' ) //Bitweise negiert
  {
    p->expression++;
    p1=*p;      
    p1.lastop.op[0]='~'; //Merker das das Einerkomplement gesucht wird
    err=eval(&p1);  //der Ausdruck wird auf dem n�chsten Level berechnet
    if(!err)
      return(0);
    if(!BuildKomplement((ULONG*)p1.retval.op,p1.retval.optyp))
      return(0);    
    *p=p1;
    return(1);
  }
  else
  {
    o1.op[0]=p->lastop.op[0];
    err=GetNextOperand(&o1,&(p->expression),0);
    if(!err)
      return(0);     // kein vern�nftiger Ausdruck
    p->retval=o1;    // der allererste Operand wird gleich dem Ergebnis zu-
                     // geordnet 
  }                    
  p1.expression=p->expression;
  err=GetNextOperator(&z1,&(p->expression));  //1. Operator
  if(err==-1 && *p->expression==0)             //kein Operand gefunden 
    return(1);                      //das wars schon  Ergebnis=Operand
  else if(err==-1)
    return(1);
  if( z1.op[0]==']' || z1.op[0]==')' )  // schliessende Klammer-> Ebene zur�ck
  {
    level--;
    return(1);
  }  
  while( z1.op[0]=='[' )  //eine oder mehrere Klammern
  {   
    level++;
    p1.expression=p->expression;
    err=eval(&p1);
    if(!err)
      return(0);
    err=ExecOperation(&(p->retval),&(p1.retval),&z1);
    if(err)
      return(0);
    p->expression=p1.expression;  
    err=GetNextOperator(&z1,&(p->expression));  
    if( err==-1 && *(p->expression)==0
       || *z1.op==']' 
       || *z1.op==')')  
    {  
      if(*z1.op==']' || *z1.op==')' )
      {        
        level--;
      }  
      return(1);
    }  
    if(*z1.op=='.') //strukturarray
    {
       err=GetNextOperand(&o1,&(p->expression),buff); //hole nur den Namen nach dem Punkt        
       hlb.pTypdesc=(CTypdesc*)(p->retval.optyp);
       if(hlb.pTypdesc->typ != T_STRUCTDESC)
         return 0; //alles Mist
       else if( hlb.pTypdesc->pref->typ == T_STRUCTDESC) //das array ist Teil einer strukturliste 
         hlb.pTypdesc=hlb.pTypdesc->pref; 
       hlb.pTypdesc=hlb.pTypdesc->pref; //der Listdescriptor  
       hlb.addr=p->retval.addr;
       hlb.memspec=(int)(p->retval.memspec); 
       hlb.ModID=0;
       hlb.pproc=0;
       b=GetLabelVal(buff,&(p->retval),&hlb); 
       if(!b)
         return 0;      
       err=GetNextOperator(&z1,&(p->expression));  
       if( err==-1 && *(p->expression)==0
          || *z1.op==']' 
          || *z1.op==')')  
       {  
         if(*z1.op==']' || *z1.op==')' )         
           level--;
         if(p->lastop.op[0]=='&')    //die Berechnung der Adresse ist beendet
           p->lastop.op[0]=0;  
         return(1);
      }
    }
    if(z1.op[0]=='-' && z1.op[1]=='>') //Pointerrarray in/auf einer struktur
    {
       err=GetNextOperand(&o1,&(p->expression),buff);        
       hlb.pTypdesc=(CTypdesc*)(p->retval.optyp);
       if(   hlb.pTypdesc->typ !=T_SPACEDPTR 
          && hlb.pTypdesc->typ !=T_GENPTRDESC
          && hlb.pTypdesc->typ !=T_POINTDESC
          && hlb.pTypdesc->typ !=T_SDCGENPOINT)
         return 0; //alles Mist zum -> geh�rt der Strukturpointer
       else if( hlb.pTypdesc->pref->typ == T_ARRAYDESC) //das array ist Teil einer strukturliste 
         hlb.pTypdesc=hlb.pTypdesc->pref; 
       hlb.addr=p->retval.addr;
       hlb.memspec=(int)(p->retval.memspec);         
       b=prc->GetPointer(&hlb.addr,&hlb.addr,hlb.pTypdesc,(USHORT)hlb.memspec,&memspec);
       if(b==FALSE)  
         return 0;  // irgendwas an dem Zeiger stimmte nicht        
       hlb.memspec=memspec; //der Zeiger kann auf einen anderen Speicherbereich zeigen  
       hlb.ModID=0;
       hlb.pproc=0;
       hlb.pTypdesc=hlb.pTypdesc->pref->pref; //typdesc listelement->pointertyp->struktdesc->LISTE      
       b=GetLabelVal(buff,&(p->retval),&hlb);
       if(!b)
         return 0;      
       err=GetNextOperator(&z1,&(p->expression));  
       if( err==-1 && *(p->expression)==0
          || *z1.op==']' 
          || *z1.op==')')  
       {  
         if(*z1.op==']' || *z1.op==')' )       
           level--;
         if(p->lastop.op[0]=='&')    //die Berechnung der Adresse ist beendet
           p->lastop.op[0]=0;  
         return(1);
       }
    }    
  }     
  if(z1.op[0]=='-' && z1.op[1]=='>') //Klammer um einen Zeiger auf eine Struktur
  {  
    
     if(p->retval.optyp <0x1F)
       return 0;  //das ist kein Zeiger
     err=GetNextOperand(&o1,&(p->expression),buff);        
     hlb.pTypdesc=(CTypdesc*)(p->retval.optyp);

     if(   hlb.pTypdesc->typ !=T_SPACEDPTR 
        && hlb.pTypdesc->typ !=T_GENPTRDESC
        && hlb.pTypdesc->typ !=T_POINTDESC 
        && hlb.pTypdesc->typ !=T_SDCGENPOINT)
       return 0; //alles Mist zum -> geh�rt der Strukturpointer
     else if( hlb.pTypdesc->pref->typ == T_ARRAYDESC) //das array ist Teil einer strukturliste 
       hlb.pTypdesc=hlb.pTypdesc->pref; 
     hlb.addr=*(unsigned long*)(p->retval.op);      
     hlb.memspec=p->retval.memspec;  
     hlb.ModID=0;
     hlb.pproc=0;
     hlb.pTypdesc=hlb.pTypdesc->pref->pref; //typdesc listelement->pointertyp->struktdesc->LISTE      
     if(hlb.pTypdesc->typ != T_LISTDESC)  // der Zeiger ist selbst Teil einer Liste
       hlb.pTypdesc=hlb.pTypdesc->pref;
     b=GetLabelVal(buff,&(p->retval),&hlb);
     if(!b)
       return 0;      
     err=GetNextOperator(&z1,&(p->expression));  
     if( err==-1 && *(p->expression)==0
        || *z1.op==']' 
        || *z1.op==')')  
     {  
       if(*z1.op==']' || *z1.op==')' )       
         level--;
       if(p->lastop.op[0]=='&')    //die Berechnung der Adresse ist beendet
         p->lastop.op[0]=0;  
       return(1);
     }
     if(*z1.op== '[')
     {
       level++;        
       p1.expression=p->expression;
       p1.lastop=z1;
       err=eval(&p1);
       if(!err)
         return(0); 
       err=ExecOperation(&(p->retval),&p1.retval,&z1);
       if(!err) 
         return(1);
       p->expression=p1.expression;
     }
  }   

  if((p->lastop.op[0]=='&' && p->lastop.op[1]!='&') || p->lastop.op[0]=='*') //die Berechnung der Adresse ist beendet
  { 
    p->expression=p1.expression;
    p->lastop.op[0]=0;
    p->retval.flags=ISADDR;
    return 1;                    
  }  
  
  
  //Schleife bis der Ausdruck abgearbeitet ist
  while(*(p->expression))
  {          
    hp1=p->expression;
    if( *(p->expression)=='&' )
    { 
      p->expression++;
      p->lastop.op[0]='&';
    }
    err=GetNextOperand(&o1,&(p->expression),0);  // 2. Operand
   // if(!err)
   //   return(0);     // kein vern�nftiger Ausdruck
    if( p->lastop.op[0]=='&' && p->lastop.op[1]!='&')
    {
      p->lastop.op[0]=0;
      *(unsigned long*)o1.op=o1.addr;
      o1.flags=ISADDR;
    }
    if(!err)       //erst mal keinen Operanden gefunden                          
    {
      if( o1.op[0]=='(' )  //�ffnende Klammer->n�chste Ebene
      {  
        level++;        
        p1.expression=p->expression;
        p1.lastop=z1;
        err=eval(&p1);
        if(!err)
          return(0); 
        o1=p1.retval;
        p->expression=p1.expression;        
      }
      else
        return(0);
    }    
    hp=p->expression;
    err=GetNextOperator(&z2,&hp);              // 2.Operator
    
    if(err==-1 && *(p->expression)==0) //kein weiter Operator gefunden 
    {
      err=ExecOperation(&(p->retval),&o1,&z1);
      if(!err) 
        return(1);
      else
        return(0);  
    }
    else if(err==-1)
      return(0);     
    
    // Test welcher Operator Vorrang hat                              
    if(z1.optyp <= z2.optyp)  //die Operation auf diesem Level hat Vorrang
    {      
      p->expression=hp;  // die Operation wird auf dem Level ausgef�hrt 
                         // deshalb wird auch der String auf dem Level gek�rzt
      err=ExecOperation(&(p->retval),&o1,&z1);
      if(err)  // Fehler 
        return(0);
      if(z2.optyp>=20)  // schliessende Klammer 
      {
        level--; 
        return(1);
      }     
      if(p->lastop.optyp<=z2.optyp)
      {    
        p->expression--; // ein Zeichen mehr wegen der fehlenden Klammer
        p->lastop=z2;
        return 1;
      }   
      z1=z2;           
    }
    else
    {
      p1.retval=o1;  // das aktuelle Argument wird auf dem n�chsten Level berechnet
      p1.expression=hp1;    
      p1.lastop=z1;
      err=eval(&p1); 
      if(!err)
        return(0);
      err=ExecOperation(&(p->retval),&(p1.retval),&(z1)); 
      if(err)
        return(0);  
      p->expression=p1.expression; 
      err=GetNextOperator(&z1,&p->expression);           // 2.Operator  
      if(err==-1 && *(p->expression)==0) //kein weiter Operator gefunden 
      {
        return(1);
      }           
      if(p->lastop.optyp<=z1.optyp)
      {
        p->expression--; // ein Zeichen mehr wegen der fehlenden Klammer
        return 1;
      }
      
      if(z1.op[0]==')')
      {
        level--;
        return(1);
      }   
    }
  }  
  return 1;
}     

//liefert den n�chsten Operanden im String
//wenn vorhanden mit rechts assoziativen Operator!!
//R�ckgabewert ist die Stringl�nge des Operanden
//pexpression steht nach der operation auf dem
//n�chsten Operationszeichen
 
int GetNextOperand(op_t* o,char** pexpression,char* namebuffer)
{
char* hp;
char* startp;
int i; 
char c;
char buff[100];
int err;
    
  i=0;
  hp=buff;  
  startp=*pexpression;
  
op1:
  
  c=**pexpression;
  if(c==' ')       //Leerzeichen
    goto op3;  
  if(c==0)         //Stringende
    goto op3;
  if(**pexpression=='+' && *pexpression==startp)
    goto op4; 
  if(**pexpression=='-' && *(*pexpression+1)== '>'  && *pexpression==startp)
    goto op2;
  if(**pexpression=='-' &&  *pexpression==startp )
    goto op4; 
  if(**pexpression=='-' && (*(*pexpression+1)!= '>'))  
    goto op2;
  if(**pexpression=='*' && *pexpression!=startp) 
  {  
    if( *(*pexpression-1)!= '*')
      goto op2;  
    else
      goto op4;  
  }    
  if(**pexpression=='+')
    goto op2;   
  if(**pexpression=='/')
    goto op2;
  if(**pexpression=='%')
    goto op2; 
  if(**pexpression=='(') 
  {  
    if(strnicmp(buff,"sizeof",6))
    {
      goto op2;
    }
    else
    { 
      while( **pexpression != ')')
      {
        *hp++=**pexpression;
        (*pexpression)++;
        i++;         
      }      
      (*pexpression)++;
      goto op3;    
    }   
  }  
  if(**pexpression=='[')
    goto op2;      
  if(**pexpression==')')
    goto op2; 
  if(**pexpression==']')
    goto op2;   
  if(**pexpression=='|')
    goto op2;
  if(**pexpression=='^')
    goto op2;
  if(**pexpression=='=')
    goto op2;
  if(**pexpression=='!')
    goto op2;    
  if(**pexpression=='&' && *pexpression!=startp)
    goto op2;
  if(**pexpression=='~' && *pexpression!=startp)
    goto op2;  
  if(**pexpression=='>' && (*(*pexpression-1)!= '-'))
    goto op2;  
  if(**pexpression=='<')
    goto op2; 
    
op4:
  *hp++=**pexpression;
  (*pexpression)++;
  i++;
  goto op1;
  
op2:       
   if(hp==buff)  //keinen Operanden gefunden, nur Operatorzeichen
   {
     o->op[0]=**pexpression;       
     (*pexpression)++; 
     o->optyp=0; 
     return(0);  //Fehler kein Operand gefunden 
   }
op3:
   *hp=0;
   if(namebuffer)
   {
     strcpy(namebuffer,buff);
     return 1;
   }  
   else  
     err=GetOperandVal(buff,o);   
   return(err);
}                   

//liefert das n�chste Operatorzeichen und dessen Priorit�t
//0=h�chste Priorit�t
//poperator muss auf einen Puffer mit wenigstens 3 Zeichen L�nge zeigen
//pexpression steht nach der operation auf dem Anfang des n�chsten Operanden
//oder des ersten folgenden Leerzeichens


int GetNextOperator(op_t* o, char** pexpression)
{
int i;
char c;

  i=0;
  c=**pexpression;
  if(!c)       //leerer String
    return(-1); 
  (*pexpression)++;
  o->op[0]=c;
  o->op[1]=0; 
  switch(c)
  {
    case '(': i=0;
              break;
    case '[': 
    case '.': i=1;
              break;
    case '*':               
    case '/': i=2;
              break;
    case '%': i=3;
              break;
    case '+': i=4;
              break;
    case '-': if(*(*pexpression)=='>')
              {
                i=1;  
                o->op[1]='>';
                o->op[2]=0;
                (*pexpression)++;
              }
              else  
                i=4;
              break;
    case '<':
    case '>': if(*(*pexpression)==c) 
              {
                o->op[1]=c;
                o->op[2]=0;
                i=5;  
                (*pexpression)++;
              }  
              else if(*(*pexpression)=='=')
              {
                o->op[1]='=';
                o->op[2]=0;
                i=6;  
                (*pexpression)++;
              }  
              else
                i=6;
              break;  
    case '=': if(*(*pexpression)==c)
              {
                o->op[1]=c;
                o->op[2]=0;
                i=7;  
                (*pexpression)++;
              }  
              else
                i=-1;   //ung�ltig
              break;                                     
    case '!': if(*(*pexpression)=='=')
              {
                o->op[1]='=';
                o->op[2]=0;
                i=7;
                (*pexpression)++;
              } 
              else
                i=-1;   //ung�ltig
              break;          
    case '&': if(*(*pexpression)==c)
              {
                o->op[1]=c;
                o->op[2]=0;
                i=11;
                (*pexpression)++;  
              }
              else
                i=8;  
              break;
    case '^': i=9;
              break;                    
    case '|': if(*(*pexpression)==c)
              {
                o->op[1]=c;
                o->op[2]=0;
                i=12;          
                (*pexpression)++;
              }
              else                
                i=10;
              break;   
    case ')': i=20;
              break;
    case ']': i=21; 
              break;         
    default:  i=-1; 
              break;
  }          
  o->optyp=i;  
  return(i);
}            
                 
int GetOperandSize(CTypdesc* pt)
{    
  if((ULONG)pt<0x1E) //Standardtyp
  {
    switch((ULONG)pt)
    {
      case T_SCHAR:          
      case T_UCHAR:
                   return(1);
                   break;
      case T_SINT:
      case T_UINT:
      case T_CODELABEL:
                   return(2);
                   break; 
      case T_SLONG:
      case T_ULONG:                        
      case T_FLOATL:
      case T_DOUBLE:
                   return(4);
                   break;
      case T_FLOATB:
                   return(8);
                   break;
    }  
  }  
  if(pt->typ==T_STRUCTDESC)     
    return(pt->size);  
  if( pt->typ==T_POINTDESC || pt->typ==T_SDCGENPOINT)
    return(3);  
  if( pt->typ==T_GENPTRDESC)
    return (pt->size/8);
  if( pt->typ==T_SPACEDPTR) 
    return(pt->size); 
  return 0;
}                 
             
int GetArraySize(CTypdesc* pt)
{
int s;
int sdim;

  s=1; 
  sdim=1; 
  while((ULONG)pt>0x1E  &&  pt->typ==T_ARRAYDESC)
  {
    sdim*=pt->elements;
    pt=pt->pref;  //durch alle Dimensionen hangeln bis der Typ des Arrays gefunden        
  }
  if((ULONG)pt<0x1E)
  {
     s=GetOperandSize(pt);          
  }
  else if(   pt->typ==T_STRUCTDESC 
          || pt->typ==T_POINTDESC
          || pt->typ==T_GENPTRDESC 
          || pt->typ==T_SPACEDPTR 
          || pt->typ==T_SDCGENPOINT)
  { 
     s=GetOperandSize(pt);         
  } 
  sdim*=s; 
  return sdim;
}
    
int ExecOperation(op_t* op1,op_t* op2,op_t* opr)
{    
CTypdesc* pt;  
CTypdesc* ptmp;
ULONG s;
ULONG memspec;

  if( *opr->op =='[')
  { 
    if(op2->optyp > T_ULONG)
      return 1;  // Float kann kein Index sein
    pt= (CTypdesc*)(op1->optyp);    
    if((ULONG)pt>0x1E && pt->typ==T_ARRAYDESC)  //nur wenn der Typ ein Array ist
    {
      if(!pt->tparent || (ULONG)pt->pref<0x20)
        pt=pt->pref; 
      else 
        pt=pt->pref->pref; // ist noch element einer Liste von Strukturelementen      
        
      if((ULONG)pt<0x1E) //Standardtyp
      { 
        s=GetOperandSize(pt);
        op1->addr= *(long*)(op1->op)+(*(long*)(op2->op) * s); 
        GetVal(op1->op,op1->addr,(int)op1->memspec,(ULONG)pt);         
        op1->optyp=(ULONG)pt; 
        return 0;  //OK                  
      }     
      if(   pt->typ==T_POINTDESC
         || pt->typ==T_GENPTRDESC
         || pt->typ==T_SPACEDPTR 
         || pt->typ==T_SDCGENPOINT)
      { 
        s=GetOperandSize(pt); //holt die Gr��e des Zeigers =1,2,3Byte 
        op1->addr= *(long*)(op1->op)+(*(long*)(op2->op) * s); //berechne die Adresse                        
        BOOL b=prc->GetPointer(&(op1->addr),(unsigned long*)(op1->op),pt,(USHORT)op1->memspec,&memspec);        
        if(!b)
          return 1; //der Zeiger l�sst sich nicht berechnen
        op1->memspec=memspec;
        op1->optyp=(ULONG)pt;
        return 0;  //OK
      }     
      else if(pt->typ==T_STRUCTDESC)
      {
        s=GetOperandSize(pt); //holt die Gr��e des Zeigers =1,2,3Byte 
        op1->addr= *(long*)(op1->op)+(*(long*)(op2->op) * s); //berechne die Adresse  
        *(long*)(op1->op)=op1->addr;
        op1->optyp=(ULONG)pt;
        return 0;  //OK
      }
      else if( pt->typ==T_ARRAYDESC ) 
      { 
        s=GetArraySize(pt);
        *(long*)(op1->op)= *(long*)(op1->op)+(*(long*)(op2->op) * s);
        op1->addr=*(long*)(op1->op);
        op1->optyp=(ULONG)pt;
        return 0;     
      }
      return 1;         
    }   
  } 
  pt=(CTypdesc*)op1->optyp;
  if((   op1->optyp > 0x1E
      && op1->flags != ISADDR 
      && pt->typ != T_POINTDESC 
      && pt->typ != T_SPACEDPTR
      && pt->typ != T_GENPTRDESC
      && pt->typ != T_SDCGENPOINT ) 
      ||(   op2->optyp > 0x1E 
         && op2->flags!= ISADDR))
      return 1;

  if(*opr->op== '+')
  { 
    if((ULONG)pt>0x1E && (   pt->typ == T_POINTDESC 
                          || pt->typ == T_GENPTRDESC 
                          || pt->typ == T_SPACEDPTR
                          || pt->typ == T_SDCGENPOINT))
    {
      ptmp=pt->pref;
      if((ULONG)ptmp < 0x1E)
      {
        s=GetOperandSize(ptmp);
        *(long*)(op1->op) += (*(long*)(op2->op) * s); 
        return 0;
      }  
      else if(   ptmp->typ==T_STRUCTDESC 
              || ptmp->typ == T_POINTDESC 
              || ptmp->typ == T_GENPTRDESC 
              || ptmp->typ == T_SPACEDPTR
              || ptmp->typ == T_SDCGENPOINT)
      {
        s=GetOperandSize(ptmp);
        *(long*)(op1->op) += (*(long*)(op2->op) * s);         
        return 0;
      }
      else if(ptmp->typ==T_ARRAYDESC)
      {
        s=GetArraySize(pt);
        *(long*)(op1->op)= *(long*)(op1->op)+(*(long*)(op2->op) * s); 
      }      
    }
    else if(op1->optyp != T_FLOATL )
      *(long*)(op1->op) += *(long*)(op2->op); 
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(float*)(op1->op) += *(long*)(op2->op);
    else 
      *(float*)(op1->op) += *(float*)(op2->op);
    return 0; 
  }  
  else if(*opr->op =='-') 
  {   
    if((ULONG)pt>0x1E && (   pt->typ == T_POINTDESC 
                          || pt->typ == T_GENPTRDESC 
                          || pt->typ == T_SPACEDPTR
                          || pt->typ == T_SDCGENPOINT))
    {
      ptmp=pt->pref;
      if((ULONG)ptmp < 0x1E)
      {
        s=GetOperandSize(ptmp);
        *(long*)(op1->op) -= (*(long*)(op2->op) * s); 
        return 0;
      }  
      else if(   ptmp->typ==T_STRUCTDESC 
              || ptmp->typ == T_POINTDESC 
              || ptmp->typ == T_GENPTRDESC 
              || ptmp->typ == T_SPACEDPTR
              || ptmp->typ == T_SDCGENPOINT)
      {
        s=GetOperandSize(ptmp);
        *(long*)(op1->op) -= (*(long*)(op2->op) * s);         
        return 0;
      }
      else if(ptmp->typ==T_ARRAYDESC)
      {
        s=GetArraySize(pt);
        *(long*)(op1->op)= *(long*)(op1->op)-(*(long*)(op2->op) * s); 
      }      
    }
    else if(op1->optyp != T_FLOATL )
      *(long*)(op1->op) -= *(long*)(op2->op); 
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(float*)(op1->op) -= *(long*)(op2->op);
    else 
      *(float*)(op1->op) -= *(float*)(op2->op);
    return 0; 
  }  
  else if(*opr->op =='*')  
  {    
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) *= *(long*)(op2->op); 
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(float*)(op1->op) *= *(long*)(op2->op);
    else
      *(float*)(op1->op) *= *(float*)(op2->op);
    return 0; 
  }
  else if(*opr->op =='/')  
  {    
    if(!(*(long*)(op2->op)))
      return(1);
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) /= *(long*)(op2->op); 
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(float*)(op1->op) /= *(long*)(op2->op);
    else
      *(float*)(op1->op) /= *(float*)(op2->op);
    return 0; 
  }  
  else if(*opr->op =='%')
  {     
    if(!(*(long*)(op2->op)))
      return(1);
    *(long*)(op1->op) %= *(long*)(op2->op); 
  }   
  else if(opr->op[0] =='<' && opr->op[1] =='<')  
  {        
    *(long*)(op1->op) = *(long*)(op1->op) << *(long*)(op2->op);    
    return 0;
  }
  else if(opr->op[0] =='<' && opr->op[1] =='=')  
  {    
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) = *(long*)(op1->op) <= *(long*)(op2->op);
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(long*)(op1->op) = *(float*)(op1->op) <= *(long*)(op2->op);
    else
      *(long*)(op1->op) = *(float*)(op1->op) <= *(float*)(op2->op);
    op1->optyp=T_BIT;
    return 0; 
  }
  else if(*opr->op =='<')  
  {     
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) = *(long*)(op1->op) < *(long*)(op2->op);
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(long*)(op1->op) = *(float*)(op1->op) < *(long*)(op2->op);
    else
      *(long*)(op1->op) = *(float*)(op1->op) < *(float*)(op2->op);
    op1->optyp=T_BIT;
    return 0; 
  }    
  else if(opr->op[0] =='>' && opr->op[1] =='>')  
  {    
    *(long*)(op1->op) = *(long*)(op1->op) >> *(long*)(op2->op);
    return 0;
  }
  else if(opr->op[0] =='>' && opr->op[1] =='=')  
  {    
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) = *(long*)(op1->op) >= *(long*)(op2->op);
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(long*)(op1->op) = *(float*)(op1->op) >= *(long*)(op2->op);
    else
      *(long*)(op1->op) = *(float*)(op1->op) >= *(float*)(op2->op);
    op1->optyp=T_ULONG;
    return 0; 
  }    
  else if(*opr->op =='>')  
  {    
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) = *(long*)(op1->op) > *(long*)(op2->op);
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(long*)(op1->op) = *(float*)(op1->op) > *(long*)(op2->op);
    else
      *(long*)(op1->op) = *(float*)(op1->op) > *(float*)(op2->op);
    op1->optyp=T_BIT;
    return 0; 
  }
  else if(opr->op[0] =='=' && opr->op[1] =='=')  
  {    
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) = *(long*)(op1->op) == *(long*)(op2->op);
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(long*)(op1->op) = *(float*)(op1->op) == *(long*)(op2->op);
    else
      *(long*)(op1->op) = *(float*)(op1->op) == *(float*)(op2->op);
    op1->optyp=T_BIT;
    return 0; 
  }         
  else if(opr->op[0] =='!' && opr->op[1] =='=')  
  {    
    if(op1->optyp != T_FLOATL)
      *(long*)(op1->op) = *(long*)(op1->op) != *(long*)(op2->op);
    else if(op1->optyp ==T_FLOATL && op2->optyp!=T_FLOATL)
      *(long*)(op1->op) = *(float*)(op1->op) != *(long*)(op2->op);
    else
      *(long*)(op1->op) = *(float*)(op1->op) != *(float*)(op2->op);
    op1->optyp=T_BIT;
    return 0; 
  }
  else if(opr->op[0] =='&' && opr->op[1] =='&')  
  {    
    *(long*)(op1->op) = *(long*)(op1->op) && *(long*)(op2->op);
    op1->optyp=T_BIT; 
    return 0;
  }  
  else if(*opr->op =='&')  
  {
    *(long*)(op1->op) = *(long*)(op1->op) & *(long*)(op2->op);    
    return 0;
  }
  else if(opr->op[0] =='|' && opr->op[1] =='|')  
  {    
    *(long*)(op1->op) = *(long*)(op1->op) || *(long*)(op2->op);
    op1->optyp=T_BIT;
    return 0;
  }  
  else if(*opr->op =='|')  
  {   
    *(long*)(op1->op) = *(long*)(op1->op) | *(long*)(op2->op);
    return 0;
  } 
  else if(*opr->op =='^')  
  {   
    *(long*)(op1->op) = *(long*)(op1->op) ^ *(long*)(op2->op);
    return 0;       
  }  
  return(1);
};        

//testet ob der string ein float sein k�nnte
BOOL IsFloat(const char* s)
{
  if( *s<0x30 || *s>0x3A && *s!='+')
    return FALSE;  //wenn schon das erste Zeichen keine Zahl oder vorzeichen ist 
  while(*s)
  {
    if(  ( *s<0x30 || *s>0x3A)
        && *s!='E' 
        && *s!='e'
        && *s!='+'
        && *s!='-'
        && *s!='.')
      return FALSE;
    s++;
  }
  return TRUE;
}
 
BOOL IsDezNum(char* s)
{
  while(*s)
  {
    if(*s<0x2F || *s>0x3A)
      return FALSE;
    s++;  
  }
  return TRUE;
} 

BOOL IsSignedDezNum(char* s)
{
  while(*s && *s=='-' || *s=='+')
    s++;
  if(*s==0)
    return FALSE;
  while(*s)
  {
    if(*s<0x2F || *s>0x3A)
      return FALSE;
    s++;  
  }
  return TRUE;
} 

BOOL IsHexNum(char* s)
{
char c;

  if(*s!='0')
    return FALSE;
  s++;  
  if(*s != 'X' && *s != 'x') 
    return FALSE;
  s++;   
  while(*s)
  {                              
    c= *s;
    if(   (c<0x2F || c>0x3A) 
       && (c<'A' || c>'F') 
       && (c<'a' || c>'f') )
      return FALSE;
    s++;  
  }
  return TRUE;
}   


              
         
     
//liefert in *v den Wert der auf addr im spezifizierten Speicher
//steht im entsprechenden Format
    
void GetVal(unsigned char* v,ULONG addr,int memspec,ULONG typ )
{   
unsigned long bitaddr;
unsigned long val;
unsigned long mask;
       
  BOOL malign=prc->GetMemAlignment();           
  switch(typ)
  {
    case T_BIT:
              if(addr<0x80)
                bitaddr=addr/8+0x20; //bit im Bereich 20-2F
              else
                bitaddr=addr & 0xF8; //sfbit
              mask= 1<<(addr & 0x07);             
              prc->GetMemFromAddr(bitaddr,&val,M_DATA);
              if(mask & val)
                *(unsigned long*)v=1;
              else
                *(unsigned long*)v=0;   
              *((unsigned long*)(v+4))=0;                
              break;
    case T_SCHAR:
    case T_UCHAR:      
              prc->GetMemFromAddr(addr,&val,memspec);        
              *(unsigned long*)v=val; 
              *((unsigned long*)(v+4))=0; 
              break; 
    case T_SINT:
    case T_UINT:  
              if(theApp.objinfo.orderHL)
              {                     
                if(malign)  // LH
                {                
                  prc->GetMemFromAddr(addr,(ULONG*)v,memspec); //LOW         
                  prc->GetMemFromAddr(addr+1,(ULONG*)(v+1),memspec); //HIGH  
                  *((USHORT*)(v+2))=0;
                  *((ULONG*)(v+4))=0;                
                } 
                else    //HL
                {
                  prc->GetMemFromAddr(addr+1,(ULONG*)v, memspec); //HIGH         
                  prc->GetMemFromAddr(addr,(ULONG*)(v+1),memspec);  //LOW
                  *((USHORT*)(v+2))=0;
                  *((ULONG*)(v+4))=0;                
                }
              }
              else
              {                     
                if(!malign)  // HL
                {                
                  prc->GetMemFromAddr(addr,(ULONG*)v,memspec); //LOW         
                  prc->GetMemFromAddr(addr+1,(ULONG*)(v+1),memspec); //HIGH  
                  *((USHORT*)(v+2))=0;
                  *((ULONG*)(v+4))=0;                
                } 
                else    //LH
                {
                  prc->GetMemFromAddr(addr+1,(ULONG*)v, memspec); //HIGH         
                  prc->GetMemFromAddr(addr,(ULONG*)(v+1),memspec);  //LOW
                  *((USHORT*)(v+2))=0;
                  *((ULONG*)(v+4))=0;                
                }
              }
              break;
    case T_SLONG:
    case T_ULONG:
              if(theApp.objinfo.orderHL)
              {
                if(malign)  // LH
                { 
                  prc->GetMemFromAddr(addr  ,(ULONG*)v  ,memspec);//LSByte         
                  prc->GetMemFromAddr(addr+1,(ULONG*)(v+1),memspec); 
                  prc->GetMemFromAddr(addr+2,(ULONG*)(v+2),memspec);         
                  prc->GetMemFromAddr(addr+3,(ULONG*)(v+3),memspec);//MSByte                               
                } 
                else    //HL
                {               
                  prc->GetMemFromAddr(addr+3,(ULONG*)v  ,memspec);//LSByte         
                  prc->GetMemFromAddr(addr+2,(ULONG*)(v+1),memspec);   
                  prc->GetMemFromAddr(addr+1,(ULONG*)(v+2),memspec);          
                  prc->GetMemFromAddr(addr  ,(ULONG*)(v+3),memspec);//MSByte
                }
              }
              else
              {
                if(!malign)  // HL
                { 
                  prc->GetMemFromAddr(addr  ,(ULONG*)v  ,memspec);//LSByte         
                  prc->GetMemFromAddr(addr+1,(ULONG*)(v+1),memspec); 
                  prc->GetMemFromAddr(addr+2,(ULONG*)(v+2),memspec);         
                  prc->GetMemFromAddr(addr+3,(ULONG*)(v+3),memspec);//MSByte                               
                } 
                else    //LH
                {               
                  prc->GetMemFromAddr(addr+3,(ULONG*)v  ,memspec);//LSByte         
                  prc->GetMemFromAddr(addr+2,(ULONG*)(v+1),memspec);   
                  prc->GetMemFromAddr(addr+1,(ULONG*)(v+2),memspec);          
                  prc->GetMemFromAddr(addr  ,(ULONG*)(v+3),memspec);//MSByte
                }  
              } 
              *((ULONG*)(v+4))=0;
              break;
    case T_FLOATL:
    case T_DOUBLE: 
              if(malign)  // LH
              { 
                prc->GetMemFromAddr(addr+3,(ULONG*)v    ,memspec);//MSByte         
                prc->GetMemFromAddr(addr+2,(ULONG*)(v+1),memspec); 
                prc->GetMemFromAddr(addr+1,(ULONG*)(v+2),memspec);         
                prc->GetMemFromAddr(addr,  (ULONG*)(v+3),memspec);//LSByte
                *((ULONG*)(v+4))=0;
              }
              else
              {
                prc->GetMemFromAddr(addr,  (ULONG*)v    ,memspec);//MSByte         
                prc->GetMemFromAddr(addr+1,(ULONG*)(v+1),memspec); 
                prc->GetMemFromAddr(addr+2,(ULONG*)(v+2),memspec);         
                prc->GetMemFromAddr(addr+3,(ULONG*)(v+3),memspec);//LSByte
                *((ULONG*)(v+4))=0;
              }
              break;
    case T_FLOATB:
              prc->GetMemFromAddr(addr+7,(ULONG*)v    ,memspec);//MSByte         
              prc->GetMemFromAddr(addr+6,(ULONG*)(v+1),memspec); 
              prc->GetMemFromAddr(addr+5,(ULONG*)(v+2),memspec);         
              prc->GetMemFromAddr(addr+4,(ULONG*)(v+3),memspec);
              prc->GetMemFromAddr(addr+3,(ULONG*)(v+4),memspec);        
              prc->GetMemFromAddr(addr+2,(ULONG*)(v+5),memspec); 
              prc->GetMemFromAddr(addr+1,(ULONG*)(v+6),memspec);         
              prc->GetMemFromAddr(addr  ,(ULONG*)(v+7),memspec);//LSByte
              break;  
    case T_CODELABEL:
    case T_UNTYPED:
              *(ULONG*)v=addr;
              break;                    
  } 
}  
 
//Der Benutzer muss lp und tp immer NULL setzen um den obersten
//Level in Strukturen zu kennzeichnen
//opname ist der volle Name des Labels bzw des Strukturelementes
//Bei der R�ckkehr aus der untersten Ebene ist, wenn return=TRUE,
//in op der Typ,der Wert,Speicherbereich und die Adresse von opname abgelegt  
BOOL GetLabelVal(LPCSTR opname, op_t* op, labeldef_t* lp)
{  
CString modname,lbl;
int modid;
int l,l1;
CString lname;    
labeldef_t* lp1;  
labeldef_t hlb;
CObjInfo* pobjinfo; 
CPtrList* ldp;
POSITION  pos; 
int offset;
ULONG typ; 
ULONG memspec;
ULONG addr;
BOOL b;
CTypdesc* tp;
CModDef* pm;
CProcDef* pp;
ULONG bitval;
ULONG v;
    
  pobjinfo=&(((CJSTEPApp*)AfxGetApp())->objinfo);
  offset=0;
  lname=opname;                                     
  if(!lp) // das ist kein Strukturelement oder wir befinden uns noch in der Wurzel
  { 
    pp=0;
    modid=-1; 
    l=lname.Find(':');
    if(l != -1)    // Modulname oder Procname ist dabei
    {       
      modname=lname.Left(l);
      modid=pobjinfo->FindModuleId(modname,&pm); 
      if(modid==-1)  //das Modul mit dem Namen gibts nicht dann suche nach einer Prozedur mit dem Namen
      {
        pm=pobjinfo->GetModuleFromAddress(prc->GetProgramCounter());
        if(!pm)
          return FALSE;
        modid=pm->ModID;  // das Modul an der aktuellen Adresse 
        pp=pobjinfo->FindProc(modname,pm);
        if(!pp)
          return FALSE; //trotz aller M�he nicht gefunden
        lname=lname.Mid(l+1); 
        goto w1;
      }
      else
        lname=lname.Mid(l+1);     
    } 
    l=lname.Find(':');  //falls sowohl 
    if(l != -1)    //  Procname ist dabei
    {       
      modname=lname.Left(l);
      lname=lname.Mid(l+1);
      pp=pobjinfo->FindProc(modname,pm);
      if(!pp)
        return FALSE; //trotz aller M�he nicht gefunden
    }
     
w1:
    l=lname.Find('.'); 
    l1= lname.Find("->");
    if(l1 < l && l1!=-1 || l==-1)    // ->kommt zuerst im Namen
      l=l1;
    if(l !=-1 && l!=l1 )  // das ist eine Struktur mit gesuchtem Element
    {      
      lbl=lname.Left(l);
      lname=lname.Mid(l+1);      
      lp1=pobjinfo->FindLabelDesc(lbl,modid,pp);      
      if(!lp1)
        return FALSE;       //die Struktur gibts nicht 
      if((ULONG)(lp1->pTypdesc)>0x1E && lp1->pTypdesc->typ!=T_STRUCTDESC)
        return FALSE;       //zum . geh�rt die Struktur
      hlb.addr=lp1->addr;  
      hlb.label=lp1->label;
      hlb.memspec=lp1->memspec; //der Speicherbereich bleibt  
      hlb.ModID=lp1->ModID;
      if((ULONG)(lp1->pTypdesc)<0x20)
        return FALSE; //ung�ltig
      hlb.pTypdesc=lp1->pTypdesc->pref; //typdesc LISTE
      hlb.pproc=lp1->pproc;
      return GetLabelVal(lname,op,&hlb);         
    }
    else if(l !=-1 && l==l1)  //das ist ein Zeiger auf eine Struktur
    {
      lbl=lname.Left(l);
      lname=lname.Mid(l+2);       
      lp1=pobjinfo->FindLabelDesc(lbl,modid); 
      if(!lp1)
        return FALSE;       //die Struktur gibts nicht 
      if((ULONG) lp1->pTypdesc <0x20)
         return FALSE;  //ung�ltiger Ausdruck      
      typ=lp1->pTypdesc->typ;  
      if(typ !=T_SPACEDPTR && typ !=T_GENPTRDESC && typ !=T_POINTDESC && typ !=T_SDCGENPOINT)
        return FALSE;   // zum -> geh�rt der Strukturpointer        
      addr=lp1->addr;
      b=prc->GetPointer(&addr,&hlb.addr,lp1->pTypdesc,(USHORT)(lp1->memspec),&memspec);
      if(b==FALSE)  
        return FALSE;  // irgendwas an dem Zeiger stimmte nicht
      hlb.label=lp1->label;
      hlb.memspec=memspec; //der Zeiger kann auf einen anderen Speicherbereich zeigen  
      hlb.ModID=lp1->ModID;
      if((ULONG)(lp1->pTypdesc->pref) < 0x1E) // der Zeiger weist auf einen Standardtyp
        return FALSE;  // Zeiger stimmt nicht
      hlb.pTypdesc=lp1->pTypdesc->pref->pref; //typdesc LISTE
      hlb.pproc=lp1->pproc;     
      return GetLabelVal(lname,op,&hlb);       
    }
    else  //das ist ein standardtyp oder ein Komplexer Typ 
    {
      lp1=pobjinfo->FindLabelDesc(lname,modid,pp); 
#ifdef _DEBUG
     if(lp1)
       pobjinfo->DebugTypdesc(lp1->pTypdesc);      
#endif
      if(!lp1)
        return FALSE;       //die Struktur gibts nicht  
      typ=(ULONG)(lp1->pTypdesc);   
      if(typ < 0x1E) //ein Standard Typ 
      {
        GetVal(op->op,lp1->addr,lp1->memspec,typ);
        op->optyp=typ; 
        op->memspec=lp1->memspec;
        op->addr=lp1->addr;
        return TRUE;
      } 
      else
      { 
        tp=(CTypdesc*)typ;       
        op->addr=lp1->addr; 
        op->optyp=typ;        
        if(tp->typ == T_POINTDESC || tp->typ==T_SPACEDPTR || tp->typ==T_GENPTRDESC)
        {
          if(op->op[0] != '&')
          {
            b=prc->GetPointer(&op->addr,(unsigned long*)(op->op),tp,(USHORT)lp1->memspec,&memspec,pobjinfo->orderHL);                                    
            op->memspec=memspec;           
            if(b==FALSE)  
              return FALSE;  // irgendwas an dem Zeiger stimmte nicht  
          }
          else  //nur die Adresse des Zeigers wird gesucht
          {
            *(unsigned long*)(op->op)=op->addr;  
            op->memspec=lp1->memspec;
          } 
          return TRUE;  
        }
        else if(tp->typ==T_SDCGENPOINT)
        {
          if(op->op[0] != '&')
          {            
            ULONG v;
            prc->GetMemFromAddr(op->addr+2,&memspec,lp1->memspec);
            prc->GetMemFromAddr(op->addr,&v,lp1->memspec);
            op->op[0]=(BYTE)v;
            prc->GetMemFromAddr(op->addr+1,&v,lp1->memspec);
            op->op[1]=(BYTE)v;
            op->op[2]=0;
            op->op[3]=0;
            op->op[4]=0;
            op->op[5]=0;
            op->op[6]=0;
            op->op[7]=0;
            switch(memspec)
            {
              case 0: 
                      if(op->op[0]<0x80)
                        memspec=lp1->memspec<<16 |DATAMEM;
                      else
                        memspec=lp1->memspec<<16 |IDATAMEM;
                      break;
              case 1: memspec=lp1->memspec<<16 |XDATAMEM;
                      break;
              case 2: memspec=lp1->memspec<<16 | CODEMEM;
                      break;
              default: return FALSE;
            }
            //b=prc->GetPointer(&op->addr,(unsigned long*)(op->op),tp,(USHORT)lp1->memspec,&memspec);          
            op->memspec=memspec;                        
          }
          else  //nur die Adresse des Zeigers wird gesucht
          {
            *(unsigned long*)(op->op)=op->addr;  
            op->memspec=lp1->memspec;
          } 
          return TRUE;  
        }
        else 
        { 
          *(unsigned long*)(op->op)=lp1->addr;
          op->memspec=lp1->memspec; //speicherbereich 
          return TRUE;
        }       
      }   
    } 
  } 
  //+++++++++++ hier kommt der rekursive Aufruf an ++++++++++++++++
  else  //wir befinden uns schon in der Struktur
  {
     if((ULONG)(lp->pTypdesc->typ) != T_LISTDESC)  
       return FALSE; //hier stimmt was nicht unter der Struktur muss immer eine Liste kommen 
     l=lname.Find('.'); 
     l1= lname.Find("->");
     if(l1 < l && l1!=-1 || l==-1)    // ->kommt zuerst im Namen
       l=l1;  
     if(l==-1) //die Struktur ist hier zu Ende und es ist ein Standardtyp oder ein Komplexer Typ
     { 
       ldp = lp->pTypdesc->pmem;  //die Liste der Strukturelemente
       pos=ldp->GetHeadPosition();   
       while(pos)
       {     
         tp=(CTypdesc*)ldp->GetNext(pos);    
         if(*(tp->pname)==lname)    //das Element ist gefunden
         {
           offset=tp->offset;  //den offset zum Anfang der Struktur berechnen
             

           if((ULONG)tp->typ > 0x1E) //kein Standardtyp  
           {                          
             op->addr=lp->addr+offset;   
             op->optyp=(ULONG)tp;
             if(   tp->typ==T_POINTDESC 
                || tp->typ==T_SPACEDPTR 
                || tp->typ==T_GENPTRDESC 
                || tp->typ==T_SDCGENPOINT)
             {
               if(((ULONG)(tp->pref))>0x1E && tp->pref->typ==tp->typ) // der Pointer ist element einer Liste
                 tp=tp->pref;
               if(op->op[0] != '&')
               {
                 b=prc->GetPointer(&(op->addr),(unsigned long*)(op->op),tp,(USHORT)lp->memspec,&memspec);
                 op->memspec=memspec;
                 if(b==FALSE)  
                   return FALSE;  // irgendwas an dem Zeiger stimmte nicht  
               }
               else
               {
                 *(unsigned long*)(op->op)=op->addr; // liefere die Adresse
                 op->memspec=lp->memspec; //speicherbereich   
                 return TRUE;  
               }
             }  
			       else if(tp->typ==T_BITARRDESC)
             {
               bitval=0;
			         if(tp->pref->typ == tp->typ) // das Array ist Element einer Liste
                 tp=tp->pref;			         
			         if(tp->size==1) //ein einzelnes Bit
               {             
                 if(!tp->elements)  //Basis ist char
			             GetVal((unsigned char*)&bitval,lp->addr,lp->memspec,T_UCHAR);
			           else if(tp->elements==1)  //Basis ist short
                   GetVal((unsigned char*)&bitval,lp->addr,lp->memspec,T_UINT);                
			           bitval &= (1 <<tp->offset);
			           if(bitval)
                   *(unsigned long*)(op->op)=1;
			           else
                   *(unsigned long*)(op->op)=0;
                 op->optyp=(ULONG)tp;
			           op->memspec=lp->memspec; //speicherbereich
               }
			         else  // mehrere Bits
               {
                 l=tp->size;				 
                 while(l--)
                   bitval=(bitval<<1) | 0x01;  
                 bitval = bitval << tp->offset;
				         if(!tp->elements)  //Basis ist char                 
			             GetVal((unsigned char*)&v,lp->addr,lp->memspec,T_UCHAR);
			           else if(tp->elements==1)  //Basis ist short
                    GetVal((unsigned char*)&v,lp->addr,lp->memspec,T_UINT);				 
                 *(unsigned long*)(op->op)=(v & bitval)>>tp->offset; 				 
			           op->memspec=lp->memspec; //speicherbereich
				         op->optyp=(ULONG)tp;
               }
             }              
             else 
             { 
               *(unsigned long*)(op->op)=op->addr; // liefere die Adresse
               op->memspec=lp->memspec; //speicherbereich 
               return TRUE;
             }                      
           }  
           else           
           {             
             op->optyp=tp->typ;   //der Typ des gesuchten Elements  
             op->memspec=lp->memspec; //der Speicherbereich
             op->addr=lp->addr+offset;          
             GetVal(op->op,op->addr,lp->memspec,tp->typ); //jetzt hole den echten Wert             
           }  
           return TRUE;
         }  
       } 
       return FALSE;
     }
     else if(l !=-1  &&  l1!=l )  // das ist eine unterstukturierte Struktur mit gesuchtem Element
     {
       lbl=lname.Left(l);     //das ist das Element
       lname=lname.Mid(l+1);  // und das der Rest 
       ldp = lp->pTypdesc->pmem;  //die Liste der Strukurelemente
       pos=ldp->GetHeadPosition();   
       while(pos)
       {     
         tp=(CTypdesc*)ldp->GetNext(pos);    
         if(*(tp->pname)==lbl)    //das Element ist gefunden
         {
           offset=tp->offset;  //den Offset zum Anfang der Struktur berechnen            
           if(tp->typ!=T_STRUCTDESC)
              return FALSE;       //zum . geh�rt die Struktur  
           hlb.addr=lp->addr+offset;  
           //hlb.label=lp->label;
           hlb.memspec=lp->memspec; 
           hlb.ModID=lp->ModID;
           hlb.pTypdesc=tp->pref->pref; //typdesc LISTE
           hlb.pproc=lp->pproc;       
           return GetLabelVal(lname,op,&hlb);           
         }  
       }
       return FALSE;    
     }
     else  //das element ist ein Zeiger auf eine Struktur
     {
       lbl=lname.Left(l);
       lname=lname.Mid(l+2);      
       ldp = lp->pTypdesc->pmem;  //die Liste der Strukurelemente
       pos=ldp->GetHeadPosition();   
       while(pos)
       {     
         tp=(CTypdesc*)ldp->GetNext(pos);    
         if(*(tp->pname)==lbl)    //das Element ist gefunden
         {
           offset=tp->offset;  //den Offset zum Anfang der Struktur berechnen            
           if(tp->typ !=T_SPACEDPTR && tp->typ !=T_GENPTRDESC && tp->typ !=T_POINTDESC && tp->typ !=T_SDCGENPOINT)
             return FALSE;   // zum -> geh�rt der Strukturpointer        
           addr=lp->addr+offset;
           b=prc->GetPointer(&addr,&hlb.addr,tp->pref,(USHORT)lp->memspec,&memspec);
           if(b==FALSE)  
             return FALSE;  // irgendwas an dem Zeiger stimmte nicht
           offset=0; //es geht ab pointeradresse neu los  
           hlb.memspec=memspec; //der Zeiger kann auf einen anderen Speicherbereich zeigen  
           hlb.pTypdesc=tp->pref->pref->pref; //typdesc listelement->pointertyp->struktdesc->LISTE
           hlb.pproc=lp->pproc;
           return GetLabelVal(lname,op,&hlb);
         }
       }  
       return FALSE;
     }       
  }     
}                                                                          
  
  
int GetOperandVal(char* opname,op_t* o)    
{
long v;
char c;  
char* cp;
char* ov;
char* hp;  
op_t opn;
CTypdesc* pt;

  //nur zum test 
  // alle Werte sind mal long 
  ov=(char*)o->op;
  o->optyp=0;
  v=0;
  c=0;
  cp=&c;
  if(*opname == 's')
  {
    if(!(strnicmp(opname,"sizeof",6))) 
    {  
      if( opname[6] =='(' )
        hp=opname+7;
      else
        hp=opname+6;
      if(!GetLabelVal(hp,&opn,0))
        return FALSE;
      pt=(CTypdesc*)opn.optyp;
      if(opn.optyp<0x1E)
      {
        v=GetOperandSize(pt);
      }
      else if(   pt->typ==T_STRUCTDESC
              || pt->typ==T_SPACEDPTR
              || pt->typ==T_POINTDESC
              || pt->typ==T_GENPTRDESC
              || pt->typ==T_SDCGENPOINT)  
      {
        v=GetOperandSize(pt);  
      }
      else if( pt->typ==T_ARRAYDESC)
      {
        v=1;
        if(pt->typ==T_ARRAYDESC && !pt->elements) //das Array ist Teil einer Liste
          pt=pt->pref;           
        while((ULONG)pt > 0x1E && pt->typ==T_ARRAYDESC)
        {
          v*=pt->elements; 
          pt=pt->pref;
        }
        v*=GetOperandSize(pt);  
      }      
    } 
    else
    {
      if(GetLabelVal(opname,o,0))
        v=*(unsigned long*)o->op;
      else
        return FALSE;   
    }  
  }
  else
  {
    cp=&c;       
    if(IsHexNum(opname))
    {
      if(*(opname+2)<'8')
        v=strtol(opname+2,&cp,16);
      else
        v=strtoul(opname+2,&cp,16);
    }
    else if(IsDezNum(opname))
    {
      v=strtol(opname,&cp,10);          
    }
    else   
    {        
      if(IsFloat(LPCSTR(opname)))
      {
        sscanf(LPCSTR(opname),"%f",(float*)&v);
        *(long*)ov=v;
        o->optyp=T_FLOATL;
        return TRUE;
      }
      else if(GetLabelVal(opname,o,0))
        v=*(unsigned long*)o->op; 
      else        
        return FALSE;
    }     
  }  
  *(long*)ov=v;
  return TRUE; // is ok
}

BOOL GetContens(char* op, long* val)
{
  if(*op=='*')
  {
    if(!GetContens(op+1,val))
      return 0;  
    //*(unsigned long*)val=GetValFromAddr(val,memspec);
    return 1;   
  }
  else
  {
    //*(unsigned long*)val=GetValFromAddr(val,memspec); 
    return 1; 
  }
}
 
//Bildet das Einer-Komplement einer Zahl
BOOL BuildKomplement(unsigned long* pval,unsigned long valtyp)
{
UCHAR  vc;
USHORT vs;

  if(valtyp == T_UNTYPED) //suche die passende Gr��e selbst
  {
    if(*pval <= 0xFF)
       valtyp=T_UCHAR;
    else if(*pval <= 0xFFFF)
       valtyp=T_UINT;
    else
       valtyp=T_ULONG;
  }
  switch(valtyp)
  {    
    case T_SCHAR:
    case T_UCHAR:
                  vc= *(unsigned char*) pval;
                  vc=(UCHAR)~vc;
                  *(unsigned char*)pval=vc;
                  break;
    case T_SINT:
    case T_UINT:
                  vs=*(unsigned short*) pval;
                  vs=(UCHAR)~vs;
                  *(unsigned short*) pval=vs;
                  break; 
    case T_SLONG:
    case T_ULONG:
    case T_FLOATL:    
                  *pval=~*pval;                  
                  break;
    default:      return FALSE;
                  break;
  }
  return TRUE;
}
                        