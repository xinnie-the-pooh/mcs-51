// HListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "JSTEP.h"
#include "HListCtrl.h"
#include "proc.h"
#include "objinfo.h"
#include "globals.h"
#include "MainFrm.h"
#include "ChangeTyp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHListCtrl

CHListCtrl::CHListCtrl()
{
  lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier");   

  imageList.Create(IDB_HIERACH,16,1,RGB(255,255,255));
  viewmode=V_HEX;
  obext=TRUE;
  delItem=-1;
  ContextEn=FALSE;
}

CHListCtrl::~CHListCtrl()
{
  
}


BEGIN_MESSAGE_MAP(CHListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CHListCtrl)
	ON_WM_LBUTTONDOWN()
  ON_MESSAGE(UM_ENTER,OnEditReturn)
	ON_WM_DESTROY()
	ON_WM_RBUTTONDOWN()
  ON_COMMAND(IDM_DEZ,OnDez)
  ON_COMMAND(IDM_HEX,OnHex) 
  ON_COMMAND(IDM_BIN,OnBin)	
  ON_COMMAND(ID_FLOAT,OnFloat)
  ON_COMMAND(ID_DOCK,OnDock)
  ON_COMMAND(ID_DELETEWATCH,OnDelWatch)
  ON_COMMAND(ID_CHANGETO,OnChangeWatch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHListCtrl message handlers

#define DEFAULT_TEXTDRAW  DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER
#define TEXTOFFSET 2

void CHListCtrl::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
int item;
int image;
int rl,l;
CDC* pDC;
CRect rcItem;
CPen* oldPen;
CBrush* oldbrush;
RECT rc;
item_t* pi;
item_t* ppi;
char szBuff[100];
CImageList* pImageList;
CTypdesc* pt;


  GetClientRect(&rc);   
  rcItem=lpDrawItemStruct->rcItem;
  rcItem.left+=TEXTOFFSET;
	item=lpDrawItemStruct->itemID;	
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
  CFont* oldfont=pDC->SelectObject(&lfont);
  CPen dotpen(PS_DOT,1,(COLORREF)0xC0C0C0L); 

  oldPen=(CPen*)pDC->SelectObject(&bkpen);
  pDC->MoveTo(rcItem.left,rcItem.bottom);
  pDC->LineTo(rcItem.right,rcItem.bottom);
  pDC->MoveTo(rcItem.left,rcItem.top);
  pDC->LineTo(rcItem.right,rcItem.top);

  pDC->SelectObject(&dotpen);
  pDC->MoveTo(rcItem.left,rcItem.bottom);
  pDC->LineTo(rcItem.right,rcItem.bottom);
  pDC->MoveTo(rcItem.left,rcItem.top);
  pDC->LineTo(rcItem.right,rcItem.top);
  int c0=GetColumnWidth(0);
  pDC->MoveTo(c0,rcItem.top);
  pDC->LineTo(c0,rcItem.bottom);
  pi=(item_t*)GetItemData(item);  
  pt=(CTypdesc*)(pi->wtyp.optyp);
  // Draw Text Column 0
  GetItemText(item,0,szBuff,sizeof(szBuff));
  rcItem.left+=TEXTOFFSET;
  pImageList=GetImageList(LVSIL_SMALL);
  if(!pi->level)  // oberste Ebene
  {           
    ImageList_Draw(pImageList->m_hImageList
		    	           ,pi->image   //normal Icon 
			    				   ,pDC->m_hDC
				    				 ,rcItem.left
					    			 ,rcItem.top+1
						    		 ,ILD_NORMAL);
  }
  else
  {
    if(!pi->last)
      image=B_SUBLINE;
    else
      image=B_LINEEND;     
    ImageList_Draw(pImageList->m_hImageList
		   	           ,image   //normal Icon 
		    				   ,pDC->m_hDC
			    				 ,rcItem.left+16*(pi->level -1)
				    			 ,rcItem.top+1
					    		 ,ILD_NORMAL);


    l=pi->level-1;
    rl=rcItem.left;
    if(item==5) 
      int x=0;
    ppi=pi;
    while(l--)
    {
      ppi=(item_t*)ppi->pparent;
      if(!ppi->last)
        image=B_LINE;
      else
        image=B_EMPTY;
      
      ImageList_Draw(pImageList->m_hImageList
		     	           ,image   //normal Icon 
			    				   ,pDC->m_hDC
				    				 ,rl+16*l
					    			 ,rcItem.top+1
						    		 ,ILD_NORMAL);
    }
    rcItem.left+=16*pi->level;
    ImageList_Draw(pImageList->m_hImageList
		    	           ,pi->image   //normal Icon 
			    				   ,pDC->m_hDC
				    				 ,rcItem.left
					    			 ,rcItem.top+1
						    		 ,ILD_NORMAL);
    
  } 
  rcItem.left+=18;
  l=rcItem.right;
  rcItem.right=c0;
	pDC->DrawText(szBuff,-1,rcItem,DEFAULT_TEXTDRAW);
  pDC->SelectObject(oldPen);
  rcItem.right=l;


  //Draw SubItem 1
  if(edit.act==item && edit.act && (edit.GetStyle() & WS_VISIBLE))
  {  //Der Variablenname wird gerade editiert
    oldbrush=(CBrush*)pDC->SelectStockObject(BLACK_BRUSH);
    pDC->Rectangle(c0,rcItem.top,c0+GetColumnWidth(1),rcItem.bottom);
    pDC->SelectObject(oldbrush);
  }
  else
  {
    rcItem.left=c0+TEXTOFFSET;
    GetItemText(item,1,szBuff,sizeof(szBuff));
    if(pi->changed)
      pDC->SetTextColor(0x0000FF); //rot        
	  pDC->DrawText(szBuff,-1,rcItem,DEFAULT_TEXTDRAW);
    pDC->SelectObject(oldPen);
    pDC->SetTextColor(0); //wieder schwarz 
  }
}


void CHListCtrl::Create()
{
LV_COLUMN lvc;
RECT rc;
  
  bkpen.CreatePen(PS_SOLID,1,GetBkColor());
  SetImageList(&imageList,LVSIL_SMALL); 
  edit.Create(WS_CHILD|WS_BORDER|WS_OVERLAPPED|ES_NOHIDESEL
              |ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL,rc,this,0);
  edit.SetFont(&lfont,FALSE);	
  
  CClientDC dc(this);
  dc.GetOutputCharWidth('0','0',&fwidth);
  edit.act=-1;
  // zuerst alle Spalten anlegen
  
  GetClientRect(&rc);
  lvc.cx=130;
  lvc.mask=LVCF_WIDTH|LVCF_TEXT;
  lvc.pszText="Watch Variable";
  lvc.iSubItem=0;
  InsertColumn(0,&lvc);  //Spalte 0
#ifdef _DEUTSCH
  lvc.pszText="Wert";
#else
  lvc.pszText="Value";
#endif
  lvc.cx=rc.right-lvc.cx;
  lvc.iSubItem=1;
  InsertColumn(1,&lvc);  //Spalte 1
  AddWatch("");
}


//f�gt einen neuen Eintrag an die Liste an
int CHListCtrl::AddWatch(LPCSTR txt,int item)
{
int newitem;

  if(*txt==0)
    txt=" ";
  if(item==-1)
    item=GetItemCount();
  newitem=InsertItem(item,txt,B_EMPTY);
  SetItemText(item,1," ");
  item_t* pi=new item_t;
  pi->IsAddr=FALSE;
  pi->wtyp.optyp=0;
  pi->level=0;
  pi->last=0;
  pi->pparent=0;
  pi->editable[0]=TRUE;
  pi->editable[1]=FALSE;
  pi->changed=FALSE;
  pi->image=B_EMPTY;
  pi->vtyp=viewmode;
  SetItemData(newitem,(ULONG)pi);      
  return newitem;
}

//l�scht einem Eintrag
BOOL CHListCtrl::DeleteItem(int iItem)
{
  if(iItem >= GetItemCount() || iItem==-1)
    return FALSE;
  delete (item_t*)GetItemData(iItem);
  return  CListCtrl::DeleteItem(iItem); 
}




BOOL CHListCtrl::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
HD_NOTIFY* p;	
RECT rc;
int cxy;


  p=((HD_NOTIFY*)lParam);
  if(p->hdr.code==HDN_ENDTRACK)
  { 
    GetClientRect(&rc);    
    cxy=rc.right - p->pitem->cxy;
    SetColumnWidth(1,cxy);
    edit.ShowWindow(SW_HIDE);
  }    
	return CListCtrl::OnNotify(wParam, lParam, pResult);
}


// liefert zu einem Punkt das zugeh�rige Rechteck ,Index und SubIndex
BOOL CHListCtrl::GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc)
{
BOOL b;
int ncol;
int w;
LV_COLUMN lvc;
int x;

  
  UINT flags=LVHT_ONITEM |LVHT_TORIGHT ;
  lvi->iItem=HitTest(point,&flags);  //finde den Index des Items zum Punkt
	GetItemRect(lvi->iItem,rc,LVIR_LABEL);
  x=point.x;
  point.x=rc->left;
  if( lvi->iItem == -1) //item nicht gefunden
	  return FALSE;	
	lvc.mask=LVCF_WIDTH ;
	ncol=0;
	w=0;
  do
	{
    b=GetColumn(ncol,&lvc);
		if(b)                 
    {
			rc->left=w;
      w+=lvc.cx;
			if(x <=w)
      {   // die Spalte haben wir gesucht        
				rc->right=w;
				lvi->iSubItem=ncol;
				return TRUE;
      }
    } 
		ncol++;
	}while(b);
	return FALSE;
}

void CHListCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
LV_ITEM lvi;
RECT rc;
CString txt; 
item_t* pi; 
CTypdesc* pt;
int image;
int r,l;

  GetItemRectFromPoint(point,&lvi,&rc);
//  if(edit.act != -1 && edit.actsub != -1)  
//    edit.GetWindowText(txt);  
  if(lvi.iItem == -1)
  {
    edit.ShowWindow(SW_HIDE);
    if(edit.act != -1)
    {
      RedrawItems(edit.act,edit.act);    
    }
    return;
  }  
  pi=(item_t*)GetItemData(lvi.iItem);
  if( pi->image > B_LINEEND  && !lvi.iSubItem )  //kein Standardtyp also nicht editierbar
  {                                            // jetzt wird ein Baum aufgeklappt  
    //test ob Zeiger auf Icon
    l=pi->level*16;
    r=l+16;
    if(point.x < r && point.x > l)
    {
      edit.ShowWindow(SW_HIDE);           
      pt=(CTypdesc*)pi->wtyp.optyp;
      if(!pt)
        return;

      switch(pt->typ)
      {
        case T_ARRAYDESC: 
                        image=pi->image;
                        if(image==B_ROOT) 
                          pi->image=B_SUB;
                        else if(image==B_SUBROOT)
                          pi->image=B_SUBOPEN;
                        if(image==B_SUBROOT || image==B_ROOT)
                          OpenArray(lvi.iItem,pi);
                        else if(image==B_SUB || image==B_SUBOPEN)
                          CloseTree(lvi.iItem,pi);
                        break;
        case T_STRUCTDESC:image=pi->image;
                        if(image==B_ROOT) 
                          pi->image=B_SUB;
                        else if(image==B_SUBROOT)
                          pi->image=B_SUBOPEN;
                        if(image==B_SUBROOT || image==B_ROOT)
                          OpenStruct(lvi.iItem,pi);
                        else if(image==B_SUB || image==B_SUBOPEN)
                          CloseTree(lvi.iItem,pi);
                        Update(lvi.iItem);
                        break;
        case T_POINTDESC:
        case T_GENPTRDESC:
        case T_SPACEDPTR:
        case T_SDCGENPOINT:
                        image=pi->image;
                        if(image==B_ROOT) 
                          pi->image=B_SUB;
                        else if(image==B_SUBROOT)
                          pi->image=B_SUBOPEN;
                        if(image==B_SUBROOT || image==B_ROOT)
                          FollowPointer(lvi.iItem,pi);
                        else if(image==B_SUB || image==B_SUBOPEN)
                          CloseTree(lvi.iItem,pi);
                        Update(lvi.iItem);
                        break;            
      }
      return;
    }
    else if(!pi->level && pi->editable[0])
    {
      if(!obext)
        SetUCase(TRUE);           
      edit.SetWindowPos(&wndTop,
	                    rc.left,
                        rc.top,
			      		rc.right,
				      	rc.bottom-rc.top,
					    SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);
      
      txt=GetItemText(lvi.iItem,lvi.iSubItem);
      edit.SetWindowText(txt);  
      edit.Invalidate(FALSE);
      edit.ShowWindow(SW_SHOW);
      edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols    
      edit.SetFocus();             
      CDC* pDC=GetDC();
 	    CBrush* oldbrush=(CBrush*)pDC->SelectStockObject(BLACK_BRUSH);
      pDC->Rectangle(rc.right,rc.top,rc.right+GetColumnWidth(1),rc.bottom);
      pDC->SelectObject(oldbrush);
      RedrawItems(edit.act,edit.act);
      edit.act=lvi.iItem;
      edit.actsub=lvi.iSubItem; 
    }
  }

  else  //in die 2. Spalte geklickt oder Standardtyp
  {
    if(!obext)
    {
      if(lvi.iSubItem)
        SetUCase(FALSE);
      else 
        SetUCase(TRUE);
    }
    pt=(CTypdesc*)(pi->wtyp.optyp);
    if(pi->editable[lvi.iSubItem])      
    {
      edit.SetWindowPos(&wndTop,
                        rc.left,
                        rc.top,
                        rc.right,
                        rc.bottom-rc.top,
                        SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
      txt=GetItemText(lvi.iItem,lvi.iSubItem);
      if((ULONG)pt > 0x1E && pt->typ != T_BITARRDESC && !pi->IsAddr ) // dann muss es ein Zeiger sein sonst k�nnen nur Standardtypen editiert werden
        edit.SetWindowText(txt.Mid(5)); 
      else if((ULONG)pt != T_SCHAR)
        edit.SetWindowText(txt);  
      else    
      { 
        txt.TrimLeft();
        l=txt.Find(" ");
        if(l!=-1)
          edit.SetWindowText(txt.Left(txt.Find(" ")));        
        else
          edit.SetWindowText(txt);
      }
      edit.Invalidate(FALSE);
      edit.ShowWindow(SW_SHOW);
     // edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols    
      edit.SetFocus(); 
      RedrawItems(edit.act,edit.act);
      edit.act=lvi.iItem;
      edit.actsub=lvi.iSubItem; 
      CDC* pDC=GetDC();
 	    CBrush* oldbrush=(CBrush*)pDC->SelectStockObject(BLACK_BRUSH);
      pDC->Rectangle(rc.right,rc.top,rc.right+GetColumnWidth(1),rc.bottom);
      pDC->SelectObject(oldbrush);
    }
    else
    {
      edit.ShowWindow(SW_HIDE);
      RedrawItems(edit.act,edit.act);
    }
  }
}

void CHListCtrl::OnDelWatch()
{
  CloseTree(delItem,(item_t*)GetItemData(delItem));
  DeleteItem(delItem);
  delItem=-1;
  UpdateWatchWnd(FALSE);
}

void CHListCtrl::OnChangeWatch()
{
labeldef_t* pl;
  item_t* pi=(item_t*)GetItemData(delItem);
  if(pi->subname.Right(1)==".")
  { 
	CString tmptxt;
	tmptxt=pi->subname.Left(pi->subname.GetLength()-1);
	pl=theApp.objinfo.FindLabel(&tmptxt);
  }	 
  else
    pl=theApp.objinfo.FindLabel(&pi->subname);
  if(!pl)
	return;
  if(pl->memspec & PDATAMEM)
  {    
    pl->memspec=XDATAMEM;
  }
  else if(pl->memspec & XDATAMEM)
  {
    pl->memspec=PDATAMEM;
  }
   delItem=-1;
  ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches();
}


long CHListCtrl::OnEditReturn(UINT wparam, LONG lparam)
{
char wtxt[200];
char buff[200];
CString txt;
eval_t r; 
int x,l;
ULONG bitval; 
item_t* pi;
CTypdesc* pt;
conv_t newval,oldval; 
ULONG memspec;

   edit.GetWindowText(wtxt,sizeof(wtxt));
   edit.ShowWindow(SW_HIDE);
   
   int icnt=GetItemCount();
   if(!edit.actsub)
   {
     SetItemText(edit.act,0,wtxt);
     if(!strlen(wtxt) && icnt > 1)
     {
       pi=(item_t*)GetItemData(edit.act);
       pt=(CTypdesc*)pi->wtyp.optyp;
       if(pi->image==B_SUB || pi->image==B_SUBOPEN)
         CloseTree(edit.act,pi);                        
       if( edit.act!=icnt-1 )
         DeleteItem(edit.act);
       return (0);
     }
     if(!strlen(wtxt) && edit.act==icnt-1)
     {     
       return (0);
     }
     pi=(item_t*)GetItemData(edit.act);
		 pi->IsAddr=0;
     if(pi->image==B_SUB || pi->image==B_SUBOPEN)
       CloseTree(edit.act,pi);     
     r.expression=wtxt; 		 
     *(long*)r.lastop.op=0;
     x=Evaluate(&r);
     pi=(item_t*)GetItemData(edit.act);
     if(x)   //Ausdruck kann nicht berechnet werden
     {
       SetItemText(edit.act,1,"illegal expression");
       pi->image=B_ERROR;     
       pi->subname=wtxt;
       pi->editable[1]=FALSE;       
     }
     else
     {       
       pi->wtyp=r.retval; 
       pi->changed=FALSE;
       pt=(CTypdesc*)(r.retval.optyp);
       pi->subname=wtxt;       
       if((ULONG)pt>0x1E) 
       {
         if(pt->typ==T_STRUCTDESC)
           pi->subname += ".";
         else if(pt->typ==T_POINTDESC || pt->typ==T_SPACEDPTR || pt->typ==T_GENPTRDESC || pt->typ==T_SDCGENPOINT)
         {
           //if((ULONG)(pt->pref)>0x1E)  
           //  pi->subname += "->";      
           pi->editable[1]=TRUE;
         }
		     else if(pt->typ==T_BITARRDESC)
         {
           pi->editable[1]=TRUE;
         }  
       }
       else if((ULONG)pt!=T_CODELABEL && (ULONG)pt!=T_UNTYPED)
         pi->editable[1]=TRUE;
       if(r.retval.flags==ISADDR)
       {
         pi->subname=pi->subname.Mid(1); //das "&" entfernen        
         pi->IsAddr=TRUE;
         pi->editable[1]=FALSE;
       }
       if(r.lastop.op[0]=='~')
       {
         pi->editable[1]=FALSE;
       }
       GetWatchValString(wtxt,&r,sizeof(wtxt),viewmode);              
       SetItemText(edit.act,1,wtxt);
       if(r.retval.optyp >0x1E && pt->typ != T_BITARRDESC && !pi->IsAddr) // kein Standardtyp
         pi->image=B_ROOT;
       else
         pi->image=B_EMPTY;   
     } 
     
     RedrawItems(edit.act,edit.act);
     if(edit.act==icnt-1) //nur wenn der Eintrag neu ist
       AddWatch("");      //wird eine Zeile angef�gt   
   }
   else
   {
      //Wert �ndern 
       if(IsHexNum(wtxt))
         newval.l=strtoul(wtxt,0,16);
       else if(IsDezNum(wtxt))
         newval.l=strtoul(wtxt,0,10);
       else if(IsSignedDezNum(wtxt))
         newval.l=strtol(wtxt,0,10);
       else if(wtxt[strlen(wtxt)-1]=='B') //bin�r
         newval.l=strtoul(wtxt,NULL,2);       
       pi=(item_t*)GetItemData(edit.act);       
       strcpy(buff,LPCSTR(pi->subname));
       x=strlen(buff);
    //   if(buff[x-1]=='>')  //wenn es ein Zeiger ist dann das "->" abschneiden
    //     buff[x-2]=0;
       r.expression=buff; 
       *(long*)r.lastop.op=0;
       x=Evaluate(&r);
       if(!x)
       {         
         pt=(CTypdesc*)(r.retval.optyp);
         
         if((ULONG)pt > 0x1E && 
            (   pt->typ==T_SPACEDPTR
             || pt->typ==T_GENPTRDESC)) // das kann nur ein Zeiger sein ,alle anderen Typen sind nicht editierbar
         {
           if((ULONG)(pt->pref) >0x1E && pt->pref->typ ==pt->typ)
             pt=pt->pref;  //der Zeiger ist Element einer Liste
           memspec=(r.retval.memspec >> 0x10) & 0xFF00;
           switch(pt->offset)
           {
             case MS_DATA:
             case MS_IDATA:
             case MS_PDATA:                                      
                  prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec);     
                  break;
             case MS_CODE:
             case MS_XDATA:
                  if(!prc->GetMemAlignment())
                  {
                    prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[1],memspec);
                    prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[0],memspec);
                  }
                  else
                  {
                    prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],memspec);
                    prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],memspec);
                  }
                  break;             
             default:
                  if(!prc->GetMemAlignment())
                  {
                    prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[3],memspec);
                    prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[2],memspec);
                    prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[1],memspec);
                    prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[0],memspec);
                  }
                  else
                  {
                    prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],memspec);
                    prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],memspec);
                    prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[2],memspec);
                    prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[3],memspec);
                  }
                  break;  
		   }
		   ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches();
           return 0;
     }
		 else if ((ULONG)pt>0x1E && pt->typ== T_BITARRDESC)
     {
		   memspec=r.retval.memspec;		   		   
		   if(pt->size ==1) //ein einfaches Bit
       {
				 txt=wtxt;
		     txt.TrimRight();
		     txt.TrimLeft();				 
		     txt.MakeUpper();
				 if(!pt->elements) //Basis ist char
         {
           prc->GetMemFromAddr(r.retval.addr,(ULONG*)&newval.l,memspec);
           if(txt == "FALSE" || txt=="0")
		       {	             
			       newval.c[0] &= ~(1<<pt->offset);  
			       prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec);               
           }
		       else if(txt == "TRUE" || txt=="1")
           {
             newval.c[0] |= 1<<pt->offset;
             prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec);
           }
         }
				 else if(pt->elements==1) // Basis ist int
         {
           GetVal((UCHAR*)&newval.l,r.retval.addr,memspec,T_UINT);
           if(txt == "FALSE" || txt=="0")
		       {	             
			       newval.s[0] &= ~(1<<pt->offset); 
             if(!prc->GetMemAlignment())
             {
			         prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[1],memspec); 
						   prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[0],memspec);
             }
             else
             {
               prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec); 
						   prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],memspec);
             }
           }
		       else if(txt == "TRUE" || txt=="1")
           {
             newval.s[0] |= 1<<pt->offset;             
             if(!prc->GetMemAlignment())
             {
			         prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[1],memspec); 
						   prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[0],memspec);
             }
             else
             {
               prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec); 
						   prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],memspec);
             }
           }
         }
		   }
		   else
       {
         l=pt->size;
			   bitval=0;
			   while(l--)
           bitval=(bitval<<1)|0x01;
				 bitval=bitval <<pt->offset; 
         newval.l=newval.l<<pt->offset;
			   newval.l &=bitval;
			   if(!pt->elements) //Basis ist char
         {
           prc->GetMemFromAddr( r.retval.addr,(ULONG*)&oldval.c[0],memspec);
           oldval.c[0] &=~bitval; 
			     newval.l|=oldval.l;
           prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec);
         }
         else if(pt->elements==1) //Basis ist short
			   {
					 GetVal((UCHAR*)&oldval.l,r.retval.addr,memspec,T_UINT);   
           oldval.s[0] &=~bitval; 
			     newval.l|=oldval.l;
					 if(!prc->GetMemAlignment())
           {
             prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[1],memspec);
             prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[0],memspec);
           }
					 else
           {
             prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],memspec);
             prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],memspec);
           }
         }
       }
		   ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches();
       return 0;
     }
         
     ULONG bitaddr;
     BYTE mask;
     switch((ULONG)pt)
     {
		   case T_BIT:
			      memspec=r.retval.memspec;			      
		        txt=wtxt;
		        txt.TrimRight();
		        txt.TrimLeft();
		        txt.MakeUpper();
            if(r.retval.addr<0x80)
              bitaddr=r.retval.addr/8+0x20; //bit im Bereich 20-2F
            else
              bitaddr=r.retval.addr & 0xF8; //sfbit
            mask= 1<<(r.retval.addr & 0x07);   
            prc->GetMemFromAddr( bitaddr,(ULONG*)&newval.c[0],memspec);
            if(txt == "FALSE" || txt=="0")
		        {	             
			        newval.c[0]&=~mask;  
			        prc->SetMemAtAddr( bitaddr,(ULONG*)&newval.c[0],memspec);               
            }
		        else if(txt == "TRUE" || txt=="1")
            {
              newval.c[0]|=mask;
              prc->SetMemAtAddr( bitaddr,(ULONG*)&newval.c[0],memspec);
            } 
            break;
       case T_SCHAR:
       case T_UCHAR:                
            prc->SetMemAtAddr( r.retval.addr,(ULONG*)&newval.c[0],r.retval.memspec);
            break;
       case T_SINT:
       case T_UINT:    
            if(theApp.objinfo.orderHL)
            {
              if(!prc->GetMemAlignment())
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[1],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[0],r.retval.memspec);
              }
              else
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],r.retval.memspec);
              }
            }
            else
            {
              if(prc->GetMemAlignment())
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[1],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[0],r.retval.memspec);
              }
              else
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],r.retval.memspec);
              }
            }
            break;
       case T_SLONG:
       case T_ULONG:  
            if(theApp.objinfo.orderHL)
            {  
              if(!prc->GetMemAlignment())
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[3],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[2],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[1],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[0],r.retval.memspec);
              }
              else
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[2],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[3],r.retval.memspec);
              }
            }
            else
            {  
              if(prc->GetMemAlignment())
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[3],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[2],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[1],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[0],r.retval.memspec);
              }
              else
              {
                prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[2],r.retval.memspec);
                prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[3],r.retval.memspec);
              }
            }  
            break;           
       case T_UNTYPED:
            break;
       case T_FLOATL:
            sscanf(wtxt,"%f",&newval.f);
            if(!prc->GetMemAlignment())
            {
              prc->SetMemAtAddr( r.retval.addr,  (ULONG*)&newval.c[0],r.retval.memspec);
              prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[1],r.retval.memspec);
              prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[2],r.retval.memspec);
              prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[3],r.retval.memspec);
            }
            else
            {
              prc->SetMemAtAddr( r.retval.addr+3,(ULONG*)&newval.c[0],r.retval.memspec);
              prc->SetMemAtAddr( r.retval.addr+2,(ULONG*)&newval.c[1],r.retval.memspec);
              prc->SetMemAtAddr( r.retval.addr+1,(ULONG*)&newval.c[2],r.retval.memspec);
              prc->SetMemAtAddr( r.retval.addr  ,(ULONG*)&newval.c[3],r.retval.memspec);
            }
       case T_DOUBLE:
       case T_FLOATB:
            sscanf(wtxt,"%f",&newval.f);
            break;
     }                 
      ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches();
    }
  }
  return(0);
}

void CHListCtrl::OnDestroy() 
{
int n,i;
item_t* pi;
	
  n=GetItemCount();  
  for(i=0;i<n;i++)
  {
    pi=(item_t*)GetItemData(i);
    delete pi;
  }
  bkpen.DeleteObject();
	CListCtrl::OnDestroy();
}

void CHListCtrl::OpenArray(int item, item_t* pi,int dimension)
{
int elements;
CTypdesc* pt;
int i,ni;
char buff[200];
item_t* pni;
CString ptxt;
eval_t r;
  
  SetRedraw(FALSE);
  pt=(CTypdesc*)(pi->wtyp.optyp);
  if(!pt->elements && pt->pref->typ==T_ARRAYDESC) //ARRAY ist Element einer Liste
    pt=pt->pref;
  elements=pt->elements;
  ptxt=pi->subname;
  
  for(i=0;i<elements;i++)
  {
    sprintf(buff,"[0x%2.2X]",i);
    ni=AddWatch(buff,item+i+1);    
    sprintf(buff,"%s[0x%2.2X]",ptxt,i);
    r.expression=buff;
    *(long*)r.lastop.op=0;
    Evaluate(&r);
    pni=(item_t*)GetItemData(ni);
    pni->editable[0]=FALSE;
    if(i==elements-1)
      pni->last=1;    
    pni->wtyp=r.retval; 
    pni->level=pi->level+1;
    pni->pparent=pi;
    pni->subname=buff; 
    pni->IsAddr=pi->IsAddr;
    pt=(CTypdesc*)r.retval.optyp;
    if((ULONG)pt>0x1E)
    { 
      if(pt->typ==T_STRUCTDESC)
        pni->subname += ".";
      else if(pt->typ==T_POINTDESC || pt->typ==T_SPACEDPTR || pt->typ==T_GENPTRDESC || pt->typ==T_SDCGENPOINT)
      {
       // pni->subname += "->";
        pni->editable[1]=TRUE;
      }
      else if(pt->typ==T_ARRAYDESC)
        pni->subname=buff;
    }  
    else if((ULONG)pt!=T_CODELABEL)
      pni->editable[1]=TRUE;
    GetWatchValString(buff,&r,sizeof(buff),viewmode);
    SetItemText(ni,1,buff);
    if((ULONG)pt > 0x1E) // kein Standardtyp
      pni->image=B_SUBROOT;
    else
      pni->image=B_HORZLINE;    
  }
  Update(item);
  SetRedraw(TRUE);
}

void CHListCtrl::CloseTree(int item, item_t* pi)
{
int level;
item_t* pid;
    
    SetRedraw(FALSE);
    level=pi->level;
c1:
    pid=(item_t*)GetItemData(item+1);
    if(pid->level >= level+1)
    {
      DeleteItem(item+1);      
      goto c1;
    }
    if(pi->image == B_SUBOPEN)
      pi->image = B_SUBROOT;
    else if(pi->image == B_SUB)
      pi->image = B_ROOT; 
    RedrawItems(item,item);
    SetRedraw(TRUE);
}

void CHListCtrl::OpenStruct(int item, item_t* pi)
{
int elements;
CTypdesc* pt;
CTypdesc* ptl;
POSITION pos;
int i,ni;
char buff[50];
item_t* pni;
CString ptxt;
CString ltxt;
eval_t r;
  
  ltxt.Empty();
  SetRedraw(FALSE);
  pt=(CTypdesc*)(pi->wtyp.optyp);      
  
  if((ULONG)pt>0x1E &&(   pt->typ==T_SPACEDPTR
                       || pt->typ==T_GENPTRDESC
                       || pt->typ==T_POINTDESC
                       || pt->typ==T_SDCGENPOINT))
  {    
    ptxt.Format("(%s)->",pi->subname);   
  }
  else
  {
    if((ULONG)(pt->pref)>0x1E && pi->subname.GetAt(0)=='*') // zeigt nicht auf einen Standardtyp
      ptxt=pi->subname.Mid(1);      
    else
      ptxt=pi->subname;
  }
  while((ULONG)pt > 0x1E && pt->typ!=T_STRUCTDESC)
    pt=pt->pref;

  if(pt->typ==T_STRUCTDESC)
  { 
    elements=pt->elements;      
    pt=pt->pref;  //der Listdescriptor oder wenn Liste der n�chste Struktur desc
    if(pt->typ==T_STRUCTDESC) // die Struktur ist Element einer Liste
    {
      elements=pt->elements;      
      pt=pt->pref; 
    }
  }
  pos=pt->pmem->GetTailPosition();
  i=1;
  int last=1;  // wird nur einmal gesetzt
  while(pos)
  {
    ptl=(CTypdesc*)pt->pmem->GetPrev(pos);  //das Listenelement
    ltxt=*(ptl->pname);
    sprintf(buff,"%s%s",ptxt,ltxt);              
    r.expression=buff;   
    *(long*)r.lastop.op=0;
    if(Evaluate(&r))
    {
      pi->image=B_ERROR;
      SetRedraw(TRUE);
      return;
    }
    ni=AddWatch(ltxt,item+i);  
    pni=(item_t*)GetItemData(ni);
    pni->editable[0]=FALSE;
    pni->last=last;    
    pni->wtyp=r.retval; 
    pni->level=pi->level+1;
    pni->pparent=pi;
    pni->subname=buff; 
    pni->IsAddr=pi->IsAddr;
    ptl=(CTypdesc*)r.retval.optyp;
    if((ULONG)ptl>0x1E && ptl->typ != T_BITARRDESC)
    { 
      if(ptl->typ==T_STRUCTDESC)
        pni->subname += ".";
      else if(ptl->typ==T_POINTDESC || ptl->typ==T_SPACEDPTR || ptl->typ==T_GENPTRDESC ||ptl->typ==T_SDCGENPOINT)
      {
        //pni->subname += "->";      
        pni->editable[1]=TRUE;
      }
    } 
	
    else if((ULONG)ptl!=T_CODELABEL)
      pni->editable[1]=TRUE;
    GetWatchValString(buff,&r,sizeof(buff),viewmode);
    SetItemText(ni,1,buff);
    if((ULONG)ptl > 0x1E && ptl->typ != T_BITARRDESC) // kein Standardtyp
      pni->image=B_SUBROOT;
    else 
      pni->image=B_HORZLINE;           
    last=0;
  }  
  Update(item);
  SetRedraw(TRUE);
}

void CHListCtrl::FollowPointer(int item, item_t* pi)
{
CTypdesc* pt;
CString ptxt;
int ptyp,x;
CTypdesc* ptl;
int ni;
char buff[50];
item_t* pni;
eval_t r;
   
  pt=(CTypdesc*)(pi->wtyp.optyp); 
  ptyp=pt->typ;
  while((ULONG)pt>0x1E && pt->typ==ptyp)
    pt=pt->pref;
 // if((ULONG)pt>0x1E && pi->subname.Find("->") ==-1)  //wenn generische Pointer erst sp�ter g�ltig werden
 //   pi->subname+="->";
  
  ptxt=pi->subname;
  if((ULONG)pt>0x1E && pt->typ==T_STRUCTDESC)
  {
    OpenStruct(item,pi);
  }
  else if((ULONG)pt>0x1E && pt->typ==T_ARRAYDESC)
  {

  }
  else //Zeiger auf Standardtyp
  {    
    ni=AddWatch("",item+1);    
    sprintf(buff,"*(%s)",LPCSTR(pi->subname));
    r.expression=buff;   
    *(long*)r.lastop.op=0;
    x=Evaluate(&r);
    pni=(item_t*)GetItemData(ni);   
    pni->level=pi->level+1;
    pni->last=1; 
    if(x)   //Ausdruck kann nicht berechnet werden
    {
      SetItemText(ni,1,"illegal expression");         
    }
    else
    {
      pni->editable[0]=FALSE;               
      pni->wtyp=r.retval;       
      pni->pparent=pi;
      pni->subname=buff; 
      ptl=(CTypdesc*)r.retval.optyp;
      pni->editable[1]=TRUE;
      GetWatchValString(buff,&r,sizeof(buff),viewmode);
      SetItemText(ni,1,buff); 
    }
  }
  Update(item);
}

BOOL CHListCtrl::UpdateWatch(int item,BOOL checkChanges)
{
item_t* pi;
char buff[200];
eval_t r;
CString oldtxt;
CTypdesc* pt;
int l;
int x;

  
   oldtxt=GetItemText(item,1);
   pi=(item_t*)GetItemData(item);
   if(pi->subname=="")
   {
      DeleteItem(item);
      return FALSE;
   }
   if(pi->IsAddr)
   {
     buff[0]='&';
     strcpy(buff+1,LPCSTR(pi->subname));
   }
   else
     strcpy(buff,LPCSTR(pi->subname));
   l=strlen(buff)-1;
   if(buff[l]=='.')
     buff[l]=0;
   else if(buff[l]=='>')
     buff[l-1]=0;
   r.expression=buff;   
   *(long*)r.lastop.op=0;
   x=Evaluate(&r);
   if(!x)
   {     
     //GetWatchValString(buff,&r,sizeof(buff),viewmode);
     GetWatchValString(buff,&r,sizeof(buff),pi->vtyp);
     pt=(CTypdesc*) r.retval.optyp;
     pi->wtyp=r.retval;
     if((ULONG)pt>0x1E && pi->image==B_ERROR)
       pi->image=B_ROOT;
   }
   else
   {
     strcpy(buff,"illegal expression");            
     pi->image=B_ERROR;   
     if(!pi->level)
     {     
       CloseTree(item,pi);
     }
   //  else
   //    DeleteItem(item);
   }          
  
   if(oldtxt != buff)
   {
     if(r.retval.optyp==T_SCHAR)
     {  //der String soll nicht in den Vergleich einbezogen werden
       l=oldtxt.Find('"'); 
       if(strncmp(LPCSTR(oldtxt),buff,l))
       { 
         SetItemText(item,1,buff);
         pi->changed=TRUE;  
       }
       else
       {
         SetItemText(item,1,buff);
         pi->changed=FALSE;
         RedrawItems(item,item);
       }
     }
     else
     {
       SetItemText(item,1,buff);
       pi->changed=TRUE;  
     }

     if(!checkChanges)
     { 
       pi->changed=FALSE;
       RedrawItems(item,item);
     }
   }
   else
   {
     if(pi->changed)     
     {
       pi->changed=FALSE;            
       RedrawItems(item,item);
     } 
   }
   return pi->changed;
}

void CHListCtrl::UpdateWatchWnd(BOOL checkChanges)
{
int n,i;

   SetRedraw(FALSE);
   n=GetItemCount();
   for(i=0;i<n-1;i++)
   {
     if(UpdateWatch(i,checkChanges))
       RedrawItems(i,i);
     n=GetItemCount();
   }
   SetRedraw(TRUE);
}

void GetWatchValString(char* txt, eval_t* eval,int txtlen,int viewmode)
{
ULONG v;
char c;
ULONG mem;
int memsize,l;
CTypdesc *pt;
op_t* pval;
int i;
ULONG flags;


  flags=0;
  if(eval->lastop.op[0]== '&' || eval->retval.flags==ISADDR)
    flags |= ISADDR;
  if(eval->lastop.op[0]== '~')
    flags |= ISNEG;
  pval=&(eval->retval);
  v=*(unsigned long*)(pval->op); 
  pt=(CTypdesc*)(pval->optyp);  
  const char* memstr=0;
  if((ULONG)pt < 0x1E && (!(flags & ISADDR) || (ULONG)pt==T_UNTYPED)) //StandardTyp und es wurde nicht die Adresse gesucht
  {
    if((ULONG)pt==T_UNTYPED) // suche selbst eine passende L�nge
    {
      if(v <= 0xFF)
        pval->optyp=T_UCHAR;
      else if(v <= 0xFFFF)
        pval->optyp=T_UINT;
      else
        pval->optyp=T_ULONG;
    }
    switch(pval->optyp)
    { 
       case T_BIT:
                  if(v)
                    strcpy(txt,"TRUE");
                  else
                    strcpy(txt,"FALSE");
                  break;
       case T_SCHAR: 
                  v&=0xFF;
                  l=0;                  
                  if(viewmode==V_DEZ)
                    l=sprintf(txt,"%+1.1d ",(char)v);                  
                  else if(viewmode==V_HEX)                 
                    l=sprintf(txt,"0x%2.2X ",v);
                  else  //V_BIN 
                  {
                    CString btxt;
                    ::GetBinString(BYTE_BIN,(void*)&v,btxt);  
                    strcpy(txt,btxt);
                  } 
                  if(eval->lastop.op[0]=='~' || viewmode==V_DEZ || viewmode==V_BIN)  //keine Anzeige des Strings
                    break;
                  i=0;
                  txt[l++]='"';
                  
                  if(txtlen>0x80)
                    txtlen=80;
                  while(l<txtlen-3)
                  {        
                    prc->GetMemFromAddr(eval->retval.addr+i,&v,(eval->retval.memspec));
                    c=(char)(v&0xFF);
                    if(c) 
                      txt[l]=c;
                    else
                    {
                      txt[l]='"';
                      txt[l+1]=0;
                      break;
                    }
                    l++;
                    i++;
                  }
                  break;
       case T_UCHAR:
                  v&=0xFF;
                  if(viewmode==V_DEZ)
                    sprintf(txt,"%1.1d",(UCHAR)v);
                  else if(viewmode==V_HEX)
                    sprintf(txt,"0x%2.2X",(UCHAR)v);                  
                  else  //V_BIN 
                  {
                    CString btxt;
                    ::GetBinString(BYTE_BIN,(void*)&v,btxt);  
                    strcpy(txt,btxt);
                  }
                  break;
       case T_SINT:                   
                  if(viewmode==V_DEZ)
                    sprintf(txt,"%+d",(SHORT)v);
                  else
                    sprintf(txt,"0x%4.4X",(USHORT)v);                                                      break;
       case T_UINT:
       case T_CODELABEL:
                  if(viewmode==V_DEZ)
                    sprintf(txt,"%u",(USHORT)v);
                  else
                    sprintf(txt,"0x%4.4X",(USHORT)v);                                                      
                  break;
       case T_SLONG:
                  if(viewmode==V_DEZ)
                    sprintf(txt,"%+ld",(long)v);
                  else
                    sprintf(txt,"0x%8.8X",v);                                                      
                  break;
       case T_ULONG:
       case T_VOID:
                  if(viewmode==V_DEZ)
                    sprintf(txt,"%lu",v);
                  else
                    sprintf(txt,"0x%8.8X",v);  
                  break;
       case T_FLOATL:       
       case T_DOUBLE:
       case T_FLOATB:
                  sprintf(txt,"%G",*(float*)(pval->op)); 
                  break;
    }   
       
  }
  else if((ULONG)pt > 0x1E && pt->typ==T_BITARRDESC && !(flags&ISADDR))
  {    
    if(pt->size ==1) //nur ein Bit
    {
			if(v)
        strcpy(txt,"TRUE");
      else
        strcpy(txt,"FALSE");
    }
	else
    { 
      if(!pt->elements) // Base ist char
        sprintf(txt,"0x%2.2X",(BYTE)v);
	  else  // Base ist short
        sprintf(txt,"0x%4.4X",(USHORT)v);
    }
  }
  else if(flags&ISADDR) //die Adressse wurde gesucht
  {   
    memsize=prc->GetMemSize(pval->memspec);
    const char* memstr=0;
    switch(pval->memspec & 0xFFFF)
    {
      case CODEMEM: memstr="CD:"; 
                    break;
      case XDATAMEM:memstr="XD:"; 
                    break;
      case DATAMEM: memstr="D: ";
                    break;
      case IDATAMEM:memstr="ID:";
                    break;
      case PDATAMEM:memstr="PD:";
                    break;
    }
    switch(memsize)
    {
      case S8: sprintf(txt,"%s{0x%2.2X}",memstr,(BYTE)v); 
               break;
      case S16:sprintf(txt,"%s{0x%4.4X}",memstr,(USHORT)v);
               break;
      default:
      case S32:sprintf(txt,"%s{0x%8.8X}",memstr,v);
               break;
    }
  }
  else //es wurde kein Standardtyp und auch nicht die Adresse gesucht
  {          
    if(   pt->typ == T_POINTDESC
       || pt->typ == T_SPACEDPTR
       || pt->typ == T_GENPTRDESC
       || pt->typ == T_SDCGENPOINT )  //der gesuchte Typ ist ein Zeiger       
    { 
      if((ULONG)(pt->pref)>0x1E && pt->pref->typ==pt->typ)  // Zeiger ist Element einer Liste
        pt=pt->pref;      
      if(pt->typ == T_POINTDESC)
      {
        BOOL b=prc->GetMemFromAddr(pval->addr,&mem,(pval->memspec>>16)); //pval->memspec=Memory wo der Zeiger steht!! 
        if(!b)
        {
          memstr="illegal memspec";
          return;
        }        
      } 
      else if(pt->typ == T_SDCGENPOINT)
      {
        BOOL b=prc->GetMemFromAddr(pval->addr+2,&mem,pval->memspec>>16); //pval->memspec=Memory wo der Zeiger steht!! 
        if(!b)
        {
          memstr="illegal memspec";
          return;
        } 
        else
        { 
          switch(mem)
          {
            case 0: if(pval->op[0]<0x80)
                      mem=MS_DATA;
                    else
                      mem=MS_IDATA;
                    break;
            case 1: mem=MS_XDATA;
                    break;
            case 2: mem=MS_CODE;
                    break;
            default: memstr="illegal memspec";
                     return;
          }
        }       
      }           
      else
        mem=pt->offset;      
      switch(mem)
      {
        default:
        case MS_CODE:  memstr="CD:"; 
                       memsize=prc->GetMemSize(CODEMEM);
                       break;
        case MS_XDATA: memstr="XD:";
                       memsize=prc->GetMemSize(XDATAMEM);
                       break;
        case MS_DATA:  memstr="D: ";
                       memsize=prc->GetMemSize(DATAMEM);
                       break;
        case MS_IDATA: memstr="ID:";
                       memsize=prc->GetMemSize(IDATAMEM);
                       break;
        case MS_PDATA: memstr="PD:";
                       memsize=prc->GetMemSize(PDATAMEM);
                       break;
      }
      switch(memsize)
      {
        case S8: sprintf(txt,"->%s0x%2.2X",memstr,(UCHAR)v); 
                 break;
        case S16:sprintf(txt,"->%s0x%4.4X",memstr,(USHORT)v);
                 break;
        default:
        case S32:sprintf(txt,"->%s0x%8.8X",memstr,v);
                 break;
      }
    }    
    else  // der Typ ist ein anderer (Struct oder Array)
    { 
      memsize=prc->GetMemSize(pval->memspec);
      switch(pval->memspec & 0xFFFF)
      {
        case CODEMEM: memstr="CD:"; 
                      break;
        case XDATAMEM:memstr="XD:"; 
                      break;
        case DATAMEM: memstr="D: ";
                      break;
        case IDATAMEM:memstr="ID:";
                      break;
        case PDATAMEM:memstr="PD:";
                      break;
      }     
      switch(memsize)
      {
        case S8: sprintf(txt,"%s{0x%2.2X}",memstr,(BYTE)v); 
                 break;
        case S16:sprintf(txt,"%s{0x%4.4X}",memstr,(USHORT)v);
                 break;
        default:
        case S32:sprintf(txt,"%s{0x%8.8X}",memstr,v);
                 break;
      }
    }
  }      
} 

void CHListCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
CMenu    Popup;
int c1,item;
CString txt;
int newtyp;  
POSITION pos;
item_t* pi;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  c1=GetColumnWidth(0);
  item=HitTest(point); 
  if(item == -1)
    return;
  txt=GetItemText(item,0);
  pi=(item_t*)GetItemData(item);
  if(txt=="" && !pi->level)
  {    
    return;
  }
  if(item != -1 && point.x >c1) // in der 2.Spalte
  {
    delItem=item; 
    ClientToScreen(&point);
    Popup.LoadMenu (IDR_WATCHMENU);
    if(   pi->wtyp.optyp>0x20 || pi->wtyp.optyp==T_FLOATB 
       || pi->wtyp.optyp==T_FLOATL || pi->wtyp.optyp==T_DOUBLE)
    { 
      Popup.EnableMenuItem(IDM_HEX, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND); 
      Popup.EnableMenuItem(IDM_BIN, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
      Popup.EnableMenuItem(IDM_DEZ, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
    }
    else if(pi->wtyp.optyp != T_SCHAR && pi->wtyp.optyp != T_UCHAR)
    {       
      Popup.EnableMenuItem(IDM_BIN, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);      
    }
    Popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
                                         point.x,point.y,this);    
  } 
  else if(item != -1 && point.x <c1)
  { 
    if(!pm->pDoc->pobjinfo->ObExt)
    {
      CObjInfo* pobjinfo=&(((CJSTEPApp*)AfxGetApp())->objinfo);
      txt=GetItemText(item,0);
      txt.TrimRight();
      txt.TrimLeft();
      labeldef_t* lp=pobjinfo->FindLabel(&txt);
      if(lp)
      {
        CChangeTyp typdlg; 

        if((ULONG)(lp->pTypdesc) > 0x1E) // also muss es ein Zeiger sein      
          typdlg.acttyp=(lp->pTypdesc->offset << 8) | (ULONG)lp->pTypdesc->pref;      
        else
          typdlg.acttyp=(ULONG)lp->pTypdesc;

        newtyp=typdlg.DoModal(); 
        if(newtyp&0x80000000) //Eintrag l�schen
        {
          CloseTree(item,(item_t*)GetItemData(item));
          DeleteItem(item);
          item=-1;
          UpdateWatchWnd(FALSE);
          return;
        }
        if(newtyp < 0x1E) //also ein einfacher Typ
        { 
          if((ULONG)lp->pTypdesc >0x1E) //l�sche Typdescriptor aus der Templiste
          {
            pos=pobjinfo->typelist.GetHeadPosition();
            while(pos)
            {
              if(pobjinfo->typelist.GetAt(pos)==lp->pTypdesc) 
              {  
                pobjinfo->typelist.RemoveAt(pos);
                delete lp->pTypdesc;
                break;
              }
            }
          }
          lp->pTypdesc=(CTypdesc*)newtyp;               
        }
        else //ein Zeiger erfordert einen neuen Typdescriptor
        {
          if((ULONG)lp->pTypdesc < 0x1E)  //noch kein Typdescriptor vorhanden
          {
            lp->pTypdesc=new CTypdesc;
            pobjinfo->typelist.AddTail(lp->pTypdesc);
          }
          lp->pTypdesc->offset=(USHORT)(newtyp>>8);
          switch(newtyp>>8)
          {
            case MS_DATA:
            case MS_PDATA:
            case MS_IDATA:
                       lp->pTypdesc->size=1; //1 Byte Pointer
                       break;
            case MS_CODE:
            case MS_XDATA:
                       lp->pTypdesc->size=2; //2 Byte Pointer
                       break;
          }
          lp->pTypdesc->typ=T_SPACEDPTR;
          lp->pTypdesc->pref=(CTypdesc*) (newtyp & 0xFF);
          pi->image=B_ROOT;
        }
      }
      UpdateWatch(item,FALSE);
    }
    else if(!pi->level)// ist zwar ObExt aber man will ja noch XDATA-PDATA wandeln k�nnen
    {                                  
       CMenu Popup;      
       Popup.LoadMenu(IDR_CHANGETYP); 
       delItem=item; 
       if(!ContextEn) 
       {          
         Popup.EnableMenuItem(ID_DELETEWATCH, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);       
       }
       else
         Popup.EnableMenuItem(ID_DELETEWATCH, MF_ENABLED|MF_BYCOMMAND);
       if(pi->IsAddr || !(pi->wtyp.memspec & PDATAMEM+XDATAMEM)) // || pi->wtyp.optyp >0x20 
         Popup.EnableMenuItem(ID_CHANGETO, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
       else
       {
         CString mtxt;
         Popup.GetMenuString( ID_CHANGETO, mtxt,MF_BYCOMMAND );
         if(pi->wtyp.memspec & PDATAMEM)
           mtxt+="XDATA";
         else
           mtxt+="PDATA"; 
         Popup.ModifyMenu(ID_CHANGETO,MF_BYCOMMAND|MF_STRING,ID_CHANGETO,LPCSTR(mtxt));                       
       }      
       ClientToScreen(&point);
       Popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
        point.x,point.y,this);  
    }
  }	
}

void CHListCtrl::OnFloat()
{
RECT rd;

  GetDesktopWindow()->GetWindowRect(&rd);
	POINT pt;
	pt.x=rd.right/2-50;
  pt.y=rd.bottom/2-50;
  ((CFrameWnd*)AfxGetMainWnd())->FloatControlBar(((CControlBar*)GetParent()),pt,0);	
}

void CHListCtrl::OnDock()
{
  CMDIFrameWnd* pm=(CMDIFrameWnd*)AfxGetMainWnd(); 
  pm->DockControlBar(((CControlBar*)GetParent()),AFX_IDW_DOCKBAR_RIGHT);
}

void CHListCtrl::OnDez()
{
  item_t* pi=(item_t*)GetItemData(delItem);
  pi->vtyp=V_DEZ;
  //viewmode=V_DEZ;
  UpdateWatch(delItem,FALSE);
}

void CHListCtrl::OnHex()
{
  item_t* pi=(item_t*)GetItemData(delItem);
  pi->vtyp=V_HEX;
  //viewmode=V_HEX;
  UpdateWatch(delItem,FALSE);
}

void CHListCtrl::OnBin()
{
  item_t* pi=(item_t*)GetItemData(delItem);
  pi->vtyp=V_BIN;
  //viewmode=V_BIN;
  UpdateWatch(delItem,FALSE);
}

void CHListCtrl::SetUCase(BOOL ucase)
{
  if(!ucase)
    edit.ModifyStyle(ES_UPPERCASE, 0);
  else
    edit.ModifyStyle(0, ES_UPPERCASE);
}

BOOL CHListCtrl::AddWatchExpression(CString& expression,BOOL openSubStruct,CModDef* pm, CProcDef* pp,int vmode)
{
char wtxt[100];
CTypdesc* pt;
eval_t r;
item_t* pi;
int x,icnt;
  
  
  icnt=GetItemCount()-1;
  if(!expression.GetLength())
    return FALSE;
  if(!pm && !pp)
    strcpy(wtxt,LPCSTR(expression));
  else
  {
    strcpy(wtxt,LPCSTR(pm->modname));
    strcat(wtxt,":");
    strcat(wtxt,LPCSTR(pp->Procname));
    strcat(wtxt,":");
    strcat(wtxt,LPCSTR(expression));
  }
  r.expression=wtxt; 
  *(long*)r.lastop.op=0;  
  x=Evaluate(&r);
  pi=(item_t*)GetItemData(icnt);
  pi->vtyp=vmode;
  SetItemText(icnt,0,expression);  
  if(x)   //Ausdruck kann nicht berechnet werden
  {
    SetItemText(icnt,1,"illegal expression");
    pi->image=B_ERROR;     
    pi->subname=wtxt;
    pi->editable[1]=FALSE;  
    RedrawItems(icnt,icnt);
    AddWatch("");
    return FALSE;
  }
  else
  {       
    pi->wtyp=r.retval; 
    pi->changed=FALSE;
    pt=(CTypdesc*)(r.retval.optyp);
    pi->subname=wtxt;
    if((ULONG)pt>0x1E) 
    {
      if(pt->typ==T_STRUCTDESC)
        pi->subname += ".";
      else if(pt->typ==T_POINTDESC || pt->typ==T_SPACEDPTR || pt->typ==T_GENPTRDESC || pt->typ==T_SDCGENPOINT)
      {
       // if((ULONG)(pt->pref)>0x1E)          
       //   pi->subname += "->";             
        pi->editable[1]=TRUE;
      }
    }
    else if((ULONG)pt!=T_CODELABEL)
      pi->editable[1]=TRUE;
    if(r.lastop.op[0]=='&')
    {
      pi->subname=pi->subname.Mid(1); //das "&" entfernen        
      pi->IsAddr=TRUE;
      pi->editable[1]=FALSE;
    }
    if(r.lastop.op[0]=='~')
    {
      pi->editable[1]=FALSE;
    }
    GetWatchValString(wtxt,&r,sizeof(wtxt),viewmode);              
    SetItemText(icnt,1,wtxt);
    if(r.retval.optyp >0x1E) // kein Standardtyp
      pi->image=B_ROOT;
    else
      pi->image=B_EMPTY;   
  } 
   
  RedrawItems(icnt,icnt);
  AddWatch("");  
  
  if(openSubStruct && (ULONG) pt>0x1E)
  {
    pi->image=B_SUB;
    switch(pt->typ)
    {
      case T_ARRAYDESC: 
             OpenArray(0,pi);                        
             break;
      case T_STRUCTDESC:
             OpenStruct(0,pi);
             break;
      case T_POINTDESC:
      case T_GENPTRDESC:
      case T_SPACEDPTR:
      case T_SDCGENPOINT:
             FollowPointer(0,pi);
             break;            
    }
  }
  return TRUE;
}
