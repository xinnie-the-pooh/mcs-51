// IntCtrl.cpp : implementation file
//

#include "stdafx.h"
#include <WTYPES.H>
#include "jstep.h"
#include "proc.h"
#include "IntCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIntCtrl

CIntCtrl::CIntCtrl()
{
  Created=FALSE;
}

CIntCtrl::~CIntCtrl()
{
}

BEGIN_MESSAGE_MAP(CIntCtrl, CDialogBar)
	//{{AFX_MSG_MAP(CIntCtrl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
    ON_COMMAND(IDC_IE0, OnEnable0)	    
    ON_COMMAND(IDC_IE1, OnEnable1)	    
    ON_COMMAND(IDC_IE2, OnEnable2)	    
    ON_COMMAND(IDC_IE3, OnEnable3)	    
    ON_COMMAND(IDC_IE4, OnEnable4)	        
    ON_COMMAND(IDC_IP0, OnPrioInt0)	
    ON_COMMAND(IDC_IP1, OnPrioInt1)	    
    ON_COMMAND(IDC_IP2, OnPrioInt2)	    
    ON_COMMAND(IDC_IP3, OnPrioInt3)	    
    ON_COMMAND(IDC_IP4, OnPrioInt4)	    
    ON_COMMAND(IDC_INTENABLE, OnIntEnable)	
    ON_UPDATE_COMMAND_UI(IDC_INTENABLE, OnUpdateIntEnable)
    ON_COMMAND(IDC_INT0, OnInt0)	
    ON_UPDATE_COMMAND_UI(IDC_INT0, OnUpdateInt0)
    ON_COMMAND(IDC_INT1, OnInt1)	
    ON_UPDATE_COMMAND_UI(IDC_INT1, OnUpdateInt1)
    ON_COMMAND(IDC_INT2, OnInt2)	
    ON_UPDATE_COMMAND_UI(IDC_INT2, OnUpdateInt2)
    ON_COMMAND(IDC_INT3, OnInt3)	
    ON_UPDATE_COMMAND_UI(IDC_INT3, OnUpdateInt3)
    ON_COMMAND(IDC_INTRX4, OnIntRx4)	
    ON_UPDATE_COMMAND_UI(IDC_INTRX4, OnUpdateIntRx4)
    ON_COMMAND(IDC_INTTX4, OnIntTx4)	
    ON_UPDATE_COMMAND_UI(IDC_INTTX4, OnUpdateIntTx4)    
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CIntCtrl message handlers


#define CBRS_ALIGN_INTERRUPT  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT | CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP  

BOOL CIntCtrl::Create(CWnd* pParent)
{

ULONG b8,a8;

  Created= CDialogBar::Create(pParent, IDD_INTERRUPT
	       ,CBRS_ALIGN_INTERRUPT,IDD_INTERRUPT);	
  
  if(Created)
  {    	    
    SetBarStyle( GetBarStyle()
		         | CBRS_TOOLTIPS 
     			 | CBRS_FLYBY 							 
				 | CBRS_BORDER_ANY 
				 | CBRS_BORDER_3D );
		
    EnableDocking(CBRS_ALIGN_INTERRUPT);
	SetWindowText(_T("Interrupts"));
     
    ((CButton*)GetDlgItem(IDC_IP0))->SetCheck(b8 & 0x01);  
    ((CButton*)GetDlgItem(IDC_IP1))->SetCheck(b8 & 0x02); 
    ((CButton*)GetDlgItem(IDC_IP2))->SetCheck(b8 & 0x04); 
    ((CButton*)GetDlgItem(IDC_IP3))->SetCheck(b8 & 0x08);
    ((CButton*)GetDlgItem(IDC_IP4))->SetCheck(b8 & 0x10);
    ((CButton*)GetDlgItem(IDC_EA ))->SetCheck(a8 & 0x80);
    RECT rd;
	GetDesktopWindow()->GetWindowRect(&rd);    		
	CPoint pt;
	pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;	
    m_FloatingPosition=pt; 
  }
  EnableToolTips(TRUE);
  return(Created); 
}

void CIntCtrl::OnEnable0()
{

}

void CIntCtrl::OnEnable1()
{

}


void CIntCtrl::OnEnable2()
{

}


void CIntCtrl::OnEnable3()
{

}


void CIntCtrl::OnEnable4()
{

}


// Priorit�t
void CIntCtrl::OnPrioInt0()
{

}


void CIntCtrl::OnPrioInt1()
{

}

void CIntCtrl::OnPrioInt2()
{

}


void CIntCtrl::OnPrioInt3()
{

  
}

void CIntCtrl::OnPrioInt4()
{

}


// Interrupt Buttons
void CIntCtrl::OnInt0() //Ext0
{

}


void CIntCtrl::OnUpdateInt0(CCmdUI* pCmdUI)
{
 
}

void CIntCtrl::OnInt1() //Timer0
{

}

void CIntCtrl::OnUpdateInt1(CCmdUI* pCmdUI)
{
 
}

void CIntCtrl::OnInt2() //Ext2
{


}

void CIntCtrl::OnUpdateInt2(CCmdUI* pCmdUI)
{
 }

void CIntCtrl::OnInt3() //Timer1
{

}

void CIntCtrl::OnUpdateInt3(CCmdUI* pCmdUI)
{
  
}

void CIntCtrl::OnIntRx4()
{

}

void CIntCtrl::OnUpdateIntRx4(CCmdUI* pCmdUI)
{

}

void CIntCtrl::OnIntTx4()
{

}

void CIntCtrl::OnUpdateIntTx4(CCmdUI* pCmdUI)
{

}

void CIntCtrl::OnIntEnable()
{

}

void CIntCtrl::OnUpdateIntEnable(CCmdUI* pCmdUI)
{

}

void CIntCtrl::UpdateIntWnd()
{

}
