// ProcSel.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProcSel dialog

class CProcSel : public CDialog
{
// Construction
public:
	CProcSel(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CProcSel)
	enum { IDD = IDD_SELPROC };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProcSel)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL CheckDLLvalid(LPCSTR dllname);

	// Generated message map functions
	//{{AFX_MSG(CProcSel)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSearchProc();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
