// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////
#ifndef _MAINFRAME
#define _MAINFRAME

#include "proc.h"
#include "jstepdoc.h"
#include "MemWnd.h"
#include "dbgbar.h"
#include "regwnd.h"
#include "watchwnd.h"
#include "localwnd.h" 
#include "quickwatch.h"
#include "browswnd.h"
#include "stackwnd.h"
#include "anawnd.h"
#include "analysbar.h"
#include "traceview.h"


class CMainFrame : public CMRCMDIFrameWndSizeDock
{
	DECLARE_DYNAMIC(CMainFrame)
public:		
    dynamenu_t addcmds[NUMBER_OF_ADDCMDS];	
    int addcmdNo;
	CTraceView* m_pWndTrace;
	CProgressCtrl m_progress;
	CAnaWnd m_wndAnalyser;    
	CStackWnd m_wndStack;
	CBrowsWnd m_browsWnd;
	CQuickWatch* pquick;
	void UpdateAllWatches();
	int UpdateAllMemWnds(CMemWnd* pmem0=0,BOOL redraw=FALSE);
	
	CPtrList memwnds;
	USHORT tbvis;
	CJSTEPDoc* pDoc;
	CDbgBar m_DbgBar;
	void DockControlBarLeftOf(CToolBar* Bar,CToolBar* LeftOf);
	CMainFrame();
  BOOL winmax;

protected:
   void CMainFrame::GetMessageString(UINT nID, CString& rMessage)const;

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	CMenu m_menu;
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif  
  CRegWnd    m_wndRegBar;
  CWatchWnd  m_wndWatch;
  CLocalWnd  m_wndLocals;
  CFlatToolBar   m_wndToolBar;
  //CToolBarEx   m_wndToolBar;
  CAnalysBar   m_wndAnalyserBar;
  CToolTipCtrl ttp;
  CStatusBar  m_wndStatusBar;

// Generated message map functions
protected:
  //{{AFX_MSG(CMainFrame)
  afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);	
  afx_msg long UpdateDisplay( UINT wparam, LONG lparam);
  afx_msg long DoStimulation( UINT wparam, LONG lparam);
  afx_msg void OnEditCopy();
  afx_msg void OnEditCut();
  afx_msg void OnEditPaste();
  afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
  afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
  afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
  afx_msg void OnProject(); 
  afx_msg void OnUpdateProject(CCmdUI* pCmdUI);
  afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSelproc(); 
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};



/////////////////////////////////////////////////////////////////////////////
//WM_COMMAND

#endif // _MAINFRAME
