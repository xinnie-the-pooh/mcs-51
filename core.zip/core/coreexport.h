// global export functions for use by the processor implementation

#define DLLExport __declspec(dllexport)

#ifndef _USRDLL
   #define DLLDIR DLLExport
#else   
   #define DLLDIR __declspec(dllimport)
#endif

//#define DLLExport 


extern void DLLDIR RemoveFromCallStackWnd(ULONG returnAddr);
extern void DLLDIR AddToCallStackWnd(ULONG callAddr,ULONG returnAddr);
extern BOOL DLLDIR FindLabel(ULONG addr, LPSTR lbl,int memspec,int typmask,int precision);
extern BOOL DLLDIR FindBitLabel(ULONG addr, LPSTR lbl,int memspec,int typmask,int precision);

// styles for extra DLL-windows

#define DLLWND_FIX      0x0001  //window is a normal DialogBar, the menu will be inserted below "View"
#define DLLWND_DYNAMIC  0x0002  //window can be resized, the menu will be inserted below "View"
#define DLLWND_MODAL    0x0004  //creates a modal dialog, the menu will be inserted below "Edit"

extern void DLLExport InsertProcMenuItem(UINT cmdID,LPCSTR itemName,UINT bmpID,LPCSTR tooltip,LPCSTR stattxt,ULONG style);
extern void DLLExport WriteCurrentTraceRecord(int tracetyp,ULONG pc);
extern void DLLExport UpdateAllWatches();
extern void DLLExport DoNextStimulation();


// functions usable by the DLL if it parse the objectfile by itself

extern void DLLExport AddGlobalSymbol(ULONG addr,LPSTR symbolname, CTypdesc* pt,int memspec);
extern HANDLE DLLExport AddModule(LPCSTR moduleName,LPCSTR sourcePath);
extern HANDLE DLLExport AddProcedure(LPCSTR procedureName,HANDLE hModule,ULONG startaddr,ULONG endaddr);
extern void DLLExport AddDebugSymbol(ULONG addr, char* label,int valrange,int memspec,HANDLE hModule,HANDLE hProc,CTypdesc* ptd);
extern void DLLExport AddLineInfo(ULONG addr, ULONG lineno, HANDLE hModul);
