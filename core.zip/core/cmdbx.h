// cmdbx.h : header file
/////////////////////////////////////////////////////////////////////////////
// CCmdBox window

#ifndef _CMDBOX
#define _CMDBOX

class CCmdBox : public CComboBox
{
// Construction


// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCmdBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCmdBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCmdBox)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif// _CMDBOX
/////////////////////////////////////////////////////////////////////////////
