// AnaWnd.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "editnotify.h"
#include "tpedit.h"
#include "AnaWnd.h"
#include "mainfrm.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnaWnd

CAnaWnd::CAnaWnd()
{
  Created=FALSE; 
  traceEnabled=FALSE; 
  clockval=16;
  t0=0;
  t1=0; 
  stimfilename="";
  stimfile.m_hFile=-1;
  cmdbuff="";
}

CAnaWnd::~CAnaWnd()
{
  if(stimfile.m_hFile!=-1)
    stimfile.Close();
}

void CAnaWnd::OnDock()
{
  if(docking)
    EnableDocking(FALSE);
  else
    EnableDocking(CBRS_ALIGN_ANY);
  docking=!docking; 
}

void CAnaWnd::OnHide()
{
  CFrameWnd * pFrameWnd = GetParentFrame();
	pFrameWnd->ShowControlBar(this, FALSE, FALSE);
}
BEGIN_MESSAGE_MAP(CAnaWnd, CDialogBar)
	//{{AFX_MSG_MAP(CAnaWnd)
    ON_COMMAND(IDC_CNTRESET, OnCntReset)	
    ON_UPDATE_COMMAND_UI(IDC_CNTRESET, OnUpdateCntReset)
    ON_MESSAGE(UM_ENTER,OnEditReturn)
    ON_COMMAND(IDC_TRACEENABLE, OnTraceEnable)
    ON_COMMAND(IDC_ASMTRACE, OnTraceTyp)
    ON_COMMAND(IDC_MPENABLE, OnMesEnable)
	  ON_COMMAND(IDC_STIMON, OnStimEnable)
    ON_COMMAND(IDC_TPOINT, OnTraceTyp)
    ON_COMMAND(ID_MRC_ALLOWDOCKING,OnDock)
    ON_COMMAND(ID_MRC_HIDE,OnHide)
    ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


#define CBRS_ALIGN_ANALYSER  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT | CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP  
/////////////////////////////////////////////////////////////////////////////
// CAnaWnd message handlers

/*
int CAnaWnd::OnToolHitTest( CPoint point, TOOLINFO* pTI ) const
{   //Workaround f�r Fehler im VC-Servicepack2

    HWND hWndChild = NULL;
    // find child window which hits the point
    // (don't use WindowFromPoint, because it ignores disabled windows)
    // see _AfxChildWindowFromPoint(m_hWnd, point);
    ::ClientToScreen(m_hWnd, &point);
    HWND hChild = ::GetWindow(m_hWnd, GW_CHILD);
    for (; hChild != NULL; hChild = ::GetWindow(hChild, GW_HWNDNEXT))
    {
      if (_AfxGetDlgCtrlID(hChild) != (WORD)-1 &&
          (::GetWindowLong(hChild, GWL_STYLE) & WS_VISIBLE))
      {
        // see if point hits the child window
        CRect rect;
        ::GetWindowRect(hChild, rect);
        if (rect.PtInRect(point))
        {
          hWndChild = hChild;
          break;
        }
      }
    }
    if (hWndChild != NULL)
    {
      // return positive hit if control ID isn't -1
      int nHit = _AfxGetDlgCtrlID(hWndChild);
      // hits against child windows always center the tip
      if (pTI != NULL && pTI->cbSize >= sizeof(AfxOldTOOLINFO))
      {
        // setup the TOOLINFO structure
        pTI->hwnd = m_hWnd;
        pTI->uId = (UINT)hWndChild;
        pTI->uFlags |= TTF_IDISHWND;
        pTI->lpszText = LPSTR_TEXTCALLBACK;
        // set TTF_NOTBUTTON and TTF_CENTERTIP if it isn't a button
        if (!(::SendMessage(hWndChild, WM_GETDLGCODE, 0, 0) & DLGC_BUTTON))
            pTI->uFlags |= TTF_NOTBUTTON|TTF_CENTERTIP;
      }
      return nHit;
    }
    return -1;  // not found
}
*/

BOOL CAnaWnd::Create( CWnd* pParentWnd )
{
  Created= CDialogBar::Create(pParentWnd, IDD_ANALYSER
	       ,CBRS_ALIGN_ANALYSER 
           ,IDD_ANALYSER);	
  
  if(Created)
  {    	         
    editclock.SubclassDlgItem(IDC_CLOCK,this);    
    SetBarStyle( GetBarStyle()
			     | CBRS_FLYBY 
                 | CBRS_TOOLTIPS						 
				 | CBRS_BORDER_ANY 
				 | CBRS_BORDER_3D );     
		
    EnableDocking(CBRS_ALIGN_ANALYSER);
	SetWindowText(_T("Analyser"));
   
    SetDlgItemText(IDC_CLOCK,"16");  
    SetDlgItemText(IDC_RUNTIME,"0"); 
    SetDlgItemText(IDC_SIMTIME,"0"); 
    ((CButton*)GetDlgItem(IDC_ASMTRACE))->SetCheck(1);
    SetDlgItemText(IDC_STIMFILE,stimfilename); 
    RECT rd;
	GetDesktopWindow()->GetWindowRect(&rd);    		
	CPoint pt;
	pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;	
    m_FloatingPosition=pt; 
  }
  return(Created);    
}


void CAnaWnd::OnCntReset()
{
  prc->GetCyclCnt(TRUE);
  SetDlgItemText(IDC_RUNTIME,"0");
  SetDlgItemText(IDC_SIMTIME,"0");
}


void CAnaWnd::OnUpdateCntReset(CCmdUI* pCmdUI)
{
  if(prc->GetCyclCnt())
    pCmdUI->Enable(TRUE);
  else
    pCmdUI->Enable(FALSE); 
}

void CAnaWnd::UpdateAnalyser()
{
ULONG cycles;
char simbuff[15];
char runbuff[15];
float clk;

    if(!m_hWnd)
      return;    
    cycles=prc->GetCyclCnt(FALSE);
    time(&t1); 
    GetDlgItemText(IDC_CLOCK,runbuff,sizeof(runbuff));    
    sscanf(runbuff,"%f",&clockval);       
    if(((CButton*)GetDlgItem(IDC_AUTOSTART))->GetCheck() && t0) 
    { 
      sprintf(simbuff,"%ds",t1-t0);
      SetDlgItemText(IDC_SIMTIME,simbuff);
      t0=0;
    }
    else
      SetDlgItemText(IDC_SIMTIME,0);    
    clk=cycles/clockval/1000000;
    if(clk < 0.001)
      sprintf(runbuff,"%01.2fus",clk*1000000);
    else if(clk < 1)
      sprintf(runbuff,"%01.3fms",clk*1000);
    else 
      sprintf(runbuff,"%01.3fs",clk);
    SetDlgItemText(IDC_RUNTIME,runbuff);  
    ((CButton*)GetDlgItem(IDC_TRACEENABLE))->SetCheck(traceEnabled);
    
    if(((CButton*)GetDlgItem(IDC_MPENABLE))->GetCheck())
    {
      DisplayMeasureResult();
    }
    return;
}

void CAnaWnd::StartCnt()
{
  if(((CButton*)GetDlgItem(IDC_AUTOSTART))->GetCheck()) 
    prc->GetCyclCnt(TRUE);
  time(&t0);      
}

long CAnaWnd::OnEditReturn(UINT wparam, LONG lparam)
{
ULONG cycles;
char runbuff[15];
float clk;
  
  GetDlgItemText(IDC_CLOCK,runbuff,sizeof(runbuff));    
  if(sscanf(runbuff,"%f",&clockval))
  {  
    cycles=prc->GetCyclCnt(FALSE); 
    clk=cycles/clockval/1000000;
    if(clk < 0.001)
      sprintf(runbuff,"%01.2fus",clk*1000000);
    else if(clk < 1)
      sprintf(runbuff,"%01.3fms",clk*1000);
    else 
      sprintf(runbuff,"%01.3fs",clk);
    SetDlgItemText(IDC_RUNTIME,runbuff);       
  }
  if(((CButton*)GetDlgItem(IDC_MPENABLE))->GetCheck())
  {
    DisplayMeasureResult();
  }
  return 0;
}

void CAnaWnd::OnTraceTyp()
{
  if(((CButton*)GetDlgItem(IDC_TPOINT))->GetCheck())
  {    
    if(!((CMainFrame*)theApp.pMainWnd)->pDoc->tpt.isValid)
    {
      CString msgtxt;
      msgtxt.LoadString(IDS_NOTRACEPOINT);
      MessageBox(msgtxt,"TRACE-Enabled",MB_OK|MB_ICONEXCLAMATION);      
    }
    if(!((CMainFrame*)theApp.pMainWnd)->pDoc->tpt.expressions.GetSize())
    {
      CTPEdit tped;
      tped.DoModal();
    }
  }
}


void CAnaWnd::OnStimEnable()
{
CEdit* pe;

  pe=(CEdit*)GetDlgItem(IDC_STIMFILE);
  if(((CButton*)GetDlgItem(IDC_STIMON))->GetCheck())
  {
    GetDlgItemText(IDC_STIMFILE,stimfilename);
    if(stimfilename=="")
	{
      CFileDialog fd(TRUE,"stm",0,0,"Stimulation Files (*.stm)|*.stm|All Files (*.*)|*.*||");
	  if(fd.DoModal()==IDOK)
	  {
        stimfilename=fd.GetPathName();
        SetDlgItemText(IDC_STIMFILE,fd.GetPathName());
      }
	  else
      {
        ((CButton*)GetDlgItem(IDC_STIMON))->SetCheck(FALSE);
        return;
	  }	
	}
	pe->ModifyStyle(0,WS_DISABLED);	
	if(!stimfile.Open(stimfilename,CFile::modeRead|CFile::shareDenyNone))
    {
#ifdef _DEUTSCH
	  AfxMessageBox("Die Datei kann nicht ge�ffnet werden!");	 
#else 
	  AfxMessageBox("Can't open this file!");	
#endif
      return;
    }    
  }
  else
  {
    pe->ModifyStyle(WS_DISABLED,0);
	stimfile.Close();
  }
}

void CAnaWnd::OnMesEnable()
{
ULONG memsize;
char buff[12];

  CMeasurePoint* mp= &((CMainFrame*)theApp.pMainWnd)->pDoc->mpt;
  if(((CButton*)GetDlgItem(IDC_MPENABLE))->GetCheck()) 
  {
    ((CButton*)GetDlgItem(IDC_AUTOSTART))->SetCheck(FALSE);
    ((CButton*)GetDlgItem(IDC_AUTOSTART))->ModifyStyle(0,WS_DISABLED);
    ((CButton*)GetDlgItem(IDC_AUTOSTART))->Invalidate();
    mp->enabled=TRUE;
    if(mp->isValid)
    {      
      mp->SetMeasurePoint(mp->addr);
      CString txt;
      txt.LoadString(IDS_AKTMESPOINT);
      memsize=prc->GetMemSize();
      switch(memsize)
      {
        case S32:  sprintf(buff,": 0x%8.8X",mp->addr);
             break;
        case S16:  sprintf(buff,": 0x%4.4X",mp->addr);
             break;
        case S8:   sprintf(buff,": 0x%4.4X",mp->addr);
             break;
      }
      txt+=buff; 
      GetDlgItem(IDC_MPSTAT)->SetWindowText(txt);
    }
  }
  else
  {
    ((CButton*)GetDlgItem(IDC_AUTOSTART))->ModifyStyle(WS_DISABLED,0);
    ((CButton*)GetDlgItem(IDC_AUTOSTART))->Invalidate();
    mp->enabled=FALSE;
    prc->SetMeasurePoint(0);
    GetDlgItem(IDC_MPSTAT)->SetWindowText("");
  }
}

void CAnaWnd::OnTraceEnable()
{
  if(((CButton*)GetDlgItem(IDC_TRACEENABLE))->GetCheck()) 
  {  
    ((CButton*)GetDlgItem(IDC_ASMTRACE))->ModifyStyle(0,WS_DISABLED);
    ((CButton*)GetDlgItem(IDC_TPOINT))->ModifyStyle(0,WS_DISABLED);
       
    if(((CButton*)GetDlgItem(IDC_TPOINT))->GetCheck())
    {
      if(!((CMainFrame*)theApp.pMainWnd)->pDoc->tpt.isValid)
      {
        CString msgtxt;
        msgtxt.LoadString(IDS_NOTRACEPOINT);
        MessageBox(msgtxt,"TRACE-Enabled",MB_OK|MB_ICONEXCLAMATION);
      }
      if(!((CMainFrame*)theApp.pMainWnd)->pDoc->tpt.expressions.GetSize())
      {
        CTPEdit tped;
        tped.DoModal();
      }      
      theApp.objinfo.EnableTraceLog("temptrace.log",TRACE_WATCH,((CMainFrame*)theApp.pMainWnd)->pDoc->tpt.GetAddr());
    }
    else
      theApp.objinfo.EnableTraceLog("temptrace.log",TRACE_ASM,0);     
    traceEnabled=TRUE;    
  }
  else
  {   
    ((CButton*)GetDlgItem(IDC_ASMTRACE))->ModifyStyle(WS_DISABLED,0);
    ((CButton*)GetDlgItem(IDC_TPOINT))->ModifyStyle(WS_DISABLED,0);
    traceEnabled=FALSE;
    theApp.objinfo.EnableTraceLog(0,0,0);
	  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
	  if( pm->m_pWndTrace && pm->m_pWndTrace->GetStyle() & WS_VISIBLE )
      pm->m_pWndTrace->ReadTraceFile();   
  }
  GetDlgItem(IDC_ASMTRACE)->Invalidate();
  GetDlgItem(IDC_TPOINT)->Invalidate();
}


void CAnaWnd::DisplayMeasureResult()
{
char minbuff[15];
char avbuff[15];
char maxbuff[15];
char buff[200];
float clk;
CString txt,txt1,txt2,txt3,txt4;

   CMeasurePoint* mpt=&((CMainFrame*)AfxGetMainWnd())->pDoc->mpt; 
      if(mpt->isValid)
      {
        ULONG memsize=prc->GetMemSize();      
        if(mpt->measures)
        {      
          txt.LoadString(IDS_AKTMESPOINT);
          txt1.LoadString(IDS_MEASURENO);
          txt2.LoadString(IDS_MINCYCLES); 
          txt3.LoadString(IDS_AVERAGECYCLES);     
          txt4.LoadString(IDS_MAXCYCLES);     
          clk=mpt->MinCycles/clockval/1000000;
          if(clk < 0.001)
            sprintf(minbuff,"%01.2fus",clk*1000000);
          else if(clk < 1)
            sprintf(minbuff,"%01.3fms",clk*1000);
          else 
            sprintf(minbuff,"%01.3fs",clk); 
 
          clk=(mpt->cycles/mpt->measures)/clockval/1000000;
          if(clk < 0.001)
            sprintf(avbuff,"%01.2fus",clk*1000000);
          else if(clk < 1)
            sprintf(avbuff,"%01.3fms",clk*1000);
          else 
            sprintf(avbuff,"%01.3fs",clk);
         
          if(!mpt->MaxCycles)
            mpt->MaxCycles=mpt->MinCycles;
          clk=mpt->MaxCycles/clockval/1000000;
          if(clk < 0.001)
            sprintf(maxbuff,"%01.2fus",clk*1000000);
          else if(clk < 1)
            sprintf(maxbuff,"%01.3fms",clk*1000);
          else 
            sprintf(maxbuff,"%01.3fs",clk);  
          switch(memsize)
          {
            case S32:  sprintf(buff,"%s:\t0x%8.8X\n%s:\t%d\n%s:\t%s\n%s:\t%s\n%s:\t%s",
                       txt,mpt->addr,
                       txt1,mpt->measures,
                       txt2,minbuff,
                       txt3,avbuff,
                       txt4,maxbuff);             
                       break;
            case S16:  sprintf(buff,"%s: 0x%4.4X\n%s:\t%d\n%s:\t%s\n%s:\t%s\n%s:\t%s",
                       txt,mpt->addr,
                       txt1,mpt->measures,
                       txt2,minbuff,
                       txt3,avbuff,
                       txt4,maxbuff);
                       break;
            case S8:   sprintf(buff,"%s: 0x%2.2X\n%s:\t%d\n%s:\t%s\n%s:\t%s\n%s:\t%s",
                       txt,mpt->addr,
                       txt1,mpt->measures,
                       txt2,minbuff,
                       txt3,avbuff,
                       txt4,maxbuff);
                       break;
          }
        }
        else
        {
          txt.LoadString(IDS_AKTMESPOINT);
          txt1.LoadString(IDS_NOMEASURES);
          switch(memsize)
          {
            case S32:  sprintf(buff,"%s: 0x%8.8X\n%s",
                       txt,mpt->addr,
                       txt1);             
                       break;
            case S16:  sprintf(buff,"%s: 0x%4.4X\n%s",
                       txt,mpt->addr,
                       txt1);
                       break;
            case S8:   sprintf(buff,"%s: 0x%2.2X\n%s",
                       txt,mpt->addr,
                       txt1);
                       break;
          }
        }
      }
      else
      {
        ::LoadString(theApp.m_hInstance,IDS_NOMPOINT,buff,sizeof(buff));
      }
      GetDlgItem(IDC_MPSTAT)->SetWindowText(buff);
}

void CAnaWnd::SetClockVal(LPCSTR clk)
{
  SetDlgItemText(IDC_CLOCK,clk);
  sscanf(clk,"%f",&clockval);
  UpdateAnalyser();  
}

CString* CAnaWnd::GetNextCommand()
{
  cmdbuff="";
  if(stimfile.m_hFile==-1) 
    return &cmdbuff;   
  if(stimfile.ReadString(cmdbuff))
    return &cmdbuff;
  else
  {
    stimfile.SeekToBegin();
    stimfile.ReadString(cmdbuff);
  }
  return &cmdbuff;
}

void CAnaWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CMenu popup;
  popup.LoadMenu(IDR_CONTMENU);
  if(docking)
    popup.CheckMenuItem(ID_MRC_ALLOWDOCKING, MF_CHECKED|MF_BYCOMMAND);
  ClientToScreen(&point);
  popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
        point.x,point.y,this);  
	CDialogBar::OnRButtonDown(nFlags, point);
}
