#include <afxtempl.h>

#ifndef _COBJINFO
  #define   _COBJINFO


#include "reginfo.h"
#include "ModDef.h"
#include "Typdesc.h"
#include "measpt.h"


//Verwaltungsinfos f�r die Debuginformationen
typedef struct
      {
		ULONG addr;       //Adresse des Symbols 
		//int type;         //Speicherbereich und Typ 
        int memspec;
        int valrange;
		int ModID;        //zugeh�riges Modul								
		CProcDef* pproc;  //zugeh�rige Prozedurdefinition, 
		CString label;    //Labelname 
        CTypdesc* pTypdesc; //Verweis auf Labeltyp
      } labeldef_t;


 
typedef CMap<CString,LPCSTR,CPtrArray*,CPtrArray*&> CMapStringToPtrArray;
typedef CMap<ULONG,ULONG,CPtrArray*,CPtrArray*&> CMapAddrToPtrArray;
typedef CMap<ULONG,ULONG,WORD,WORD&>CMapAddrToWord;
typedef CMap<ULONG,ULONG,CWordArray*,CWordArray*&> CMapLongToWordArray;

class CObjInfo : public CObject
{
// Operations
public:	
	CString globSrcPath;
  void WriteCurrentTraceRecord(int tracetyp,ULONG pc);
  void WriteCurrentWatchTraceRecord(CArchive* fp, CTracePoint* ptp);
  
  BOOL LoadHexfile(CString& hexfileName);
  BOOL LoadMotorolaHexfile(CString& hexfileName);  
  int ParseObjFile(LPCSTR filename);
  CTime absfiletime;	
  labeldef_t* FindLabel(CString* plabel);
  BOOL FindLabel( ULONG addr, LPSTR lbl,int memspec=0,int valrange=PUBSYM, int precision=0);
  BOOL FindBitLabel(ULONG addr, LPSTR lbl,int memspec,int valrange,int precision=0);
  BOOL FindLabel( ULONG addr, CString& lbl,int memspec=0,int valrange=PUBSYM, int precision=0);
  BOOL FindLabelAddr(const CString& lbl, ULONG* addr, int modID=-1, CProcDef* pproc=NULL );
	
  BOOL ObExt;
  CProcDef* FindProc(CString& pname,CModDef* pmod=0);
  CPtrList typelist;  
  CProcDef* GetProcFromAddr( ULONG addr, CModDef* pmod=NULL );
  BOOL IsHLLLine(ULONG addr);
  BOOL FindPrevHLLAddress(ULONG* addr, int modId=-1);
  BOOL FindNextHLLAddress(ULONG* addr, int modId);
  CModDef* GetLibModule();
  int FindModuleId(CString& modname,CModDef** pm=0);
	
  BOOL FindLineAddr(int lineno, int modID, ULONG* lineaddr=NULL);
  CModDef* GetModuleFromSEGLblAddr(ULONG addr);
  BOOL IsHLLModule(int modid);	
  CModDef* GetModuleFromAddress(ULONG address);
  labeldef_t* FindLabelDesc(const CString& lbl, int modID=-1,CProcDef* pp=0);
  BOOL IsHLL();

  CObjInfo();
  virtual ~CObjInfo();			

public:		
	BOOL orderHL;
	BOOL LoadSDCSymbolInfo(LPCSTR prjname);
  void EnableTraceLog(LPCSTR logname,int tracetyp,ULONG addr=0);
#ifdef _DEBUG
  void DebugTypdesc(CTypdesc* ptd);
  void DebugTypdesc1(CTypdesc* ptd);
  void GetTypname(ULONG typindex,char* typbuf);
#endif
  int tracelen;
  int tracetyp;
  BYTE* prec;
  BOOL objLoaded;
  void Clear();
  void SetModuleName(int index, char* modname);
  int GetModuleCnt();
  int AddModuleInfo( LPCSTR modname=NULL, LPCSTR modpath=NULL);
  
  int AddDbgInfo (ULONG addr, char* label=NULL, int valrange=PUBSYM,int memspec=0,int modid=-1,CProcDef* pproc=0, CTypdesc* ptd=NULL);
  void AddDbgInfo(ULONG addr, ULONG lineno, int modid);
  
  UCHAR* GetRec(CFile* fp); // gibt den n�chsten Record zur�ck
  UCHAR* GetSRec(CFile* fp,BYTE* rec);
  UCHAR* GetHexRec(CFile* fp,BYTE* rec,int bDos); // gibt den n�chsten Trecord eines IntelHexfiles zur�ck
  CPtrArray moduls; 
  CMapStringToPtrArray labels;
  CMapAddrToPtrArray a2lbl;
  CMapLongToWordArray a2line;
protected:
	
	int GetMemSpecFromCDB(char mchar);
	CTypdesc* BuildTypeInfoFromCDBfile(char *pcdb, char *ptypstr, CTypdesc* pparent=NULL);
	BOOL ParseCDBFiles(char* pmap);
	CFile tracefile;
  CString tracename;
  CArchive* traceptr;
  CPtrList* pTmpList;
  void ProcessTypedefRec(LPCSTR bp);

private:
#ifdef _DEBUG
	int typlevel;
  char levelbuf[20];
#endif

};

#endif //_COBJINFO