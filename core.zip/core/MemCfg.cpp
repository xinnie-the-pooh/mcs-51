// MemCfg.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mcfglst.h"
#include "MemCfg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemCfg dialog


CMemCfg::CMemCfg(CWnd* pParent /*=NULL*/)
	: CDialog(CMemCfg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMemCfg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CMemCfg::OnOK() {}

void CMemCfg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMemCfg)
	DDX_Control(pDX, IDC_MEMCFGLIST, mcfglist);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMemCfg, CDialog)
	//{{AFX_MSG_MAP(CMemCfg)
	ON_BN_CLICKED(ID_MOK, OnMok)
	ON_BN_CLICKED(IDC_DEFAULTMEM, OnDefaultmem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemCfg message handlers

BOOL CMemCfg::OnInitDialog() 
{
LV_COLUMN lvc;
RECT rc;


CDialog::OnInitDialog();
  //mcfglist.SubclassDlgItem(IDC_MEMCFGLIST,this);   
mcfglist.Create(); 
mcfglist.GetClientRect(&rc);

    // zuerst alle Spalten anlegen
lvc.mask=LVCF_WIDTH|LVCF_TEXT;
lvc.iSubItem=0;
#ifdef _DEUTSCH
    lvc.pszText="Typ";
#else
    lvc.pszText="typ";
#endif
  lvc.cx=rc.right-220;    
  mcfglist.InsertColumn(0,&lvc);  //Spalte 0
#ifdef _DEUTSCH
    lvc.pszText="Anfang";
#else
    lvc.pszText="start";
#endif
  lvc.cx=110;  
  mcfglist.InsertColumn(1,&lvc);  //Spalte 1
#ifdef _DEUTSCH
    lvc.pszText="Ende";
#else
    lvc.pszText="end";
#endif
  lvc.cx=110;  
  mcfglist.InsertColumn(2,&lvc);  //Spalte 2  
  
  UpdateMemcfg(); 
  return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CMemCfg::OnMok() 
{
int n,i;
ULONG s,e,m;
CString txt;
    
  mcfglist.edit.GetWindowText(txt);
  mcfglist.edit.SetWindowText("");
  mcfglist.edit.ShowWindow(SW_HIDE);
  mcfglist.SetItemText(mcfglist.edit.act,mcfglist.edit.actsub,txt);
  n=mcfglist.GetItemCount();
  prc->DeleteMem(-1);
  i=0;
  while(i<n-1)
  {
    txt=mcfglist.GetItemText(i,0);
    if(txt == "")
      m='C';
    else
      m=txt[0];    
    txt=mcfglist.GetItemText(i,1);     
    s=strtoul(txt,0,16);
    txt=mcfglist.GetItemText(i,2);
    e=strtoul(txt,0,16);
    if(s<=e)  //Check valid
      prc->CreateMemInRange(m,s,e);
    i++;
  }
  UpdateMemcfg();  
}

void CMemCfg::UpdateMemcfg()
{
char buff[20];
mcfg_t mcfg;

  mcfglist.edit.ShowWindow(SW_HIDE);
  mcfglist.edit.SetWindowText("");
  mcfglist.edit.act=-1;
  mcfglist.edit.actsub=-1;
  
  mcfglist.DeleteAllItems();
  mcfglist.InsertItem(0,"");
  mcfglist.SetItemText(0,1,"");
  mcfglist.SetItemText(0,2,"");
  mcfglist.SetItemData(0,1);
  int block=0;
  while(block != -1)
  {
    block=prc->GetNextMemMapping(&mcfg,block);
    if(block==-1)
      break;
    buff[0]=(char)mcfg.memspec;
    buff[1]=0;
    mcfglist.InsertItem(0,buff);
    mcfglist.SetItemData(0,mcfg.editable);
    int s=prc->GetMemSize(mcfg.memspec);
    switch(s)
    {
      case S8: 
               sprintf(buff,"0x%2.2X",mcfg.startaddr);
               mcfglist.SetItemText(0,1,buff);    
               sprintf(buff,"0x%2.2X",mcfg.endaddr);
               mcfglist.SetItemText(0,2,buff);
               break;
      case S16: 
               sprintf(buff,"0x%4.4X",mcfg.startaddr);
               mcfglist.SetItemText(0,1,buff);    
               sprintf(buff,"0x%4.4X",mcfg.endaddr);
               mcfglist.SetItemText(0,2,buff);
               break;
      case S32: 
      default:
               sprintf(buff,"0x%8.8X",mcfg.startaddr);
               mcfglist.SetItemText(0,1,buff);    
               sprintf(buff,"0x%8.8X",mcfg.endaddr);
               mcfglist.SetItemText(0,2,buff);
               break; 
    }
  }
}


void CMemCfg::OnDefaultmem() 
{	
  prc->CreateMemInRange((ULONG)-1);
  UpdateMemcfg();
}

