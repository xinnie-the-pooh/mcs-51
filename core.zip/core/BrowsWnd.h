// BrowsWnd.h : header file
//

#include "moddef.h"

#ifndef _BROWSEWND
#define _BROWSEWND


typedef struct
{
  int typ;
  CModDef* pm;
  CProcDef* pp;
}bref_t;

/////////////////////////////////////////////////////////////////////////////
// CBrowsWnd window
#define CBRS_ALIGN_BROWSWND  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT 
#define ICOMODUL 1
#define ICOPROC  0

#define ISMOD  1
#define ISPROC 2

class CBrowsWnd : public CMRCSizeDialogBar
{
// Construction
public:
	void Expand();
	
	void Clear();
	void AddProc(CProcDef* pp,CModDef* pm=0);	
	void AddRoot(CString& prjname);
	void InsertModule(CModDef* pm);
	CTreeCtrl tree;
	BOOL Create( CWnd* pParentWnd );
	CBrowsWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBrowsWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBrowsWnd();

	// Generated message map functions
protected:
	void DeleteSubItems(HTREEITEM subItem);
	HTREEITEM actItem;
    HTREEITEM libItem;
    HTREEITEM root;
    CImageList treeicons;
	//{{AFX_MSG(CBrowsWnd)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
  afx_msg void OnTreeSelChanged( NMHDR * pNotifyStruct, LRESULT * result );
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_BROWSEWND
/////////////////////////////////////////////////////////////////////////////
