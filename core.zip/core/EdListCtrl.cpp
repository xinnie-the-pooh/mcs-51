// EdListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "reginfo.h"
#include "Proc.h"
#include "EdListCtrl.h"
#include "Jstep.h"
#include "Mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEdListCtrl

CEdListCtrl::CEdListCtrl()
{
  selitem=-1;
  lastsel=-1;
}


CEdListCtrl::~CEdListCtrl()
{
}


BEGIN_MESSAGE_MAP(CEdListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CEdListCtrl)  
	ON_WM_SIZE()
	ON_WM_KILLFOCUS()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
  ON_MESSAGE(UM_ENTER,ProcessChanges)   
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEdListCtrl message handlers






// liefert zu einem Punkt das zugeh�rige Rechteck ,Index und SubIndex
BOOL CEdListCtrl::GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc)
{
BOOL b;
int ncol;
int w;
LV_COLUMN lvc;
int x;

  
  UINT flags=LVHT_ONITEM |LVHT_TORIGHT ;
  lvi->iItem=HitTest(point,&flags);  //finde den Index des Items zum Punkt
	GetItemRect(lvi->iItem,rc,LVIR_LABEL);
  x=point.x;
  point.x=rc->left;
  if( lvi->iItem == -1) //item nicht gefunden
	  return FALSE;	
	lvc.mask=LVCF_WIDTH ;
	ncol=0;
	w=0;
  do
	{
    b=GetColumn(ncol,&lvc);
		if(b)                 
    {
			rc->left=w;
      w+=lvc.cx;
			if(x <=w)
      {   // die Spalte haben wir gesucht        
				rc->right=w;
				lvi->iSubItem=ncol;
				return TRUE;
      }
    } 
		ncol++;
	}while(b);
	return FALSE;
}

#define DEFAULT_TEXTDRAW  DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER
#define TEXTOFFSET 2

void CEdListCtrl::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
CDC* pDC;
CRect rcItem;
int nItem;
int len;
LV_ITEM lvi;
LV_COLUMN lvc;
BOOL bSelected;
char szBuff[100];
COLORREF bkcolor,txtcolor;
RECT rc,rc1;
CBrush br((COLORREF)0);
CString txt;

  lvc.mask=LVCF_WIDTH;
	GetClientRect(&rc);  
  
  rcItem=lpDrawItemStruct->rcItem;	
	nItem=lpDrawItemStruct->itemID;	
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);

	//Draw label in the first Column

	len=GetColumnWidth(0);
	if(len<40)
  {
    SetColumnWidth(0,40);
    return;
  }
  lvi.mask=LVIF_STATE;
	lvi.iItem=nItem;
	lvi.iSubItem=0;
	lvi.stateMask=0xFFFF;		// get all state flags
	GetItem(&lvi);  
	GetItemRect(nItem,rcItem,LVIR_LABEL);	
	bSelected=lvi.state & LVIS_SELECTED;	
   
  if(bSelected)
	{   
    //Hintergrund Spalte 0 =sw	
		GetColumn(0,&lvc);
    bkcolor=pDC->SetBkColor(0);
    txtcolor=pDC->SetTextColor(0xFFFFFF); //text weiss
    rcItem.left=TEXTOFFSET;
    rcItem.right=lvc.cx;		
    pDC->FillSolidRect(&rcItem,0); //Rechteck schwarz
    GetItemText(nItem,0,szBuff,sizeof(szBuff));
		pDC->DrawText(szBuff,-1,rcItem,DEFAULT_TEXTDRAW);
		pDC->SetTextColor(txtcolor);
    pDC->SetBkColor(bkcolor);
    

		// auf die Spalte 1 wird das Editcontrol geschoben
    GetColumn(1,&lvc);
		rcItem.left=rcItem.right+TEXTOFFSET;
		rcItem.right+=lvc.cx-TEXTOFFSET;
		txt=GetItemText(nItem,1);	    
		if(nItem != edit.act)
    {    
      edit.SetText(txt);
      lastsel=edit.act;
			edit.act=nItem;         
    }
    edit.SetWindowPos(&wndTop,
		                  rcItem.left,
		    						  rcItem.top,
				  					  lvc.cx-TEXTOFFSET,
					  				  rcItem.bottom-rcItem.top,
						  			  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
    
    edit.Invalidate(FALSE);
    edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols
    
		if(selitem !=nItem)
    {
		  RedrawItemUnsel(selitem,pDC);	      
		  selitem=nItem;
    }
  }
	else
  {      
	  RedrawItemUnsel(nItem,pDC);
  }
	if(selitem!=-1 && nItem != selitem ) //verschiebe das editcontrol
  {		
    GetItemRect(selitem,rcItem,LVIR_LABEL);
    GetItemRect(GetTopIndex(),&rc1,LVIR_LABEL);
		if(rcItem.top < rc1.top)
			edit.ShowWindow(SW_HIDE);
		else
    {
      GetColumn(1,&lvc);
		  rcItem.left=rcItem.right+TEXTOFFSET;		  			
		  edit.SetWindowPos(&wndTop,
				              rcItem.left,
											rcItem.top,
											lvc.cx-TEXTOFFSET,
											rcItem.bottom-rcItem.top,
											SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);
      edit.Invalidate(FALSE);
      edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols			 
    }
  }
}


void CEdListCtrl::Create()
{  
  const RECT rc={0,0,10,10};
	edit.Create(WS_CHILD|WS_BORDER|WS_OVERLAPPED|ES_NOHIDESEL|ES_MULTILINE|ES_WANTRETURN,rc,this,0);
	edit.SetFont(GetFont(),FALSE);	
}


// zeichnet eine nichtselektierte Zeile

void CEdListCtrl::RedrawItemUnsel(int item, CDC* pDC)
{
RECT rcItem;
int ncol;
BOOL b;
RECT rc;
int w;
LV_COLUMN lvc;
char szBuff[100];
COLORREF txtcolor;


  if(item==-1)
		return;
  // Draw Text for all Cols  
  GetClientRect(&rc);
	GetItemRect(item,&rcItem,LVIR_LABEL);	
  rcItem.left=TEXTOFFSET;		
  rcItem.right=rc.right;
  
  pDC->FillSolidRect(&rcItem,pDC->GetBkColor()); //Rechteck mit normaler Hintergrundfarbe �ber die ganze Breite		
  w=0;
  ncol=0;
	lvc.mask=LVCF_WIDTH ;
  do 
  {
    b=GetColumn(ncol,&lvc);
	  if(b)
    {				
      rcItem.left=w+1+TEXTOFFSET;
 		  rcItem.right=rcItem.left+lvc.cx;
      w=rcItem.right;        		  
			CRegdef* preg=(CRegdef*)GetItemData(item);
			if(preg->bchanged && ncol>0)  // die erste Spalte ist immer schwarz
        txtcolor=pDC->SetTextColor(0xFF);  //rot
			else
				txtcolor=pDC->SetTextColor(0);  //schwarz
		  GetItemText(item,ncol++,szBuff,sizeof(szBuff));      
		  pDC->DrawText(szBuff,-1,&rcItem,DEFAULT_TEXTDRAW);
			pDC->SetTextColor(txtcolor);
    }
  }while(b);	
}


void CEdListCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CListCtrl::OnSize(nType, cx, cy);
	int c1=cx-GetColumnWidth(0);
  SetColumnWidth(1,c1);	
}



void CEdListCtrl::OnKillFocus(CWnd* pNewWnd) 
{	
CString txt;
LV_ITEM lvi;
 	 
  if(pNewWnd == this || pNewWnd ==&edit)
    return;
  lvi.state=0;
  lvi.stateMask=0xFFFF;
  SetItemState(selitem,&lvi);
  edit.ShowWindow(SW_HIDE);      
  edit.GetWindowText(txt);    
  selitem=-1;
}

void CEdListCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
LV_ITEM lvi;
RECT rc;
CString txt; 
    
	GetItemRectFromPoint(point,&lvi,&rc);
	lvi.mask=LVIF_STATE;
  
  if(GetItemState(lvi.iItem,LVIS_SELECTED))
  {  //ist schon selektiert deshalb verschwindenlassen und bei Bedarf updaten    
	  lvi.state=0;
    lvi.stateMask=0xFFFF;
    SetItemState(lvi.iItem,&lvi);
    edit.ShowWindow(SW_HIDE);     
    edit.GetWindowText(txt);    
  }
 	else  //noch nicht selektiert deshalb edit control laden und anzeigen
  { 
    edit.GetWindowText(txt);
    txt=GetItemText(lvi.iItem,1);	 
    edit.SetWindowText(txt);
    edit.SetFocus();
    lvi.state=LVIS_SELECTED;
    lvi.stateMask=0xFFFF;
    SetItemState(lvi.iItem,&lvi);
   
		//CListCtrl::OnLButtonDown(nFlags, point);    
  }
}

void CEdListCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	edit.SetFocus();
	edit.SetSel(0,-1);	
	CListCtrl::OnLButtonDblClk(nFlags, point);
}



//pr�ft die G�ltigkeit des eingegebenen Wertes. Wenn OK und ge�ndert wird der wert auf 
// *pcurval geschrieben,return=TRUE

BOOL CEdListCtrl::CheckValid(int item, CString& txt)
{
int fmt;
CRegdef* preg;  
ULONG val;

  if(item==-1)
		return FALSE;
	if(! IsNum(txt))
    return FALSE;
  if(txt.Left(2)=="0x") //hexwert eingegeben
    val=strtoul(txt,NULL,16);
	else if(txt.Right(1)=='B') //bin�r
    val=strtoul(txt,NULL,2);
  else                   //dezimal
    val=strtoul(txt,NULL,10);
  preg=(CRegdef *)GetItemData(item);
  fmt=preg->regfmt;  
  if(fmt & (BYTE_HEX|BYTE_BIN))  //Byte
  {
		if( val < 256)
    {			  
	    if(preg->SetRegVal(val) != val)
      {       
		    return(TRUE);
      }
		} 	
	}
	else if(fmt & (SHORT_HEX|SHORT_BIN|SHORT_HEX_INVERS))  //SHORT
  {
		if( val < 0x10000)
    {
	    if(preg->SetRegVal(val) != val)
      {        
		    return(TRUE);
      }
		} 	
	}
  if(fmt & (LONG_HEX|LONG_BIN|LONG_HEX_INVERS))  //LONG
  {
		if(preg->SetRegVal(val) != val)
    {      
		  return(TRUE);
    }		
	}
  return FALSE;
}

//setzt den Eintrag in der Liste entsprechend dem wert im Register
//regindex==Listen Index
void CEdListCtrl::SetItemValText(int regindex)
{
CString sval;
CString txt;

	CRegdef* preg=(CRegdef*)GetItemData(regindex);
  txt=GetItemText(regindex,1);
	if (preg)
  {
    void* pv=preg->GetRegPtr();
	  if(preg->regfmt & BYTE_HEX)                //ein Byte hexadezimal
      sval.Format("0x%2.2X",*(UCHAR*)pv);
    else if(preg->regfmt & SHORT_HEX)          //zwei Byte hexadezimal HIGH-LOW
      sval.Format("0x%4.4X",*(USHORT*)pv);
	  else if(preg->regfmt & LONG_HEX)           //vier Byte hexadezimal HIGH-LOW
      sval.Format("0x%8.8X",*(ULONG*)pv);
    else if(preg->regfmt & SHORT_HEX_INVERS)   //zwei Byte low-High
    {
      UCHAR* ph=(UCHAR*)pv;
      sval.Format("0x%2.2X%2.2X",*(ph+1),*ph);
    }
    else if(preg->regfmt & LONG_HEX_INVERS)   //zwei Byte low-High
    {
      UCHAR* ph=(UCHAR*)pv;
      sval.Format("0x%2.2X%2.2X%2.2X%2.2X",*(ph+3),*(ph+2),*(ph+1),*ph);
    }
  	else if(preg->regfmt & BINARY)  //1,2,4Byte Bin�r //HIGH-LOW
		  ::GetBinString(preg->regfmt,pv,sval);    
		if(sval!=txt)
    {
      preg->bchanged=TRUE;
		  SetItemText(regindex,1,sval);				
    }
		else if(preg->bchanged)
    {
			RedrawItems(regindex,regindex);
      preg->bchanged=FALSE;
    }
    if(regindex==edit.act)
      edit.SetWindowText(sval);
  }
}

void CEdListCtrl::UpdateList()
{
int items;
  
  items=GetItemCount();
	while(items--)
  {		      
    SetItemValText(items);     	 
  }    
}

long CEdListCtrl::ProcessChanges(UINT wparam, LONG lparam)
{
CString txt;
  
  SetRedraw(FALSE);
  edit.GetWindowText(txt);
  edit.ShowWindow(SW_HIDE);
  SetItemState(selitem,0,LVIS_SELECTED);  
  if(CheckValid(selitem,txt))
  {
    UpdateList();
  } 
  ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches();
  selitem=-1;
  SetRedraw(TRUE);
  return(0);
}



void CEdListCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//CListCtrl::OnRButtonDown(nFlags, point);//verhindert das Kontextmen�
}
