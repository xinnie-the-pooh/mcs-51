// QuickWatch.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "QuickWatch.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQuickWatch dialog


CQuickWatch::CQuickWatch(LPCSTR expression,CWnd* pParent)
	: CDialog(CQuickWatch::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQuickWatch)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
  exprtxt=expression;
 
}


void CQuickWatch::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQuickWatch)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQuickWatch, CDialog)
	//{{AFX_MSG_MAP(CQuickWatch)
	ON_BN_CLICKED(IDC_RECALCULATE, OnRecalculate)	
	ON_BN_CLICKED(IDC_CLOSEQUICK, OnClosequick)
	ON_BN_CLICKED(IDC_ADDWATCH, OnAddwatch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQuickWatch message handlers


BOOL CQuickWatch::OnInitDialog() 
{
int cnt;

	CDialog::OnInitDialog();
  SetDlgItemText(IDC_EXPRESSION,exprtxt);
  hlc.SubclassDlgItem(IDC_QUICKWATCH,this); 
	hlc.Create();	
  hlc.SetBkColor(0xE0E0E0);
  hlc.AddWatchExpression(exprtxt,TRUE);
  cnt=hlc.GetItemCount();
  item_t* pi=(item_t*)hlc.GetItemData(cnt-1);
  pi->editable[0]=FALSE;
  hlc.UpdateWatchWnd(TRUE);
	return TRUE;  
}

void CQuickWatch::OnOK()   // ENTER im EditWindow
{
  CEdit* pe =(CEdit*)GetDlgItem(IDC_EXPRESSION);
  if(pe->GetModify())
  {
    pe->GetWindowText(exprtxt);
    item_t* pi=(item_t*)hlc.GetItemData(0);
    hlc.CloseTree(0,pi); 
    hlc.DeleteItem(1);
    hlc.AddWatchExpression(exprtxt,TRUE); 
  }
}

void CQuickWatch::OnRecalculate() 
{
int cnt;

  CEdit* pe =(CEdit*)GetDlgItem(IDC_EXPRESSION);
	pe->GetWindowText(exprtxt);
  item_t* pi=(item_t*)hlc.GetItemData(0);
  hlc.CloseTree(0,pi); 
  hlc.DeleteItem(1);
  hlc.AddWatchExpression(exprtxt,TRUE);  
 	cnt=hlc.GetItemCount();
  pi=(item_t*)hlc.GetItemData(cnt-1);
  pi->editable[0]=FALSE;
}

void CQuickWatch::OnClosequick() 
{
	CDialog::OnOK();	
}

void CQuickWatch::OnAddwatch() 
{
	CMainFrame* pm= (CMainFrame*)AfxGetMainWnd();
  if(pm->m_wndWatch.Created)
    pm->m_wndWatch.hlc.AddWatchExpression(exprtxt);	
  else
  {
    pm->m_wndWatch.Create( pm ); 
    pm->m_wndWatch.barIsInitialised=TRUE;
    pm->FloatControlBar(&pm->m_wndWatch,pm->m_wndWatch.m_FloatingPosition);
    pm->m_wndWatch.hlc.AddWatchExpression(exprtxt);
    pm->ShowControlBar(&pm->m_wndWatch,TRUE,FALSE);
  }
}
