// Implementierung der KLasse CRegInfo und CRegdef

#include "stdafx.h"
#include "proc.h"
#include "reginfo.h"
#ifdef _USRDLL
  #include "../8051/procdll.h"
#else
  #include "jstep.h"
#endif 



CRegInfo::CRegInfo()
{
  regno=0;
  nextindex=0;
}
  

CRegInfo::~CRegInfo()
{
POSITION pos;
CRegdef* preg;
  
  pos=reglist.GetHeadPosition();
	while(pos)
  {
    preg=(CRegdef*)reglist.GetAt(pos);
		delete preg;
    preg=(CRegdef*)reglist.GetNext(pos);
  }
}

void CRegInfo::AddReg(LPCSTR name, void* ploc, int fmt)
{
  CRegdef* preg=new CRegdef;
  //Name darf maximal 9 Zeichen lang sein
  strcpy(preg->regname,name);  
  preg->regfmt=fmt & ~REGVARLOC;
  preg->SetRegLoc(ploc,fmt & REGVARLOC);
  reglist.AddTail(preg);
  regno++;
}

CRegdef* CRegInfo::GetReg(int index)
{
POSITION pos;
  
  if(index==-1)
  {
    pos=reglist.FindIndex(nextindex);
    if(pos)
    { 
      nextindex++;  
	  return (CRegdef*)reglist.GetAt(pos);
    }
    else
    {
      nextindex=0;
      return 0;
    }
  }
  else
  {   
    pos=reglist.FindIndex(index);
    if(pos)
    { 
      nextindex++;  
      return (CRegdef*)reglist.GetAt(pos);
    }
    else
    {
      nextindex=0;
      return 0;
    }
  }
}



//setzt den Wert eines Registers typsicher
void CRegInfo::SetReg(int index, ULONG val)
{
  POSITION pos=reglist.FindIndex(index);
  if(pos)
  {
	  CRegdef* preg=(CRegdef*)reglist.GetAt(pos);		
    preg->SetRegVal(val);     
  }
	return;
}

void* CRegdef::GetRegPtr()
{
  if(varloc)
    return ((UCHAR*)pcurval+prc->GetRegOffset());
  return(pcurval);
}


ULONG CRegdef::SetRegVal(ULONG val)
{
ULONG ret=0; 
UCHAR* puc;
UCHAR* pval;

  pval=(UCHAR*)pcurval;
  if(varloc)
    pval+=prc->GetRegOffset();
  
  switch(regfmt)
  {
	case BYTE_HEX:
    case BYTE_BIN:     //1 Byte
          ret=(ULONG)(*(UCHAR*)pval);
		  *(UCHAR*)pcurval=(UCHAR)val;
				break;
    case SHORT_HEX:
    case SHORT_BIN:     //2 Byte
	      ret=(ULONG)(*(USHORT*)pval);
		  *(USHORT*)pcurval=(USHORT)val;    
		  break;
    case LONG_HEX:
    case LONG_BIN:     //4 Byte
		  ret=*(ULONG*)pval;
		  *(ULONG*)pcurval=val;
				break;
    case SHORT_HEX_INVERS:   //short invers low-high
        puc= (UCHAR*)pval;
        ret=*puc++;        
        ret+=(*puc)<<8;        
        *puc=(UCHAR)((val & 0xFF00)>>8);
        puc--;
        *puc=(UCHAR)(val & 0xFF);
        break; 
    case LONG_HEX_INVERS:   //long invers low-high
        puc= (UCHAR*)pval;
        ret=*puc++;        
        ret+=(*puc++)<<8;     
        ret+=(*puc++)<<16;
        ret+=(*puc)<<24;         
        *puc=(UCHAR)((val & 0xFF00)>>24);
        puc--;
        *puc=(UCHAR)((val & 0xFF00)>>16);
        puc--;
        *puc=(UCHAR)((val & 0xFF00)>>8);
        puc--;
        *puc=(UCHAR)(val & 0xFF);
        break; 
	}
	return ret;
}

CRegdef::CRegdef()
{
  bchanged=FALSE;   
}

ULONG CRegdef::GetRegVal()
{
ULONG ret=0; 
UCHAR* puc;
UCHAR* pval;

  pval=(UCHAR*)pcurval;
  if(varloc)
    pval+=prc->GetRegOffset();
  
  switch(regfmt)
  {
		case BYTE_HEX:
    case BYTE_BIN:     //1 Byte
			  ret=(ULONG)(*(UCHAR*)pval);
				break;
    case SHORT_HEX:
    case SHORT_BIN:     //2 Byte
			  ret=(ULONG)(*(USHORT*)pval);			 
				break;
    case LONG_HEX:
    case LONG_BIN:     //4 Byte
			  ret=*(ULONG*)pval;			 
				break;
    case SHORT_HEX_INVERS:   //short invers low-high
        puc= (UCHAR*)pval;
        ret=*puc++;        
        ret+=(*puc)<<8;        
        break; 
    case LONG_HEX_INVERS:   //long invers low-high
        puc= (UCHAR*)pval;
        ret=*puc++;        
        ret+=(*puc++)<<8;     
        ret+=(*puc++)<<16;
        ret+=(*puc)<<24;                 
        break; 
	}
	return ret;
}

void CRegdef::SetRegLoc(void* loc,BOOL vloc)
{ 
  pcurval=loc;
  varloc=vloc;
}