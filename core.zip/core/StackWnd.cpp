// StackWnd.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "proc.h"
#include "JSTEPView.h" 
#include "Mainfrm.h"
#include "StackWnd.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStackWnd

CStackWnd::CStackWnd()
{
  memsize=S32;
  lastproc=0;  
}

CStackWnd::~CStackWnd()
{
}


BEGIN_MESSAGE_MAP(CStackWnd, CMRCSizeDialogBar)
	//{{AFX_MSG_MAP(CStackWnd)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CStackWnd message handlers

BOOL CStackWnd::Create(CWnd* pParentWnd,BOOL visible)
{
BOOL b;

  b= CMRCSizeDialogBar::Create(pParentWnd, IDD_STACK
		             ,CBRS_ALIGN_STACKWND|CBRS_SIZE_DYNAMIC
			  	     ,IDD_STACK);	 
  if(!visible)
     ModifyStyle(WS_VISIBLE,0,SWP_NOACTIVATE);
  
  Created=b;
  if(b)
  {        
    lbx.SubclassDlgItem(IDC_STACKLIST,this);
    SetBarStyle( GetBarStyle()			         
							 | CBRS_FLYBY 							 
							 | CBRS_BORDER_ANY 
							 | CBRS_BORDER_3D );	
    SetWindowText(_T("Call Stack"));

    EnableDocking(CBRS_ALIGN_STACKWND);
    RECT rd;
    GetDesktopWindow()->GetWindowRect(&rd);    		
    CPoint pt;
    pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;	
    m_FloatingPosition=pt;	
        
    memsize=prc->GetMemSize(0);    
    pobj=&((CJSTEPApp*)AfxGetApp())->objinfo;     
    lbx.InsertString(0,"Program Counter");
  }  
  return b;  
}

void CStackWnd::OnSize(UINT nType, int cx, int cy) 
{
RECT rc,re;
 
  CMRCSizeDialogBar::OnSize(nType, cx, cy);
  if(Created)
  {
    GetWindowRect(&rc);
    if(!IsFloating())
    {
      re.top=rc.top+16;
      GetDlgItem(IDC_STATIC1)->ModifyStyle(0,WS_VISIBLE,FALSE);
    }
    else
    {
      re.top=rc.top;
      GetDlgItem(IDC_STATIC1)->ModifyStyle(WS_VISIBLE,0,FALSE);
    }
	  re.left=rc.left;
    re.right=rc.right;
    re.bottom=rc.bottom;  
    ScreenToClient(&re);  	
    lbx.MoveWindow(&re,TRUE);	        
  }
}

void CStackWnd::AddToCallStackWnd(ULONG callAddr,ULONG returnAddr)
{
CString txt,txt1;
  
  if(!Created)
    return;   
  txt1.LoadString(IDS_CALLEDFROM);
  ULONG addr=prc->GetProgramCounter();
  CProcDef* pp=pobj->GetProcFromAddr(addr);
  if(!pp)
  {
    switch(memsize)
    {
    case S8:  txt.Format(" %s0x%2.2X",txt1,callAddr);
              break;
    case S16: txt.Format(" %s0x%4.4X",txt1,callAddr);
              break;
    case S32: txt.Format(" %s0x%8.8X",txt1,callAddr);
              break;
    }      
  }
  else
  {  
    lastproc=pp;
    switch(memsize)
    {
      case S8:  txt.Format(" %s(..)%s0x%2.2X",pp->Procname,txt1,callAddr);
                break;
      case S16: txt.Format(" %s(..)%s0x%4.4X",pp->Procname,txt1,callAddr);
                break;
      case S32: txt.Format(" %s(..)%s0x%8.8X",pp->Procname,txt1,callAddr);
                break;
    }
  }  
  lbx.InsertString(1,txt); 
  lbx.SetItemData(1,returnAddr);  
}  

void CStackWnd::RemoveFromCallStackWnd(ULONG returnAddr)
{
ULONG addr;
int n,i;
  
  if(!lbx.m_hWnd)
    return;
  if(lbx.pvlast)
    ((CJSTEPView*)lbx.pvlast)->ResetStackCursor();
  n=lbx.GetCount();
  if(!n)
    return;
  addr=lbx.GetItemData(1);
  if(addr==returnAddr)
    lbx.DeleteString(1);
  else
  {    
    for(i=2;i<n;i++)
    {
      addr=lbx.GetItemData(1);
      lbx.DeleteString(1);
      if(addr!=returnAddr)
        return;
      n=lbx.GetCount();
    }
  }
}

void CStackWnd::Clear()
{  
  if(!lbx.m_hWnd)
    return;
  lbx.ResetContent();
  if(lbx.pvlast)
    ((CJSTEPView*)(lbx.pvlast))->ResetStackCursor();
  lbx.pvlast=0;
  lbx.InsertString(0,"Program Counter");
}

void CStackWnd::EnableUpdate(BOOL enable)
{
RECT rc;
  
  if(!lbx.m_hWnd)  
    return;
  CClientDC dc(&lbx);
  lbx.GetClientRect(&rc);
  if(enable && !lbx.unlocked)
  {
    CClientDC dc(&lbx);
    lbx.GetClientRect(&rc);
    lbx.unlocked=TRUE;
    lbx.unlocked1=TRUE;
    lbx.SetRedraw(TRUE);           
    rc.top+=3;
    rc.bottom =rc.top+14;
    rc.left+=8;        
    lbx.InvalidateRect(&rc,TRUE); 
    lbx.Invalidate(FALSE);    
  }
  else if(!enable && lbx.unlocked)
  {
    CClientDC dc(&lbx);
    lbx.GetClientRect(&rc);
    lbx.unlocked=FALSE;
    lbx.unlocked1=FALSE; 
    lbx.SetRedraw(FALSE);           
    dc.SelectObject(&lbx.lfont);
    dc.FillSolidRect(&rc,dc.GetBkColor());    
    rc.top+=3;
    rc.bottom =rc.top+14;
    rc.left+=8;
    rc.right -=3;
    CString txt;
    txt.LoadString(IDS_STACKAV);
    dc.DrawText(txt,-1,&rc,DT_SINGLELINE|DT_TOP);                    
  }
}


void CStackWnd::UpdateLevel0()
{
  if(!Created)
    return;  
  CString txt;
  ULONG addr=prc->GetProgramCounter(); 
  CProcDef* pp=pobj->GetProcFromAddr(addr);
  if(!pp || pp==lastproc)
    return;
  lastproc=pp;
  switch(memsize)
  {
    case S8:  txt.Format(" %s(..), 0x%2.2X",pp->Procname,pp->EndAddr);
              break;
    case S16: txt.Format(" %s(..), 0x%4.4X",pp->Procname,pp->EndAddr);
              break;
    case S32: txt.Format(" %s(..), 0x%8.8X",pp->Procname,pp->EndAddr);
              break;
  }    
  lbx.DeleteString(1);
  lbx.InsertString(1,txt);  
  lbx.SetItemData(1,pp->EndAddr);
}
