// StackList.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "jstepview.h"
#include "StackList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStackList

CStackList::CStackList()
{
  unlocked=TRUE;
  unlocked1=TRUE;
  lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier");
  pvlast=0;
}

CStackList::~CStackList()
{
}


BEGIN_MESSAGE_MAP(CStackList, CListBox)
	//{{AFX_MSG_MAP(CStackList)
	ON_WM_LBUTTONDBLCLK()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStackList message handlers

void CStackList::OnLButtonDblClk(UINT nFlags, CPoint point) 
{	
CString txt;
ULONG addr;
int i;
CModDef* pmod;
CJSTEPView* pv;
  
  
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pm->pDoc->b_DbgRun)
    return; 
  i=GetCurSel();
  if(i==-1)
    return; 
  if(!i)
  {       
    pm->pDoc->ViewNewModule(prc->GetProgramCounter(),TRUE,FALSE); 
    return;
  }
  GetText(i,txt);  
  i=txt.ReverseFind('x');
  txt=txt.Mid(i+1);
  addr=strtoul(LPCSTR(txt),0,16);
  pmod=theApp.objinfo.GetModuleFromAddress(addr);
  if(pmod)
  {
    int modid=pmod->ModID;
    pv=(CJSTEPView*)pm->pDoc->GetViewFromModule(pmod);
    if(!pv)  //wird noch nicht angezeigt
    {
      pm->pDoc->ViewNewModule(addr,FALSE,TRUE); 
      pvlast=(CJSTEPView*)pm->pDoc->GetViewFromModule(pmod);
      return;
    } 
    if(pv==pvlast)
    {
      pv->ResetStackCursor();
      pvlast=0;    
    }
    else
    {
      if(pvlast)
        ((CJSTEPView*)pvlast)->ResetStackCursor();
    
      if(theApp.objinfo.IsHLLModule(modid))
      {        
        if(pv->GetViewMode()==HLL)
          theApp.objinfo.FindPrevHLLAddress(&addr);
      } 
      pvlast=pv;
      pm->pDoc->ViewNewModule(addr,FALSE,TRUE);  
    }
  }
  else
     pm->pDoc->ViewNewModule(addr,FALSE,TRUE);  
}



void CStackList::OnPaint() 
{
	
	if(unlocked1==FALSE)
  {
    CPaintDC dc(this); // device context for painting	
	  RECT rc;         
    dc.SelectObject(&lfont);
    GetClientRect(&rc);
    dc.FillSolidRect(&rc,dc.GetBkColor());    
    rc.top+=3;
    rc.bottom =rc.top+14;
    rc.left+=8;    
    CString txt;
    txt.LoadString(IDS_STACKAV);
    dc.DrawText(txt,-1,&rc,DT_SINGLELINE|DT_TOP);    
  }
	else
	  CListBox::OnPaint();
}
