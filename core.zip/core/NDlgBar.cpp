// NDlgBar.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "jstep.h"
#include "NDlgBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNDlgBar

CNDlgBar::CNDlgBar()
{
  docking=TRUE;
}

CNDlgBar::~CNDlgBar()
{
}

void CNDlgBar::OnDock()
{
  if(docking)
    EnableDocking(FALSE);
  else
    EnableDocking(CBRS_ALIGN_ANY);
  docking=!docking; 
}

void CNDlgBar::OnHide()
{
  CFrameWnd * pFrameWnd = GetParentFrame();
	pFrameWnd->ShowControlBar(this, FALSE, FALSE);
}

void CNDlgBar::OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler)
{
  UpdateDialogControls(pTarget, FALSE);
}

BEGIN_MESSAGE_MAP(CNDlgBar, CDialogBar)
	//{{AFX_MSG_MAP(CNDlgBar)
	ON_WM_RBUTTONDOWN()
  ON_COMMAND(ID_MRC_ALLOWDOCKING,OnDock)
  ON_COMMAND(ID_MRC_HIDE,OnHide)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CNDlgBar 


void CNDlgBar::OnRButtonDown(UINT nFlags, CPoint point) 
{
	CMenu popup;
  popup.LoadMenu(IDR_CONTMENU);
  if(docking)
    popup.CheckMenuItem(ID_MRC_ALLOWDOCKING, MF_CHECKED|MF_BYCOMMAND);
  ClientToScreen(&point);
  popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
        point.x,point.y,this);  
	CDialogBar::OnRButtonDown(nFlags, point);
}
