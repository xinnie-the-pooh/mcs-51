// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "FlatToolbar.h"
//#include "ToolBarEx.h"
#include "resource.h"       // main symbols
#include "DbgBar.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "JSTEP.h"
#include "JSTEPDoc.H"
#include "RegWnd.h"
#include "MemWnd.h"
#include "MainFrm.h"
#include "JSTEPView.h"
#include "procsel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMRCMDIFrameWndSizeDock)

BEGIN_MESSAGE_MAP(CMainFrame, CMRCMDIFrameWndSizeDock)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
    ON_MESSAGE(UM_THREADEND, UpdateDisplay)
	ON_MESSAGE(UM_DOSTIMULATION, DoStimulation)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
    ON_COMMAND(IDD_BROWSDLG, OnProject)	
    ON_UPDATE_COMMAND_UI(IDD_BROWSDLG, OnUpdateProject)	
	ON_WM_SIZE()
	ON_COMMAND(IDD_SELPROC, OnSelproc)
	//}}AFX_MSG_MAP
	END_MESSAGE_MAP()



static UINT indicators[] =
{
  ID_SEPARATOR,           // status line indicator 	
  ID_INDICATOR_PC,
  ID_INDICATOR_PROGRESSBAR,
  ID_INDICATOR_PROCTYP 
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction


CMainFrame::CMainFrame()  
{
int i;	
  pDoc=0;
  m_pWndTrace=0;
  winmax=TRUE;
  tbvis= DEBUGBAR_VISIBLE;
  pquick=NULL;
  addcmdNo=0;
  for( i=0;i<NUMBER_OF_ADDCMDS; i++)
  {
    addcmds[i].cmdID=ID_SEPARATOR;
    addcmds[i].bmpID=IDB_BMPDEFAULT;
    addcmds[i].ttptxt="";
    addcmds[i].menuname.Format("CustomCmd %d",i);
    addcmds[i].stattxt.Format("CustomCmd %d",i);
    addcmds[i].pWnd=0; 
    addcmds[i].style=0;
  } 
 
}

CMainFrame::~CMainFrame()
{  
int i;

  if(m_pWndTrace)
    delete m_pWndTrace; 
  for( i=0;i<NUMBER_OF_ADDCMDS; i++)   
    delete addcmds[i].pWnd; 
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
RECT rc;
  
  if (CMRCMDIFrameWndSizeDock::OnCreate(lpCreateStruct) == -1)
	return -1;
  theApp.pMainWnd=this;  //f�r die Applikation abspeichern  
  if (!m_wndStatusBar.Create(this))
  {
	TRACE0("Failed to create status bar\n");
	return -1;      // fail to create
  } 
  m_wndStatusBar.SetIndicators(indicators,4);  
  m_progress.Create(WS_VISIBLE|WS_CHILD, rc, &m_wndStatusBar, ID_INDICATOR_PROGRESSBAR); 
  m_progress.SetRange(0,100); //Set the range to between 0 and 100
  
  if(!m_wndToolBar.Create(this) || !m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
  {
	TRACE0("Failed to create toolbar\n");
	return -1;      // fail to create
  }		
  m_wndToolBar.SetFlatLookStyle();	  
  // m_wndToolBar.SetFlatLook(FALSE);
  m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
                         CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC );  
  m_wndToolBar.GetToolBarCtrl().ModifyStyle(0,CCS_ADJUSTABLE,0); 
  m_wndToolBar.EnableDocking(CBRS_ALIGN_TOP);
  EnableDocking(CBRS_ALIGN_ANY);	
  DockControlBar(&m_wndToolBar,AFX_IDW_DOCKBAR_TOP);
  
  if (!m_browsWnd.Create(this))
  {
	TRACE0("Failed to create ProjectWnd\n");
	return -1;      // fail to create
  }	
  DockControlBar(&m_browsWnd,AFX_IDW_DOCKBAR_LEFT);  
  return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
RECT rd;
  GetDesktopWindow()->GetWindowRect(&rd);

	cs.x=20;  //immer in die linke obere Ecke schieben
	cs.y=20;
	cs.cx=rd.right-40;  //zum debuggen eine kleine Gr��e einstellen
	cs.cy=rd.bottom-50;
    cs.lpszName="JSIM-51";
	return CMRCMDIFrameWndSizeDock::PreCreateWindow(cs);
}

// wir nach Beendigung des RUN-Threads aufgerufen um die aktuelle Sicht
// zu aktualisieren.
LONG CMainFrame::UpdateDisplay(UINT wparam, LONG lparam)
{ 
  if(pDoc)
    pDoc->ViewNewModule(lparam,TRUE);
  return(0);
}

// wird aufgerufen um den n�chsten Stimulations befehl abzusetzen
long CMainFrame::DoStimulation( UINT wparam, LONG lparam)
{
CString* pcmd;
int l;
CString txt;

  if(m_wndAnalyser.Created && m_wndAnalyser.stimfile.m_hFile !=-1)
  {
    pcmd=m_wndAnalyser.GetNextCommand();
    l=0;
    do
    {
	    l=pcmd->Find(',');
	   if(l!=-1)
     {
       txt=pcmd->Left(l);
	     *pcmd=pcmd->Mid(l+1);
		   pDoc->OnSetCmd(&txt);
     }	   
	   else
       pDoc->OnSetCmd(pcmd);
    }while(l!=-1);  
  }
  return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::DockControlBarLeftOf(CToolBar* Bar,CToolBar* LeftOf)
{
	CRect rect;
	DWORD dw;
	UINT n;

	// get MFC to adjust the dimensions of all docked ToolBars
	// so that GetWindowRect will be accurate
	RecalcLayout();
	LeftOf->GetWindowRect(&rect);
	rect.OffsetRect(1,0);
	dw=LeftOf->GetBarStyle();
	n = 0;
	n = (dw&CBRS_ALIGN_TOP) ? AFX_IDW_DOCKBAR_TOP : n;
	n = (dw&CBRS_ALIGN_BOTTOM && n==0) ? AFX_IDW_DOCKBAR_BOTTOM : n;
	n = (dw&CBRS_ALIGN_LEFT && n==0) ? AFX_IDW_DOCKBAR_LEFT : n;
	n = (dw&CBRS_ALIGN_RIGHT && n==0) ? AFX_IDW_DOCKBAR_RIGHT : n;

	// When we take the default parameters on rect, DockControlBar will dock
	// each Toolbar on a seperate line.  By calculating a rectangle, we in effect
	// are simulating a Toolbar being dragged to that location and docked.
	DockControlBar(Bar,n,&rect);
}


// Aktualisiert alle sichtbaren Speicherfenster
// unsichtbare Fenster werden gel�scht
// R�ckgabewert ist die Anzahl aktiver Speicherfenster

int CMainFrame::UpdateAllMemWnds(CMemWnd* pmem0,BOOL redraw)
{
POSITION pos,pos1;
int i;

  i=0;
  pos=memwnds.GetHeadPosition();
  while(pos)
  {
    CMemWnd* pmw=(CMemWnd*)memwnds.GetAt(pos);
    if(!pmw->IsWindowVisible( ))
    {
      if(!pmw->IsFloating())
        pmw->DestroyWindow();
		  else
      { 
        ShowControlBar(pmw,FALSE,FALSE);	
        FloatControlBar(pmw,CPoint(0,0),0);		
        pmw->GetParent()->DestroyWindow(); //der dar�berliegende Rahmen wird zerst�rt
      }
      pos1=pos;
      memwnds.GetNext(pos);      
      delete pmw;
      memwnds.RemoveAt(pos1);
    }
    else
    {
      i++;
      if(pmw != pmem0)
        pmw->UpdateMem(redraw);
      memwnds.GetNext(pos);
    }    
  }
  return(i);
}


void CMainFrame::UpdateAllWatches()
{
BOOL mbvis;
int i;

  UpdateAllMemWnds();
  if(m_wndWatch.Created)
  {
    mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndWatch.GetStyle() & WS_VISIBLE;
    if(mbvis)
      m_wndWatch.hlc.UpdateWatchWnd();
  }
  if(m_wndLocals.Created)
  {
    mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndLocals.GetStyle() & WS_VISIBLE;
    if(mbvis)
      m_wndLocals.UpdateLocals();
  }
  if(m_wndRegBar.Created)
  {
    mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndRegBar.GetStyle() & WS_VISIBLE;
    if(mbvis)
      m_wndRegBar.UpdateAllRegisters();
  }
  
  if(pquick)
    pquick->hlc.UpdateWatchWnd();

  if(m_wndAnalyser.Created)
    m_wndAnalyser.UpdateAnalyser(); 

  //m_wndStack.UpdateLevel0(); 
  char buff[20];
  ULONG memsize=prc->GetMemSize();
  switch(memsize)
  {
  case S32:  sprintf(buff,"PC:0x%8.8X",prc->GetProgramCounter());
             break;
  case S16:  sprintf(buff,"PC:0x%4.4X",prc->GetProgramCounter());
             break;
  case S8:   sprintf(buff,"PC:0x%4.4X",prc->GetProgramCounter());
             break;
  }
  m_wndStatusBar.SetPaneText(1,buff,TRUE);
  for(i=0;i<NUMBER_OF_ADDCMDS;i++)
  {
    if(addcmds[i].pWnd)
      addcmds[i].pWnd->SendMessage(UM_UPDATEWATCHES);
  }
}



void CMainFrame::OnEditCopy() 
{
char cname[10];
	CWnd* pWnd = GetFocus();
  HWND hWnd = pWnd->GetSafeHwnd();
  if (hWnd == NULL)
    return;
  ::GetClassName(hWnd, cname, 10);
  if(!strcmp (cname,"Edit"))
    ((CEdit*)pWnd)->Copy();
  else if(!strcmp (cname,"NList"))
  {
    ::ReleaseCapture(); 
    ((CJSTEPView*)pWnd)->Copy();    	
  }
}


void CMainFrame::OnEditCut() 
{
char cname[10];
	CWnd* pWnd = GetFocus();
  HWND hWnd = pWnd->GetSafeHwnd();
  if (hWnd == NULL)
    return;
  ::GetClassName(hWnd, cname, 10);
  if(!strcmp (cname,"Edit"))
    ((CEdit*)pWnd)->Cut();
  if(!strcmp (cname,"NList")) 
    ((CJSTEPView*)pWnd)->Copy(); // ist nicht editierbar	
}

void CMainFrame::OnEditPaste() 
{
char cname[10];
	CWnd* pWnd = GetFocus();
  HWND hWnd = pWnd->GetSafeHwnd();
  if (hWnd == NULL)
    return;
  ::GetClassName(hWnd, cname, 10);
  if(!strcmp (cname,"Edit"))
    ((CEdit*)pWnd)->Paste(); 

}

void CMainFrame::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
char cname[10];
int nBeg, nEnd;
  
  CWnd* pWnd = GetFocus();
  HWND hWnd = pWnd->GetSafeHwnd();
  if (hWnd == NULL)
    return;
  ::GetClassName(hWnd, cname, 10);
  
  if(!strcmp (cname,"Edit"))
  {
    ((CEdit*)pWnd)->GetSel( nBeg, nEnd );
    pCmdUI->Enable( nBeg != nEnd );
    return;
  } 
  if(!strcmp (cname,"NList")) 
  {  
	  pCmdUI->Enable( ((CJSTEPView*)pWnd)->GetSeltextLen() );
    return;
  }
}

void CMainFrame::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
char cname[10];
int nBeg, nEnd;
  
  CWnd* pWnd = GetFocus();
  HWND hWnd = pWnd->GetSafeHwnd();
  if (hWnd == NULL)
    return;
  ::GetClassName(hWnd, cname, 10);
  
  if(!strcmp (cname,"Edit"))
  {
    ((CEdit*)pWnd)->GetSel( nBeg, nEnd );
    pCmdUI->Enable( nBeg != nEnd );
    return;
  }  
  pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
char cname[10];
  
  CWnd* pWnd = GetFocus();
  HWND hWnd = pWnd->GetSafeHwnd();
  if (hWnd == NULL)
    return;
  ::GetClassName(hWnd, cname, 10);
  
  if(!strcmp (cname,"Edit"))
  {
    pCmdUI->Enable( TRUE );
    return;
  }   
  pCmdUI->Enable( FALSE );
}


void CMainFrame::OnProject() 
{
  
  BOOL mbvis=m_browsWnd.GetStyle() & WS_VISIBLE;	
	if(mbvis)  
    ShowControlBar(&m_browsWnd,FALSE,FALSE);		
	else
    ShowControlBar(&m_browsWnd,TRUE,FALSE);
}


void CMainFrame::OnUpdateProject(CCmdUI* pCmdUI) 
{
  BOOL mbvis=m_browsWnd.GetStyle() & WS_VISIBLE;
	pCmdUI->SetCheck(mbvis);
}


void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
RECT rc;

  CMRCMDIFrameWndSizeDock::OnSize(nType, cx, cy);
  m_wndStatusBar.GetItemRect(2, &rc);

  // Reposition the progress control correctly!
  m_progress.SetWindowPos(&wndTop, rc.left, rc.top, rc.right - rc.left,
             rc.bottom - rc.top, 0); 	
	
}

void CMainFrame::GetMessageString(UINT nID, CString& rMessage) const
{
  if(nID>=IDC_PROCWND0 && nID<=IDC_PROCWND9)
  {
    rMessage=addcmds[nID-IDC_PROCWND0].stattxt; 
  }
  else 
  {
    CFrameWnd::GetMessageString(nID, rMessage);
    if(rMessage != "")
      return;
    LPCSTR statustxt;
    int i;
    for (i=0;i<NUMBER_OF_ADDCMDS;i++)
    {
      if(!addcmds[i].pWnd) // addcmdNo
        continue;
      statustxt=(LPCSTR)addcmds[i].pWnd->SendMessage(UM_GETSTATUSTXT,nID);
      if(statustxt) 
      { 
        rMessage=statustxt;
        return;
      }
    }
  }
  return;
}

void CMainFrame::OnSelproc() 
{
  CProcSel dlg;
  dlg.DoModal();
}


