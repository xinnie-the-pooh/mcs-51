// BkptEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBkptEdit dialog

class CBkptEdit : public CDialog
{
// Construction
public:
	CImageList imagelist;
	CBkptEdit(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBkptEdit)
	enum { IDD = IDD_BREAKPOINT };
	CListCtrl	blist;
	BOOL	bdisable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBkptEdit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	

	// Generated message map functions
	//{{AFX_MSG(CBkptEdit)
	virtual BOOL OnInitDialog();
	afx_msg void OnBkptdel();
	afx_msg void OnBkptdisable();  
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
