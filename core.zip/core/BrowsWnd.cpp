// BrowsWnd.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "BrowsWnd.h"
#include "mainfrm.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBrowsWnd

CBrowsWnd::CBrowsWnd()
{
  root=0;
  libItem=(HTREEITEM)0;
  treeicons.Create(IDB_TREEICONS,16,1,RGB(255,255,255));
}

CBrowsWnd::~CBrowsWnd()
{

}


BEGIN_MESSAGE_MAP(CBrowsWnd, CMRCSizeDialogBar)
	//{{AFX_MSG_MAP(CBrowsWnd)
	ON_WM_SIZE()
	ON_WM_DESTROY()
  ON_NOTIFY(NM_DBLCLK,IDC_TREE,OnTreeSelChanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CBrowsWnd message handlers

BOOL CBrowsWnd::Create( CWnd* pParentWnd )
{
  BOOL b= CMRCSizeDialogBar::Create(pParentWnd, IDD_BROWSDLG
	       ,CBRS_ALIGN_BROWSWND|CBRS_SIZE_DYNAMIC
	  		 ,IDD_BROWSDLG);	
  
	if(b)
  {    	  
    tree.SubclassDlgItem(IDC_TREE,this);   		
    tree.SetIndent(20);
    tree.SetImageList(&treeicons,TVSIL_NORMAL);
	SetBarStyle( GetBarStyle()
		         | CBRS_TOOLTIPS 
				 | CBRS_FLYBY 							 
				 | CBRS_BORDER_ANY 
	             | CBRS_BORDER_3D );
		
    EnableDocking(CBRS_ALIGN_BROWSWND);
		SetWindowText(_T("Project"));   
  }
  EnableToolTips(TRUE);
  return(b);  
}

void CBrowsWnd::OnSize(UINT nType, int cx, int cy) 
{
RECT rc,re;

	CMRCSizeDialogBar::OnSize(nType, cx, cy);
	GetWindowRect(&rc);
	CTreeCtrl* pe=(CTreeCtrl*)GetDlgItem(IDC_TREE);
	if(!pe)     
    return;  
	re.top=rc.top+7;
	re.left=rc.left;
  re.right=rc.right;
  re.bottom=rc.bottom;  
  ScreenToClient(&re);  	
  pe->MoveWindow(&re,TRUE);	 
  pe->GetClientRect(&rc);  
}

void CBrowsWnd::InsertModule(CModDef* pm)
{
bref_t* pb;

  if(pm->modname.Find("?C_") != -1)
    return;
  actItem=tree.InsertItem(pm->modname,ICOMODUL,ICOMODUL,root,TVI_LAST);
  pb=new bref_t;
  pb->pm=pm;
  pb->pp=0;
  pb->typ=ISMOD;
  tree.SetItemData(actItem,(DWORD)pb); 
  if(pm->modname=="LIBRARY")
    libItem=actItem; 
}

void CBrowsWnd::OnDestroy() 
{
  Clear();
	CMRCSizeDialogBar::OnDestroy();
}

void CBrowsWnd::AddRoot(CString& prjname)
{
  root=tree.InsertItem(prjname,2,2,TVI_ROOT,TVI_FIRST);
  tree.SetItemData(root,0);
}

void CBrowsWnd::AddProc(CProcDef* pp,CModDef* pm)
{
bref_t* pb;
HTREEITEM item;
  
  if(pp->Procname=="LIB" || pp->Procname=="CONST")
    return; 
  if(!pm)
  {  
    item=tree.InsertItem(pp->Procname,ICOPROC,ICOPROC,actItem,TVI_LAST);
  } 
  else if(!pm || pm->modname=="LIBRARY")
  {
    item=tree.InsertItem(pp->Procname,ICOPROC,ICOPROC,libItem,TVI_LAST); 
  }
  else
  {
    item=tree.GetNextItem(NULL,TVGN_ROOT);
    item=tree.GetNextItem(item,TVGN_CHILD);
    while(item)
    {
      pb=(bref_t*)tree.GetItemData(item);   
      if(pb && pb->pm == pm)
      {    
        item=tree.InsertItem(pp->Procname,ICOPROC,ICOPROC,item,TVI_LAST);  
        break;
      }      
      item=tree.GetNextItem(item,TVGN_NEXT);  
    }; 

    if(!item)
      item=tree.InsertItem(pp->Procname,ICOPROC,ICOPROC,libItem,TVI_LAST);   
  }
  pb=new bref_t;
  pb->pm=0;
  pb->pp=pp;
  pb->typ=ISPROC;
  tree.SetItemData(item,(DWORD)pb); 
}

void CBrowsWnd::Clear()
{
  if(!tree.GetCount())
    return;
  DeleteSubItems(root);
  tree.DeleteAllItems();
}

void CBrowsWnd::DeleteSubItems(HTREEITEM subItem)
{
bref_t* bp;
HTREEITEM hItem;

   hItem=tree.GetChildItem(subItem);
   while(hItem)   
   {
     bp= (bref_t*)tree.GetItemData(hItem);    
     delete bp;  
     if(tree.ItemHasChildren(hItem))
       DeleteSubItems(hItem);
     hItem=tree.GetNextItem(hItem,TVGN_NEXT);
   }
}


void CBrowsWnd::OnTreeSelChanged( NMHDR * pNotifyStruct, LRESULT * result )
{
HTREEITEM sitem;
bref_t* bp;
ULONG addr;

   CJSTEPDoc* pdoc=((CMainFrame*)AfxGetMainWnd())->pDoc;
   sitem=tree.GetSelectedItem();
   if(sitem)
   {
     bp=(bref_t*)tree.GetItemData(sitem);
     if(bp)
     {
       if(bp->typ==ISMOD)
       {         
         if(bp->pm->GetLowAddr()!=-1 && bp->pm->GetHighAddr())
           pdoc->ViewNewModule(bp->pm->GetLowAddr(),FALSE);
         else
         {
           labeldef_t* lp=theApp.objinfo.FindLabel( &(bp->pm->modname) );
           if(lp)
             pdoc->ViewNewModule(lp->addr,FALSE);
           else
             pdoc->ViewNewModule(prc->GetStartUpAddress(),FALSE); 
         } 
       }  
       else if(bp->typ==ISPROC) 
       {         
         if(theApp.objinfo.FindLabelAddr(bp->pp->Procname,&addr))
           pdoc->ViewNewModule(addr,TRUE);
         else
           pdoc->ViewNewModule(bp->pp->AnfAddr,TRUE);
       }
     }   
   }
}

void CBrowsWnd::Expand()
{
  tree.Expand(root,TVE_EXPAND);
}
