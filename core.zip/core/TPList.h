// TPList.h : header file
//

#ifndef _TPLIST
#define _TPLIST
/////////////////////////////////////////////////////////////////////////////
// CTPList window

class CTPList : public CListCtrl
{
// Construction
public:
	void Create();
	CTPList();

// Attributes
public:
CEditNotify edit;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTPList)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTPList();

	// Generated message map functions
protected:
  void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
	CPen bkpen;	
  CFont lfont;
	//{{AFX_MSG(CTPList)	
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg long OnEditReturn(UINT wparam, LONG lparam);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_TPLIST
/////////////////////////////////////////////////////////////////////////////
