// RTraceCtl.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "RTraceCtl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRTraceCtl

CRTraceCtl::CRTraceCtl()
{
}

CRTraceCtl::~CRTraceCtl()
{
}


BEGIN_MESSAGE_MAP(CRTraceCtl, CRichEditCtrl)
	//{{AFX_MSG_MAP(CRTraceCtl)
	ON_WM_PAINT()
	ON_WM_RBUTTONDOWN()
	ON_WM_CONTEXTMENU()
  ON_COMMAND(ID_FLOAT,OnFloat)
  ON_COMMAND(ID_DOCK,OnDock)
  ON_COMMAND(ID_CLEAR,OnClear)
  ON_COMMAND(ID_RELOAD,OnReload)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRTraceCtl message handlers

void CRTraceCtl::OnPaint() 
{
RECT re;
	
	CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
	if(pm->m_wndAnalyser.traceEnabled)
  {
    CPaintDC dc(this); // device context for painting
    GetClientRect(&re);     	     
    CBrush br(HS_CROSS,0x808080);
    dc.FillRect(&re,&br);  
    return; 
  }
  
	CRichEditCtrl::OnPaint();
}

void CRTraceCtl::OnRButtonDown(UINT nFlags, CPoint point) 
{
  /*
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  ClientToScreen(&point);
  pm->m_pWndTrace->SendMessage(WM_CONTEXTMENU,nFlags,point.x+point.y*0x10000);
  */
  CMenu Popup;

  ClientToScreen(&point);
  Popup.LoadMenu (IDR_TRACEMENU);
  Popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
                                         point.x,point.y,this);
}

void CRTraceCtl::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	GetParent()->SendMessage(WM_CONTEXTMENU,(UINT)(GetParent()->m_hWnd),point.x+point.y*0x10000);
	
}

void CRTraceCtl::OnDock()
{
  CMDIFrameWnd* pm=(CMDIFrameWnd*)AfxGetMainWnd(); 
  pm->DockControlBar(((CControlBar*)GetParent()),AFX_IDW_DOCKBAR_RIGHT);
}

void CRTraceCtl::OnFloat()
{
RECT rd;

  GetDesktopWindow()->GetWindowRect(&rd);
	POINT pt;
	pt.x=rd.right/2-50;
  pt.y=rd.bottom/2-50;
  ((CFrameWnd*)AfxGetMainWnd())->FloatControlBar(((CControlBar*)GetParent()),pt,0);	
}

void CRTraceCtl::OnClear()
{
  SetSel(0,-1);
  ReplaceSel("");
}

void CRTraceCtl::OnReload()
{
  ((CMainFrame*)AfxGetMainWnd())->m_pWndTrace->ReadTraceFile();
}

