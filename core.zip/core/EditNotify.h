// EditNotify.h : header file
//

#ifndef _EDITNOTIFY
  #define  _EDITNOTIFY
// USER-Message zur Benachrichtigung des Parent Windows das ein Eintrag
// aktualisiert wurde
#define UM_ENTER        WM_USER+0x22 
#define UM_CURSORKEY    WM_USER+0x23 
#define UM_PASTE        WM_USER+0x24 
#define UM_GETMENUSTATE WM_USER+0x25 
#define UM_CTRLKEY      WM_USER+0x26
#define UM_TAB          WM_USER+0x27

/////////////////////////////////////////////////////////////////////////////
// CEditNotify window


class CEditNotify : public CEdit
{
// Construction
public:	
  int extramenu;
	int actsub;
	void SetText(CString& txt);
	CString lasttext;
	int act;
	CEditNotify();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditNotify)
	public:
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEditNotify();

	// Generated message map functions
protected:
	
	//{{AFX_MSG(CEditNotify)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
  afx_msg long OnEdPaste(UINT wparam, LONG lparam);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnEditUndo();
	afx_msg void OnEditSelAll();
  afx_msg void OnEditClr();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_EDITNOTIFY
/////////////////////////////////////////////////////////////////////////////
