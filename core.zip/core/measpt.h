//Verwaltungsinfo f�r Messpunkte
#ifndef _MEASURE
#define _MEASURE

class CMeasurePoint
{
public:
  BOOL enabled;
  void ResetMeasure();
  CMeasurePoint(); 
  void SetMeasurePoint(ULONG addr);
  BOOL isValid;
  ULONG addr;
  ULONG measures;
  ULONG cycles;
  ULONG MinCycles;
  ULONG MaxCycles; 
  int item;
  CWnd* pv;
};

// CTracePoint  Deklaration
class CTracePoint
{
public:	
  BOOL IsTracePointAtAddr(ULONG addr);
  void SetTracePoint(ULONG addr);
  ULONG GetAddr(){ return addr;};
  void DeleteAllExpressions();
  ~CTracePoint();
  CTracePoint();  
  BOOL isValid;
  int item;
  CPtrArray expressions;
  CWnd* pv;
protected:
  ULONG addr;
  
};

#endif //_MEASURE