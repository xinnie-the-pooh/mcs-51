// StackList.h : header file
//
#ifndef _STACKLIST
#define _STACKLIST
/////////////////////////////////////////////////////////////////////////////
// CStackList window

class CStackList : public CListBox
{
// Construction
public:
	CStackList();

// Attributes
public:
  BOOL unlocked;
  BOOL unlocked1;
  CFont lfont;
  CView* pvlast;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStackList)
	protected:	
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStackList();

	// Generated message map functions
protected:

	//{{AFX_MSG(CStackList)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_STACKLIST
/////////////////////////////////////////////////////////////////////////////
