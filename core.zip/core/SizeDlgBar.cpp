// SizeDlgBar.cpp : implementation file
//

#include "stdafx.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "JSTEP.h"
#include "SizeDlgBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////
 
// CSizeDlgBar.cpp : implementation file
//
 
 
////////////////////////////////////////////////////////////////////
// CResizableDlgBar Construction/Destruction
 
BOOL CSizeDlgBar::Create( CWnd* pParentWnd, UINT nIDTemplate,
                          UINT nStyle, UINT nID, BOOL bChange)
{
     if(!CDialogBar::Create(pParentWnd,nIDTemplate,nStyle,nID))
          return FALSE;
 
     m_bChangeDockedSize = bChange;
     m_sizeFloating = m_sizeDocked = m_sizeDefault;
     return TRUE;
}
 
BOOL CSizeDlgBar::Create( CWnd* pParentWnd,
                               LPCTSTR lpszTemplateName, UINT nStyle,
                               UINT nID, BOOL bChange)
{
    if (!CDialogBar::Create( pParentWnd, lpszTemplateName,
                                              nStyle, nID))
        return FALSE;
 
    m_bChangeDockedSize = bChange;
    m_sizeFloating = m_sizeDocked = m_sizeDefault;
    return TRUE;
}
 
////////////////////////////////////////////////////////////////////
// Overloaded functions
 
CSize CSizeDlgBar::CalcDynamicLayout(int nLength, DWORD nMode)
{
    // Return default if it is being docked or floated
    if ((nMode & LM_VERTDOCK) || (nMode & LM_HORZDOCK))
    {
        if (nMode & LM_STRETCH) // if not docked stretch to fit
            return CSize((nMode & LM_HORZ) ? 32767 : m_sizeDocked.cx,
                         (nMode & LM_HORZ) ? m_sizeDocked.cy : 32767);
          else
            return m_sizeDocked;
    }
    if (nMode & LM_MRUWIDTH)
        return m_sizeFloating;
    // In all other cases, accept the dynamic length
    if (nMode & LM_LENGTHY)
        return CSize(m_sizeFloating.cx, (m_bChangeDockedSize) ?
                     m_sizeFloating.cy = m_sizeDocked.cy = nLength :
                     m_sizeFloating.cy = nLength);
     else
        return CSize((m_bChangeDockedSize) ?
                     m_sizeFloating.cx = m_sizeDocked.cx = nLength :
                     m_sizeFloating.cx = nLength, m_sizeFloating.cy);
}
 
BEGIN_MESSAGE_MAP(CSizeDlgBar, CDialogBar)
    //{{AFX_MSG_MAP(CSizeDlgBar)
        // NOTE - the ClassWizard will add and remove mapping macros here.
    //}}AFX_MSG_MAP
END_MESSAGE_MAP()
 
/////////////////////////////////////////////////////////////////////
// CSizeDlgBar message handlers
/////////////////////////////////////////////////////////////////////
 
