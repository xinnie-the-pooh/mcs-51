// JSTEP.h : main header file for the JSTEP application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#ifndef _JSIMAPP
#define _JSIMAPP

#include "resource.h"       // main symbols
#include "ModDef.h"
#include "ObjInfo.h"
#include "proc.h"
#include "DbgBar.h"
#include "JSTEPDoc.h"
#include "RegWnd.h"


////// ///////////////////////////////////////////////////////////////////////
// CJSTEPApp:
// See JSTEP.cpp for the implementation of this class
//

// imported Functions from DLL
/*  //f�r implizite Bindung
__declspec( dllimport ) CProc* prc;
__declspec( dllimport ) int HandleExtraWndUpdateCmd(UINT id);
__declspec( dllimport ) UINT HandleExtraWndCmd(UINT id,HWND hWnd,CDialogBar* pd);
__declspec( dllimport ) UINT HandleCommandLine(LPCSTR cmd);
__declspec( dllimport ) int LoadFile(LPCSTR filename);
__declspec( dllimport ) int LoadWorkspaceFile(LPCSTR filename);
__declspec( dllimport ) int StoreWorkspaceFile(LPCSTR filename);
*/

typedef int  (CALLBACK* LPFNDLLFUNC1)(UINT);
typedef UINT (CALLBACK* LPFNDLLFUNC2)(UINT,HWND,CDialogBar*);
typedef UINT (CALLBACK* LPFNDLLFUNC3)(LPCSTR);
typedef int (CALLBACK* LPFNDLLFUNC4)(LPCSTR);
typedef void (CALLBACK* LPFNDLLFUNC5)(LPCSTR);

class CJSTEPApp : public CWinApp
{
public:	
	BOOL ProcIsLoaded;
	BOOL AttachProcessor(LPCSTR dllname);
	CString procname;
	CString dllname;
	CWnd* pMainWnd;
	CString projectfile;
	char exepath[100];
	CString wspfile;
    CString hexfile;
	HMODULE h_rdll;
	BOOL IsIdleMessage( MSG* pMsg );	
	CMultiDocTemplate* pDocTemplate;
  CMultiDocTemplate* pDocTemplate1; 
  CMultiDocTemplate* pDocTemplate2;   	
  CMultiDocTemplate* pDocTemplate3;
	CObjInfo objinfo;
	CJSTEPApp();
    ~CJSTEPApp();    
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJSTEPApp)
public:
	virtual BOOL InitInstance();
	virtual CDocument* OpenDocumentFile(LPCTSTR lpszFileName);
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CJSTEPApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


// Definitions of global variables
extern LPFNDLLFUNC1 HandleExtraWndUpdateCmd;
extern LPFNDLLFUNC2 HandleExtraWndCmd;
extern LPFNDLLFUNC3 HandleCommandLine;
extern LPFNDLLFUNC4 LoadFile;
extern LPFNDLLFUNC5 LoadWorkspaceFile;
extern LPFNDLLFUNC5 StoreWorkspaceFile;
extern CProc* prc;
extern CJSTEPApp theApp;
extern HINSTANCE hinstDLL;

#endif // JSIMAPP
/////////////////////////////////////////////////////////////////////////////
