// debugbar.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "DbgBar.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#define COMBOBOX_INDEX 0
#define COMBOBOX_WIDTH 350
#define COMBOBOX_HEIGHT 150


static UINT BASED_CODE DbgButtons[] =
{     
  ID_DEBUG_DUMMY,
  ID_SEPARATOR,
	ID_DEBUG_RUN,
	ID_DEBUG_STOPDEBUGGING,
  ID_SEPARATOR,
	ID_DEBUG_STEPINTO,
  ID_DEBUG_STEPOVER,
	ID_DEBUG_STEPOUT,	
	ID_DEBUG_RUNTOCURSOR,
	ID_SEPARATOR,
	ID_DEBUG_QUICKWATCH,
	ID_DEBUG_WATCH,
  IDD_LOCALS
};

/////////////////////////////////////////////////////////////////////////////
// CDbgBar

CDbgBar::CDbgBar()
{
  Created=FALSE;
}

CDbgBar::~CDbgBar()
{
}

BOOL CDbgBar::Init(CWnd* pParentWnd)
{
  if(Created)
    return TRUE;
	// start out with no borders
  DWORD dwStyle = WS_CHILD 
 	            | WS_VISIBLE								
				| CBRS_SIZE_DYNAMIC
		        | CBRS_TOOLTIPS 
				| CBRS_FLYBY;  //| CBRS_TOP
  if (!Create(pParentWnd, dwStyle, IDW_DBGBAR))
  {
	return FALSE;
  }	
  LoadBitmap(IDR_DBGBAR);
  SetFlatLookStyle();
  //SetFlatLook();
  //hier wird das Bitmap mit den Defines verbunden  
  if(!SetButtons(DbgButtons, sizeof(DbgButtons)/sizeof(UINT)))
 	return FALSE;
	
  CRect rect(-COMBOBOX_WIDTH, -COMBOBOX_HEIGHT, 0, 0);
	// The ID of the ComboBox is important for two reasons.  One, so you
	// can receive notifications from the control.  And also for ToolTips.
	// During HitTesting if the ToolBar sees that the mouse is one a child
	// control, the toolbar will lookup the controls ID and search for a
	// string in the string table with the same ID to use for ToolTips
	// and StatusBar info.
  if (!cmdbox.Create(WS_CHILD | CBS_DROPDOWN |
      CBS_AUTOHSCROLL | WS_VSCROLL | CBS_HASSTRINGS, rect, this,
	  IDC_DBCMDBOX))
  {
	return FALSE;
  }

  HFONT hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
  if (hFont == NULL)
	hFont = (HFONT)GetStockObject(ANSI_VAR_FONT);

  cmdbox.SendMessage(WM_SETFONT, (WPARAM)hFont);
  SetBarStyle(GetBarStyle() | CBRS_ALIGN_ANY);
  SetButtonInfo(COMBOBOX_INDEX, IDC_DBCMDBOX, TBBS_SEPARATOR, COMBOBOX_WIDTH);
  if (cmdbox.m_hWnd != NULL)
  {
	CRect rect;
	GetItemRect(COMBOBOX_INDEX, rect);
	cmdbox.SetWindowPos(NULL, rect.left, rect.top, 0, 0, SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOSIZE|SWP_NOCOPYBITS);
	cmdbox.ShowWindow(SW_SHOW);
  }
  SetWindowText(_T("Debug"));
  EnableDocking(CBRS_ALIGN_ANY);
  Created=TRUE;
  return TRUE;
}

//BEGIN_MESSAGE_MAP(CDbgBar, CToolBarEx)
BEGIN_MESSAGE_MAP(CDbgBar, CFlatToolBar)
	//{{AFX_MSG_MAP(CDbgBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CDbgBar message handlers
