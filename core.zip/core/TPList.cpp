// TPList.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "TPList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTPList

CTPList::CTPList()
{ 
  lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier");   
}

CTPList::~CTPList()
{
}


BEGIN_MESSAGE_MAP(CTPList, CListCtrl)
	//{{AFX_MSG_MAP(CTPList)
	ON_WM_DRAWITEM()
	ON_WM_LBUTTONDOWN()
    ON_MESSAGE(UM_ENTER,OnEditReturn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTPList message handlers
#define DEFAULT_TEXTDRAW  DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER
#define TEXTOFFSET 2

void CTPList::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
RECT rc,rcItem;
int item;
CDC* pDC;
CPen* oldPen;
CString txt;

	GetClientRect(&rc);   
  rcItem=lpDrawItemStruct->rcItem;
  rcItem.left+=TEXTOFFSET;
	item=lpDrawItemStruct->itemID;	
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
  CFont* oldfont=pDC->SelectObject(&lfont);
  CPen dotpen(PS_DOT,1,(COLORREF)0xC0C0C0L); 

  oldPen=(CPen*)pDC->SelectObject(&bkpen);
  pDC->MoveTo(rcItem.left,rcItem.bottom);
  pDC->LineTo(rcItem.right,rcItem.bottom);
  pDC->MoveTo(rcItem.left,rcItem.top);
  pDC->LineTo(rcItem.right,rcItem.top);

  pDC->SelectObject(&dotpen);
  pDC->MoveTo(rcItem.left,rcItem.bottom);
  pDC->LineTo(rcItem.right,rcItem.bottom);
  pDC->MoveTo(rcItem.left,rcItem.top);
  pDC->LineTo(rcItem.right,rcItem.top);
  int c0=GetColumnWidth(0);
  pDC->MoveTo(c0,rcItem.top);
  pDC->LineTo(c0,rcItem.bottom);
  // Draw Text Column 0
  txt=GetItemText(item,0);
  pDC->DrawText(txt,&rcItem,DEFAULT_TEXTDRAW);
  pDC->SelectObject(oldPen);
}



void CTPList::Create()
{
LV_COLUMN lvc;
RECT rc;
  
  bkpen.CreatePen(PS_SOLID,1,GetBkColor());  
  edit.Create(WS_CHILD|WS_BORDER|WS_OVERLAPPED|ES_NOHIDESEL|ES_MULTILINE|ES_WANTRETURN|ES_AUTOHSCROLL,rc,this,0);
  edit.SetFont(&lfont,FALSE);	
  
  CClientDC dc(this);
	
  lvc.mask=LVCF_WIDTH;
  GetClientRect(&rc);
  lvc.cx=rc.right;
  lvc.iSubItem=0;
  InsertColumn(0,&lvc);  //nur Spalte 0
  InsertItem(0,"");
}

void CTPList::OnLButtonDown(UINT nFlags, CPoint point) 
{
RECT rc;
CString txt; 
int item;

  
  item=HitTest(point);
  if(item == -1)
  {
    edit.ShowWindow(SW_HIDE);
    if(edit.act != -1)
    {
      RedrawItems(edit.act,edit.act);    
      edit.act=-1;
    }
    GetParent()->GetDlgItem(IDC_DELETE)->ModifyStyle(0,WS_DISABLED);
    GetParent()->GetDlgItem(IDC_DELETE)->Invalidate();
    return;
  }
  else
  {
    GetItemRect(item,&rc,LVIR_BOUNDS);                 
    edit.SetWindowPos(&wndTop,
                      rc.left,
                      rc.top,
   					  rc.right,
      				  rc.bottom-rc.top,
	      			  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
    
    if(edit.act != -1)    
      RedrawItems(edit.act,edit.act); 
    edit.act=item;
    txt=GetItemText(item,0);
    edit.SetWindowText(txt);  
    edit.Invalidate(FALSE);
    edit.ShowWindow(SW_SHOW);
    //edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols    
    edit.SetFocus();      
    if(item+1<GetItemCount())
      GetParent()->GetDlgItem(IDC_DELETE)->ModifyStyle(WS_DISABLED,0);
    else
      GetParent()->GetDlgItem(IDC_DELETE)->ModifyStyle(0,WS_DISABLED);
    GetParent()->GetDlgItem(IDC_DELETE)->Invalidate();
  }	
}

long CTPList::OnEditReturn(UINT wparam, LONG lparam)
{
CString txt,oldtext;
RECT rc;
int i=0;

  edit.GetWindowText(txt);  
  oldtext=GetItemText(edit.act,0);
  if(txt!="")
  {
    int icnt=GetItemCount(); 
    SetItemText(edit.act,0,txt);
    edit.SetWindowText("");
    if(oldtext=="")
      i=InsertItem(icnt,"");  //neuen Eintrag einf�gen wenn der text vorher leer war
    GetItemRect(i,&rc,LVIR_BOUNDS);                     
    edit.act=i;
  }
  else
    DeleteItem(edit.act); //eintrag l�schen wenn Text leer
  edit.SetWindowPos(&wndTop,
	                rc.left,
                    rc.top,
			      	rc.right,
				    rc.bottom-rc.top,
					SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
  return 0;
}