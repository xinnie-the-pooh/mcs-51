// ProcSel.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "ProcSel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProcSel dialog


CProcSel::CProcSel(CWnd* pParent /*=NULL*/)
	: CDialog(CProcSel::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProcSel)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CProcSel::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProcSel)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProcSel, CDialog)
	//{{AFX_MSG_MAP(CProcSel)
	ON_BN_CLICKED(IDC_SEARCH, OnSearchProc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProcSel message handlers

BOOL CProcSel::OnInitDialog() 
{
CString pname,entry,selname;
int i,l,l1,sel;
const char* curprofile_p;

  CDialog::OnInitDialog();  
  sel=-1;
  curprofile_p=theApp.m_pszProfileName;
  theApp.m_pszProfileName=theApp.exepath;	
  i=0;
  do
  {
    entry.Format("Proc%d",i++);
    pname=theApp.GetProfileString("Processors",entry,0);    
    if(pname!="")
    {    
      selname=pname;     
      l=pname.ReverseFind('\\');
      l1=pname.ReverseFind('.');
      if(l1==-1)
        pname=pname.Mid(l+1);   
      else
        pname=pname.Mid(l+1,l1-l-1);        
      ((CListBox*)GetDlgItem(IDC_PROCLIST))->AddString(pname);   
      if(selname==theApp.procname)
         sel=((CListBox*)GetDlgItem(IDC_PROCLIST))->GetCount()-1;      
    }
  }while(pname!=""); 
  ((CListBox*)GetDlgItem(IDC_PROCLIST))->SetCurSel(sel);
  theApp.m_pszProfileName=curprofile_p;
  return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CProcSel::OnOK() 
{
CString actlib,entry,curprofile,txt;
int i;
const char* curprofile_p;

  curprofile_p=theApp.m_pszProfileName;
  theApp.m_pszProfileName=theApp.exepath;	
  CListBox* pl=(CListBox*)GetDlgItem(IDC_PROCLIST);
  if(pl->GetCurSel()!=-1)
  {
    entry.Format("Proc%d",pl->GetCurSel());
    entry=theApp.GetProfileString("Processors",entry,0);     
    if(!theApp.AttachProcessor(entry))  //aus der Liste entfernen
    {
      i=pl->GetCurSel();
      pl->DeleteString(i);  
      entry.Format("Proc%d",i);
      theApp.WriteProfileString("Processors",entry,0); 
      do
      {
        entry.Format("Proc%d",i+1);
        txt=theApp.GetProfileString("Processors",entry,0);  
        entry.Format("Proc%d",i++);
        theApp.WriteProfileString("Processors",entry,txt); 
      }while (txt!="");  
      theApp.WriteProfileString("Processors",entry,0);              
    } 
    else
    {  
      theApp.procname=entry;
      theApp.m_pszProfileName=curprofile_p;   
      theApp.ProcIsLoaded=TRUE;   
      ((CMainFrame*)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(3,prc->GetProcessorName(),TRUE);
	  CDialog::OnOK();
    }
  }         
}

void CProcSel::OnSearchProc() 
{
CString entry,pname,newdll;
LPCSTR curprofile_p;
int i,l,l1;
  
   CFileDialog fdlg(TRUE,".dll","*.dll",0,"dll (Processor library)",this);
   if(fdlg.DoModal()==IDOK)
   { 
     curprofile_p=theApp.m_pszProfileName;
     theApp.m_pszProfileName=theApp.exepath;
     newdll=fdlg.GetPathName();
     i=0;
     do
     {
       entry.Format("Proc%d",i++);
       pname=theApp.GetProfileString("Processors",entry,0);               
       if(!stricmp(newdll,pname))
         return;
     }while( pname != "");     
     if(CheckDLLvalid(newdll))
     { 
       entry.Format("Proc%d",i-1);
       theApp.WriteProfileString("Processors",entry,newdll);
       theApp.m_pszProfileName=curprofile_p;
     
       l=newdll.ReverseFind('\\');
       if(l==-1)
         l=0;
       l1=newdll.ReverseFind('.');
       if(l1==-1)
         newdll=newdll.Mid(l+1);   
       else
         newdll=newdll.Mid(l+1,l1-l-1);       
       CListBox* plb= (CListBox*)GetDlgItem(IDC_PROCLIST);
       plb->AddString(newdll); 
       plb->SetSel(plb->GetCount()-1);     
     }
  }  
}

BOOL CProcSel::CheckDLLvalid(LPCSTR dllname)
{
CString entry;
    
    prc=0;
    if(theApp.procname!="")
      ::FreeLibrary(GetModuleHandle(theApp.procname));
	HINSTANCE dllinst=::LoadLibrary(dllname);
    prc=(CProc*)GetProcAddress(dllinst,"prc");
    if(!prc)  //keine g�ltige DLL
    {
#ifdef _DEUTSCH    
      MessageBox("Das ist keine g�ltige Prozessor-DLL!","Fehler beim Laden", MB_ICONSTOP|MB_OK);
#else
      MessageBox("This is not a valid processor-DLL!","Error on load", MB_ICONSTOP|MB_OK);   
#endif
      ::FreeLibrary(dllinst);
      theApp.procname=dllname;
      return FALSE;        
    }      
    return TRUE;
}
