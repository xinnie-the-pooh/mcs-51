#ifndef AFX_NDLGBAR_H__26CFB681_D54D_11D1_AF60_444553540000__INCLUDED_
#define AFX_NDLGBAR_H__26CFB681_D54D_11D1_AF60_444553540000__INCLUDED_

// NDlgBar.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Fenster CNDlgBar 

class CNDlgBar : public CDialogBar
{
// Konstruktion
public:
	CNDlgBar();

// Attribute
public:
POINT m_FloatingPosition;
BOOL Created;

// Operationen
public:

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CNDlgBar)
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CNDlgBar();  
	void OnUpdateCmdUI(CFrameWnd* pTarget, BOOL bDisableIfNoHndler);
	// Generierte Nachrichtenzuordnungsfunktionen
protected:
	BOOL docking;
	//{{AFX_MSG(CNDlgBar)
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnDock();
  afx_msg void OnHide();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // AFX_NDLGBAR_H__26CFB681_D54D_11D1_AF60_444553540000__INCLUDED_
