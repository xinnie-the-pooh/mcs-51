// JSTEPDoc.cpp : implementation of the CJSTEPDoc class
//

#include "stdafx.h"
#include "dbgBar.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "JSTEP.h"
#include "JSTEPView.h"
#include "ViewUnknown.h"
#include "StackWnd.h"
#include "bkptedit.h"
#include "TPEdit.h"
#include "JSTEPDoc.h"
#include "RegWnd.h"
#include "AnaWnd.h"
#include "traceview.h"
#include "MainFrm.h"
#include "childfrm.h"
#include "memcfg.h"
#include "coreexport.h"
#include "ndlgbar.h"
#include "procsel.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTracePoint
CTracePoint::CTracePoint()
{
  isValid=FALSE;
  addr=0;
  item=-1;
  pv=0;
}

CTracePoint::~CTracePoint()
{
  
  DeleteAllExpressions();
  isValid=FALSE;
}

void CTracePoint::DeleteAllExpressions()
{ 
  int i;
  int n=expressions.GetSize();
  for(i=0;i<n;i++)
    delete (CString*)(expressions.GetAt(i));
  expressions.RemoveAll();
}

void CTracePoint::SetTracePoint(ULONG addr)
{
  CTracePoint::addr=addr;
}


BOOL CTracePoint::IsTracePointAtAddr(ULONG addr)
{
  if(CTracePoint::addr==addr)
    return TRUE;
  return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// CJSTEPDoc

IMPLEMENT_DYNCREATE(CJSTEPDoc, CDocument)

BEGIN_MESSAGE_MAP(CJSTEPDoc, CDocument)
	//{{AFX_MSG_MAP(CJSTEPDoc)  
  ON_COMMAND(IDC_MIX, OnMix)
  ON_COMMAND(IDC_ASM, OnAsm)
  ON_COMMAND(IDC_HLL, OnHll)
  ON_UPDATE_COMMAND_UI(IDC_HLL, OnUpdateHll)
  ON_UPDATE_COMMAND_UI(IDC_MIX, OnUpdateMix)
  ON_UPDATE_COMMAND_UI(IDC_ASM, OnUpdateAsm)
  ON_COMMAND(IDW_DBGBAR, OnDbgbar)
  ON_UPDATE_COMMAND_UI(IDW_DBGBAR, OnUpdateDbgbar)
  ON_COMMAND(IDR_ANABAR, OnAnabar)
  ON_COMMAND(IDR_JSTEPTYPE,OnPrjbar)
  ON_UPDATE_COMMAND_UI(IDR_JSTEPTYPE,OnUpdatePrjbar)
  ON_UPDATE_COMMAND_UI(IDR_ANABAR, OnUpdateAnabar)
  ON_COMMAND(ID_DEBUG_RUN, OnRun)	 
  ON_UPDATE_COMMAND_UI(ID_DEBUG_RUN, OnUpdateRun)
  ON_COMMAND(ID_DEBUG_STOPDEBUGGING, OnStop)	 
  ON_UPDATE_COMMAND_UI(ID_DEBUG_STOPDEBUGGING, OnUpdateStop)	
  ON_COMMAND(ID_DEBUG_STEPINTO, OnStepIn)	 
  ON_COMMAND(ID_DEBUG_STEPOUT,OnStepOut)
  ON_COMMAND(ID_DEBUG_STEPOVER, OnStepOver)	 
  ON_COMMAND(ID_DEBUG_RUNTOCURSOR, OnRunToCursor)	 
  ON_COMMAND(IDD_REGBAR, OnRegbar)
  ON_UPDATE_COMMAND_UI(IDD_REGBAR, OnUpdateRegbar)  
  ON_COMMAND(IDD_MEMORY, OnMemory)
  ON_COMMAND(IDD_WATCH, OnWatch)
  ON_UPDATE_COMMAND_UI(IDD_WATCH, OnUpdateWatch)
  ON_COMMAND(ID_RESETCPU, OnResetcpu)
  ON_COMMAND(IDD_LOCALS, OnLocals)
  ON_UPDATE_COMMAND_UI(IDD_LOCALS, OnUpdateLocals)
  ON_COMMAND(ID_DEBUG_QUICKWATCH, OnQuickWatch)	
  ON_UPDATE_COMMAND_UI(ID_DEBUG_QUICKWATCH, OnUpdateQuickWatch)	
  ON_COMMAND(IDD_STACK, OnStack)	
  ON_UPDATE_COMMAND_UI(IDD_STACK, OnUpdateStack)	
  ON_COMMAND(IDD_BREAKPOINT, OnBreakpoint)
  ON_COMMAND(IDD_ANALYSER, OnAnalyser)	
  ON_UPDATE_COMMAND_UI(IDD_ANALYSER, OnUpdateAnalyser)
  ON_COMMAND(IDD_TRACEVIEW, OnTrace)	
  ON_UPDATE_COMMAND_UI(IDD_TRACEVIEW, OnUpdateTrace) 
  ON_COMMAND(IDC_TRACEENABLE, OnTraceEnabled)	
  ON_UPDATE_COMMAND_UI(IDC_TRACEENABLE, OnUpdateTraceEnabled) 	
  ON_UPDATE_COMMAND_UI(IDD_MEMORY, OnUpdateMemory)
  ON_COMMAND(IDC_CLRALLBKPT, OnClrBkpt)
  ON_COMMAND(IDC_DEACTALLBKPT,OnDeacBkpt)  
  ON_COMMAND(IDD_TRACEPOINT, OnTracepoint)
  ON_COMMAND(IDC_SETBREAK, OnSetBreak)
  ON_COMMAND(IDC_SETTRACEPOINT, OnSetTracepoint)  
  ON_COMMAND(IDC_UPDATEALL, OnUpdateAll)
  ON_COMMAND(IDC_SETMEASUREPOINT, OnSetMeasurepoint) 
  ON_UPDATE_COMMAND_UI(IDC_SETMEASUREPOINT, OnUpdateMeasurepoint)
  ON_COMMAND(IDC_SETSTIMUPT, OnSetStimulationpoint) 
  ON_UPDATE_COMMAND_UI(IDC_SETSTIMUPT, OnUpdateStimulationpoint)
  ON_UPDATE_COMMAND_UI(IDC_SETTRACEPOINT, OnUpdateTracepoint)
  ON_COMMAND(ID_DEBUG_WATCH, OnWatch)
  ON_UPDATE_COMMAND_UI(ID_DEBUG_WATCH,OnUpdateWatch)
  ON_COMMAND(IDD_MEMORYWND, OnMemory)	
  ON_UPDATE_COMMAND_UI(IDD_MEMORYWND, OnUpdateMemory) 
  ON_COMMAND(IDC_RESETCPU, OnResetcpu)
  ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
  ON_COMMAND_RANGE( IDC_PROCWND0, IDC_PROCWND9, OnProcWnds )
  ON_UPDATE_COMMAND_UI_RANGE( IDC_PROCWND0, IDC_PROCWND9,OnUpdateProcWnds )
  ON_COMMAND(IDD_MEMCFG, OnMemCfg)
  ON_COMMAND(ID_SEBRKATLOC,OnToggleBreak)  
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJSTEPDoc construction/destruction

CJSTEPDoc::CJSTEPDoc()
{

  pthread=0;
  bInit=FALSE;  
  viewmode=HLL;
  pobjinfo=&theApp.objinfo;
  pprc=prc;
  vHLL=FALSE;
  vMIX=FALSE;
  vASM=TRUE;
  b_runEnabled=TRUE;
  b_DbgRun=FALSE;	
  punknown=0;  
  hexloaded=FALSE;  
  stpt.addr=0;
  stpt.isValid=FALSE;  
}

CJSTEPDoc::~CJSTEPDoc() 
{
 
}


/////////////////////////////////////////////////////////////////////////////
// CJSTEPDoc serialization

void CJSTEPDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CJSTEPDoc diagnostics

#ifdef _DEBUG
void CJSTEPDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CJSTEPDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJSTEPDoc commands

BOOL CJSTEPDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
CModDef* mp;
int r;
ULONG addr;
CString title,txt;
CFileStatus fs;
LPCSTR curprofile_p;
  
  if (!CDocument::OnOpenDocument(lpszPathName))
  {
   	return FALSE;	 
  }     
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();    
  //suche ob ein Absolutfile oder ein .wsp -File geladen werden soll  
  title=lpszPathName; 
  txt=title;
  txt.MakeLower();
  r=txt.Find(".ihx");
  if(r!=-1)  //SDC-Hexfile
  {
    if(!LoadSDCProject(txt))
      return FALSE;
    theApp.projectfile=lpszPathName; 
    goto loadhex;
  }
  r=txt.Find(".hex");  
  if(r!=-1)  //Hexfile
  {
h1:
    if(pobjinfo->objLoaded)
    {
      AfxMessageBox(IDS_CANNOTLOADHEX);
      return FALSE;
    }
    else
    {
      theApp.wspfile=title.Left(r)+".wsp";      
      if(!theApp.ProcIsLoaded)  //noch kein Prozessortyp geladen
      {
        curprofile_p=theApp.m_pszProfileName;
        theApp.m_pszProfileName= LPCSTR(theApp.wspfile); 
        txt=theApp.GetProfileString("Project","PROCDLL",0);
        if(txt=="") //nicht gefunden
        {
          CProcSel dlg;
          dlg.DoModal();                    
        }
        else
        {
          theApp.AttachProcessor(txt);		  
        }       
        if(!theApp.ProcIsLoaded)
        {
          theApp.m_pszProfileName=curprofile_p;
          return FALSE;
        }        
      }        
	    theApp.m_pszProfileName=curprofile_p;
      pm->m_menu.LoadMenu(IDR_JSTEPTYPE);
#ifdef _DEUTSCH 
      prc->Init(pm->m_hWnd,_GER);
#else
      prc->Init(pm->m_hWnd);
#endif
      if(::LoadFile((LPCSTR)title))
         return TRUE;
      if(pobjinfo->LoadHexfile(title))
      {                   
        theApp.hexfile=title;     
        pm->m_progress.SetPos(0);        
        hexloaded=TRUE;    
        title.MakeLower();
        r=title.Find(".hex");  
        title=title.Mid(r+1);
        pm->m_browsWnd.AddRoot(title);                           
        goto loadhex;
      }
      return FALSE;
    }     
  }  
  r=title.Find(".wsp");
  if(r!=-1)  //Workspace
  {
    theApp.wspfile=lpszPathName; 
    theApp.m_pszProfileName= LPCSTR(theApp.wspfile);    
    theApp.projectfile=theApp.GetProfileString("Project","Name",0);
    if(theApp.projectfile=="")
    {
      txt=theApp.GetProfileString("Project","Hexfile");
      if(txt != "") 
      {                    
        title=txt;
        goto h1;  //try to load a hexfile
      }
    }
    r=theApp.projectfile.Find(".ihx");
    if(r!=-1)
    {      
      if(!LoadSDCProject(theApp.projectfile))
        return FALSE;
      theApp.wspfile=txt;              
       goto loadhex;
    }
    pobjinfo->globSrcPath=theApp.GetProfileString("Project","SourcePath",0);
    if( pobjinfo->globSrcPath != "")
    {
      r=pobjinfo->globSrcPath.ReverseFind('\\');
      if(r==-1 || r< pobjinfo->globSrcPath.GetLength()-1)
        pobjinfo->globSrcPath+="\\";
    }
  }
  else
  { 
    theApp.projectfile=lpszPathName;    
    if(theApp.wspfile=="")
    {    
      r=title.ReverseFind('.');
      if(r==-1)
        theApp.wspfile=theApp.projectfile + ".wsp";      
      else
        theApp.wspfile=theApp.projectfile.Left(r) + ".wsp";    
    }    
  }  
  theApp.m_pszProfileName= LPCSTR(theApp.wspfile);     
  if(!theApp.ProcIsLoaded)  //noch kein Prozessortyp geladen
  {
     prc=0;
     txt=theApp.GetProfileString("Project","PROCDLL",0);
     if(txt=="") //nicht gefunden
     {
       CProcSel dlg;
       dlg.DoModal();       
     }
     else
     {
       theApp.AttachProcessor(txt);
     } 
     if(!theApp.ProcIsLoaded)
       return FALSE;
  }

  txt=theApp.GetProfileString("Project","Hexfile");
  if(txt != "")
    theApp.hexfile=txt;
  if(theApp.hexfile != "")
  {   
    if(::LoadFile((LPCSTR)theApp.hexfile))
       return TRUE;
    if( !pobjinfo->LoadHexfile(theApp.hexfile))
      theApp.hexfile="";
    pm->m_progress.SetPos(0);
  }
  r=title.ReverseFind('.');
  if(r!=-1)
    title=title.Left(r); 
  r=title.ReverseFind('\\');
  if(r!=-1)
  title=title.Mid(r+1);  
  pm->m_browsWnd.AddRoot(title);    
  pm->m_menu.LoadMenu(IDR_JSTEPTYPE);    
#ifdef _DEUTSCH 
      prc->Init(pm->m_hWnd,_GER);
#else
      prc->Init(pm->m_hWnd);
#endif
  if(theApp.projectfile!="")
  {
    CFile::GetStatus(theApp.projectfile,fs);
    pobjinfo->absfiletime=fs.m_mtime;
    if(::LoadFile(LPCSTR(theApp.projectfile)))
       return TRUE;
    r=pobjinfo->ParseObjFile(LPCSTR(theApp.projectfile));
    if(!r)
    {
      AfxMessageBox(IDS_INVALIDOBJFILE);
      pobjinfo->objLoaded=TRUE;
	    return FALSE;
    }
    if(!pobjinfo->GetModuleCnt())
    {
      AfxMessageBox(IDS_INVALIDOBJFILE);
	    return FALSE;
    }	
    pobjinfo->objLoaded=TRUE;
    pm->m_browsWnd.Expand();	   
  }
 loadhex:

  pm->pDoc=this;  //Zeiger auf das Dokument im Main Window speichern
  pm->m_wndToolBar.LoadToolBar(IDR_JSTEPTYPE);  
 		
  pm->m_DbgBar.Init(pm);	 
  pm->ShowControlBar(&(pm->m_DbgBar),TRUE,TRUE);
  pm->DockControlBar(&(pm->m_DbgBar),AFX_IDW_DOCKBAR_BOTTOM);
   
  pm->m_wndAnalyserBar.Init(pm);
  pm->ShowControlBar(&(pm->m_wndAnalyserBar),TRUE,TRUE);	 
  pm->DockControlBar(&(pm->m_wndAnalyserBar),AFX_IDW_DOCKBAR_BOTTOM);

  // Stackwindow anlegen
  if (!pm->m_wndStack.Created && !pm->m_wndStack.Create(pm,FALSE))
  {
	  TRACE0("Failed to create StackWnd\n");
	  return -1;      // fail to create
  }	 

  ReadWorkspace(theApp.wspfile);
  
  if(hexloaded)  //wenn ein Hexfile geladen wurde muss der Browswer nicht angezeigt werden
    pm->ShowControlBar(&(pm->m_browsWnd),FALSE,FALSE);  
  pm->m_progress.SetPos(0); 
  pm->m_wndStatusBar.SetPaneText(3,prc->GetProcessorName(),TRUE);	
  SetPathName(lpszPathName); // wird hier schon gesetzt weil die Sicht den Pfad ben�tigt    
  if(pobjinfo->GetModuleCnt())
  {
    mp=(CModDef*)(pobjinfo->moduls.GetAt(0));
    addr=mp->GetLowAddr();
  }
  else 
    mp=0;
  if(pobjinfo->IsHLL())
  {		
    vHLL=TRUE;
    vASM=FALSE;
    vMIX=FALSE;		
    if(pobjinfo->FindLabelAddr("MAIN",&addr))
    {
      ViewNewModule(addr);	 
      pm->RecalcLayout(FALSE); 
      return TRUE;
    }
    if(pobjinfo->FindLabelAddr("main",&addr))
    {      
      ViewNewModule(addr); 	
      pm->RecalcLayout(FALSE);  
      return TRUE;
    }
    else     //Main nicht gefunden 
    {         
      ViewNewModule(prc->GetStartUpAddress()); 
      pm->RecalcLayout(FALSE); 
	  return TRUE;
    }
  }
  else if(mp && (addr!= 0xFFFFFFFF || pobjinfo->GetModuleCnt()>1))
  {
    if(addr!=0xFFFFFFFF)
      ViewNewModule(addr);	 
    else
    {
      mp=(CModDef*)(pobjinfo->moduls.GetAt(1));
      addr=mp->GetLowAddr();
      ViewNewModule(addr);
    } 
    pm->RecalcLayout(FALSE); 
    return TRUE;   
  }
  else
  {  
    POSITION pos=GetFirstViewPosition();
    punknown=(CViewUnknown*)GetNextView(pos);
    ViewNewModule(prc->GetStartUpAddress(),TRUE,FALSE);    
    pm->RecalcLayout(FALSE); 
    return TRUE;   
  }       
}



//erzeugt eine neue Sichtbzw aktiviert wenn schon vorhanden das Moduls,
//das die �bergebene Adresse beinhaltet
//wenn setcursor=TRUE wird die Sicht bis zu addr gescrollt 

BOOL CJSTEPDoc::ViewNewModule(ULONG addr, BOOL setcursor,BOOL setstackcur)
{
POSITION pos;
CJSTEPView* pv;
CViewUnknown* pu;
int item;
CMainFrame *pMainWnd;
  
    
  actdisplayAddr=addr;
  pMainWnd=(CMainFrame*)AfxGetMainWnd();
  CModDef* pm=pobjinfo->GetModuleFromAddress(addr);
  CProcDef* pp=pobjinfo->GetProcFromAddr(addr,pm);
  if(!pm || (pp && pp->Procname=="CONST" ))
  { 
    TRACE(" _ViewNewModule: Modul zur Adresse %8.8X nicht gefunden\n",addr);
    if(punknown) // die Sicht f�r unbekanntes Programm existiert schon
    {
      CMDIChildWnd* pw=(CMDIChildWnd*)(punknown->GetParent());
      // Sicht mit Daten f�llen
      pu=(CViewUnknown*)pw->GetDescendantWindow(AFX_IDW_PANE_FIRST,TRUE);      
      if(pMainWnd->winmax)
        pMainWnd->MDIMaximize(pu->GetParent());
      
      pu->SetupUnknownList(addr);
      if(setcursor)
      {
        item=pu->ScrollToAddr(addr);
        pu->GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);		            			
        pu->GetListCtrl().RedrawItems(item,item);
      }
      else if(setstackcur)
      {
        item=pu->ScrollToAddr(addr);
        pu->GetListCtrl().SetItemState(item,LVIS_CUT,LVIS_CUT);
      }  
      if(pw)             
         ((CChildFrame*)pw)->SetSharedMenu(&pMainWnd->m_menu);     
      pu->SetFocus();
      return TRUE;
    }
    else  // die Sicht f�r unbekanntes Programm existiert noch nicht
    {
      CMDIChildWnd* pActiveChild = ((CMDIFrameWnd*)AfxGetMainWnd())->MDIGetActive();           
      CDocTemplate* pTemplate = ((CJSTEPApp*) AfxGetApp())->pDocTemplate1;
      ASSERT_VALID(pTemplate);
      CFrameWnd* pFrame = pTemplate->CreateNewFrame(this,pActiveChild);
      if (pFrame == NULL)
      {
        TRACE0("Warning: failed to create new frame for unknown view\n");
        AfxMessageBox(AFX_IDP_COMMAND_FAILURE);
        return FALSE;        // command failed
      }
      pu=(CViewUnknown*)pFrame->GetDescendantWindow(AFX_IDW_PANE_FIRST,TRUE);
      punknown=pu;	    
      pTemplate->InitialUpdateFrame(pFrame, this);
      if(pMainWnd->winmax)
        pMainWnd->MDIMaximize(pu->GetParent());
      pu->SetupUnknownList(addr);
      if(setcursor)
      {		 
        item=pu->ScrollToAddr(addr);
        pu->GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);			        
      }
      else if(setstackcur)
      {
        item=pu->ScrollToAddr(addr);
        pu->GetListCtrl().SetItemState(item,LVIS_CUT,LVIS_CUT);
      }      
      pu->SetFocus();   
      if (pActiveChild)    
        ((CChildFrame*)pActiveChild)->SetSharedMenu(&pMainWnd->m_menu);   
      return TRUE;
    }
    
  }
  pos=GetFirstViewPosition();
  while(pos)
  {	  
    pv=(CJSTEPView*)GetNextView(pos);	
    if(pv->pmod==pm)  //das Modul wird schon angezeigt
    {
      pv->actitem=-1;
      pv->selend=pv->selstart;
      if(setcursor)
      {        
        item=pv->ScrollToAddr(addr);  
        pv->GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);		        
      }
      else if(setstackcur)
      {
        item=pv->ScrollToAddr(addr);
        pv->GetListCtrl().SetItemState(item,LVIS_CUT,LVIS_CUT);
      }
  	  CMDIChildWnd* pw=(CMDIChildWnd*)(pv->GetParent());       
      pw->MDIActivate();
      pw->SetFocus();
      if(pw)
       ((CChildFrame*)pw)->SetSharedMenu(&pMainWnd->m_menu);   
	  return TRUE;
    }
  }
	// das Modul muss neu angezeigt werden
  pos=GetFirstViewPosition();
  pv=(CJSTEPView*)GetNextView(pos);
  if(!pv->pmod)  //die Sicht existiert schon wurde aber noch nicht initialisiert
  {
    pv->SetupList(pm);
    if(setcursor)
    {
      item=pv->ScrollToAddr(addr);
      pv->GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);			
    }
    else if(setstackcur)
    {
      item=pv->ScrollToAddr(addr);
      pv->GetListCtrl().SetItemState(item,LVIS_CUT,LVIS_CUT);
    }          
    pv->SetFocus();
    if(pMainWnd->winmax)
      pMainWnd->MDIMaximize(pv->GetParent());     
    CChildFrame* pw=(CChildFrame*)(pv->GetParent());  
    if(pw)  
      pw->SetSharedMenu(&pMainWnd->m_menu);   
	return TRUE;
  }
  // die Sicht wird neu erzeugt

  CMDIChildWnd* pActiveChild = pMainWnd->MDIGetActive();           
  //CDocTemplate* pTemplate = ((CJSTEPApp*) AfxGetApp())->pDocTemplate;
  CDocTemplate* pTemplate =GetDocTemplate();
  ASSERT_VALID(pTemplate);
   
  CFrameWnd* pFrame = pTemplate->CreateNewFrame(this,pActiveChild);
  if (pFrame == NULL)
  {
    TRACE0("Warning: failed to create new frame\n");
    AfxMessageBox(AFX_IDP_COMMAND_FAILURE);
    return FALSE;        // command failed
  }

  pv=(CJSTEPView*)pFrame->GetDescendantWindow(AFX_IDW_PANE_FIRST,TRUE);
  pv->SetupList(pm);
  pTemplate->InitialUpdateFrame(pFrame, this);
  if(setcursor)
  {
    item=pv->ScrollToAddr(addr);
    pv->GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);
  }
  else if(setstackcur)
  {
    item=pv->ScrollToAddr(addr);
    pv->GetListCtrl().SetItemState(item,LVIS_CUT,LVIS_CUT);
  }
  pv->SetFocus();
  if(pMainWnd->winmax)
    pMainWnd->MDIMaximize(pFrame); 
  CChildFrame* pw=(CChildFrame*)(pv->GetParent());    
  if(pw)
    pw->SetSharedMenu(&pMainWnd->m_menu);    
  return TRUE;
}


void CJSTEPDoc::OnCloseDocument() 
{
POSITION pos;
ULONG  excode;
BOOL b;
bkpt_t bp;
int i;
CMenu* pmn;

  if(!pobjinfo->objLoaded && !hexloaded)
  { 
    CDocument::OnCloseDocument();
    return;
  }
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(b_DbgRun)
  {
    int i=0xFFFF;
    b_DbgRun=FALSE;    //beendet einen m�glicherweise noch laufenden Thread  
    do    
      b=::GetExitCodeThread(pthread->m_hThread,&excode);
    while(b && i--);
    if( b && !i)  // der l��t sich nicht beenden    
      TerminateThread(pthread->m_hThread,0);    
  }   
  if(!hexloaded)
#ifdef _DEUTSCH 
      prc->Init(0,_GER);
#else
      prc->Init(0);
#endif
  theApp.m_pszProfileName=theApp.wspfile;
  WriteWorkspace(theApp.wspfile);
  theApp.m_pszProfileName= theApp.exepath;
  if(pobjinfo->objLoaded)
    theApp.hexfile="";
  pobjinfo->Clear(); //alle Eintr�ge l�schen	
  prc->ResetCPU();   
  pm->m_wndStatusBar.SetPaneText(1,"",TRUE);
  pm->m_browsWnd.Clear();
  pm->tbvis=0;
  if(pm->m_wndAnalyserBar.Created)
  {
    pm->ShowControlBar(&pm->m_wndAnalyserBar,FALSE,FALSE);
    //DeleteControlBar(&pm->m_wndAnalyserBar);
  }
  if(pm->m_DbgBar.Created)
  { 
    pm->ShowControlBar(&pm->m_DbgBar,FALSE,FALSE);
    //DeleteControlBar(&pm->m_DbgBar);
  }
   
  //Tracepoint l�schen
  tpt.isValid=FALSE;
  tpt.DeleteAllExpressions();
  tpt.pv=0;
  tpt.item=-1;

  // alle Breakpointe l�schen
  pos=0;
  do
  {    
    b=prc->GetNextBreakpoint(pos,&bp);
    if(b)
      prc->RemoveBreakpoint(bp.addr);
  }while(pos);

  // l�schen des Registerfensters
  if(pm->m_wndRegBar && pm->m_wndRegBar.Created==TRUE)
     DeleteControlBar(&pm->m_wndRegBar);
  

  // l�schen des Analyserfensters
  if(pm->m_wndAnalyser.Created==TRUE)
  { 
    pm->m_wndAnalyser.Created=FALSE;
    DeleteControlBar(&pm->m_wndAnalyser);   
  }
     
  // l�schen des Tracefensters
  if(pm->m_pWndTrace && pm->m_pWndTrace->Created==TRUE)
  {    
    DeleteControlBar(pm->m_pWndTrace); 
    delete pm->m_pWndTrace;
    pm->m_pWndTrace=0;    
  }

  // l�schen des Watchfensters
  if(pm->m_wndWatch.Created==TRUE)    
    DeleteControlBar(&pm->m_wndWatch);
  
  //l�schen des Localfensters
  if(pm->m_wndLocals.Created==TRUE)  
    DeleteControlBar(&pm->m_wndLocals);  
  
  // l�schen des Stackfensters  
  if(pm->m_wndStack.Created==TRUE)
     DeleteControlBar(&pm->m_wndStack);
  
 
  //l�schen der Speicherfenster
  pos=pm->memwnds.GetHeadPosition();
  while(pos)
  {
    CMemWnd* pmw=(CMemWnd*)pm->memwnds.GetNext(pos);     
    DeleteControlBar(pmw);
    delete pmw;
    pmw=0;
  }
  pm->memwnds.RemoveAll();
  pm->m_wndToolBar.LoadToolBar(IDR_MAINFRAME);
  pm->RecalcLayout(FALSE);	
 
  //l�schen der Extra DLL Windows
   
  
  
  for(i=0;i<NUMBER_OF_ADDCMDS;i++)
  {
    if(pm->addcmds[i].pWnd)
    {      
      CRuntimeClass* prcl=pm->addcmds[i].pWnd->GetRuntimeClass();      
      if( !strcmp(prcl->m_lpszClassName,"CMRCSizeControlBar"))      
        DeleteControlBar((CMRCSizeControlBar*)pm->addcmds[i].pWnd);     
      else      
        DeleteControlBar((CControlBar*)pm->addcmds[i].pWnd);     
      pm->addcmds[i].pWnd->DestroyWindow();
    } 
    if(pm->addcmds[i].cmdID)
    {
      pmn=&((CMainFrame*)theApp.pMainWnd)->m_menu;
      pmn=pmn->GetSubMenu(2); 
      if(pm->addcmds[i].style==DLLWND_FIX || pm->addcmds[i].style==DLLWND_DYNAMIC)     
      {
        pmn=pmn->GetSubMenu(2);
        if(pmn) 
          pmn->DeleteMenu(11,MF_BYPOSITION);        
      }
      else if(pm->addcmds[i].style==DLLWND_MODAL)   
      {   
        pmn=pmn->GetSubMenu(1);
        if(pmn)
          pmn->DeleteMenu(7,MF_BYPOSITION);
      }  
    }
    delete  pm->addcmds[i].pWnd;
    pm->addcmds[i].cmdID=ID_SEPARATOR;
    pm->addcmds[i].bmpID=IDB_BMPDEFAULT;
    pm->addcmds[i].ttptxt="";
    pm->addcmds[i].menuname.Format("CustomCmd %d",i);      
    pm->addcmds[i].pWnd=0;      
    pm->addcmds[i].stattxt="";
    pm->addcmds[i].style=0;
  }
  pm->addcmdNo=0;
  pm->m_wndAnalyserBar.ResetAnalysBar();

  prc->SetMeasurePoint(0);  
  theApp.wspfile="";
  pm->pDoc=0;
  pthread=0;
  bInit=FALSE;  
  viewmode=HLL;
  pprc=prc;
  vHLL=FALSE;
  vMIX=FALSE;
  vASM=TRUE;
  b_runEnabled=TRUE;	
  punknown=0;  
  hexloaded=FALSE;	
  pm->m_menu.Detach();    
  CDocument::OnCloseDocument();
}

void CJSTEPDoc::OnMix() 
{
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  vMIX=TRUE;
  vHLL=FALSE;
  vASM=FALSE;
  pv->OnUpdate(0,UPDATEMODE_MIX|SETCURSOR,this);
}

void CJSTEPDoc::OnAsm() 
{
	CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
	vASM=TRUE;
	vMIX=FALSE;
	vHLL=FALSE;
	pv->OnUpdate(0,UPDATEMODE_ASM|SETCURSOR,this);
}

void CJSTEPDoc::OnHll() 
{
	CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
	vHLL=TRUE;
	vMIX=FALSE;
	vASM=FALSE;
	pv->OnUpdate(0,UPDATEMODE_HLL|SETCURSOR,this);
}

void CJSTEPDoc::OnUpdateHll(CCmdUI* pCmdUI) 
{
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(!pv)
     return;
  if(b_DbgRun)
    pCmdUI->Enable(FALSE);
  if(pv->vmode==HLL && pv->enableHLL)
  {
	  pCmdUI->SetCheck(TRUE);
		vHLL=TRUE;
		vASM=FALSE;
		vMIX=FALSE;
  }
  else
	{ 		    
    if(pv->enableHLL )  //nur wenn das geladene Modul HLL-Zeilen enth�lt wird das Men� freigegeben
      pCmdUI->SetCheck(FALSE);	
    else
    { 
			pCmdUI->SetCheck(FALSE);
      pCmdUI->Enable(FALSE);	
    } 
  }
}

void CJSTEPDoc::OnUpdateMix(CCmdUI* pCmdUI) 
{
	CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(b_DbgRun)
    pCmdUI->Enable(FALSE);
	if(pv->vmode==MIX && pv->enableHLL)
  {		
  	pCmdUI->SetCheck(TRUE); 
		vMIX=TRUE;
		vASM=FALSE;
		vHLL=FALSE;
  }
	else
	{	 			    
    if(pv && pv->enableHLL)   //nur wenn das geladene Modul HLL-Zeilen enth�lt wird das Men� freigegeben
      pCmdUI->SetCheck(FALSE);	
		else
    { 
			pCmdUI->SetCheck(FALSE);
      pCmdUI->Enable(FALSE);	
    }
  }	
}

void CJSTEPDoc::OnUpdateAsm(CCmdUI* pCmdUI) 
{
  
  if(b_DbgRun)   //nur wenn nicht gerade der Simulator l�uft
  {
     pCmdUI->Enable(FALSE);	
     return;
  }
	CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();

	if(pv->vmode==ASM || !pv->enableHLL )
  {		
  	pCmdUI->SetCheck(TRUE); 
		vASM=TRUE;
		vMIX=FALSE;
		vHLL=FALSE;
  }
	else
	{	 
    pCmdUI->SetCheck(FALSE);	
  }			
}

void CJSTEPDoc::SetViewMode(int mode)
{
	viewmode=mode;
  if(mode==HLL)
  {
		vHLL=TRUE;
		vMIX=FALSE;
    vASM=FALSE;
  }
	else if(mode==MIX)
  {
		vHLL=FALSE;
		vMIX=TRUE;
    vASM=FALSE;
  }
	else
  {
		vHLL=FALSE;
		vMIX=FALSE;
    vASM=TRUE;
  }   
}

void CJSTEPDoc::OnDbgbar() 
{
	CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();   
  BOOL mbvis=pm->m_DbgBar.GetStyle() & WS_VISIBLE;	
	if(mbvis)  
    pm->ShowControlBar(&(pm->m_DbgBar),FALSE,FALSE);		
	else
    pm->ShowControlBar(&(pm->m_DbgBar),TRUE,FALSE);
}


void CJSTEPDoc::OnUpdateDbgbar(CCmdUI* pCmdUI) 
{
	BOOL mbvis=((CMainFrame*)AfxGetMainWnd())->m_DbgBar.GetStyle() & WS_VISIBLE;
	pCmdUI->SetCheck(mbvis && TRUE);
}

void CJSTEPDoc::OnPrjbar() 
{
	CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();   
  BOOL mbvis=pm->m_wndToolBar.GetStyle() & WS_VISIBLE;	
	if(mbvis)  
    pm->ShowControlBar(&(pm->m_wndToolBar),FALSE,FALSE);		
	else
    pm->ShowControlBar(&(pm->m_wndToolBar),TRUE,FALSE);
}

void CJSTEPDoc::OnUpdatePrjbar(CCmdUI* pCmdUI) 
{
	BOOL mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndToolBar.GetStyle() & WS_VISIBLE;
	pCmdUI->SetCheck(mbvis && TRUE);
}

void CJSTEPDoc::OnAnabar() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();   
  if(pm->m_wndAnalyserBar.Created)
  {
    BOOL mbvis=pm->m_wndAnalyserBar.GetStyle() & WS_VISIBLE;	
	  if(mbvis)  
      pm->ShowControlBar(&(pm->m_wndAnalyserBar),FALSE,FALSE);		
	  else
      pm->ShowControlBar(&(pm->m_wndAnalyserBar),TRUE,FALSE);
  }
  else
  {
    pm->m_wndAnalyserBar.Init(pm);
    pm->DockControlBarLeftOf(&pm->m_wndAnalyserBar,&pm->m_wndToolBar);
    if(pm->tbvis & ANALYSERBAR_VISIBLE)
	    pm->ShowControlBar(&(pm->m_wndAnalyserBar),TRUE,FALSE);
  }
}


void CJSTEPDoc::OnUpdateAnabar(CCmdUI* pCmdUI) 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  if(!pm->m_wndAnalyserBar.Created)
    pCmdUI->SetCheck(FALSE);
  else
  {
	  BOOL mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndAnalyserBar.GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);
  }
}

// Debug-Start-free-Run
void CJSTEPDoc::OnRun() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  if(pm->m_wndAnalyser.Created)
    pm->m_wndAnalyser.StartCnt(); 
  pm->m_wndStack.EnableUpdate(FALSE);
  RunCode();	
}

//Debug-StepIn
void CJSTEPDoc::OnStepIn() 
{
  StepIn();	
}

void CJSTEPDoc::OnStepOut()
{
  StepOut();
}

//Debug-Stop
void CJSTEPDoc::OnStop() 
{
	b_DbgRun=FALSE;
}

void CJSTEPDoc::OnUpdateRun(CCmdUI* pCmdUI) 
{  
	if(b_DbgRun)
  {
		pCmdUI->Enable(FALSE); //es kann nicht nochmals gestartet werden    
  }
	else
  {
    pCmdUI->Enable(TRUE);	    
  }
}


void CJSTEPDoc::OnUpdateStop(CCmdUI* pCmdUI) 
{
CMainFrame* pmainwnd=(CMainFrame*)AfxGetMainWnd();

	if(!b_DbgRun)
  {    
		pCmdUI->Enable(FALSE); //es kann nicht nochmals gestartet werden
    if(!b_runEnabled) // damit die Routine nur einmal aufgerufen wird
    {      
      b_runEnabled=TRUE;      
      if(!ViewNewModule(prc->GetProgramCounter(), TRUE))  
      {
        CString msg;
        msg.LoadString(IDS_NOMODULE);
	    	pmainwnd->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);            
      }
      pmainwnd->UpdateAllWatches();      
      pmainwnd->m_wndStack.EnableUpdate(TRUE);
    }
  }
	else
  {
    pCmdUI->Enable(TRUE);	
    b_runEnabled=FALSE;    
  }
}

//Handler f�r Eingabe im Kommandofenster
// c ..change
//   |- p  Label ..setzt Variable auf PDATA
//   |- x  Label ..setzt Variable auf XDATA 
//
// d ..display
//   |- p  [0x] adresse..Programm -Speicher scrollt oder �ffnet das zugeh�rige Code Window
//   |- m  [0x] adresse..Speicher ..
//                                 | /optional Speicherspezifizierer (x,c=default,d,i) 
// 
// b ..breakpoint
//   |- c  l�scht den breakpoint auf label
//   |- s  setzt den breakpoint auf adresse
//   |- a  setzt den aktiven breakpoint auf Hex-adresse
//   |- d  setzt den inaktiven breakpoint auf Hex-adresse
// t ..tracpoint
//   |- s  setzt die Tracepointaddresse  
//   |- a  f�gt einen Ausdruck dazu
// m .. Laufzeit Messpunkt 
// w ..window
//   |- b  Browser Window
//   |- s  Stack Window
//   |- w  Watch Window
//   |- l  Local Window
//   |- a  Analyser Window
//   |- t  Trace Window
//   |- r  Register Window
//   |- m  Memory Window
//      |- a ASCII
//      |- b Byte
//      |- s Short
//      |- l long
//   |- x  Extra DLL-Windows (nur vom Workspace) 
// s .. Speicher Konfiguration
//   |- memspec
//   |- Anfang(hex)
//   |- Ende(hex) 	
// $ - frei f�r kommandos die durch die Prozessor DLL behandelt werden sollen	 

void CJSTEPDoc::OnSetCmd(CString* cmdp ,SizeBarInfo_t* psbi)
{
CString cmd,c1,cmdx;
int len,i;
ULONG addr;
BOOL b;
CMainFrame* pm;
CSize newSize;
CMRCSizeControlBar* pcb;
CString entry,expression;  
ULONG cmdid;
RECT rd;
POINT pt;
int bkptfmt;
              
  pm=(CMainFrame*)theApp.pMainWnd;
  if(cmdp)
  {
    cmd=*cmdp;
    cmdx=*cmdp;
    len=cmd.GetLength();
  }
  else  
    len=((CMainFrame*)(AfxGetMainWnd()))->m_DbgBar.GetDlgItemText(IDC_DBCMDBOX,cmd);
  if(cmd=="")
    return;
  cmdx=cmd;
  cmd.TrimLeft();
  cmd.TrimRight();
  if(cmd.GetLength()>2)
  {
    c1=cmd.Left(2);
    cmd=cmd.Mid(2);
  }
	// Auswertung des Kommandos
  if(cmdx[0]=='$') //Kommando das immer an die Prozessor DLL geht
  {
    ::HandleCommandLine(LPCSTR(cmdx)); 
    return;
  }
  if(!stricmp(cmdx,"stop"))
  {
    b_DbgRun=FALSE;
    return;
  }
  if(!stricmp(cmdx,"update"))
  {
    pm->UpdateAllWatches();
    return;
  }
  if(cmdx.Left(3)=="stm")
  {
    cmd=cmd.Mid(4);
	if(!stpt.isValid)  // es existiert noch kein Stimulationspunkt
    {
      stpt.addr=strtoul(cmd,0,16);
      stpt.isValid=TRUE;
      stpt.item=-1;    
      bkptfmt=prc->GetBkptFormat(stpt.addr);
      prc->SetBreakpoint(stpt.addr,bkptfmt|STIMUPT);
    }
    else  //erst den Alten l�schen
    {
      bkptfmt=prc->GetBkptFormat(stpt.addr);
      prc->SetBreakpoint(stpt.addr,bkptfmt&~STIMUPT);
      stpt.addr=strtoul(cmd,0,16);
      bkptfmt=prc->GetBkptFormat(stpt.addr);
      prc->SetBreakpoint(stpt.addr,bkptfmt|STIMUPT);
    }
    stpt.isValid=TRUE;
    stpt.item=-1;
    return;
  }
  if(c1=="c." || c1=="C.")    //Change variable from XDATA<->PDATA
  {
    c1=cmd[0];
    cmd=cmd.Mid(2);
    cmd.TrimLeft();
    labeldef_t* pl=pobjinfo->FindLabel(&cmd);
    if(!pl)
      return; 
    if(!(pl->memspec & XDATAMEM|PDATAMEM))
      return;    
    if(c1=="x" || c1=="X")    //set to XDATA
    {       
      pl->memspec|=XDATAMEM;  
    }
    else
    if(c1=="p" || c1=="P")    //set to PDATA
    {       
      pl->memspec|=PDATAMEM;
    }
    ((CMainFrame*)(AfxGetMainWnd()))->UpdateAllWatches();
  }
  if(c1=="d." || c1=="D.")    //Display
  {
    c1=cmd[0];
	cmd=cmd.Mid(2);
	cmd.TrimLeft();
	if(c1=="p" || c1=="P")    //view Program
    {			
      if(GetAddrFromString(cmd,&addr))
      {       
        addr &= prc->GetMemSize(CODEMEM);  
        ViewNewModule(addr,TRUE);
      }
    }
    else
      HandleCommandLine(LPCSTR(cmdx));
  }
  else if(c1=="t." || c1=="T.")  //setze..
  {    
    c1=cmd.Left(2);
    cmd=cmd.Mid(2);
    if(c1=="s " || c1=="S ")   // setze Tracepoint
    {
      addr=strtoul(cmd,0,16);
	  tpt.SetTracePoint(addr);  
      tpt.isValid=TRUE;
      return;
    }
    else if(c1=="a " || c1=="A ")   // add Tracepoint expression
    {
      CString* ps=new CString;
      *ps=cmd;
      tpt.expressions.Add(ps);
    }
    else
     ::HandleCommandLine(LPCSTR(cmdx)); 
  } 
  else if(c1=="b." || c1=="B.")  //setze..
  {
    c1=cmd.Left(2);
    cmd=cmd.Mid(2);
    if(c1=="a ")   // setze Breakpoint
    { 
      addr=strtoul(cmd,0,16);
	    prc->SetBreakpoint(addr,BKPT_CODE);        
    }
    if(c1=="d ")   // setze Breakpoint an absoluter Adresse
    { 
      addr=strtoul(cmd,0,16);
	    prc->SetBreakpoint(addr,BKPT_CODE|BKPT_DISABLED);       
    }		
	  cmd.TrimLeft();
    int len=cmd.Find(':');
    if(len==-1)  //modul offenbar nicht angegeben,versuch trotzdem irgend ein Label zu finden
    {										
      b=pobjinfo->FindLabelAddr(cmd,&addr);
    }
    else
    {
	    cmd=cmd.Left(len);
	    int modid=pobjinfo->FindModuleId(cmd);					
	    cmd=cmd.Mid(len+1); //das label
      b=pobjinfo->FindLabelAddr(cmd,&addr,modid);
    }
    if(c1=="s " || c1=="S ")   // setze Breakpoint
    {     
       char bpfmt,memspec=0;
       sscanf(cmd,"%X %c %c", &addr,&bpfmt,&memspec);
       int fmt;
       switch(bpfmt)
       {
          case 'p': 
          case 'P':
          default:  fmt=BKPT_CODE;
                    break;
          case 'r':
          case 'R': fmt=BKPT_READ;
                    break;
          case 'w':
          case 'W': fmt=BKPT_WRITE;
                    break;
          case 'b':
          case 'B': fmt=BKPT_READ+BKPT_WRITE;
                    break;
       }   
       prc->SetBreakpoint(addr,(USHORT)fmt,(USHORT)memspec);             
    }
    else if(c1=="c " || c1=="C ")   // l�sche Breakpoint
    {      
	    if(b)
        prc->RemoveBreakpoint(addr);            
    }        
  }
  else if(c1=="w." || c1=="W.")  //Window..
  {
    c1=cmd.Left(2);
    c1.MakeLower();
    if(cmd.GetLength()>2)
      cmd=cmd.Mid(2);
    cmd.TrimLeft();
    int len=cmd.Find('.');
    pcb=0;
   
    switch(c1[0])
    {
      case 'b': //Browser (das Fenster ist immer vorhanden da autocreated)      
	            pcb=&pm->m_browsWnd;        
                break;
      case 'l': //Locals
                if(!pm->m_wndLocals.Created) 
                {
                  if(!psbi)
                  {
                    pm->m_wndLocals.Create(pm,TRUE);
                    pm->m_wndLocals.barIsInitialised=TRUE;
                    pm->FloatControlBar(&pm->m_wndLocals,pm->m_wndLocals.m_FloatingPosition);
                  }
                  else
                    pm->m_wndLocals.Create(pm,FALSE);                       
                }
                else if(!psbi)
                { 
                  if(!pm->m_wndLocals.barIsInitialised)
                  {
                    pm->m_wndLocals.barIsInitialised=TRUE;
                    pm->FloatControlBar(&pm->m_wndLocals,pm->m_wndLocals.m_FloatingPosition);
                  }
                  pm->ShowControlBar(&pm->m_wndLocals,TRUE,FALSE);           
                }         
                if(psbi && psbi->addData != -1)
                  pm->m_wndLocals.hlc.SetColumnWidth(0,psbi->addData); 
                pcb=&pm->m_wndLocals;  
                break;
      case 's': //Stack      
                if(!pm->m_wndStack.Created) 
                {
                  if(!psbi)
                    pm->m_wndStack.Create(pm,TRUE);
                  else
                    pm->m_wndStack.Create(pm,FALSE); 
                  pm->ShowControlBar(&pm->m_wndStack,TRUE,FALSE);    
                }
                else if(!psbi)
                { 
                  if(!pm->m_wndStack.barIsInitialised)
                  {
                    pm->m_wndStack.barIsInitialised=TRUE;
                    pm->FloatControlBar(&pm->m_wndStack,pm->m_wndStack.m_FloatingPosition);
                  }
                  pm->ShowControlBar(&pm->m_wndStack,TRUE,FALSE);           
                }
                pcb=&pm->m_wndStack;  
                break;                
      case 'a': //Analyser     
                if(!pm->m_wndAnalyser.Created)              
                {
                  pm->m_wndAnalyser.Create(pm); 
                  if(!psbi)
                  {
                    pm->FloatControlBar(&pm->m_wndAnalyser,pm->m_wndAnalyser.m_FloatingPosition);    
                    pm->ShowControlBar(&pm->m_wndAnalyser,TRUE,FALSE);    
                  }
                }
                else
                  pm->ShowControlBar(&pm->m_wndAnalyser,TRUE,FALSE);                               
                break;
     

      case 'w': //Watch 
                if(!pm->m_wndWatch.Created) 
                {
                  if(!psbi)
                  {
                    pm->m_wndWatch.Create(pm,TRUE);
                    pm->m_wndWatch.barIsInitialised=TRUE;
                    pm->FloatControlBar(&pm->m_wndWatch,pm->m_wndWatch.m_FloatingPosition);
                  }
                  else
                    pm->m_wndWatch.Create(pm,FALSE);                       
                }
                else if(!psbi)
                { 
                  if(!pm->m_wndWatch.barIsInitialised)
                  {
                    pm->m_wndWatch.barIsInitialised=TRUE;
                    pm->FloatControlBar(&pm->m_wndWatch,pm->m_wndWatch.m_FloatingPosition);
                  }
                  pm->ShowControlBar(&pm->m_wndWatch,TRUE,FALSE);           
                }                   
                i=0;
                char vtyp;                
                do
                {
                  entry.Format("expression%d",i++);
                  theApp.m_pszProfileName=theApp.wspfile;
                  expression=theApp.GetProfileString("Watches",entry,0); //theApp.m_pszProfileName
                  int l=expression.Find('$');
                  if(l==-1)            
                    pm->m_wndWatch.hlc.AddWatchExpression(expression);
                  else
                  {
                    vtyp= expression.GetAt(l+1);
                    expression=expression.Left(l-1);
                    switch(vtyp)
                    {
                      case 'b':
                      case 'B':
                        pm->m_wndWatch.hlc.AddWatchExpression(expression,FALSE,0,0,V_BIN);
                        break;                    
                      case 'x':
                      case 'X':
                        pm->m_wndWatch.hlc.AddWatchExpression(expression,FALSE,0,0,V_HEX);
                        break;  
                      case 'd':
                      case 'D':
                        pm->m_wndWatch.hlc.AddWatchExpression(expression,FALSE,0,0,V_DEZ);
                        break; 
                    }
                  }
                } while(expression != "");  
                if(psbi && psbi->addData != -1)
                  pm->m_wndWatch.hlc.SetColumnWidth(0,psbi->addData);                  
                pcb=&pm->m_wndWatch;  
                pm->m_wndWatch.hlc.UpdateWatchWnd(FALSE);
                break;
      case 't': //Trace   
                if(c1[1]=='m' || c1[1]=='M')
                  goto Default;             
                if(pm->m_pWndTrace)
                { 
                  if(!pm->m_pWndTrace->Created) 
                  {
                    if(!psbi)
                      pm->m_pWndTrace->Create(pm,TRUE);
                    else
                      pm->m_pWndTrace->Create(pm,FALSE);
                    pm->ShowControlBar(pm->m_pWndTrace,TRUE,FALSE);     
                  }
                  else if(!psbi)
                  {
                    if(!pm->m_pWndTrace->barIsInitialised)
                    {
                      pm->m_pWndTrace->barIsInitialised=TRUE;
                      pm->FloatControlBar(pm->m_pWndTrace,pm->m_pWndTrace->m_FloatingPosition);
                    }
                    pm->ShowControlBar(pm->m_pWndTrace,TRUE,FALSE);             
                  }                   
                } 
                else
                {
                  pm->m_pWndTrace=new CTraceView;
                  pm->m_pWndTrace->Create(pm);
                  pm->m_pWndTrace->ReadTraceFile();
                } 
                pcb=pm->m_pWndTrace;  
                break;
      case 'r': //Register
                if(!pm->m_wndRegBar.Created) 
                {
                  if(!psbi)
                    pm->m_wndRegBar.Create(pm,TRUE);
                  else
                    pm->m_wndRegBar.Create(pm,FALSE);                      
                }                                    
                pcb=&pm->m_wndRegBar;  
                break; 
     
      case 'm': //Memory
              {
                int no=pm->memwnds.GetCount();
                if(no==10)
                {
                  CString msg;
                  msg.LoadString(IDS_MAXMEMWNDS);  
                  AfxMessageBox(LPCSTR(msg)); 	    
                  return;
                }
                if(psbi)
                  pcb=CreateMemWnd(cmd,psbi->cmdID);                   
                else
                  pcb=CreateMemWnd(cmd); 
                break;
              }
      case 'x':
      case 'X':  //extra windows from DLL created from workspace
              {
                CNDlgBar* pd;
                pd=0; 
                pcb=0;
                cmdid=strtoul(cmd,0,16);
                for(i=0;i<NUMBER_OF_ADDCMDS;i++)
                { 
                  if((psbi && psbi->cmdID==pm->addcmds[i].cmdID) || cmdid==pm->addcmds[i].cmdID)
                  {                    
                    int dllID=pm->addcmds[i].cmdID;
                    pm->GetDesktopWindow()->GetWindowRect(&rd);    		  
                    pt.x=rd.right/2-50;
                    pt.y=rd.bottom/2-50;	                            
                    AfxSetResourceHandle(hinstDLL);
                    if( pm->addcmds[i].style== DLLWND_FIX) 
                    {
                      pd=new CNDlgBar;         
                      pd->Create(pm,dllID,CBRS_ALIGN_ANY|CBRS_SIZE_DYNAMIC,dllID); 
                      pd->m_FloatingPosition=pt;                                                                 
                    }
                    else if(pm->addcmds[i].style== DLLWND_DYNAMIC)
                    {
                      pd=(CNDlgBar*)new CMRCSizeDialogBar;  
                      ((CMRCSizeDialogBar*)pd)->m_FloatingPosition=pt;      
                      ((CMRCSizeDialogBar*)pd)->Create(pm,dllID,CBRS_ALIGN_ANY|CBRS_SIZE_DYNAMIC,dllID);  
                    }    
                    AfxSetResourceHandle(AfxGetInstanceHandle());
                    pm->addcmds[i].pWnd=pd;   
                    if(pd)
                    { 
                      HandleExtraWndCmd( dllID,pd->m_hWnd,pd);        	
                      pd->SetBarStyle( pd->GetBarStyle()
			                        | CBRS_FLYBY 
                                    | CBRS_TOOLTIPS
				                    | CBRS_BORDER_ANY
				                    | CBRS_BORDER_3D
                                    | CBRS_SIZE_DYNAMIC );    
                      pd->EnableDocking(CBRS_ALIGN_ANY);    	                                                             
                      pcb=(CMRCSizeDialogBar*)pd;                    
                      if(pm->addcmds[i].style== DLLWND_DYNAMIC)
                        break;
                      else
                      { 
                         pm->FloatControlBar(pd,pt,CBRS_ALIGN_ANY);
                         pm->ShowControlBar(pd,TRUE,FALSE);  
                         return;
                      }
                    }      
                  }                        
                }
              }
              break;
  
      default: 
Default:
              cmdid=HandleCommandLine(LPCSTR(cmdx));
              if(!cmdid)
                return;
              for(i=0;i<NUMBER_OF_ADDCMDS;i++)
              {
                if(pm->addcmds[i].cmdID==cmdid) 
                {
                  OnProcWnds(IDC_PROCWND0+i);   
                  pcb=(CMRCSizeDialogBar*)pm->addcmds[i].pWnd;
                  if(!psbi)  //wenn nicht aus dem Workspace konstruiert
                    return;
                } 
              }                 
              break;
    }
    if(pcb && psbi)
    {
      pcb->m_HorzDockSize=psbi->HorzDockSize;
      pcb->m_VertDockSize=psbi->VertDockSize;
      pcb->m_FloatSize=psbi->FloatSize;
      //pcb->m_FloatingPosition.x=psbi->FloatXPos;
      //pcb->m_FloatingPosition.y=psbi->FloatYPos;
      newSize = pcb->CalcFixedLayout(FALSE,psbi->DockHorz);
      pcb->SetWindowPos(0, 0, 0, newSize.cx, newSize.cy, 
	 		          SWP_NOACTIVATE | SWP_NOZORDER | SWP_NOMOVE);	
     
      pcb->barIsInitialised=TRUE;	
      return;
    }
    else if(!psbi && pcb)
    {                  
      pm->FloatControlBar(pcb,pcb->m_FloatingPosition);
      pm->ShowControlBar(pcb,TRUE,FALSE); 
      pcb->barIsInitialised=TRUE;
    }
  }
  else if(c1=="m." || c1=="M.") 
  {
    if(mpt.isValid)
    {
      prc->SetMeasurePoint(0);
      mpt.isValid=FALSE;
    }
    if(cmd=="")
      return; 
    cmd.TrimLeft();
    mpt.addr=strtoul(cmd,0,16);
    mpt.SetMeasurePoint(mpt.addr);
    mpt.isValid=TRUE;
  }
  else if(c1=="s." || c1=="S.") 
  {
    ULONG s,e;
    char m;
    cmd.TrimLeft();
    m=0;
    sscanf(cmd,"%c %X %X",&m,&s,&e);
    if(m=='0')
      prc->CreateMemInRange(-1,0,0); //defaulteinstellung
    else if(s!=e)  // wenn Anfang und Ende ungleich
      prc->CreateMemInRange((ULONG)m,s,e);
    else if (!s && !e)  //beides Null
      prc->DeleteMem(-1,m);  //l�scht den ganzen Speicherbereich
  }
  else   
    HandleCommandLine(LPCSTR(cmdx));
}

CMemWnd* CJSTEPDoc::CreateMemWnd(CString& cmd,int cmdID)
{
CString c1;
int vtyp;

   CMainFrame* pm=(CMainFrame*)theApp.pMainWnd; 
   vtyp=V_BYTE;
   if(cmd=="")
     goto c1;
   cmd.TrimLeft();
   switch(cmd[0])
   {
     case 'S':
     case 's': vtyp=V_SHORT;
               break;
     case 'L':
     case 'l': vtyp=V_LONG;
               break;
     case 'A':
     case 'a':
               vtyp=V_ASCII;
               break;
     case 'b': 
     case 'B': 
     default:  vtyp=V_BYTE;
               break;             
   }
   
   cmd=cmd.Mid(2);
c1:
   CMemWnd* mw=new CMemWnd(vtyp,0,0);
   if(cmdID==-1)
   {  
     int no=pm->memwnds.GetCount();
     int id=IDD_MEMBAR;
     CMemWnd* pmw;
mw1:
     POSITION pos=pm->memwnds.GetHeadPosition();
     while(pos)
     {
       pmw=(CMemWnd*)pm->memwnds.GetNext(pos); 
       if(pmw->GetDlgCtrlID()==id)
       {
         id++;
         goto mw1;
       }
     }   
     if(!mw->Create( pm,id-IDD_MEMBAR ))
       TRACE("Failed to create memory window\n");	   
   }
   else
   {
     if(!mw->Create( pm,cmdID-IDD_MEMBAR))
       TRACE("Failed to create memory window\n");
   }
   mw->SetAddress(cmd);
   pm->memwnds.AddTail(mw);
   return mw;   
}

// erzeugt ein neues Speicherfenster
void CJSTEPDoc::OnMemory() 
{
	
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  int no=pm->memwnds.GetCount();
  if(no==10)
  {
    CString msg;
    msg.LoadString(IDS_MAXMEMWNDS);  
    AfxMessageBox(LPCSTR(msg)); 	    
    return;
  }
  CString txt;
  txt="w.m 0x0000"; 
  CMemWnd* mw=CreateMemWnd(txt);
  mw->Init(0);  
  pm->FloatControlBar(mw,mw->m_FloatingPosition);
  pm->ShowControlBar(mw,TRUE,FALSE);
}

void CJSTEPDoc::OnRegbar() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  if(pm->m_wndRegBar.Created)
  {
    BOOL mbvis=pm->m_wndRegBar.GetStyle() & WS_VISIBLE;	
	if(mbvis)  
      pm->ShowControlBar(&pm->m_wndRegBar,FALSE,FALSE);		
	else
    {
      if(!pm->m_wndRegBar.barIsInitialised)
      {
        pm->m_wndRegBar.barIsInitialised=TRUE;
        pm->FloatControlBar(&pm->m_wndRegBar,pm->m_wndRegBar.m_FloatingPosition);
      }
      pm->ShowControlBar(&pm->m_wndRegBar,TRUE,FALSE);
    }
    pm->m_wndRegBar.UpdateAllRegisters();
    pm->m_wndRegBar.UpdateAllRegisters(); 
  }
  else
  {
    CString txt("w.r");
    OnSetCmd(&txt);   
  }  
}

void CJSTEPDoc::OnUpdateRegbar(CCmdUI* pCmdUI) 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pm->m_wndRegBar.Created)
  {
	  BOOL mbvis=pm->m_wndRegBar.GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);   
  }
  else
    pCmdUI->SetCheck(FALSE); // noch gar nicht erzeugt 
}

void CJSTEPDoc::OnToggleBreak()
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->actitem == -1)
    return;
  if(pv->actitem == -1)
    return;  
  if(pv->vmode != ASM)
  {   
	  ULONG linestate= pv->dispstate.GetAt(pv->actitem);      
	  if(!(linestate & LINEADDRVALID))
      return;
  }
  ULONG nextaddr=pv->GetListCtrl().GetItemData(pv->actitem);
  if(prc->IsBreakpointAtAddr(nextaddr,BKPT_CODE))
  {
    prc->RemoveBreakpoint(nextaddr); 
  }
  else
  { 
    prc->SetBreakpoint(nextaddr,BKPT_CODE); 
  } 
  pv->GetListCtrl().RedrawItems(pv->actitem,pv->actitem);   
}


void CJSTEPDoc::OnSetBreak()
{
ULONG nextaddr; 
  
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->actitem == -1)
    return;  
  nextaddr=pv->GetListCtrl().GetItemData(pv->actitem);
  if(pv->vmode != ASM)
  {   
	  ULONG linestate= pv->dispstate.GetAt(pv->actitem);      
	  if(linestate & LINEADDRVALID)
      prc->SetBreakpoint(nextaddr,BKPT_CODE);    
  } 
  else
    prc->SetBreakpoint(nextaddr,BKPT_CODE); 
  pv->GetListCtrl().RedrawItems(pv->actitem,pv->actitem);
}

void CJSTEPDoc::OnSetStimulationpoint()
{
ULONG nextaddr;
USHORT bkptfmt;
BOOL bvisible=FALSE;

  CMainFrame* pm=(CMainFrame*)theApp.pMainWnd;    
  if(pm->m_wndAnalyser.Created)
    bvisible=pm->m_wndAnalyser.GetStyle() & WS_VISIBLE;
  if(!bvisible)
    return;
  CMDIChildWnd *pChild =(CMDIChildWnd *) pm->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->actitem == -1)
  {
    if(stpt.isValid)
      ViewNewModule(stpt.addr,TRUE);
    return;  
  }
  nextaddr=pv->GetListCtrl().GetItemData(pv->actitem);
  if(stpt.isValid && stpt.addr == nextaddr && pv->actitem==stpt.item)
  {
    stpt.isValid=FALSE;
    bkptfmt=prc->GetBkptFormat(stpt.addr);
    prc->RemoveBreakpoint(stpt.addr,CODEMEM);
	  if(bkptfmt & ~STIMUPT)	 
      prc->SetBreakpoint(stpt.addr,bkptfmt&~STIMUPT);
    pv->GetListCtrl().RedrawItems(stpt.item,stpt.item);
  } 
  else if(!stpt.isValid && stpt.addr==nextaddr && pv->actitem==stpt.item)
  {
    stpt.isValid=TRUE;
    bkptfmt=prc->GetBkptFormat(stpt.addr);
    prc->SetBreakpoint(stpt.addr,bkptfmt|STIMUPT);
    pv->GetListCtrl().RedrawItems(stpt.item,stpt.item);
  }
  else
  {
    if(stpt.isValid && stpt.pv)
    {
      bkptfmt=prc->GetBkptFormat(stpt.addr);
      prc->RemoveBreakpoint(stpt.addr,CODEMEM);
      if(bkptfmt & ~STIMUPT)	 
        prc->SetBreakpoint(stpt.addr,bkptfmt&~STIMUPT);
      ((CListCtrl*)stpt.pv)->RedrawItems(stpt.item,stpt.item);   
    } 
    if(pv->vmode != ASM)
    {   
	  ULONG linestate= pv->dispstate.GetAt(pv->actitem);      
	  if(linestate & LINEADDRVALID)
      {
		bkptfmt=prc->GetBkptFormat(nextaddr);
        prc->SetBreakpoint(nextaddr,bkptfmt|STIMUPT);   
		stpt.addr=nextaddr;         
        stpt.isValid=TRUE;
        stpt.item=pv->actitem;
        stpt.pv=&(pv->GetListCtrl());
      }
    }    
    else
    {
      bkptfmt=prc->GetBkptFormat(nextaddr);
      prc->RemoveBreakpoint(stpt.addr,CODEMEM);
	  if(bkptfmt & ~STIMUPT)	 
         prc->SetBreakpoint(stpt.addr,bkptfmt&~STIMUPT);  
	  stpt.addr=nextaddr; 
      stpt.isValid=TRUE;
      stpt.item=pv->actitem;
      stpt.pv=&(pv->GetListCtrl());
    }
    pv->GetListCtrl().RedrawItems(pv->actitem,pv->actitem);
  }
  if(pm->m_wndAnalyser.Created && pm->m_wndAnalyser.GetStyle() & WS_VISIBLE)
      pm->m_wndAnalyser.UpdateAnalyser(); 
}

void CJSTEPDoc::OnUpdateStimulationpoint(CCmdUI* pCmdUI)
{  
  BOOL bvisible=FALSE; 
  if(((CMainFrame*)theApp.pMainWnd)->m_wndAnalyser.Created)
    bvisible=((CMainFrame*)theApp.pMainWnd)->m_wndAnalyser.GetStyle() & WS_VISIBLE;
  pCmdUI->Enable(bvisible);
  pCmdUI->SetCheck(stpt.isValid);
}

void CJSTEPDoc::OnSetMeasurepoint()
{
ULONG nextaddr;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->actitem == -1)
  {
    if(mpt.isValid)
      ViewNewModule(mpt.addr,TRUE);
    return;  
  }
  nextaddr=pv->GetListCtrl().GetItemData(pv->actitem);
  if(mpt.addr == nextaddr && mpt.isValid && pv->actitem==mpt.item)
  {
    mpt.isValid=FALSE;
    prc->SetMeasurePoint(0);
    pv->GetListCtrl().RedrawItems(mpt.item,mpt.item);
  } 
  else if(mpt.addr==nextaddr && !mpt.isValid && pv->actitem==mpt.item)
  {
    mpt.isValid=TRUE;
    prc->SetMeasurePoint(&mpt);
    pv->GetListCtrl().RedrawItems(mpt.item,mpt.item);
  }
  else
  {
    if(mpt.pv && mpt.isValid)
    {
      mpt.ResetMeasure();  // den alten Messpunkt l�schen
      prc->SetMeasurePoint(0);
      ((CListCtrl*)mpt.pv)->RedrawItems(mpt.item,mpt.item);   
    } 
    if(pv->vmode != ASM)
    {   
	  ULONG linestate= pv->dispstate.GetAt(pv->actitem);      
	  if(linestate & LINEADDRVALID)
      {
        mpt.SetMeasurePoint(nextaddr);  
        mpt.isValid=TRUE;
        mpt.item=pv->actitem;
        mpt.pv=&(pv->GetListCtrl());
      }
    }    
    else
    {
      mpt.SetMeasurePoint(nextaddr);  
      mpt.isValid=TRUE;
      mpt.item=pv->actitem;
      mpt.pv=&(pv->GetListCtrl());
    }
    pv->GetListCtrl().RedrawItems(pv->actitem,pv->actitem);
  }
  if(pm->m_wndAnalyser.Created && pm->m_wndAnalyser.GetStyle() & WS_VISIBLE)
      pm->m_wndAnalyser.UpdateAnalyser(); 
}

void CJSTEPDoc::OnUpdateMeasurepoint(CCmdUI* pCmdUI)
{  
  pCmdUI->SetCheck(mpt.isValid);
}

void CJSTEPDoc::OnUpdateTracepoint(CCmdUI* pCmdUI)
{  
  pCmdUI->SetCheck(tpt.isValid);
}

void CJSTEPDoc::OnSetTracepoint()
{
ULONG nextaddr;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->actitem == -1)
  {
    if(tpt.isValid)
      ViewNewModule(tpt.GetAddr(),TRUE);
    return;  
  }
  nextaddr=pv->GetListCtrl().GetItemData(pv->actitem);
  if(tpt.IsTracePointAtAddr(nextaddr) && tpt.isValid && pv->actitem==tpt.item)
  {
    tpt.isValid=FALSE;
    pv->GetListCtrl().RedrawItems(tpt.item,tpt.item);
  } 
  else if(tpt.IsTracePointAtAddr(nextaddr) && !tpt.isValid && pv->actitem==tpt.item)
  {
    tpt.isValid=TRUE;
    pv->GetListCtrl().RedrawItems(tpt.item,tpt.item);
  }
  else
  {
    if(tpt.pv && tpt.isValid)
      ((CListCtrl*)tpt.pv)->RedrawItems(tpt.item,tpt.item);    
    if(pv->vmode != ASM)
    {   
	  ULONG linestate= pv->dispstate.GetAt(pv->actitem);      
	  if(linestate & LINEADDRVALID)
      {
        tpt.SetTracePoint(nextaddr);  
        tpt.isValid=TRUE;
        tpt.item=pv->actitem;
        tpt.pv=&(pv->GetListCtrl());
      }
    }    
    else
    {
      tpt.SetTracePoint(nextaddr);  
      tpt.isValid=TRUE;
      tpt.item=pv->actitem;
      tpt.pv=&(pv->GetListCtrl());
    }
    pv->GetListCtrl().RedrawItems(pv->actitem,pv->actitem);
  }
}

void CJSTEPDoc::RunToCursor()
{
ULONG addr,nextaddr;
CString txt;
ULONG bkptfmt;  
  
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  if(pm->m_wndAnalyser.Created)
    pm->m_wndAnalyser.StartCnt(); 
  addr=prc->GetProgramCounter();  
  CMDIChildWnd *pChild =(CMDIChildWnd *) ((CMainFrame*)AfxGetMainWnd())->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->actitem == -1)
    return;  
  nextaddr=pv->GetListCtrl().GetItemData(pv->actitem);
  bkptfmt=prc->IsBreakpointAtAddr(nextaddr);
  if(pv->vmode != ASM)
  {   
	ULONG linestate= pv->dispstate.GetAt(pv->actitem);      
	if(linestate & LINEADDRVALID)
    {
      if(addr==nextaddr)
        prc->ExecNextCmd(); 
      if(!bkptfmt || bkptfmt & BKPT_DISABLED)
        prc->SetBreakpoint(nextaddr,BKPT_CODE|BKPT_TMP);      
      OnRun();
    }
  }
  else
  {
     if(addr==nextaddr)
        prc->ExecNextCmd();
     if(!bkptfmt || bkptfmt & BKPT_DISABLED)
        prc->SetBreakpoint(nextaddr,BKPT_CODE|BKPT_TMP);          
     OnRun();
  }
}

void CJSTEPDoc::StepOver() 
{	
ULONG addr,nextaddr;
CString txt;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  addr=prc->GetProgramCounter();
  CMDIChildWnd *pChild =(CMDIChildWnd *) pm->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->vmode==ASM || pv->vmode==MIX ) // in diesen Modi wird auf ASM-Level gesteppt
  {
    nextaddr=prc->GetStepOverAddr(addr); 
    if(nextaddr==addr)
      StepIn();
    else
    {
      prc->SetBreakpoint(nextaddr,BKPT_CODE|BKPT_TMP);      
      if(pm->m_wndAnalyser.Created)
        pm->m_wndAnalyser.StartCnt(); 
      RunCode();
    }
  }
  else
  {
    nextaddr=addr;
    if(pobjinfo->FindNextHLLAddress( &nextaddr,pv->pmod->ModID ))    
    {
      CProcDef* pd1=pobjinfo->GetProcFromAddr(addr,pv->pmod);
      CProcDef* pd2=pobjinfo->GetProcFromAddr(nextaddr,pv->pmod);
      if(pd1 && pd2 && pd1==pd2)
      {
        CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
        if(pm->m_wndAnalyser.Created)
          pm->m_wndAnalyser.StartCnt();   
        RunCode(STEPOVER_HLL|STEP_HLL);
      }
      else
        StepIn();
    } 
    else
      StepIn();
  }
}

int CJSTEPDoc::StepIn()
{
ULONG addr;
int ret=0;
CString msg;

   
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  if(pm->m_wndAnalyser.Created)
    pm->m_wndAnalyser.StartCnt();  
  if(!ViewNewModule(prc->GetProgramCounter(), TRUE)) 
  {    
    msg.LoadString(IDS_NOMODULE);
	  pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);            
  }  
  CMDIChildWnd *pChild =(CMDIChildWnd *) pm->MDIGetActive();
  CJSTEPView* pv= (CJSTEPView*) pChild->GetActiveView();
  if(pv->vmode==ASM || pv->vmode==MIX ) // in diesen Modi wird auf ASM-Level gesteppt
  {
    ret=prc->ExecNextCmd();
    if( ret == -1)  //wir stehen grade auf einem Breakpoint,also muss der vor�bergehend 
    {               // entfernt werden
      addr=prc->GetProgramCounter();
      USHORT fmt=prc->GetBkptFormat(addr);
      prc->RemoveBreakpoint(addr);
      prc->ExecNextCmd();  //jetzt nochmal
      if( !(fmt & BKPT_TMP))  //tempor�re Breakpoints werden nicht wieder gesetzt
        prc->SetBreakpoint(addr,fmt);
    }
    if(!ViewNewModule(prc->GetProgramCounter(), TRUE))  
	{    
      msg.LoadString(IDS_NOMODULE);
	  pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);            
    }  
    pm->UpdateAllWatches();    
    pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,"");
  } 
  else  // step auf HLL-Level
  {
    RunCode(STEP_HLL);    
    //pm->UpdateAllWatches();
  }  
  return ret;
}


BOOL CJSTEPDoc::GetAddrFromString(CString& cmd,ULONG* addr )
{
ULONG a;
BOOL b;
CString c1;

  if(cmd.Left(2)=="0x" || cmd.Left(2)=="0X")  //k�nnte eine hexadezimale Adresse sein
  {
    c1=cmd.Mid(2);
	  if(IsHexString(c1))
    {
		   *addr=strtoul(LPCSTR(c1),0,16);          		 
       return TRUE;
    }
  }
  else if(IsDezString(cmd)) //Dezimaladresse
  {
	  *addr=strtoul(LPCSTR(cmd),0,10);
    return TRUE;
  }
  else
  {
    int len=cmd.Find('.');
    if(len==-1)  //modul offenbar nicht angegeben,versuch trotzdem irgend ein Label zu finden
    {										
      b=pobjinfo->FindLabelAddr(cmd,&a);
    }
    else
    {
		  cmd=cmd.Left(len);
		  int modid=pobjinfo->FindModuleId(cmd);					
		 	cmd=cmd.Mid(len+1); //das label
      b=pobjinfo->FindLabelAddr(cmd,&a,modid);
    }
		if(b)  // wenn eine adresse gefunden wurde
    {
       *addr=a;
       return TRUE;
    }
  }
  return FALSE;
}

void CJSTEPDoc::OnRunToCursor()
{
  RunToCursor();  
}


void CJSTEPDoc::OnStepOver() 
{
  StepOver();
}

void CJSTEPDoc::RunCode(int option)
{
CMainFrame* pm;
USHORT fmt;

  pm=(CMainFrame*)AfxGetMainWnd();
  pm->m_wndStack.lbx.unlocked1=TRUE; 
  ULONG pc=prc->GetProgramCounter();
  ULONG bkptfmt=prc->IsBreakpointAtAddr(pc);
  if(bkptfmt&BKPT_CODE && !(bkptfmt&BKPT_DISABLED) ) //�berspringen
  {   
    fmt=prc->GetBkptFormat(pc);
    prc->RemoveBreakpoint(pc);
    prc->ExecNextCmd();  
    prc->SetBreakpoint(pc,fmt);
    prc->RestoreBkpt(pc);  
    if((option & (STEPOVER_HLL|STEP_HLL)) && pobjinfo->IsHLLLine(prc->GetProgramCounter()))
    {
      ViewNewModule(prc->GetProgramCounter(),TRUE);
      return;  //Die HLL-Zeile enthielt nur einen Assemblerbefehl
    }
  }
  b_DbgRun=TRUE;  
  b_runEnabled=FALSE;
  threadpar.pprc=pprc;
  threadpar.b_DbgRun=&b_DbgRun;
  threadpar.option=option;
  threadpar.pobjinfo=pobjinfo;
  threadpar.hwd=AfxGetMainWnd()->m_hWnd;      
  pthread=AfxBeginThread(FreeRun,&threadpar,THREAD_PRIORITY_NORMAL);
}

void CJSTEPDoc::StepOut()
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  if(pm->m_wndAnalyser.Created)
    pm->m_wndAnalyser.StartCnt(); 
  RunCode(STEPOUT);
}


//wenn ein Breakpoint erreicht wurde wird  -1 zur�ckgegeben ansonsten
//l�uft es ewig, Bei Abbruch ret=-2
//Bei Step HLL ret -3
//Bei RunToCursor  -4
 
UINT FreeRun( LPVOID tp ) 
{
int ret;
CProcDef* prdef;
ULONG laddr=0;
ULONG haddr=(ULONG)-1;

  ULONG curaddr=prc->GetProgramCounter();    
  if(((threadpar_t*)tp)->option & STEPOVER_HLL)
  {       
    prdef=((threadpar_t*)tp)->pobjinfo->GetProcFromAddr(curaddr);
    if(prdef)
    {
      laddr=prdef->AnfAddr;
      haddr=prdef->EndAddr;
    }
  }
  do
  {
    ret=prc->ExecNextCmd();
    if(ret ==-1)
    {    
      *((threadpar_t*)tp)->b_DbgRun=FALSE;
      prc->ClrTempBkpt(prc->GetProgramCounter());        
      break;
    }
    else if(!(*((threadpar_t*)tp)->b_DbgRun))  // Abbruch durch den Benutzer
    {
      ret=-2;
      break;
    }
    else if(((threadpar_t*)tp)->option & STEPOUT)
    {
      if( prc->IsReturn(prc->GetProgramCounter()))
      {
        ret=-5;
        prc->ExecNextCmd();  //noch eins weiter
        *((threadpar_t*)tp)->b_DbgRun=FALSE;  
        break;
      }
    }
    else if(((threadpar_t*)tp)->option & STEP_HLL)
    {
      if(((threadpar_t*)tp)->pobjinfo->IsHLLLine(prc->GetProgramCounter()))
      {
        if(! (((threadpar_t*)tp)->option & STEPOVER_HLL) )  // StepIn auf HLL-Level
        {
          ret=-3;
          *((threadpar_t*)tp)->b_DbgRun=FALSE;  
          break;
        }
        else  //StepOver auf HLL,dh. erst wieder anhalten wenn die              
        {     //AusgangsProzedur erreicht wurde
          curaddr=prc->GetProgramCounter();
          if( curaddr >= laddr && curaddr<=haddr) //der PC befindet sich (wieder) innerhalb der Prozedur
          {          
            ret=-4;
            *((threadpar_t*)tp)->b_DbgRun=FALSE;  
            break;
          }
        }
      } 
    }
  } 
  while(!ret);   //wenn ein Breakpoint erreicht wurde wird  -1 zur�ckgegeben    
  ::PostMessage(((threadpar_t*)tp)->hwd,UM_THREADEND,0,prc->GetProgramCounter());  
  AfxEndThread( ret );
  return ret;
}

void CJSTEPDoc::OnUpdateAll() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd(); 
  pm->UpdateAllWatches();
}

void CJSTEPDoc::OnWatch() 
{
	CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  if(pm->m_wndWatch.Created)
  {
    BOOL mbvis=pm->m_wndWatch.GetStyle() & WS_VISIBLE;	
	  if(mbvis)  
      pm->ShowControlBar(&pm->m_wndWatch,FALSE,FALSE);		
	  else
    {
      if(!pm->m_wndWatch.barIsInitialised)
      {
        pm->m_wndWatch.barIsInitialised=TRUE;
        pm->FloatControlBar(&pm->m_wndWatch,pm->m_wndWatch.m_FloatingPosition);
      }
      pm->ShowControlBar(&pm->m_wndWatch,TRUE,FALSE);
    }
  }
  else
  {
    CString txt("w.w");
    OnSetCmd(&txt);
    pm->m_wndWatch.hlc.obext=pobjinfo->ObExt; //Gross-/Kleinschreibung
  }
}

void CJSTEPDoc::OnUpdateWatch(CCmdUI* pCmdUI) 
{
  if(((CMainFrame*)AfxGetMainWnd())->m_wndWatch.Created)
  {
	  BOOL mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndWatch.GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);	
  } 
}


void CJSTEPDoc::OnResetcpu() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  b_DbgRun=FALSE;
	prc->ResetCPU();
  ViewNewModule(prc->GetStartUpAddress(),TRUE);  
  mpt.ResetMeasure();
  pm->UpdateAllWatches();	
  pm->m_wndStack.Clear(); 
}

void CJSTEPDoc::OnLocals() 
{
	CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  if(pm->m_wndLocals.Created)
  {
    BOOL mbvis=pm->m_wndLocals.GetStyle() & WS_VISIBLE;	
	  if(mbvis)  
      pm->ShowControlBar(&pm->m_wndLocals,FALSE,FALSE);		
	  else
    {
      if(!pm->m_wndLocals.barIsInitialised)
      {
        pm->m_wndLocals.barIsInitialised=TRUE;
        pm->FloatControlBar(&pm->m_wndLocals,pm->m_wndLocals.m_FloatingPosition);
      }
      pm->ShowControlBar(&pm->m_wndLocals,TRUE,FALSE);
    }
  }
  else
  {
    CString txt("w.l");
    OnSetCmd(&txt);
    pm->m_wndLocals.hlc.obext=pobjinfo->ObExt; //Gross-/Kleinschreibung
  }  
}

void CJSTEPDoc::OnUpdateLocals(CCmdUI* pCmdUI) 
{
	if(((CMainFrame*)AfxGetMainWnd())->m_wndLocals.Created)
  {
	  BOOL mbvis=((CMainFrame*)AfxGetMainWnd())->m_wndLocals.GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);	
  }
}


void CJSTEPDoc::OnUpdateQuickWatch(CCmdUI* pCmdUI) 
{
char namebuff[20];
CJSTEPView* pv;

 
  pv = (CJSTEPView*)(((CMainFrame*)AfxGetMainWnd())->GetFocus());	
	if(!pv)
  {
		pCmdUI->Enable(FALSE);
		return;
  }
	::GetClassName(pv->m_hWnd,namebuff,sizeof(namebuff));
	if(strcmp(namebuff,"NList"))
  {
		pCmdUI->Enable(FALSE);
		return;
  }
  if(pv->selstart== pv->selend)
    pCmdUI->Enable(FALSE);
  else
    pCmdUI->Enable(TRUE);
}

void CJSTEPDoc::OnQuickWatch() 
{
  CJSTEPView* pv = (CJSTEPView*)(((CMainFrame*)AfxGetMainWnd())->GetFocus());
  pv->OpenQuickWatch();
}



void CJSTEPDoc::OnStack() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pm->m_wndStack.Created)
  {
    BOOL mbvis=pm->m_wndStack.GetStyle() & WS_VISIBLE;	
	  if(mbvis)  
      pm->ShowControlBar(&pm->m_wndStack,FALSE,FALSE);		
	  else
    {
      if(!pm->m_wndStack.barIsInitialised)
      {
        pm->m_wndStack.barIsInitialised=TRUE;
        pm->FloatControlBar(&pm->m_wndStack,pm->m_wndStack.m_FloatingPosition);
      }
      pm->ShowControlBar(&pm->m_wndStack,TRUE,FALSE);
    }
  }
  else
  {
    CString txt("w.s");
    OnSetCmd(&txt);
  }
}


void CJSTEPDoc::OnUpdateStack(CCmdUI* pCmdUI) 
{

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  if(pm->m_wndStack.Created)
  {
    BOOL mbvis=pm->m_wndStack.GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);
    return;
  }
  pCmdUI->SetCheck(FALSE);
}

CView* CJSTEPDoc::GetViewFromModule(CModDef* pm)
{
POSITION pos;
CJSTEPView* pv;

  pos=GetFirstViewPosition();
	while(pos)
  {	  
	  pv=(CJSTEPView*)GetNextView(pos);	
    if(pv->pmod==pm)  //das Modul wird schon angezeigt
    {
      return pv;
    }
  }
  return 0;
}

void CJSTEPDoc::OnBreakpoint() 
{
  CBkptEdit bd;
  bd.DoModal();
}


void CJSTEPDoc::OnMemCfg()
{
  CMemCfg md;
  md.DoModal();
}
                         
void CJSTEPDoc::OnAnalyser() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if( pm->m_wndAnalyser.Created)
  {
    BOOL mbvis=pm->m_wndAnalyser.GetStyle() & WS_VISIBLE;	
	if(mbvis)  
      pm->ShowControlBar(&pm->m_wndAnalyser,FALSE,FALSE);		
	else
      pm->ShowControlBar(&pm->m_wndAnalyser,TRUE,FALSE);      
  }
  else
  {
    pm->m_wndAnalyser.Create(pm);  
    pm->FloatControlBar(&pm->m_wndAnalyser,pm->m_wndAnalyser.m_FloatingPosition);    
    pm->ShowControlBar(&pm->m_wndAnalyser,TRUE,FALSE);   
  }
}


void CJSTEPDoc::OnUpdateAnalyser(CCmdUI* pCmdUI) 
{

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  if(pm->m_wndAnalyser.Created)
  {
    BOOL mbvis=pm->m_wndAnalyser.GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);
    return;
  }
  else
  {
    pCmdUI->SetCheck(FALSE);
  }
}






void CJSTEPDoc::OnTrace() 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pm->m_pWndTrace)
  {
    if( pm->m_pWndTrace->Created)
    {
      BOOL mbvis=pm->m_pWndTrace->GetStyle() & WS_VISIBLE;	
	    if(mbvis)  
        pm->ShowControlBar(pm->m_pWndTrace,FALSE,FALSE);		
	    else
      { 
        pm->ShowControlBar(pm->m_pWndTrace,TRUE,FALSE);
        pm->m_pWndTrace->ReadTraceFile();
      }
    }    
  }
  else
  {
    pm->m_pWndTrace=new CTraceView;
    pm->m_pWndTrace->Create(pm);
    pm->FloatControlBar(pm->m_pWndTrace,pm->m_pWndTrace->m_FloatingPosition);
    pm->m_pWndTrace->ReadTraceFile();
  }
}

void CJSTEPDoc::OnUpdateTrace(CCmdUI* pCmdUI) 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  if(pm->m_pWndTrace && pm->m_pWndTrace->Created)
  {
    BOOL mbvis=pm->m_pWndTrace->GetStyle() & WS_VISIBLE;
	  pCmdUI->SetCheck(mbvis && TRUE);    
  }
  else
  {   
    pCmdUI->SetCheck(FALSE);
  }
}

void CJSTEPDoc::OnTraceEnabled() 
{ 
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  /*
  if(!pm->m_wndAnalyser.traceEnabled) 
  {  
    pobjinfo->EnableTraceLog("temptrace.log", ,tpt.GetAddr());
    pm->m_wndAnalyser.traceEnabled=TRUE;    
  }
  else
  {
    pm->m_wndAnalyser.traceEnabled=FALSE;
    pobjinfo->EnableTraceLog(0,0,0);    	  
	if( pm->m_pWndTrace )
      pm->m_pWndTrace->ReadTraceFile();
   
  } 
  */ 
  pm->m_wndAnalyser.UpdateAnalyser();
}

void CJSTEPDoc::OnUpdateTraceEnabled(CCmdUI* pCmdUI) 
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pm->m_wndAnalyser.traceEnabled)
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);  
}

void CJSTEPDoc::WriteWorkspace(CString& wspfilename)
{
char buffer[200];
RECT rm;
CString txt;
CString entry;
char vtyp;
int j,i,n,k;
item_t* pi;
POSITION pos;
bkpt_t pb;
BOOL b;
   

   if(wspfilename=="")
     return;
   ::DeleteFile(LPCSTR(wspfilename));
   WritePrivateProfileString(0,0,0,LPCSTR(wspfilename));      
   CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
   pm->RecalcLayout(); 
   theApp.WriteProfileString("Project","Name",theApp.projectfile); 
   pm->GetWindowRect(&rm);
   if(!pm->IsZoomed())
     sprintf(buffer,"%d,%d,%d,%d",rm.left,rm.top,rm.right,rm.bottom);
   else
     strcpy(buffer,"M");  //ist maximiert
   theApp.WriteProfileString("Project","MainWnd",buffer);
   theApp.WriteProfileString("Project","SourcePath",pobjinfo->globSrcPath);
   theApp.WriteProfileString("Project","Hexfile",theApp.hexfile);
   theApp.WriteProfileString("Project","PROCDLL",theApp.procname);
   i=0;
   //extra DLL-Windows
   for(j=0;j<NUMBER_OF_ADDCMDS;j++)
   {
     if(pm->addcmds[j].pWnd)  //das Fenster existiert
     {
       if( pm->addcmds[j].pWnd->GetStyle() & WS_VISIBLE)
       {
         entry.Format("Controlbar%d",i++);
         CRuntimeClass* prcl=pm->addcmds[j].pWnd->GetRuntimeClass();  
         if( strcmp(prcl->m_lpszClassName,"CMRCSizeDialogBar")==0)
           WriteExtProfile(entry,(CMRCSizeControlBar*)pm->addcmds[j].pWnd);         
         sprintf(buffer,"w.x.0x%X" ,pm->addcmds[j].cmdID);  
         theApp.WriteProfileString("Project",entry,buffer);         
       }
       else
       {
         CRuntimeClass* prcl=pm->addcmds[j].pWnd->GetRuntimeClass();
         if( !strcmp(prcl->m_lpszClassName,"CMRCSizeControlBar"))
           DeleteControlBar((CMRCSizeControlBar*)pm->addcmds[j].pWnd);
         else
           DeleteControlBar((CControlBar*)pm->addcmds[j].pWnd);
         delete pm->addcmds[j].pWnd;
         pm->addcmds[j].pWnd=0;
       } 
     }
   }
   //BrowserWindow
   if(pm->m_browsWnd.GetStyle() & WS_VISIBLE)
   { 
     entry.Format("Controlbar%d",i++);   
     theApp.WriteProfileString("Project",entry,"w.b"); 
     WriteExtProfile(entry,&pm->m_browsWnd);
   }
   //WatchWindow
   if(pm->m_wndWatch.Created && (pm->m_wndWatch.GetStyle() & WS_VISIBLE))
   {  
     entry.Format("Controlbar%d",i++); 
     theApp.WriteProfileString("Project",entry,"w.w");
     WriteExtProfile(entry,&pm->m_wndWatch);
     theApp.WriteProfileInt(entry,"AddData",pm->m_wndWatch.hlc.GetColumnWidth(0)); 
     n=pm->m_wndWatch.hlc.GetItemCount()-1;
     j=0;  
     k=0;
     while(j<n)
     {
       pi=(item_t*)pm->m_wndWatch.hlc.GetItemData(j);
       if(!pi->level)
       {
         txt=pm->m_wndWatch.hlc.GetItemText(j,0);
         switch(pi->vtyp)
         {
           case V_DEZ: txt += " $d";
                       break; 
           case V_BIN: txt += " $b";
                       break;
         }
         entry.Format("expression%d",k); 
         theApp.WriteProfileString("Watches",entry,txt);
         k++;
       } 
       j++; 
     }     
   }  
   else if(pm->m_wndWatch.Created && !(pm->m_wndWatch.GetStyle() & WS_VISIBLE))
     DeleteControlBar(&pm->m_wndWatch);

   //LocalsWindow
   if(pm->m_wndLocals.Created  && (pm->m_wndLocals.GetStyle() & WS_VISIBLE))
   {   
     entry.Format("Controlbar%d",i++); 
     theApp.WriteProfileString("Project",entry,"w.l");
     WriteExtProfile(entry,&pm->m_wndLocals);
     theApp.WriteProfileInt(entry,"AddData",pm->m_wndLocals.hlc.GetColumnWidth(0));
   }
   else if(pm->m_wndLocals.Created  && !(pm->m_wndLocals.GetStyle() & WS_VISIBLE))
     DeleteControlBar(&pm->m_wndLocals);


   //StackWindow
   if(pm->m_wndStack.Created && (pm->m_wndStack.GetStyle() & WS_VISIBLE))
   {  
     entry.Format("Controlbar%d",i++); 
     theApp.WriteProfileString("Project",entry,"w.s");
     WriteExtProfile(entry,&pm->m_wndStack);
   }  
   else if(pm->m_wndStack.Created && !(pm->m_wndStack.GetStyle() & WS_VISIBLE))
     DeleteControlBar(&pm->m_wndStack);

   // Register Window
   if(pm->m_wndRegBar.Created && (pm->m_wndRegBar.GetStyle() & WS_VISIBLE))
   { 
     entry.Format("Controlbar%d",i++); 
     theApp.WriteProfileString("Project",entry,"w.r");
     WriteExtProfile(entry,&pm->m_wndRegBar);
   } 
   else if(pm->m_wndRegBar.Created && !(pm->m_wndRegBar.GetStyle() & WS_VISIBLE))
     DeleteControlBar(&pm->m_wndRegBar);
    
   // Analysator- Window
   if(pm->m_wndAnalyser.Created && pm->m_wndAnalyser.GetStyle() & WS_VISIBLE)
   { 
     entry.Format("Controlbar%d",i++);
     theApp.WriteProfileString("Project",entry,"w.a");
     //Taktfrequenz
     pm->m_wndAnalyser.GetDlgItemText(IDC_CLOCK,txt);
     theApp.WriteProfileString("Project","SimClk",txt);
     //Stimulationspunkt speichern
     if(stpt.isValid)
     {
       txt.Format("stm 0x%X",stpt.addr);
       theApp.WriteProfileString("Project","Stimulationpoint",txt);
     }
     if(pm->m_wndAnalyser.stimfilename != "")
       theApp.WriteProfileString("Project","Stimulationfile",pm->m_wndAnalyser.stimfilename);
   }   
   else if(pm->m_wndAnalyser.Created && !(pm->m_wndAnalyser.GetStyle() & WS_VISIBLE))
   {
     pm->m_wndAnalyser.Created=FALSE;
     DeleteControlBar(&pm->m_wndAnalyser);
   }

   // Trace- Window
   if(pm->m_pWndTrace && pm->m_pWndTrace->Created && (pm->m_pWndTrace->GetStyle() & WS_VISIBLE))
   { 
     entry.Format("Controlbar%d",i++); 
     theApp.WriteProfileString("Project",entry,"w.t");
     WriteExtProfile(entry,pm->m_pWndTrace);
   }
   else if(pm->m_pWndTrace && pm->m_pWndTrace->Created && !(pm->m_pWndTrace->GetStyle() & WS_VISIBLE))
   {
     DeleteControlBar(pm->m_pWndTrace);
     delete pm->m_pWndTrace;
     pm->m_pWndTrace=0;
   }
   
   //Memory-Fenster
   pos=pm->memwnds.GetHeadPosition();
   while(pos)
   {
     CMemWnd* pmw=(CMemWnd*)pm->memwnds.GetNext(pos);
     pmw->GetWindowRect(&rm);
     pmw->GetAddrString(txt);
     switch(pmw->edlc.viewtyp)
     {
       case V_BYTE:
       default:   vtyp='b';
                  break;  
       case V_SHORT:
       case V_INV_SHORT:
                  vtyp='s';
                  break; 
       case V_LONG:
       case V_INV_LONG:
                  vtyp='l';
                  break; 
       case V_ASCII:       
                  vtyp='a';
                  break;

     }
     sprintf(buffer,"w.m.%c %s ",vtyp,LPCSTR(txt)); 
     entry.Format("Controlbar%d",i++); 
     theApp.WriteProfileString("Project",entry,buffer);
     WriteExtProfile(entry,pmw);
   }   
    
   //Breakpoints
   pos=0;
   i=0;
   do
   {
     b=prc->GetNextBreakpoint(pos,&pb);
     if(b)
     {
       char bpfmt=0;
       switch(pb.fmt)
       {
         case BKPT_CODE:  bpfmt='p';
                          break;
         case BKPT_READ+BKPT_WRITE:
                          bpfmt='b';
                          break;
         case BKPT_READ:  bpfmt='r';
                          break;
         case BKPT_WRITE: bpfmt='w';
                          break;
       } 
       if( bpfmt)
       {           
         txt.Format("b.s 0x%X %c %c",pb.addr,bpfmt,pb.memspec);
         entry.Format("Breakpoint%d",i);
         theApp.WriteProfileString("Project",entry,txt);
         i++;
       } 
     }
   } while(pos); 

   //Speicherkonfiguration
   i=0;
   mcfg_t mcfg;
   while(i != -1)
   {
     entry.Format("MemCfg%d",i); 
     i=prc->GetNextMemMapping(&mcfg,i);
     if(i==-1)
       break;
     txt.Format("s. %c 0x%8.8X 0x%8.8X", mcfg.memspec,mcfg.startaddr,mcfg.endaddr);
     theApp.WriteProfileString("Project",entry,txt);
   }
          
   //Tracepoint speichern
   if(tpt.isValid && tpt.expressions.GetSize())
   {
     
     txt.Format("t.s 0x%X",tpt.GetAddr());
     theApp.WriteProfileString("Project","Tracepoint",txt);
     CString* pexp;
     n=tpt.expressions.GetSize();
     i=0;
     while(i<n)
     {
       entry.Format("TPExpr%d",i);
       pexp=(CString*)tpt.expressions.GetAt(i);
       txt.Format("t.a %s",LPCSTR(*pexp));
       theApp.WriteProfileString("Project",entry,txt);
       i++;
     }        
   }
   
   //Messpunkt speichern
   if(mpt.isValid)
   {
     txt.Format("m. 0x%X",mpt.addr);
     theApp.WriteProfileString("Project","Measurepoint",txt);
   }   
   CDockState ds;
   pm->GetDockState(ds);
   CleanUpControlBarState(ds);
   ds.SaveState("CtrlBars");
}

void CJSTEPDoc::ReadWorkspace(CString wspfile)
{
RECT rc;
CRect rd;
CString projectname;
CString txt,idtxt;
CString entry,entry1;
CMainFrame* pm; 
int i,j,n,bid,Id;
SizeBarInfo_t sbi;
LPCSTR curprofile_p;
   
   pm=(CMainFrame*)AfxGetMainWnd();  
   curprofile_p=theApp.m_pszProfileName;
   theApp.m_pszProfileName= wspfile;  
   txt=theApp.GetProfileString("Project","Name",0);
   if(txt=="" && theApp.hexfile=="")
   {
     theApp.m_pszProfileName= curprofile_p;
     return;  
   } 
   txt=theApp.GetProfileString("Project","MainWnd",0);
   if(txt=="")
   {
     theApp.m_pszProfileName= curprofile_p;
     return;  
   }
   if(txt!="M")
   {
     txt.TrimLeft();
     txt.TrimRight();
     GetRectFromString(txt,rc);
     pm->GetWindowRect(rd);
     if(!rd.EqualRect(&rc))     
       pm->MoveWindow(&rc,TRUE);
     else
       pm->ShowWindow(SW_SHOW);
   } 
   else
   {
     pm->ShowWindow(SW_SHOWMAXIMIZED);
   }   
   
   ::LoadWorkspaceFile(theApp.m_pszProfileName); 
      
   n=theApp.GetProfileInt("CtrlBars-Summary","Bars",0);
   i=0;
   do
   {     
     entry1.Format("Controlbar%d",i++);
     txt=theApp.GetProfileString("Project",entry1,NULL);
     bid=theApp.GetProfileInt(entry1,"Bar-ID",NULL);
     if(!bid)
     {
       OnSetCmd(&txt);         
     }
     else
     {
       j=0;
       while(j<n)
       {
         entry.Format("CtrlBars-Bar%d",j++);
         Id=theApp.GetProfileInt(entry,"BarID",0);
         if(Id==bid)
         {         
           sbi.MRUDockLeftPos=theApp.GetProfileInt(entry,"MRUDockLeftPos",-1);
           sbi.MRUDockRightPos=theApp.GetProfileInt(entry,"MRUDockRightPos",-1);
           sbi.MRUDockTopPos=theApp.GetProfileInt(entry,"MRUDockTopPos",-1);
           sbi.MRUDockBottomPos=theApp.GetProfileInt(entry,"MRUDockBottomPos",-1); 
           sbi.FloatXPos=theApp.GetProfileInt(entry,"MRUFloatXPos",-1); 
           sbi.FloatYPos=theApp.GetProfileInt(entry,"MRUFloatYPos",-1); 
           sbi.FloatSize.cx=theApp.GetProfileInt(entry1,"FloatSizeX",-1);
           sbi.FloatSize.cy=theApp.GetProfileInt(entry1,"FloatSizeY",-1);
           sbi.HorzDockSize.cx=theApp.GetProfileInt(entry1,"HorzDockSizeX",-1);
           sbi.HorzDockSize.cy=theApp.GetProfileInt(entry1,"HorzDockSizeY",-1);
           sbi.VertDockSize.cx=theApp.GetProfileInt(entry1,"VertDockSizeX",-1);
           sbi.VertDockSize.cy=theApp.GetProfileInt(entry1,"VertDockSizeY",-1);
           sbi.DockHorz=theApp.GetProfileInt(entry1,"DockHorz",0);
           sbi.addData=theApp.GetProfileInt(entry1,"AddData",-1); 
           sbi.cmdID=bid;
           break;
         }
       }    
       OnSetCmd(&txt,&sbi);
     }
   } while(txt!="");

   CDockState ds;  
   CleanUpControlBarState(ds);
   ds.LoadState("CtrlBars");  
   pm->SetDockState(ds); 
  
   //Breakpoints laden
   i=0;
   do
   {   
     entry.Format("Breakpoint%d",i++);       
     txt=theApp.GetProfileString("Project",entry,NULL);
     if(txt != "")
     {
       OnSetCmd(&txt);         
     }
   } while(txt!="");

   //Speicherkonfiguration laden
   entry.Format("MemCfg0",i++);
   txt=theApp.GetProfileString("Project",entry,NULL);
   if(txt!="")
   {
     prc->DeleteMem(-1);  // wenn eine Konfiguration vorhanden ist wird die Defaultkonfiguration gel�scht
     i=1;
     while(txt!="")
     {     
       OnSetCmd(&txt);              
       entry.Format("MemCfg%d",i++);
       txt=theApp.GetProfileString("Project",entry,NULL);       
     }
   }

   //Tracepoint laden
   txt=theApp.GetProfileString("Project","Tracepoint",NULL);
   if(txt!="")
   {
     OnSetCmd(&txt);
     i=0;
     do
     {     
       entry.Format("TPExpr%d",i++);
       txt=theApp.GetProfileString("Project",entry,NULL);
       if(txt != "")
       {
         OnSetCmd(&txt);         
       }
     }while(txt!="");
   }

   //Messpunkt laden
   txt=theApp.GetProfileString("Project","Measurepoint",NULL);
   if(txt!="")
   {
     OnSetCmd(&txt);  
   } 
   

   //Einstellungen Analyser laden

   if(pm->m_wndAnalyser.Created && pm->m_wndAnalyser.GetStyle() & WS_VISIBLE)
   {      
     txt=theApp.GetProfileString("Project","SimClk",NULL);
     if(txt!="")
     {
       pm->m_wndAnalyser.SetDlgItemText(IDC_CLOCK,txt);
       pm->m_wndAnalyser.UpdateAnalyser();
     }
     txt=theApp.GetProfileString("Project","Stimulationfile",NULL);
     if(txt!="")
       pm->m_wndAnalyser.SetDlgItemText(IDC_STIMFILE,txt);
     txt=theApp.GetProfileString("Project","Stimulationpoint",NULL);
     if(txt!="")
       OnSetCmd(&txt);  
   }
   theApp.m_pszProfileName=curprofile_p;
}

BOOL CJSTEPDoc::GetRectFromString(LPCSTR buffer, RECT& rc)
{
int i;
CString substr;
 
  i=sscanf(buffer,"%d,%d,%d,%d",&rc.left,&rc.top,&rc.right,&rc.bottom);
  if(i!=4)
    return FALSE;
  return TRUE; 
}


void CJSTEPDoc::CleanUpControlBarState(CDockState& state)
{ 
  for (int i = 0; i < state.m_arrBarInfo.GetSize(); i++)
  {
   CControlBarInfo* pInfo1 = (CControlBarInfo*)state.m_arrBarInfo[i];
   for (int j = 0; j < state.m_arrBarInfo.GetSize(); j++)
   {
     if (i == j)
       continue;
     CControlBarInfo* pInfo2 = (CControlBarInfo*)state.m_arrBarInfo[j];
     if (pInfo1->m_uMRUDockID == pInfo2->m_nBarID)
        continue;
     int nSize = pInfo2->m_arrBarID.GetSize();
     for (int k = 0; k < nSize - 1; k++)
     {
       if ((LONG)pInfo2->m_arrBarID[k] ==
           (LONG)pInfo1->m_nBarID + 0x10000)
           pInfo2->m_arrBarID[k] = NULL;
     }
   }
 }
 for (i = 0; i < state.m_arrBarInfo.GetSize(); i++)
 {
   CControlBarInfo* pInfo = (CControlBarInfo*)state.m_arrBarInfo[i];
   int nSize = pInfo->m_arrBarID.GetSize();
   for (int j = 0; j < nSize - 1; j++)
   {
     if (pInfo->m_arrBarID[j]==NULL)
       continue;
     for (int k = j + 1; k < nSize; k++)
     {
       if (pInfo->m_arrBarID[k]==NULL)
         continue;
       if (pInfo->m_arrBarID[k]==pInfo->m_arrBarID[j])
         pInfo->m_arrBarID[k] = NULL;
     }
   }
   while ((nSize!=0) && (pInfo->m_arrBarID[nSize-1]==NULL))
   {
     nSize--;
     pInfo->m_arrBarID.RemoveAt(nSize);
   }
   if (nSize)
     pInfo->m_arrBarID.InsertAt(nSize, (void*)NULL);
 }
} 


void CJSTEPDoc::OnUpdateMemory(CCmdUI* pCmdUI) 
{
POSITION pos,pos1;
CMainFrame* pm;

  pm=(CMainFrame*)AfxGetMainWnd();
  pos=pm->memwnds.GetHeadPosition();
  while(pos)
  { 
    pos1=pos;
    CMemWnd* pmw=(CMemWnd*)pm->memwnds.GetNext(pos);    
    if(!(pmw->GetStyle() & WS_VISIBLE))
    {  
      if(pmw->IsFloating())
      {
        pmw->DestroyWindow();
      }
      else
      { 
        pm->ShowControlBar(pmw,FALSE,FALSE);	
        pm->FloatControlBar(pmw,CPoint(0,0),0);		
        pmw->GetParent()->DestroyWindow(); //der dar�berliegende Rahmen wird zerst�rt
      }         
      delete pmw;
      pm->memwnds.RemoveAt(pos1);
      pos=pm->memwnds.GetHeadPosition();
    }
  }
}

void CJSTEPDoc::WriteExtProfile(LPCSTR section,CMRCSizeControlBar* pc)
{
  theApp.WriteProfileInt(section, "Bar-ID",       pc->GetDlgCtrlID());
  theApp.WriteProfileInt(section, "FloatSizeX",   pc->m_FloatSize.cx);
  theApp.WriteProfileInt(section, "FloatSizeY",   pc->m_FloatSize.cy);
  theApp.WriteProfileInt(section, "HorzDockSizeX",pc->m_HorzDockSize.cx);
  theApp.WriteProfileInt(section, "HorzDockSizeY",pc->m_HorzDockSize.cy);
  theApp.WriteProfileInt(section, "VertDockSizeX",pc->m_VertDockSize.cx);
  theApp.WriteProfileInt(section, "VertDockSizeY",pc->m_VertDockSize.cy);
  theApp.WriteProfileInt(section, "DockHorz",(pc->m_dwStyle & CBRS_ORIENT_HORZ)? 1 : 0);
}


BOOL CJSTEPDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
CString fname;
int l;
   	
  fname=lpszPathName;
  l=fname.Find('.');
  if(l!=-1)
  {
    fname=fname.Left(l);      
  }
  fname+=".wsp";
  WriteWorkspace(fname);    
  return CDocument::OnSaveDocument(fname);
}

void CJSTEPDoc::DeleteControlBar(CMRCSizeControlBar* pb)
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pb && pb->Created)
  {    
    pb->Created=FALSE;
		if(pb->IsFloating())
      pb->DestroyWindow();
		else
    { 
      pm->ShowControlBar(pb,FALSE,FALSE);	
      pm->FloatControlBar(pb,CPoint(0,0),0);            
      pb->GetParent()->DestroyWindow(); //der dar�berliegende Rahmen wird zerst�rt     
    }     
  }

}

void CJSTEPDoc::DeleteControlBar(CControlBar* pb)
{
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  if(pb)
  {        
	if(pb->IsFloating())
      pb->DestroyWindow();
	else
    { 
      pm->ShowControlBar(pb,FALSE,FALSE);	
      pm->FloatControlBar(pb,CPoint(0,0),0);
      pb->DestroyWindow();		
      //pb->GetParent()->DestroyWindow(); //der dar�berliegende Rahmen wird zerst�rt      
    }     
  }
}

void CJSTEPDoc::OnClrBkpt()
{
POSITION pos,pos1;
bkpt_t bp;
CJSTEPView* pv;
int n,i;
ULONG breakaddr,s;
BOOL b;

  pos=0;
  do
  {    
    b=prc->GetNextBreakpoint(pos,&bp);
    if(b)
    {
      breakaddr=bp.addr;
      prc->RemoveBreakpoint(bp.addr);
      pos1=GetFirstViewPosition();
      while(pos1)
      {
        pv=(CJSTEPView*)GetNextView(pos1); 
        if(!pv)
          break;
        CListCtrl& lc=pv->GetListCtrl();
        n=lc.GetItemCount();
        i=0;
        while(i<n)  //Breakpoints nachzeichnen wenn sichtbar war
        {
          if(pv->GetViewMode()==ASM && lc.GetItemData(i)==breakaddr)       
            lc.RedrawItems(i,i);
          else if(pv->GetViewMode()==MIX)
          {
            s=pv->GetDispState(i);
            if( !(s & ISHLLLINE) && lc.GetItemData(i)==breakaddr) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
              lc.RedrawItems(i,i);               
          }
          else if(pv->GetViewMode()==HLL)
          {
            s=pv->GetDispState(i);
            if(s & LINEADDRVALID && lc.GetItemData(i)==breakaddr)                         
              lc.RedrawItems(i,i);          
          }
          i++;    
        }
      }
    }
  }while(pos);
  
}

void CJSTEPDoc::OnDeacBkpt()
{
POSITION pos;
bkpt_t bp;
CJSTEPView* pv;
ULONG addr,s;
BOOL b;

  pos=0;
  do
  {    
    b=prc->GetNextBreakpoint(pos,&bp);
    if(b)
    {
      bp.fmt=prc->GetBkptFormat(bp.addr);      
      prc->SetBreakpoint(bp.addr,(USHORT)(bp.fmt|BKPT_DISABLED));
    }
  }while(pos);
  pos=GetFirstViewPosition();
  while(pos)
  {
    pv=(CJSTEPView*)GetNextView(pos); 
    if(!pv)
       break;
    CListCtrl& lc=pv->GetListCtrl();
    int n=lc.GetItemCount();
    int i=0;
    while(i<n)  //alle Breakpoints nachzeichnen wenn sichtbar
    {
      if(pv->GetViewMode()==ASM)
      {
        addr=lc.GetItemData(i);
        if(prc->IsBreakpointAtAddr(addr,BKPT_CODE))
          lc.RedrawItems(i,i);
      }
      else if(pv->GetViewMode()==MIX)
      {
        s=pv->GetDispState(i);
        if( !(s & ISHLLLINE)) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
        {
          addr=lc.GetItemData(i);
          if(prc->IsBreakpointAtAddr(addr,BKPT_CODE))
            lc.RedrawItems(i,i);
        }      
      }
      else if(pv->GetViewMode()==HLL)
      {
        s=pv->GetDispState(i);
        if(s & LINEADDRVALID) 
        {
          addr=lc.GetItemData(i);
          if(prc->IsBreakpointAtAddr(addr,BKPT_CODE))
            lc.RedrawItems(i,i);
        }
      }
      i++;
    }     
  }  
}



void CJSTEPDoc::OnTracepoint() 
{
  CTPEdit tpe;
  tpe.DoModal();	
}



void CJSTEPDoc::OnFileSaveAs() 
{
CString fname;
int l;
   	
  CFileDialog fd(FALSE,".wsp",theApp.wspfile,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
                 "Workspace Files (*.wsp)|*.wsp|Workspace Files");	
  fd.DoModal();

  fname=fd.GetPathName();
  l=fname.Find('.');
  if(l!=-1)
  {
    fname=fname.Left(l);      
  }
  fname+=".wsp";
  theApp.m_pszProfileName=fname;
  WriteWorkspace(fname);    	
}


HMENU CJSTEPDoc::GetDefaultMenu()
{
  HMENU hm=((CMainFrame*)AfxGetMainWnd())->m_menu.m_hMenu;
  return hm;
}


void CJSTEPDoc::OnProcWnds(UINT id)
{
int dllID;
RECT rd; 
CPoint pt;
CNDlgBar* pd;
 
  CMainFrame* pm= (CMainFrame*)AfxGetMainWnd();
  if((id-IDC_PROCWND0) > 10)
    return;  //nur maximal 10 Extrafenster
  dllID=pm->addcmds[id-IDC_PROCWND0].cmdID;
  pm->GetDesktopWindow()->GetWindowRect(&rd);    		  
  pt.x=rd.right/2-50;
  pt.y=rd.bottom/2-50;	
  pd=(CNDlgBar*)pm->addcmds[id-IDC_PROCWND0].pWnd;
  if(pd)  
  {
    BOOL mbvis=pd->GetStyle() & WS_VISIBLE;
    if(mbvis)
      pm->ShowControlBar(pd,FALSE,FALSE);	
    else
      pm->ShowControlBar(pd,TRUE,FALSE);	
  }
  else  //nur das Create erfolgt zus�tzlich �ber die DLL 
  {        
    AfxSetResourceHandle(hinstDLL);
    if( pm->addcmds[id-IDC_PROCWND0].style== DLLWND_FIX) 
    {
      pd=new CNDlgBar;         
      pd->Create(pm,dllID,CBRS_ALIGN_ANY|CBRS_SIZE_DYNAMIC,dllID); 
      pd->m_FloatingPosition=pt;
    }
    else if(pm->addcmds[id-IDC_PROCWND0].style== DLLWND_DYNAMIC)
    {
      pd=(CNDlgBar*)new CMRCSizeDialogBar;  
      ((CMRCSizeDialogBar*)pd)->m_FloatingPosition=pt;      
      ((CMRCSizeDialogBar*)pd)->Create(pm,dllID,CBRS_ALIGN_ANY|CBRS_SIZE_DYNAMIC,dllID);  
    }    
    else if(pm->addcmds[id-IDC_PROCWND0].style== DLLWND_MODAL)
    {
       HandleExtraWndCmd(dllID,0,0);
       AfxSetResourceHandle(AfxGetInstanceHandle());
       return;
    }
    AfxSetResourceHandle(AfxGetInstanceHandle());
    pm->addcmds[id-IDC_PROCWND0].pWnd=pd;    
    HandleExtraWndCmd( dllID,pd->m_hWnd,pd);        	
    pd->SetBarStyle( pd->GetBarStyle()
			    | CBRS_FLYBY 
                | CBRS_TOOLTIPS
				| CBRS_BORDER_ANY
				| CBRS_BORDER_3D
                | CBRS_SIZE_DYNAMIC );    
    pd->EnableDocking(CBRS_ALIGN_ANY);    	        
    pm->FloatControlBar(pd,pt);        
    pm->ShowControlBar(pd,TRUE,FALSE);          
  }
}

void CJSTEPDoc::OnUpdateProcWnds(CCmdUI* pCmdUI)
{
int r;
  
  CMainFrame* pm= (CMainFrame*)AfxGetMainWnd();
  r=HandleExtraWndUpdateCmd(pm->addcmds[pCmdUI->m_nID-IDC_PROCWND0].cmdID);
  if(r&CMD_ENABLED)
    pCmdUI->Enable(TRUE);
  else
    pCmdUI->Enable(FALSE);
  if(r&CMD_CHECKED)
    pCmdUI->SetCheck(1);
  else
    pCmdUI->SetCheck(0);
}


BOOL CJSTEPDoc::LoadSDCProject(CString& title)
{
int r;
CString txt;
CFileStatus fs;
LPCSTR curprofile_p;
CString prj;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();  
  r=title.Find(".ihx");
  theApp.wspfile=title.Left(r)+".wsp";      
  prj=title.Left(r);
  if(!theApp.ProcIsLoaded)  //noch kein Prozessortyp geladen
  {
    curprofile_p=theApp.m_pszProfileName;
    theApp.m_pszProfileName= LPCSTR(theApp.wspfile); 
    txt=theApp.GetProfileString("Project","PROCDLL",0);
    if(txt=="") //nicht gefunden
    {
      CProcSel dlg;
      dlg.DoModal();                    
    }
    else
    {
      theApp.AttachProcessor(txt);		  
    }       
    if(!theApp.ProcIsLoaded)
    {
      theApp.m_pszProfileName=curprofile_p;
      return FALSE;
    }        
  }        
	theApp.m_pszProfileName=curprofile_p;
  pm->m_browsWnd.AddRoot(prj);
  pm->m_menu.LoadMenu(IDR_JSTEPTYPE);
#ifdef _DEUTSCH 
  prc->Init(pm->m_hWnd,_GER);
#else
  prc->Init(pm->m_hWnd);
#endif
  if(!pobjinfo->LoadHexfile(title))
    return FALSE;
  if(!pobjinfo->LoadSDCSymbolInfo(title.Left(r)))
    return FALSE;  
  pm->m_browsWnd.Expand();
  pobjinfo->objLoaded=TRUE;
  return TRUE;
}
