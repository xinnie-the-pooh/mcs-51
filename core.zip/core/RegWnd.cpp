// RegWnd.cpp : implementation file
//

#include "stdafx.h"

#include "ModDef.h"
#include "ObjInfo.h"
#include "RegWnd.h"
#include "Proc.h"
#include "JSTEP.h"
#include "JSTEPDoc.H"
#include "DbgBar.h"
#include "MainFrm.h"
#include "JSTEPView.h"
#include "windows.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegWnd

CRegWnd::CRegWnd()
  :CMRCSizeDialogBar()  
{
}

CRegWnd::~CRegWnd()
{
}


BEGIN_MESSAGE_MAP(CRegWnd, CMRCSizeDialogBar)
	//{{AFX_MSG_MAP(CRegWnd)
	ON_WM_SIZE()	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CRegWnd message handlers

BOOL CRegWnd::Create( CWnd* pParentWnd, BOOL visible)
{
  
  Created= CMRCSizeDialogBar::Create(pParentWnd, IDD_REGBAR
 	        ,CBRS_ALIGN_REGWND|CBRS_SIZE_DYNAMIC
			,IDD_REGBAR);	
  if(!visible)
     ModifyStyle(WS_VISIBLE,0,SWP_NOACTIVATE);
  if(Created)
  {
	 edlc.SubclassDlgItem(IDD_REGBARLST,this);   
	 edlc.Create();
		
	 SetBarStyle( GetBarStyle()
		         | CBRS_TOOLTIPS 
				 | CBRS_FLYBY 							 
				 | CBRS_BORDER_ANY 
				 | CBRS_BORDER_3D );
	Init();		
    EnableDocking(CBRS_ALIGN_REGWND);
	SetWindowText(_T("Register"));
    RECT rd;
	GetDesktopWindow()->GetWindowRect(&rd);
	CPoint pt;
	pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;
    m_FloatingPosition=pt;
  }
  return(Created);  
}

void CRegWnd::Init()
{
int i;
LV_COLUMN lvc;
LV_ITEM lvi;
CRegdef* preg; 
CString  sval;
RECT rc;
  
  i=0;
  CEdListCtrl* plc=(CEdListCtrl*)GetDlgItem(IDD_REGBARLST);	 
  while(plc->DeleteColumn(i++)); //Alle Spalten L�schen 
	plc->DeleteAllItems();
	 
  // insert columns
  lvc.iSubItem=0;
  lvc.cx=70;
  lvc.pszText="Register";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;
  plc->InsertColumn(0,&lvc); 
	
  plc->GetClientRect(&rc);
  lvc.iSubItem=1;
  lvc.cx=rc.right-rc.left-70;    //geht �ber die ganze Breite
#ifdef _DEUTSCH
  lvc.pszText="Wert";
#else
  lvc.pszText="Value";
#endif
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;
  plc->InsertColumn(1,&lvc);	
  
  i=0;
  lvi.mask=LVIF_TEXT | LVIF_PARAM;
  preg=prc->GetNextRegister(0);
  i=0;
  while(preg)
  {   	
	lvi.iItem=i;
	lvi.iSubItem=0;
	lvi.pszText=(char*)(LPCSTR(preg->regname));
	lvi.lParam=(ULONG)preg;
	plc->InsertItem(&lvi); 
    plc->SetItemValText(i);
	preg->bchanged=FALSE;
    i++;
    preg=prc->GetNextRegister(-1);
  }   
}

void CRegWnd::OnSize(UINT nType, int cx, int cy) 
{
	RECT rc,re;
  
	CMRCSizeDialogBar::OnSize(nType, cx, cy);	
    GetWindowRect(&rc);
	CEdListCtrl* pe=(CEdListCtrl*)GetDlgItem(IDD_REGBARLST);
	if(!pe)     
      return;
	re.top=rc.top+7;
	re.left=rc.left;
    re.right=rc.right;
    re.bottom=rc.bottom;
    ScreenToClient(&re);	
	pe->MoveWindow(&re,TRUE);		
}


void CRegWnd::UpdateAllRegisters()
{
  if(Created)
    edlc.UpdateList();
}
