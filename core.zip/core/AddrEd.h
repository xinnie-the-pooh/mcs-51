// AddrEd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddrEd window

#ifndef _ADDREDIT
  #define _ADDREDIT
class CAddrEd : public CEdit
{
// Construction
public:	
	void OnReturnKey(CString& txt);
	CAddrEd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddrEd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAddrEd();

	// Generated message map functions
protected:
	CString lasttxt;
	//{{AFX_MSG(CAddrEd)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif // _ADDREDIT
/////////////////////////////////////////////////////////////////////////////
