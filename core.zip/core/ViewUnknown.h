// ViewUnknown.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CViewUnknown view

class CViewUnknown : public CJSTEPView
{
friend class CJSTEPDoc;
protected:
    BOOL setcols;
	ULONG endaddr;
	ULONG anfaddr;
	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	CViewUnknown();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CViewUnknown)

// Attributes
public:
	ULONG actaddr;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewUnknown)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CViewUnknown();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CViewUnknown)
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
  afx_msg void OnSetPC();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void SetupUnknownList(ULONG anfaddr);
};

/////////////////////////////////////////////////////////////////////////////
