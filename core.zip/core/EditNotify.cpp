// EditNotify.cpp : implementation file
//

#include "stdafx.h"
#include "EditNotify.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditNotify

CEditNotify::CEditNotify()
{
	act=-1;  
  actsub=1;
  extramenu=0;
}

CEditNotify::~CEditNotify()
{
}


BEGIN_MESSAGE_MAP(CEditNotify, CEdit)
	//{{AFX_MSG_MAP(CEditNotify)
	ON_WM_KILLFOCUS()
	ON_WM_KEYDOWN()
  ON_MESSAGE(WM_PASTE,OnEdPaste)
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
  ON_COMMAND(ID_EDIT_SELECT_ALL, OnEditSelAll)
  ON_COMMAND(ID_EDIT_CLEAR, OnEditClr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditNotify message handlers

void CEditNotify::OnKillFocus(CWnd* pNewWnd) 
{
	CEdit::OnKillFocus(pNewWnd);
	MSG* pmsg;
	pmsg=(MSG*)GetCurrentMessage();  
	GetParent()->SendMessage(pmsg->message,pmsg->wParam,(LONG)this);	
}


void CEditNotify::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  if(nChar==VK_RETURN)
  {
    GetParent()->SendMessage(UM_ENTER);
  }
  else if(nChar==VK_TAB)
  {
    GetParent()->SendMessage(UM_TAB,0x80&GetKeyState(VK_SHIFT));
  }
  else if(nChar> 0x24 && nChar <0x29)
  {
    GetParent()->SendMessage(UM_CURSORKEY,nChar);
  }
  else if(0x80 & GetKeyState(VK_CONTROL))
  {
    GetParent()->SendMessage(UM_CTRLKEY,nChar);
  }

  if(nChar != VK_ESCAPE)
    CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CEditNotify::SetText(CString& txt)
{
  GetWindowText(lasttext);
  SetWindowText(txt);
}

long CEditNotify::OnEdPaste(UINT wparam, LONG lparam)
{
  LRESULT r=GetParent()->SendMessage(UM_PASTE);
  if(!r) //wenn der Text eingef�gt werden soll (normalerweise) return=0
  {
    OpenClipboard();      
    HANDLE hclp=GetClipboardData(CF_TEXT);
    if(hclp)
    {
      char* cp=(char*)::GlobalLock(hclp); 
      ReplaceSel(cp);
      GlobalUnlock(hclp);  
    }   
    CloseClipboard();
  }       
  return 0; 
}


void CEditNotify::OnRButtonDown(UINT nFlags, CPoint point) 
{
  if(!extramenu)
  {
    CEdit::OnRButtonDown(nFlags, point);
    return;
  }
  int s,e;
  CString txt;
	CMenu popup;
  ClientToScreen(&point);
  popup.LoadMenu (extramenu);     
  CMenu* psub=popup.GetSubMenu(0);
  e=psub->GetMenuItemCount();
  s=0;
  while(s<e)
  {
    if(GetParent()->SendMessage(UM_GETMENUSTATE,psub->GetMenuItemID(s),0))
      psub->CheckMenuItem(s,MF_BYPOSITION|MF_CHECKED);   
    s++;
  } 
  psub->InsertMenu(0,MF_BYPOSITION|MF_SEPARATOR,0);
  txt.LoadString(ID_EDIT_SELECT_ALL);
  s=txt.Find('\n');
  txt='&' + txt.Mid(s+1);
  psub->InsertMenu(0,MF_BYPOSITION|MF_STRING,ID_EDIT_SELECT_ALL,txt);
  psub->InsertMenu(0,MF_BYPOSITION|MF_SEPARATOR,0);
  txt.LoadString(ID_EDIT_CLEAR);
  s=txt.Find('\n');
  txt='&' + txt.Mid(s+1);
  psub->InsertMenu(0,MF_BYPOSITION|MF_STRING,ID_EDIT_CLEAR,txt);
  txt.LoadString(ID_EDIT_PASTE);
  s=txt.Find('\n');
  txt='&' + txt.Mid(s+1);
  psub->InsertMenu(0,MF_BYPOSITION|MF_STRING,ID_EDIT_PASTE,txt);
  txt.LoadString(ID_EDIT_COPY);
  s=txt.Find('\n');
  txt='&' + txt.Mid(s+1);
  psub->InsertMenu(0,MF_BYPOSITION|MF_STRING,ID_EDIT_COPY,txt);
  txt.LoadString(ID_EDIT_CUT);
  s=txt.Find('\n');
  txt='&' + txt.Mid(s+1);
  psub->InsertMenu(0,MF_BYPOSITION|MF_STRING,ID_EDIT_CUT,txt);
  psub->InsertMenu(0,MF_BYPOSITION|MF_SEPARATOR,0);
  txt.LoadString(ID_EDIT_UNDO);
  s=txt.Find('\n');
  txt='&' + txt.Mid(s+1);
  psub->InsertMenu(0,MF_BYPOSITION|MF_STRING,ID_EDIT_UNDO,txt);   

  if(!CanUndo())
    psub->EnableMenuItem(ID_EDIT_UNDO|MF_BYCOMMAND,MF_GRAYED);
  GetSel(s,e);
  if(s==e)
  {
    psub->EnableMenuItem(ID_EDIT_COPY|MF_BYCOMMAND,MF_GRAYED);
    psub->EnableMenuItem(ID_EDIT_CUT|MF_BYCOMMAND,MF_GRAYED);
    psub->EnableMenuItem(ID_EDIT_CLEAR|MF_BYCOMMAND,MF_GRAYED);
  }
  if(!GetWindowTextLength( ))
    psub->EnableMenuItem(ID_EDIT_SELECT_ALL|MF_BYCOMMAND,MF_GRAYED); 
  
  psub->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
        point.x,point.y,this);

}

void CEditNotify::OnEditCopy() 
{
	Copy();	
}

void CEditNotify::OnEditCut() 
{
	Cut();	
}

void CEditNotify::OnEditPaste() 
{
	OnEdPaste(0,0);	
}

void CEditNotify::OnEditUndo() 
{
	Undo();	
}

void CEditNotify::OnEditSelAll()
{
  SetSel(0,-1);
}

void CEditNotify::OnEditClr()
{
  Clear();
}

BOOL CEditNotify::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	switch(nID)
  {
    case ID_EDIT_CUT:
    case ID_EDIT_COPY:
    case ID_EDIT_PASTE:
    case ID_EDIT_UNDO:
    case ID_EDIT_SELECT_ALL:
    case ID_EDIT_CLEAR:	
	    return CEdit::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
    default:
      UINT wparam;
      wparam=nCode<<16;
      wparam|=nID;
      GetParent()->SendMessage(WM_COMMAND, wparam,(LONG)m_hWnd);
      break;
  }
  return 1;
}
