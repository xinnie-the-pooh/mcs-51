// AnalysBar.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "AnalysBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAnalysBar

static UINT BASED_CODE AnalyserButtons[] =
{       
  IDD_ANALYSER,
  IDD_TRACEVIEW,
  IDD_STACK,
  IDD_REGBAR,
  IDD_MEMORYWND,  
  ID_SEPARATOR,
  IDC_RESETCPU,
  IDC_CLRALLBKPT,
  IDC_DEACTALLBKPT,
  IDC_SETBREAK,
  IDC_SETTRACEPOINT,
  IDC_SETMEASUREPOINT,
  IDC_SETSTIMUPT,
  IDC_UPDATEALL,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR,
  ID_SEPARATOR   
};

static UINT BASED_CODE ExtraButtonBmp[] =
{
  0,0,0,0,0,0,0,0,0,0      
};

CAnalysBar::CAnalysBar()
{
  Created=FALSE;
}

CAnalysBar::~CAnalysBar()
{
}

//BEGIN_MESSAGE_MAP(CAnalysBar, CToolBarEx)
BEGIN_MESSAGE_MAP(CAnalysBar, CFlatToolBar)
	//{{AFX_MSG_MAP(CAnalysBar)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
    ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTA, 0, 0xFFFF, OnTTPtext)
    ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTW, 0, 0xFFFF, OnTTPtext)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAnalysBar message handlers

//TBSTYLE_TOOLTIPS

BOOL CAnalysBar::Init(CWnd* pParentWnd)
{
int i,n,r;
TBBUTTON tb;
CString ttxt;

  if(Created)
    return TRUE;
	// start out with no borders
  DWORD dwStyle = WS_CHILD 
	            | WS_VISIBLE
              | CBRS_TOP
              | CBRS_SIZE_DYNAMIC
              | CBRS_TOOLTIPS 
              | CBRS_FLYBY;
  if (!Create(pParentWnd, dwStyle, IDW_ANALYSERBAR))
  {
    return FALSE;
  }	
  LoadBitmap(IDR_ANABAR);
  SetFlatLookStyle();
  //SetFlatLook();
  //hier wird das Bitmap mit den Defines verbunden   
  i=0;
  while(ExtraButtonBmp[i])
    i++; 
  if(!SetButtons(AnalyserButtons,STDBUTTONS))
    return FALSE;	  
  tb.fsState =TBSTATE_ENABLED;
  tb.fsStyle =TBSTYLE_BUTTON;
  tb.dwData =0;
  tb.iString =NULL;

  n=0; 
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  AfxSetResourceHandle(hinstDLL);
  while(n<i)
  { 
    r=GetToolBarCtrl().AddBitmap(1,ExtraButtonBmp[n]); 
    tb.iBitmap=r;    
    tb.idCommand= AnalyserButtons[STDBUTTONS+n];
    GetToolBarCtrl().AddButtons(1,&tb);
    n++;
  }   	
  AfxSetResourceHandle(AfxGetInstanceHandle());
  
  SetBarStyle(GetBarStyle() | CBRS_ALIGN_ANY);
  SetWindowText(_T("Analyser"));
  Created=TRUE;
  EnableDocking(CBRS_ALIGN_ANY);
  return TRUE;
}

int CAnalysBar::AddButton(UINT idcmd,UINT idbmp)
{
  int n=sizeof(AnalyserButtons)/sizeof(UINT)-1;
  if(AnalyserButtons[n])
    return -1;
  while(!AnalyserButtons[n])
    n--; 
  AnalyserButtons[n+1]=idcmd;   
  int i=0;
  while(ExtraButtonBmp[i])
    i++;
  ExtraButtonBmp[i]=idbmp;
  return (n+1);
}

BOOL CAnalysBar::OnTTPtext( UINT id, NMHDR * pTTTStruct, LRESULT * pResult )
{
    TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pTTTStruct;
    UINT nID =pTTTStruct->idFrom;
    if(nID>=IDC_PROCWND0 && nID<=IDC_PROCWND9)
    {
      CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
      CString ttxt;
      ttxt=LPCSTR(pm->addcmds[nID-IDC_PROCWND0].ttptxt); 
      if(pTTTStruct->code == TTN_NEEDTEXTW)
        MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,LPCSTR(ttxt),-1,(USHORT*)pTTT->szText,40);
      else
        strcpy(pTTT->szText,ttxt);  
      return(TRUE);    
    }
    else
    { 
      if (pTTT->uFlags & TTF_IDISHWND)
      {
        // idFrom ist der HWND des Werkzeugs
        nID = ::GetDlgCtrlID((HWND)nID);
        if(nID)
        {
          pTTT->lpszText = MAKEINTRESOURCE(nID);
          pTTT->hinst = AfxGetResourceHandle();
          return(TRUE);
        }
      }
    }
    return(FALSE);
}

void CAnalysBar::ResetAnalysBar()
{
int i;
  i=STDBUTTONS;
  while(i<sizeof(AnalyserButtons)/sizeof(UINT))
  {
    AnalyserButtons[i++]=ID_SEPARATOR;
    GetToolBarCtrl().DeleteButton(STDBUTTONS);
  }
  for(i=0;i<sizeof(ExtraButtonBmp)/sizeof(UINT);i++)
    ExtraButtonBmp[i]=0;
}
