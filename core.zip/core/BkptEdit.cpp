// BkptEdit.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "jstepview.h"
#include "objinfo.h"
#include "proc.h"
#include "BkptEdit.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBkptEdit dialog


CBkptEdit::CBkptEdit(CWnd* pParent /*=NULL*/)
	: CDialog(CBkptEdit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBkptEdit)
	bdisable = FALSE;
	//}}AFX_DATA_INIT
  imagelist.Create(IDB_SMALLTESTICO,16,1,RGB(255,255,255));
}


void CBkptEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBkptEdit)
	DDX_Control(pDX, IDC_BKPTLIST, blist);
	DDX_Check(pDX, IDC_BKPTDISABLE, bdisable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBkptEdit, CDialog)
	//{{AFX_MSG_MAP(CBkptEdit)
	ON_BN_CLICKED(IDC_BKPTDEL, OnBkptdel)   
	ON_BN_CLICKED(IDC_BKPTDISABLE, OnBkptdisable)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBkptEdit message handlers

BOOL CBkptEdit::OnInitDialog() 
{
LV_COLUMN lvc;
RECT rc;
POSITION pos;
bkpt_t pb;
CString txt,accesstyp,procname;
CProcDef* pp;
int i,fmt;
BOOL b;
ULONG msize;

  CDialog::OnInitDialog();
  blist.SetImageList(&imagelist,LVSIL_SMALL);
  blist.GetClientRect(&rc);
  lvc.cx=rc.right;
  lvc.mask=LVCF_WIDTH;
  lvc.iSubItem=0;
  blist.InsertColumn(0,&lvc);  //nur Spalte 0
  pos=0;
  i=0;
  do
  {
    b=prc->GetNextBreakpoint(pos,&pb);
    if(b)
    {
      if(pb.fmt & BKPT_CODE)
      {
        msize=prc->GetMemSize(pb.memspec);  //Speicherbereich in dem der Bkpt gesetzt ist      
        pp=theApp.objinfo.GetProcFromAddr(pb.addr);
        if(!pp)
        {
          procname.LoadString(IDS_UNKNOWNPROC);
        }
        else if(pp->Procname=="LIB")
        {
          if(!theApp.objinfo.FindLabel(pb.addr,procname,CODEMEM,msize))            
            procname="LIB";
        }              
        else
          procname=pp->Procname; 
        switch(msize)
        {
          case  S8:
             txt.Format("%s   , 0x%2.2X",procname,pb.addr);
             break;
          case  S16:
             txt.Format("%s   , 0x%4.4X",procname,pb.addr);
             break;
          case  S32:
             txt.Format("%s   , 0x%8.8X",procname,pb.addr);
             break;
        }
        if(pb.fmt & BKPT_DISABLED)
          blist.InsertItem(i,txt,6);
        else
          blist.InsertItem(i,txt,1); 
        blist.SetItemData(i,(ULONG)pb.addr); 
        i++;
      }
      else
      {
        procname.LoadString(IDS_MEMACCESS);
        msize=prc->GetMemSize(pb.memspec); //Speicherbereich in dem der Bkpt gesetzt ist      
        fmt= pb.fmt & (BKPT_READ|BKPT_WRITE);  
        switch(fmt)
        {
          case BKPT_READ+BKPT_WRITE:
                         accesstyp="RW";
                         break;
          case BKPT_READ:
                         accesstyp="R";
                         break; 
          case BKPT_WRITE:
                         accesstyp="W";
                         break; 
          default:
                         accesstyp="??"; 
                         break;
        }
        switch(msize)
        {
          case  S8:
             txt.Format("%s: 0x%2.2X /%c - %s",procname,pb.addr&0xFF,pb.memspec,accesstyp);
             break;
          case  S16:
             txt.Format("%s: 0x%4.4X /%c - %s",procname,pb.addr&0xFFFF,pb.memspec,accesstyp);
             break;
          case  S32:
             txt.Format("%s: 0x%8.8X /%c - %s",procname,pb.addr,pb.memspec,accesstyp);
             break;
        }
        blist.InsertItem(i,txt,11);
        blist.SetItemData(i,(ULONG)pb.addr);         
      } 
    }
  }while(pos);
  
  return TRUE;  // return TRUE unless you set the focus to a control
             // EXCEPTION: OCX Property Pages should return FALSE
}

void CBkptEdit::OnBkptdel() 
{
int  selitem;
ULONG breakaddr,s;
CModDef* pm;
POSITION pos;
CJSTEPView* pv;
int image,l;
LV_ITEM lvi;
int memspec;
CString txt;
BOOL UpdateMem;

  UpdateMem=FALSE; 
  selitem=-1;  
  selitem=blist.GetNextItem(-1,LVNI_SELECTED);    
  lvi.mask=LVIF_IMAGE+LVIF_PARAM;
  lvi.iSubItem=0;
  while(selitem!=-1)
  {   
    lvi.iItem=selitem;
    blist.GetItem(&lvi);
 
    breakaddr=(ULONG)lvi.lParam;   
    image= lvi.iImage;
    if(image != 11) //ein Codebreakpoint
    {
      pm=theApp.objinfo.GetModuleFromAddress(breakaddr);
      prc->RemoveBreakpoint(breakaddr);          
      CDocument* pd=((CMainFrame*)AfxGetMainWnd())->pDoc;
      pos=pd->GetFirstViewPosition();
      while(pos)
      {
        pv=(CJSTEPView*)pd->GetNextView(pos); 
        if(!pv)
          break;
        if(pv->pmod==pm) //der Breakpoint wurde im aktuellen Modul gel�scht
        {
          CListCtrl& lc=pv->GetListCtrl();
          int n=lc.GetItemCount();
          int i=0;
          while(i<n)  //Breakpoints nachzeichnen wenn sichtbar war
          {
            if(pv->GetViewMode()==ASM && lc.GetItemData(i)==breakaddr)       
              lc.RedrawItems(i,i);
            else if(pv->GetViewMode()==MIX)
            {
              s=pv->GetDispState(i);
              if( !(s & ISHLLLINE) && lc.GetItemData(i)==breakaddr) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
                lc.RedrawItems(i,i);               
            }
            else if(pv->GetViewMode()==HLL)
            {
              s=pv->GetDispState(i);
              if(s & LINEADDRVALID && lc.GetItemData(i)==breakaddr)                         
                lc.RedrawItems(i,i);          
            }             
            i++;
          }
        }
      } 	
    }
    else //Access Breakpoint
    {
      txt=blist.GetItemText(selitem,0);
      l=txt.Find('/');
      memspec=txt.GetAt(l+1);
      prc->RemoveBreakpoint(breakaddr,memspec); 
      UpdateMem=TRUE;     
    }
    blist.DeleteItem(selitem);
    selitem=blist.GetNextItem(-1,LVNI_SELECTED);
  }
  if(UpdateMem)
    ((CMainFrame*)AfxGetMainWnd())->UpdateAllMemWnds(0,TRUE);
}

void CBkptEdit::OnBkptdisable()
{
LV_ITEM lvi;
int  selitem;
ULONG addr,s;
POSITION pos;
CJSTEPView* pv;
USHORT fmt;


  selitem=-1;
  selitem=blist.GetNextItem(-1,LVNI_SELECTED);
  lvi.mask=LVIF_IMAGE+LVIF_PARAM;
  lvi.iSubItem=0;
  while(selitem!=-1)
  {
    lvi.iItem=selitem;
    blist.GetItem(&lvi);
    addr=lvi.lParam;
    if(lvi.iImage !=11)
    {
      fmt=prc->GetBkptFormat(addr);
      if(fmt & BKPT_DISABLED)
      {
        prc->SetBreakpoint(addr,BKPT_CODE);
        lvi.iImage=1;
        prc->RestoreBkpt(addr);
      }
       else
      {
        prc->SetBreakpoint(addr,BKPT_CODE|BKPT_DISABLED);
        lvi.iImage=6;
        prc->RestoreOpcode(addr);
      }
      lvi.iItem=selitem;
      lvi.iSubItem=0;  
      lvi.mask=LVIF_IMAGE;
      blist.SetItem(&lvi);
      blist.RedrawItems(selitem,selitem);     
    }
    selitem=blist.GetNextItem(selitem,LVNI_SELECTED);
  }
  CDocument* pd=((CMainFrame*)AfxGetMainWnd())->pDoc;
  pos=pd->GetFirstViewPosition();
  while(pos)
  {
    pv=(CJSTEPView*)pd->GetNextView(pos); 
    if(!pv)
       break;
    CListCtrl& lc=pv->GetListCtrl();
    int n=lc.GetItemCount();
    int i=0;
    while(i<n)  //alle Breakpoints nachzeichnen wenn sichtbar
    {
      if(pv->GetViewMode()==ASM)
      {
        addr=lc.GetItemData(i);
        if(prc->IsBreakpointAtAddr(addr,BKPT_CODE))
          lc.RedrawItems(i,i);
      }
      else if(pv->GetViewMode()==MIX)
      {
        s=pv->GetDispState(i);
        if( !(s & ISHLLLINE)) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
        {
          addr=lc.GetItemData(i);
          if(prc->IsBreakpointAtAddr(addr,BKPT_CODE))
            lc.RedrawItems(i,i);
        }      
      }
      else if(pv->GetViewMode()==HLL)
      {
        s=pv->GetDispState(i);
        if(s & LINEADDRVALID) 
        {
          addr=lc.GetItemData(i);
          if(prc->IsBreakpointAtAddr(addr,BKPT_CODE))
            lc.RedrawItems(i,i);
        }
      }
      i++;
    }     
  }  
}
