// JSTEPDoc.h : interface of the CJSTEPDoc class
//
/////////////////////////////////////////////////////////////////////////////

#ifndef _JSTEPDOC
  #define _JSTEPDOC

#include "proc.h"
#include "MemWnd.h"


#define MODULBAR_VISIBLE 1
#define DEBUGBAR_VISIBLE 2
#define ANALYSERBAR_VISIBLE 4

#define UPDATEMODE_HLL  0x8000000L+HLL
#define UPDATEMODE_MIX  0x8000000L+MIX
#define UPDATEMODE_ASM  0x8000000L+ASM



#define SETCURSOR       0x4000000L


// Thread f�r den freien lauf des Simulators.
// wird aus OnRestart aufgerufen
typedef struct
{
  CProc* pprc;
  CObjInfo *pobjinfo;
  BOOL*  b_DbgRun;
  int option;
  HWND hwd;    
} threadpar_t; 

#define UM_THREADEND     WM_USER+0x11
#define UM_DOSTIMULATION WM_USER+0x12
#define NUMBER_OF_ADDCMDS  10  

typedef struct{
   UINT cmdID;        // menu ID
   CString menuname;  // window name (in string table)
   UINT bmpID;        // Bitmap ID for toolbar
   CString ttptxt;    // tooltip string 
   CString stattxt;   // text for status bar
   CWnd* pWnd;        // window pointer
   ULONG style;       // style des zu erzeugenden Fensters  s. corexport.h
} dynamenu_t;
              

typedef struct
{
  int  MRUDockLeftPos;
  int  MRUDockRightPos;
  int  MRUDockTopPos;
  int  MRUDockBottomPos;
  int  FloatXPos;
  int  FloatYPos;
  SIZE FloatSize;
  SIZE HorzDockSize;
  SIZE VertDockSize;
  BOOL DockHorz;
  int  addData;
  UINT  cmdID;
} SizeBarInfo_t;


//------------------------------------------




UINT FreeRun( LPVOID tp );

class CJSTEPDoc : public CDocument
{
protected: // create from serialization only					
	virtual HMENU GetDefaultMenu();
	BOOL hexloaded;
	CMemWnd* CreateMemWnd(CString& cmd, int cmdID=-1);
	BOOL GetRectFromString(LPCSTR buffer, RECT& rc);
	CWinThread* pthread;
	BOOL b_runEnabled;
	BOOL GetAddrFromString(CString& cmd, ULONG* addr);  	
	int viewmode;	
	BOOL vASM;
	BOOL vMIX;
	BOOL vHLL;	
	void CloseModuleBar();
	CJSTEPDoc();
	DECLARE_DYNCREATE(CJSTEPDoc)
	char wspbuffer[200];

// Attributes
public:	    
	CMeasurePoint stpt;
	CMeasurePoint mpt;
	CTracePoint tpt;
	void DeleteControlBar(CMRCSizeControlBar* pb);
    void DeleteControlBar(CControlBar* pb);
	void WriteExtProfile(LPCSTR section,CMRCSizeControlBar* pc);	
	void ReadWorkspace(CString wspfile);
	void WriteWorkspace(CString& wspfilename);

	CView* GetViewFromModule(CModDef* pm);
	void StepOut();
	CListView* punknown;

    BOOL ViewNewModule(ULONG addr, BOOL setcursor=FALSE ,BOOL setstackcur=FALSE);
	void RunCode(int option=0);
	void RunToCursor();
	void StepOver();
	threadpar_t threadpar;
	int StepIn();
	ULONG actdisplayAddr;
	void SetViewMode(int mode);
	int GetViewMode(){ return viewmode;};	
	void OnSetCmd(CString* cmdp=0,SizeBarInfo_t* psbi=0);	
	BOOL bInit;
	BOOL b_DbgRun;
	CProc *pprc;
	CObjInfo* pobjinfo;
    
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJSTEPDoc)
	public:
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJSTEPDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

  // Generated message map functions
public:
	BOOL LoadSDCProject(CString& title);

  
  //{{AFX_MSG(CJSTEPDoc)  
  afx_msg void OnMix();
  afx_msg void OnAsm();
  afx_msg void OnHll();
  afx_msg void OnUpdateHll(CCmdUI* pCmdUI);
  afx_msg void OnUpdateMix(CCmdUI* pCmdUI);
  afx_msg void OnUpdateAsm(CCmdUI* pCmdUI);
  afx_msg void OnDbgbar();
  afx_msg void OnUpdateDbgbar(CCmdUI* pCmdUI);
  afx_msg void OnAnabar();
  afx_msg void OnPrjbar();
  afx_msg void OnUpdateAnabar(CCmdUI* pCmdUI);
  afx_msg void OnUpdatePrjbar(CCmdUI* pCmdUI);
  afx_msg void OnRun();
  afx_msg void OnUpdateRun(CCmdUI* pCmdUI);
  afx_msg void OnStop();
  afx_msg void OnUpdateStop(CCmdUI* pCmdUI);
  afx_msg void OnStepIn();	
  afx_msg void OnStepOut();
  afx_msg void OnStepOver();
  afx_msg void OnRunToCursor();
  afx_msg void OnRegbar();
  afx_msg void OnUpdateRegbar(CCmdUI* pCmdUI);
  afx_msg void OnMemory();
  afx_msg void OnWatch();
  afx_msg void OnUpdateWatch(CCmdUI* pCmdUI);
  afx_msg void OnResetcpu();
  afx_msg void OnLocals();
  afx_msg void OnUpdateLocals(CCmdUI* pCmdUI);
  afx_msg void OnQuickWatch(); 
  afx_msg void OnUpdateQuickWatch(CCmdUI* pCmdUI);  
  afx_msg void OnStack(); 
  afx_msg void OnUpdateStack(CCmdUI* pCmdUI);
  afx_msg void OnBreakpoint();
  afx_msg void OnAnalyser(); 
  afx_msg void OnUpdateAnalyser(CCmdUI* pCmdUI);
  afx_msg void OnTrace(); 
  afx_msg void OnUpdateTrace(CCmdUI* pCmdUI);
  afx_msg void OnTraceEnabled(); 
  afx_msg void OnUpdateTraceEnabled(CCmdUI* pCmdUI);
  afx_msg void OnUpdateMemory(CCmdUI* pCmdUI);
  afx_msg void OnClrBkpt();
  afx_msg void OnDeacBkpt();
  afx_msg void OnTracepoint();
  afx_msg void OnSetBreak();
  afx_msg void OnSetTracepoint();
  afx_msg void OnUpdateAll();
  afx_msg void OnSetMeasurepoint();
  afx_msg void OnUpdateMeasurepoint(CCmdUI* pCmdUI);
  afx_msg void OnSetStimulationpoint();
  afx_msg void OnUpdateStimulationpoint(CCmdUI* pCmdUI);
  afx_msg void OnUpdateTracepoint(CCmdUI* pCmdUI);
  afx_msg void OnFileSaveAs();
  afx_msg void OnProcWnds(UINT id);
  afx_msg void OnUpdateProcWnds(CCmdUI* pCmdUI);
  afx_msg void OnMemCfg();
  afx_msg void OnToggleBreak();
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
private:
	void CleanUpControlBarState(CDockState& state);
};

#endif //_JSTEPDOC
/////////////////////////////////////////////////////////////////////////////
