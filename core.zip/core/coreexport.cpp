//export interface for use by the processor implementation

#include "stdafx.h"
#include "jstep.h"
#include "mainfrm.h"
#include "objinfo.h"
#include "coreexport.h"


void DLLDIR RemoveFromCallStackWnd(ULONG returnAddr)
{
  ((CMainFrame*)(theApp.pMainWnd))->m_wndStack.RemoveFromCallStackWnd(returnAddr);
}

void DLLDIR AddToCallStackWnd(ULONG callAddr,ULONG returnAddr)
{  
  ((CMainFrame*)(theApp.pMainWnd))->m_wndStack.AddToCallStackWnd(callAddr, returnAddr);
}

BOOL DLLDIR FindLabel(ULONG addr, LPSTR lbl,int memspec,int typmask,int precision)
{
  return theApp.objinfo.FindLabel( addr,lbl,memspec,typmask,precision);
}

BOOL DLLDIR FindBitLabel(ULONG addr, LPSTR lbl,int memspec,int typmask,int precision)
{
  return theApp.objinfo.FindBitLabel( addr,lbl,memspec,typmask,precision);
}

void DLLDIR AddGlobalSymbol(ULONG addr, LPSTR symbolname, CTypdesc* pt,int memspec)
{  
  theApp.objinfo.AddDbgInfo (addr,symbolname,PUBSYM,memspec,-1,0,pt);   
}


void DLLDIR InsertProcMenuItem(UINT cmdID,LPCSTR menuName,UINT bmpID,LPCSTR tooltip,LPCSTR statustxt,ULONG style)
{
CMenu *pm;
int i;
TBBUTTON tbb;

  pm=&((CMainFrame*)theApp.pMainWnd)->m_menu;
  pm=pm->GetSubMenu(2);
  if(pm)
  {
    CMainFrame* pmainwnd=(CMainFrame*)theApp.pMainWnd;
    if(!bmpID)
      bmpID=IDB_BMPDEFAULT;
    
    for(i=0;i<pmainwnd->addcmdNo;i++)
    {
      if(pmainwnd->addcmds[i].cmdID==cmdID)
      {   //die ID ist schon vorhanden
        if(tooltip)
          pmainwnd->addcmds[i].ttptxt=tooltip;
        if(statustxt)
          pmainwnd->addcmds[i].stattxt=statustxt;        
        pmainwnd->addcmds[i].menuname=menuName;
        CToolBarCtrl& tbc=pmainwnd->m_wndAnalyserBar.GetToolBarCtrl();
        tbc.AddBitmap(14+pmainwnd->addcmdNo,bmpID);
        pmainwnd->m_wndAnalyserBar.SetButtonInfo(STDBUTTONS+1+i,cmdID,TBBS_BUTTON ,STDBUTTONS+1+i);
        pmainwnd->DrawMenuBar();        
        return;
      }              
    }     
    if(style==DLLWND_FIX || style==DLLWND_DYNAMIC)
    { 
      pm->InsertMenu(11,MF_STRING|MF_ENABLED|MF_BYPOSITION,
                     IDC_PROCWND0+pmainwnd->addcmdNo,menuName);  
    }
    else if(style==DLLWND_MODAL)
    {  
      pm=&((CMainFrame*)theApp.pMainWnd)->m_menu;    
      pm=pm->GetSubMenu(1);
      if(pm)
        pm->InsertMenu(9,MF_STRING|MF_ENABLED|MF_BYPOSITION,
                       IDC_PROCWND0+pmainwnd->addcmdNo,menuName);
    }  
    if(tooltip)
       pmainwnd->addcmds[pmainwnd->addcmdNo].ttptxt=tooltip;
    if(statustxt)
      pmainwnd->addcmds[pmainwnd->addcmdNo].stattxt=statustxt;   
    pmainwnd->addcmds[pmainwnd->addcmdNo].menuname=menuName;
    if(bmpID)
      pmainwnd->addcmds[pmainwnd->addcmdNo].bmpID=bmpID;
    pmainwnd->addcmds[pmainwnd->addcmdNo].cmdID=cmdID; 
    pmainwnd->addcmds[pmainwnd->addcmdNo].style=style;
    if(pmainwnd->m_wndAnalyserBar.m_hWnd)
    {    
      if(bmpID!=IDB_BMPDEFAULT)
        AfxSetResourceHandle(hinstDLL);  
      CToolBarCtrl& tbc=pmainwnd->m_wndAnalyserBar.GetToolBarCtrl();      
      int r=tbc.AddBitmap(1,bmpID);  
      tbb.iBitmap=r;                        // zero-based index of button image
      tbb.idCommand=pmainwnd->addcmdNo+IDC_PROCWND0; // command to be sent when button pressed
      tbb.fsState=TBSTATE_ENABLED;          // button state--see below
      tbb.fsStyle=TBSTYLE_BUTTON;           // button style--see below
      tbb.dwData=0;                         // application-defined value
      tbb.iString=0;                        // zero-based index of button label string      
      tbc.AddButtons(1,&tbb);
      AfxSetResourceHandle(AfxGetInstanceHandle()); 
    }
    else
    {
      pmainwnd->m_wndAnalyserBar.AddButton(pmainwnd->addcmdNo+IDC_PROCWND0,bmpID);
    }
    pmainwnd->addcmdNo++;
  }   
}

void DLLDIR UpdateAllWatches()
{
  ((CMainFrame*)theApp.pMainWnd)->UpdateAllWatches();
}

void DLLDIR WriteCurrentTraceRecord(int tracetyp,ULONG pc)
{
  theApp.objinfo.WriteCurrentTraceRecord(tracetyp,pc);
}

void DLLDIR DoNextStimulation()
{
  ::SendMessage(theApp.pMainWnd->m_hWnd,UM_DOSTIMULATION,0,0);
}

HANDLE DLLDIR AddModule(LPCSTR moduleName,LPCSTR sourcePath)
{
  int modId=theApp.objinfo.AddModuleInfo(moduleName,sourcePath);
  return (HANDLE)theApp.objinfo.moduls.GetAt(modId);
}

HANDLE DLLDIR AddProcedure(LPCSTR procedureName,HANDLE hModule,ULONG startaddr,ULONG endaddr)
{
  if(!hModule)
    return (HANDLE)0;
  return (HANDLE) (((CModDef*)hModule)->AddProc(procedureName,startaddr,endaddr,(CModDef*)hModule));
}

void DLLDIR AddDebugSymbol(ULONG addr, char* label,int valrange,int memspec,HANDLE hModule,HANDLE hProc,CTypdesc* ptd)
{
   int modid=((CModDef*)hModule)->ModID;
  theApp.objinfo.AddDbgInfo (addr,label,valrange,memspec,modid,(CProcDef*)hProc,ptd);
}

void DLLDIR AddLineInfo(ULONG addr, ULONG lineno, HANDLE hModule)
{
  int modid=((CModDef*)hModule)->ModID;
  theApp.objinfo.AddDbgInfo(addr,lineno,modid);
}