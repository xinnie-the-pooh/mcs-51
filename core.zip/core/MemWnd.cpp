// MemWnd.cpp : implementation file
//

#include "stdafx.h"

#include "ModDef.h"
#include "ObjInfo.h"
#include "RegWnd.h"
#include "Proc.h"
#include "MemWnd.h"
#include "JSTEP.h"
#include "JSTEPDoc.H"
#include "DbgBar.h"
#include "MainFrm.h"
#include "JSTEPView.h"
#include "windows.h"
#include "parser.h"
#include "proc.h"

#ifdef _DEBUG
  #define new DEBUG_NEW
  #undef THIS_FILE
  static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMemWnd

CMemWnd::CMemWnd(int vtyp,ULONG addr,int mem)
:CMRCSizeDialogBar()
{
  viewtype=vtyp;
  startaddr=addr;
  memspec=mem;
  varAddr=FALSE;
  dright=0;
}


CMemWnd::~CMemWnd()
{
}


BEGIN_MESSAGE_MAP(CMemWnd, CMRCSizeDialogBar)
//{{AFX_MSG_MAP(CMemWnd)
ON_WM_SIZE()
//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CRegWnd message handlers


BOOL CMemWnd::Create( CWnd* pParentWnd,int wndNo)
{
char buff[3];
mcfg_t mcfg;

  RECT rc;
  BOOL b= CMRCSizeDialogBar::Create(pParentWnd, IDD_MEMBAR
                                    ,CBRS_ALIGN_REGWND|CBRS_SIZE_DYNAMIC
                                    ,IDD_MEMBAR+wndNo);

  if(b)
  {
    edlc.SubclassDlgItem(IDC_MEMLIST,this);
    edlc.Create();
    edlc.edit.extramenu=IDR_EDNOTIFY1;
    SetBarStyle( GetBarStyle()
                 | CBRS_TOOLTIPS
                 | CBRS_FLYBY
                 | CBRS_BORDER_ANY
                 | CBRS_BORDER_3D );
    Init(startaddr);
    addred.SubclassDlgItem(IDC_ADDREDIT,this);
    EnableDocking(CBRS_ALIGN_REGWND);
    SetWindowText(_T("Memory"));
    RECT rd;
    GetDesktopWindow()->GetWindowRect(&rd);
    CPoint pt;
    pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;
    m_FloatingPosition=pt;
    GetWindowRect(&rc);
    dright=rc.right;
    addred.GetWindowRect(&rc);
    dright-=rc.right;
    int block=0;
    while(block != -1)
    {
      block=prc->GetNextMemMapping(&mcfg,block);
      if(block==-1)
        break;
      buff[0]=(char)mcfg.memspec;
      buff[1]=0;
      int r=((CComboBox*)GetDlgItem(IDC_MEMTYPES))->FindStringExact(0,buff);      
      if(r==CB_ERR)
        ((CComboBox*)GetDlgItem(IDC_MEMTYPES))->AddString(buff);
    }
    if(((CComboBox*)GetDlgItem(IDC_MEMTYPES))->GetCount()<2)
      ((CComboBox*)GetDlgItem(IDC_MEMTYPES))->ShowWindow(SW_HIDE);
  }
  EnableToolTips(TRUE);
  return(b);
}


void CMemWnd::Init(ULONG addr)
{
  CString saddr;

  SetStartAddr(addr,saddr,memspec);
  SetDlgItemText(IDC_ADDREDIT,LPCSTR("0x" + saddr));
  edlc.SetCols(viewtype,memspec,startaddr);
}

void CMemWnd::OnSize(UINT nType, int cx, int cy)
{
  RECT rc,re,rmemtyp,rc1;

  CMRCSizeDialogBar::OnSize(nType, cx, cy);
  GetClientRect(&rc);
  ClientToScreen(&rc);
  if(addred.m_hWnd)
  {
    addred.GetWindowRect(&re);
    re.right=rc.right-dright;
    ScreenToClient(&re);
    addred.MoveWindow(&re,TRUE);
    GetDlgItem(IDC_MEMTYPES)->GetWindowRect(&rmemtyp);
    GetDlgItem(IDC_MEMTYPES)->GetClientRect(&rc1);
    rmemtyp.top=re.top-1;
    rmemtyp.right=re.right+rc1.right+4;
    rmemtyp.left=re.right+4;
    rmemtyp.bottom=re.bottom-4;
    GetDlgItem(IDC_MEMTYPES)->MoveWindow(&rmemtyp);
  }

  CEdMemLstCtrl* pe=(CEdMemLstCtrl*)GetDlgItem(IDC_MEMLIST);
  if(!pe)
    return;
  re.top=rc.top+pe->toff;
  //re.left=rc.left+pe->loff;
  //re.bottom=rc.bottom+pe->boff;
  //re.right=rc.right+pe->roff;
  re.left=rc.left;
  re.bottom=rc.bottom;
  re.right=rc.right;
  ScreenToClient(&re);
  pe->MoveWindow(&re,FALSE);
  pe->SetCols(pe->viewtyp,memspec,startaddr);
  Invalidate(FALSE);
}

// wenn redraw gesetzt ist wird das Fenster nur neugezeichnet
// aber nicht neu berechnet
void CMemWnd::UpdateMem(BOOL redraw)
{
  eval_t r;
  char buff[80];
  CString txt;

  if(redraw)
  {
    edlc.Invalidate(FALSE);
    return;
  }
  if(!varAddr)
    edlc.ReEvaluate();
  else
  {
    addred.GetWindowText(buff,sizeof(buff));
    r.expression=buff;
    r.lastop.op[0]=0;
    int x=Evaluate(&r);
    if(x)
      return;  //falsch
    else
    {
      txt=buff;
      if(startaddr != *(ULONG*)r.retval.op)
      {
        SetStartAddr(*(ULONG*)r.retval.op,txt,r.retval.memspec);
        edlc.SetCols(-1,r.retval.memspec,*(ULONG*)r.retval.op);
      }
      else
        edlc.ReEvaluate();
    }
  }
}

void CMemWnd::SetStartAddr(ULONG addr,CString& saddr,int memspec)
{
  ULONG msize;

  CMemWnd::memspec=memspec;
  msize=prc->GetMemSize(memspec);
  addr &= msize;
  addr=prc->GetDestinationAddress(addr,memspec);
  if(memspec == BITMEM)
    addr=0x20; // Anfang Bitadressierbarer Bereich
  startaddr=addr;

  switch(msize)
  {
    case S8:
      edlc.SetItemValText(&addr,V_BYTE,saddr);
      break;
    case S16:
      edlc.SetItemValText(&addr,V_SHORT,saddr);
      break;
    case S32:
    default:
      edlc.SetItemValText(&addr,V_LONG,saddr);
      break;
  }
}

void CMemWnd::SetViewType(int type)
{
  switch(type)
  {
    case V_BYTE:
      if(viewtype!=type)
      {
        viewtype=type;
        Init(startaddr);
      }
      break;
    case V_SHORT:
      if(prc->GetMemAlignment()==INVERS)
        type=V_INV_SHORT;
      break;
    case V_LONG:
      if(prc->GetMemAlignment()==INVERS)
        type=V_INV_LONG;
      break;
  }
  if(viewtype!=type)
  {
    viewtype=type;
    UpdateMem();
  }
}


int CMemWnd::OnToolHitTest( CPoint point, TOOLINFO* pTI ) const
{
  int item;
  int sitem;
  int w,wOld;
  RECT rci,rcw;
  char vbuff[10];

  if(!pTI)
    return -1;

  // workout which grid square the mouse is in...
  // if there were any area's that are not hits, then we could return -1
  // immiediately, but in this example, every grid square fires.
  UINT flags= LVHT_ONITEM | LVHT_TORIGHT;
  edlc.GetWindowRect(&rci);
  GetWindowRect(&rcw);
  point.y-=(rci.top-rcw.top);       //point ist in Coordinaten des Parent Windows
  item=edlc.HitTest(point,&flags);
  if(item==-1)
    return -1;
  w=edlc.GetColumnWidth(0);
  wOld=w;
  sitem=0;
  while(w <= point.x)
  {
    sitem++;
    wOld=w;
    w+=edlc.GetColumnWidth(sitem);
    if(w==wOld)
    {
      sitem--;
      break;
    }
  }
  if(sitem<1)
    return -1;

  pTI->rect.left = w - edlc.GetColumnWidth(sitem-1);
  pTI->rect.right = w;
  edlc.GetItemRect(item,&rci,LVIR_BOUNDS);
  pTI->rect.top = rci.top;
  pTI->rect.bottom = rci.bottom;

  CString txt=edlc.GetItemText(item,sitem);
  if(txt.GetLength()>1)
    txt=txt.Mid(1);
  if(edlc.viewtyp!=V_ASCII)
  {
    ULONG v=strtoul(LPCSTR(txt),0,16);
    txt="0x" + txt;
    txt+= "=";
    sprintf(vbuff,"%d",v);
    txt+=vbuff;
    if(edlc.viewtyp==V_BYTE && isprint((int)v))
    {
      txt+= "='";
      txt+=(BYTE)v;
      txt+= "'";
    }
  }
  else
  {
    txt+="=0x";
    sprintf(vbuff,"%X",txt.GetAt(0));
    txt+=vbuff;
  }
  pTI->lpszText=new char[txt.GetLength()+1];
  strcpy(pTI->lpszText,LPCSTR(txt));

  // set up the rest of the flags. Not all of these are required, but it seems
  // safer to supply them.

  pTI->hwnd = edlc.m_hWnd;        // window where TTN_NEEDTEXT will be sent.
  pTI->uFlags = TTF_ALWAYSTIP ;
  pTI->cbSize = sizeof TOOLINFO;
  pTI->uId = (UINT)-2;       // dummy id, so we can tell it's not a standard command
  // if you want standard tooltip processing, you should
  // put the command id here
  // need a return value that is different for every grid square
  return (item * 256 + sitem);
}



void CMemWnd::GetAddrString(CString& txt)
{
  GetDlgItemText(IDC_ADDREDIT,txt);
}


void CMemWnd::SetAddress(CString& txt)
{
  addred.SetWindowText(txt);
  addred.OnReturnKey(txt);
}



BOOL CMemWnd::OnCommand(WPARAM wParam, LPARAM lParam) 
{
char buff[5];
CString addtxt;

	if(HIWORD(wParam)==CBN_SELCHANGE)
  {
    int r=((CComboBox*)GetDlgItem(IDC_MEMTYPES))->GetCurSel(); 
    buff[0]=' ';
    buff[1]='/';
    ((CComboBox*)GetDlgItem(IDC_MEMTYPES))->GetLBText(r,&buff[2]);
    addred.GetWindowText(addtxt);
    r=addtxt.ReverseFind('/');
    if(r!=-1)
    {
      addtxt=addtxt.Left(r);
      addtxt+=&buff[1];
    }        
    else
      addtxt+=buff;
    addred.SetWindowText(addtxt);
    addred.OnReturnKey(addtxt);
  }
	return CMRCSizeDialogBar::OnCommand(wParam, lParam);
}
