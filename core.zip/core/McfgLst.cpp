// McfgLst.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "McfgLst.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMcfgLst

CMcfgLst::CMcfgLst()
{
 lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier");   

 cols=0;
}

CMcfgLst::~CMcfgLst()
{
}


BEGIN_MESSAGE_MAP(CMcfgLst, CListCtrl)
	//{{AFX_MSG_MAP(CMcfgLst)
	ON_WM_LBUTTONDOWN()
    ON_MESSAGE(UM_ENTER,OnEditReturn)
    ON_MESSAGE(UM_TAB,OnEditTab)
	ON_WM_VSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMcfgLst message handlers

#define DEFAULT_TEXTDRAW  DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER 
#define TEXTOFFSET 2

void CMcfgLst::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
RECT rc,rcItem;
int item;
CPen* oldPen;
char szBuff[100];
int w,i;
CDC* pDC;
 
  GetClientRect(&rc);   
  rcItem=lpDrawItemStruct->rcItem;
  rcItem.left+=TEXTOFFSET;
	item=lpDrawItemStruct->itemID;	
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
  CFont* oldfont=pDC->SelectObject(&lfont);
  CPen dotpen(PS_DOT,1,(COLORREF)0xC0C0C0L); 
 
  oldPen=(CPen*)pDC->SelectObject(&bkpen);
 
  pDC->MoveTo(rcItem.left,rcItem.bottom);
  pDC->LineTo(rcItem.right,rcItem.bottom);
  pDC->MoveTo(rcItem.left,rcItem.top);
  pDC->LineTo(rcItem.right,rcItem.top);

  pDC->SelectObject(&dotpen);
  pDC->MoveTo(rcItem.left,rcItem.bottom);
  pDC->LineTo(rcItem.right,rcItem.bottom);
  pDC->MoveTo(rcItem.left,rcItem.top);
  pDC->LineTo(rcItem.right,rcItem.top);

  i=0;  
  w=0;
  while(i<cols)
  {
    w+=GetColumnWidth(i++);
    pDC->MoveTo(w,rcItem.bottom);    
    pDC->LineTo(w,rcItem.top);
  }

  // Draw text for all columns 
  pDC->SelectObject(oldPen);
  pDC->SetTextColor(0); //wieder schwarz 
  i=0;  
  rcItem.left=TEXTOFFSET;   
  if(!GetItemData(item))
    pDC->SetTextColor(0x80);
  while(i<cols)
  {
    GetItemText(item,i,szBuff,sizeof(szBuff));    
    rcItem.right=rcItem.left+GetColumnWidth(i)-TEXTOFFSET-1;  
    pDC->DrawText(szBuff,-1,&rcItem,DEFAULT_TEXTDRAW);    
    rcItem.left+=GetColumnWidth(i++);
  }    
}

void CMcfgLst::Create()
{
RECT rc;

  bkpen.CreatePen(PS_SOLID,1,GetBkColor());
  //SetImageList(&imageList,LVSIL_SMALL); 
  edit.Create(WS_CHILD|WS_BORDER|WS_OVERLAPPED|ES_NOHIDESEL|ES_MULTILINE|ES_WANTRETURN,rc,this,0);
  edit.SetFont(&lfont,FALSE);	
  
  CClientDC dc(this);
  dc.GetOutputCharWidth('0','0',&fwidth);
  edit.act=-1; 
}

int CMcfgLst::InsertColumn(int nCol, const LV_COLUMN* pColumn)
{
  cols++;
  return CListCtrl::InsertColumn(nCol,pColumn);
}

BOOL CMcfgLst::DeleteColumn(int nCol)
{
  cols--;
  return CListCtrl::DeleteColumn(nCol);
}

void CMcfgLst::OnLButtonDown(UINT nFlags, CPoint point) 
{
LV_ITEM lvi;
RECT rc;

  GetItemRectFromPoint(point,&lvi,&rc);
  if(lvi.iItem == -1)
  {
    edit.ShowWindow(SW_HIDE);
    edit.SetWindowText("");
    if(edit.act != -1)
    {
      RedrawItems(edit.act,edit.act);    
    }
    return;
  }  
  else
  {    
    if(GetItemData(lvi.iItem))
    {      
      edit.ShowWindow(SW_SHOW);
      MoveEdit(lvi.iItem,lvi.iSubItem);         
    }
  }		
	//CListCtrl::OnLButtonDown(nFlags, point);
}

// liefert zu einem Punkt das zugeh�rige Rechteck ,Index und SubIndex
BOOL CMcfgLst::GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc)
{
BOOL b;
int ncol;
int w;
LV_COLUMN lvc;
int x;

  
  UINT flags=LVHT_ONITEM |LVHT_TORIGHT ;
  lvi->iItem=HitTest(point,&flags);  //finde den Index des Items zum Punkt
	GetItemRect(lvi->iItem,rc,LVIR_LABEL);
  x=point.x;
  point.x=rc->left;
  if( lvi->iItem == -1) //item nicht gefunden
	  return FALSE;	
	lvc.mask=LVCF_WIDTH ;
	ncol=0;
	w=0;
  do
	{
    b=GetColumn(ncol,&lvc);
		if(b)                 
    {
			rc->left=w;
      w+=lvc.cx;
			if(x <=w)
      {   // die Spalte haben wir gesucht        
				rc->right=w;
				lvi->iSubItem=ncol;
				return TRUE;
      }
    } 
		ncol++;
	}while(b);
	return FALSE;
}

long CMcfgLst::OnEditTab(UINT wparam, LONG lparam)
{

  if(!wparam)
  {
    if(edit.actsub<cols-1)  
      MoveEdit(edit.act,edit.actsub+1);
    else if(edit.actsub==cols-1)  
    {
      int n=GetItemCount();
      if(edit.act==n-1 && !IsLineEmpty(edit.act))            
      {
        InsertItem(n,"");     
        MoveEdit(edit.act+1,0);
      }
      else if(edit.act<n-1)     
        MoveEdit(edit.act+1,0);
      else
        MoveEdit(edit.act,0); 
    }
  }
  else //SHIFT-TAB
  {  
    if(edit.actsub)  
      MoveEdit(edit.act,edit.actsub-1);
    else   
    {
      int n=GetItemCount();
      if(edit.act)    
        MoveEdit(edit.act-1,cols-1);      
    }
  }
  return 0;
}

long CMcfgLst::OnEditReturn(UINT wparam, LONG lparam)
{
CString txt,oldtext;
RECT rc;
int i;

  edit.GetWindowText(txt);  
  oldtext=GetItemText(edit.act,0);
  int icnt=GetItemCount(); 
  if(txt!="")
  {
   
    SetItemText(edit.act,edit.actsub,txt); 
    edit.ShowWindow(SW_HIDE);
    
    if( edit.act == icnt-1) 
    {       
      i=InsertItem(icnt,"");  //neuen Eintrag einf�gen wenn der text vorher leer war    
      GetItemRect(i,&rc,LVIR_BOUNDS);  
      edit.SetWindowText("");
      edit.act=i;
      edit.SetWindowPos(&wndTop,
	                rc.left,
                    rc.top,
			      	GetColumnWidth(0),
				    rc.bottom-rc.top,
					SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);
    }
  }
  else
  {
    if( edit.act < icnt-1)
    { 
      DeleteItem(edit.act); //eintrag l�schen wenn Text leer und nicht die letzte Zeile
      edit.ShowWindow(SW_HIDE);
      edit.SetWindowText("");
    }
  }
  	
  return 0;
}


void CMcfgLst::MoveEdit(int row, int col, BOOL redraw)
{
RECT rc;
int i;
CString txt;

   if(!(edit.GetStyle() &WS_VISIBLE))
     return;
   GetItemRect(row,&rc,LVIR_BOUNDS);
   if(rc.top < rc.bottom-rc.top)
   {
      edit.ShowWindow(SW_HIDE); 
      return;
   }
   i=0;  
   while(i<col)
   {    
     rc.left+=GetColumnWidth(i++);
   }
   rc.right=rc.left+GetColumnWidth(i);   
   edit.SetWindowPos(&wndTop,
                      rc.left,
                      rc.top,
	                  rc.right-rc.left,
				      rc.bottom-rc.top,
   					  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW); 
   if(redraw)
   {
     edit.GetWindowText(txt);
     SetItemText(edit.act,edit.actsub,txt); 
     txt=GetItemText(row,col);
     edit.SetWindowText(txt);
     edit.Invalidate(FALSE);    
     edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols    
     edit.SetFocus(); 
     Update(edit.act);     
   }  
   edit.act=row;
   edit.actsub=col;
}

BOOL CMcfgLst::IsLineEmpty(int item)
{
int n,i;
CString txt;
 
  i=0;
  n=cols;
  while(n--)
  {
    txt=GetItemText(item,n);
    if(txt=="")
      i++;
  }
  if(i==cols)
    return TRUE;
  return FALSE;
}

BOOL CMcfgLst::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{
HD_NOTIFY* p;	
RECT rc;
int cxy;

  p=((HD_NOTIFY*)lParam);
  if(p->hdr.code==HDN_ENDTRACK)
  { 
    GetClientRect(&rc);    
    cxy=p->pitem->cxy;    
    SetRedraw(FALSE);    
    SetColumnWidth(p->iItem+1,GetColumnWidth(p->iItem+1)+GetColumnWidth(p->iItem)-cxy);     
    SetColumnWidth(p->iItem,cxy);        
    SetRedraw(TRUE);
    MoveEdit(edit.act,edit.actsub);            
    Invalidate(TRUE);
  }   	
	return CListCtrl::OnNotify(wParam, lParam, pResult);
}

void CMcfgLst::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
RECT rc;

  edit.GetWindowRect(&rc); 
  ScreenToClient(&rc); //Umrechnen auf listctrlkodinaten
  InvalidateRect(&rc);
  edit.ShowWindow(SW_SHOW);
  MoveEdit(edit.act,edit.actsub);
	CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

