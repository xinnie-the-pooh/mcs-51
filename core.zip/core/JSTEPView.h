// JSTEPView.h : interface of the CJSTEPView class
//
/////////////////////////////////////////////////////////////////////////////
//ViewModes
#define ASM           1
#define HLL           2
#define MIX           4 
#define STEP_HLL      HLL
#define STEPOVER_HLL  8
#define STEPOUT       0x10

//Zustand Kommentar des Zeilenendes der vorangegangenen Zeile

#define COMMENTOPEN    0x01  //die Zeile endet mit Kommentar der nicht geschlossen wurde
#define LINEADDRVALID  0x02  //die Adresse in item.lParam ist g�ltig
#define ISHLLLINE      0x04  //Kennung das die Zeile eine HLL-Zeile und kein ASM-Code ist

// offsets for first and other columns
#define OFFSET_FIRST	2
#define OFFSET_OTHER	6


#define DEFAULT_TEXTDRAW  DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER //|DT_NOCLIP


typedef struct
{
  const char* key;
  BYTE  coloridx;
}keydef_t;



class CJSTEPView : public CListView
{
friend class CJSTEPDoc;

public:	
	ULONG GetDispState(int index);
	void ResetStackCursor();
	void OpenQuickWatch();	
	int GetToolTipString( CString& wtxt ) const;
	virtual int OnToolHitTest( CPoint point, TOOLINFO* pTI ) const;
	inline int GetSeltextLen() {return (selend-selstart);};
	void Copy();	
	int ScrollToAddr(ULONG addr);
	BOOL enableHLL;  
	CJSTEPView(int viewmode=HLL);   //Konstruktor
	void SetViewMode(int viewmode);
    int GetViewMode(){return vmode ;};
	void SetIcon(int Icoidx, int nitem);
  
private:
	void SetupASMList( CModDef* mp );
	void SetupHLLList( CModDef* mp );
	void SetupMIXList( CModDef* mp );	
	void SetupList(CModDef* mp);  
	int DrawCommentFromPos(CDC*pDC,CString& txt,RECT& rcLabel);
	int DrawCodeFromPos(CDC*pDC,CString& txt,RECT& rcLabel);	
	ULONG GetCommentState(CString& srcline, ULONG* prevcomment);
  CWordArray dispstate;

protected: 				
	int GetNextValidHllLine(CListCtrl& lc,int fromline, ULONG* addr,BOOL checkProc);    
	COLORREF bkcolor;
	int pcitem;	
    void ResetSelection();
	void RecalcSelrect(int item);
		
	COLORREF m_clrBkgnd;
	
 	int vmode;
	void DrawSelection(COLORREF bkcolor=0xFFFFFF);
    int seltextlen;
	int selend;
	int selstart;
	CString selectedText;
	BOOL bselect;
	CRect rcLabel;
	char szBuff[150];	   
	RECT selrect;
	int fwidth;
	BOOL mcaptured;
	CFont lfont;
	int actitem;
	CImageList m_SmallImageList;	
	DECLARE_DYNCREATE(CJSTEPView)

// Attributes
public:
  CModDef* pmod;
	CString title;
	CJSTEPDoc* GetDocument();

// Operations
protected:
	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJSTEPView)
	public:
	virtual void OnInitialUpdate();
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	protected:
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	//}}AFX_VIRTUAL
  BOOL OnToolTipNotify( UINT id, NMHDR * pNMHDR, LRESULT * pResult );

// Implementation
public:
	int ReplaceTabs(CString& s,int spaces=1);
	virtual ~CJSTEPView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	void DrawColoredText(LPCSTR text, CDC* pDC, RECT& rcLabel);
	void CalcColorText(LPCSTR txt, BYTE *colorbuf);
	char ttptxt[200];
	
	//{{AFX_MSG(CJSTEPView)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);	
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnAddWatch();
  afx_msg void OnSetPC();
	afx_msg void OnKillFocus(CWnd* pNewWnd);

  afx_msg LRESULT OnSetFont(WPARAM wParam, LPARAM);
	afx_msg void MeasureItem ( LPMEASUREITEMSTRUCT lpMeasureItemStruct );
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in JSTEPView.cpp
inline CJSTEPDoc* CJSTEPView::GetDocument()
   { return (CJSTEPDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
