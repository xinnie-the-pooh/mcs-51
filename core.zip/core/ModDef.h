//Deklaration der Klasse CModDef, verwaltet Modulinformationen

#ifndef _MODDEF
  #define  _MODDEF

class CProcDef : public CObject
{
public:  
  CString Procname;  //Prozedurname				
  ULONG  AnfAddr;
  ULONG  EndAddr;				
};  


typedef struct
{
  ULONG addr;
  USHORT lineno;
} linedef_t;


class CModDef : public CObject
{
friend class CObjInfo;

public:	
	void SortProcs();
	BOOL ObExt;
	int ModID;
  ULONG GetLowAddr(){ return lowaddr;};
  ULONG GetHighAddr(){ return highaddr;};
  void SetAnfAddr(CProcDef* pp, ULONG addr);
  void SetEndAddr(CProcDef* pp, ULONG addr);
  CModDef(LPCSTR pmodulname,LPCSTR psrcpath=NULL);
  ~CModDef();  
  CString SrcPath;
  CString modname;
  CProcDef* AddProc(LPCSTR pprocname,ULONG AnfAddr,ULONG EndAddr,CModDef* pmod=0);
  CProcDef* AddProc(LPCSTR procname);
  int GetProcCnt();  
  CPtrList proclist;

protected:	
  ULONG highaddr;
  ULONG lowaddr;  
  CPtrArray alines; 
};

#endif //_MODDEF

