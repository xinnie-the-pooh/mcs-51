// Header f�r CTypdesc
 
#ifndef _TYPEDESC
  #define _TYPEDESC    
  
// Standard Datentypen  

#define T_UNTYPED 0
#define T_BIT     1
#define T_SCHAR   2
#define T_UCHAR   3
#define T_SINT    4
#define T_UINT    5 
#define T_SLONG   6
#define T_ULONG   7
#define T_FLOATL  8
#define T_DOUBLE  9
#define T_CODELABEL 10 
#define T_VOID      11
#define T_FLOATB    12
#define T_REGISTER  13
#define T_OVERFLOW  0x1F     

#define T_LISTDESC    0x20   
#define T_POINTDESC   0x21
#define T_ARRAYDESC   0x22
#define T_FUNCDESC    0x23
#define T_TYPEDESC    0x24
#define T_STRUCTDESC  0x25
#define T_BITARRDESC  0x26
#define T_SPACEDPTR   0x27
#define T_GENPTRDESC  0x28 
#define T_SDCGENPOINT 0x29    

//Memoryspace  Spezifizierer bei Pointer Descriptoren   

#define MS_IDATA  1
#define MS_XDATA  2
#define MS_PDATA  3
#define MS_DATA   4
#define MS_CODE   5
  

typedef union{
    float f;
    unsigned long  l;
    unsigned short s[2];
    unsigned char  c[4];
} conv_t;

class CTypdesc : public CObject
{
public:
	  static ULONG GetSizeOfTyp(CTypdesc* pt);
    CTypdesc( int type=0);
    ~CTypdesc();    
    CTypdesc* tparent; //Typ des Typdesc von dem aus referenziert wird 
    CString* pname;    //Typedefname
                       //Name des Listenelements 
    
    int typ;           //Typ
    
    int size;          //Struct-desc.=Strukturgr��e 
                       //Bitfield-desc=Feldgr��e 
                       //SpacedPtr-desc.= Pointergr��e 1/2 *8Bit  
                       //GenericPtr-desc.=Pointergr��e 8/16/24
                       //Arraydesc Anzahl der Dimensionen 
    
    int elements;      //List-desc.=Anzahl der Elemente
                       //Array-desc.=Anzahl der Elemente der Dimension 
                       //Bitfield=Base 16/8Bit   
                       //GenericPtr-desc.= C51-PointerTyp 3Byte/Spaced/reversePtr
                       
    unsigned short offset; // Listenelement=Offset in der Struktur               
                           // Bitfeld =Offset von 0x20   
                           // SpacedPtr-desc. = Memoryspace
                           // GenericPtr-desc.= Memoryspace 
                           // TYPE-desc. = Kenner ob Struct oder typedefname
                           // Arraydesc = aktuelle Dimension
               
    CTypdesc* pref;    //Zeiger auf referenzierten Typdescr.
                       //Func-desc.=Returntyp 
                       //Arraydesc Zeiger auf Arraydesc der n�chsten Dimension oder Endtyp
                 
    CTypdesc* ptag;    //Struct desc.= Verweis auf tagname
                       //Function desc = Verweis auf Parameterliste 
                       //GenericPtr-desc.= Typ worauf der Zeiger zeigt
                       
    CPtrList* pmem;    //List-desc.= Liste der Typdesc.der Elemente               
                       //Func-desc.Parametertyp/Liste
                 
              
};

#endif  //_TYPEDESC