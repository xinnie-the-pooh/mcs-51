// TraceView.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "TraceView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTraceView

CTraceView::CTraceView()
{
}

CTraceView::~CTraceView()
{
}


BEGIN_MESSAGE_MAP(CTraceView, CMRCSizeDialogBar)
	//{{AFX_MSG_MAP(CTraceView)
	ON_WM_SIZE()	  
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CTraceView message handlers
#define CBRS_ALIGN_TRACEWND  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT | CBRS_ALIGN_BOTTOM


BOOL CTraceView::Create(CWnd* pParent,BOOL visible)
{
RECT rc;
ULONG reditstyle;

  //::DeleteFile("temptrace.log");
  BOOL b = CMRCSizeDialogBar::Create(pParent, IDD_TRACEVIEW
		        ,CBRS_ALIGN_TRACEWND|CBRS_SIZE_DYNAMIC
				,IDD_TRACEVIEW);

  if(!visible)
     ModifyStyle(WS_VISIBLE,0,SWP_NOACTIVATE);
  Created=b;
	if(b)
  {
    GetClientRect(&rc);   
    GetDlgItem(IDC_STATIC2)->ModifyStyle(WS_VISIBLE,0,FALSE);
    theApp.h_rdll=LoadLibrary("RICHED32.DLL");
    reditstyle=  ES_AUTOVSCROLL|ES_AUTOHSCROLL|ES_MULTILINE|ES_WANTRETURN
                |ES_READONLY|WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL;        
    redit.CreateEx(
                   WS_EX_DLGMODALFRAME|WS_EX_CLIENTEDGE,
                   "RichEdit",
                   NULL,
                   reditstyle,
                   rc.left,rc.top,
                   rc.right-rc.left,rc.bottom-rc.top,                  
                   GetSafeHwnd(),
                   NULL,
                   NULL);     
    lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier");
    redit.SetFont(&lfont,TRUE);
    redit.SetReadOnly(TRUE);
	  SetBarStyle( GetBarStyle()			         
							 | CBRS_FLYBY 							 
							 | CBRS_BORDER_ANY 
							 | CBRS_BORDER_3D );	
    SetWindowText(_T("Trace Viewer"));
    EnableDocking(CBRS_ALIGN_TRACEWND);	
    RECT rd;
	  GetDesktopWindow()->GetWindowRect(&rd);
	 	CPoint pt;
	  pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;
    m_FloatingPosition=pt;	    
  }   
  return(b);   
}

void CTraceView::OnSize(UINT nType, int cx, int cy) 
{
RECT rc,re;

	CMRCSizeDialogBar::OnSize(nType, cx, cy);
  if(Created)
  {	   
    GetWindowRect(&rc);
    if(!IsFloating())
    {
      re.top=rc.top+16;
      GetDlgItem(IDC_STATIC2)->ModifyStyle(0,WS_VISIBLE,FALSE);
    }
    else
    {
      re.top=rc.top;
      GetDlgItem(IDC_STATIC2)->ModifyStyle(WS_VISIBLE,0,FALSE);
    }
	  re.left=rc.left;
    re.right=rc.right;
    re.bottom=rc.bottom;  
    ScreenToClient(&re);  	      
    redit.MoveWindow(&re,TRUE);	
  }
}

void CTraceView::ReadTraceFile()
{
CFile tracefile;
unsigned char rec[1000];
char txt[500];
char txt1[200];
ULONG readlen;
CString fmt;
ULONG addr;
int i;
BYTE rectyp;
USHORT reclen;
CHARFORMAT cv;  
PARAFORMAT cp;  
    
  CWaitCursor wait;	// display wait cursor

  redit.SetSel(0,-1);
  redit.ReplaceSel(""); 
  redit.ModifyStyle(0,WS_VISIBLE);
  cp.cbSize=sizeof(PARAFORMAT);
  cp.dwMask=PFM_TABSTOPS;
  cp.cTabCount=3;
  cp.rgxTabs[0]=600;
  cp.rgxTabs[1]=1300;
  cp.rgxTabs[2]=3000;
  redit.SetParaFormat(cp);

  cp.cbSize=sizeof(CHARFORMAT);
  cv.dwMask=CFM_COLOR;
  redit.SetWindowText("");
  if(!tracefile.Open("temptrace.log",CFile::modeRead))
    return;
  redit.SetRedraw(FALSE);    
  switch(prc->GetMemSize(0))
  {
    case S8:  fmt="%2.2X\t";
              break;
    case S16: fmt="%4.4X\t";
              break;
    case S32: fmt="%8.8X\t";
              break;
  }     
  i=0;
  do
  {
    //redit.SetSel(0,0);
    readlen=tracefile.Read(&rectyp,1);
    if(!readlen)
      break;
    readlen=tracefile.Read(&reclen,2);
    if(!readlen)
      break;
    if(rectyp==TRACE_ASM)
    {
      readlen=tracefile.Read(rec,17);
      if(!readlen)
        break;
      sprintf(txt1,"%d\t",i);
      i++;
      cv.crTextColor=0xC0C0C0;
      redit.SetSelectionCharFormat(cv);
      redit.ReplaceSel(txt1);
      addr=rec[0]*256 + rec[1];     
      sprintf(txt1,LPCSTR(fmt),addr);
      cv.crTextColor=0x000000;
      redit.SetSelectionCharFormat(cv);
      redit.ReplaceSel(txt1); 
      prc->Reassemble(addr,txt1);
      cv.crTextColor=0xFF0000;
      redit.SetSelectionCharFormat(cv);
      redit.ReplaceSel(txt1);
    //PC- PSW- A- R0..R7- B- DPH- DPL- P2- SP
      cv.crTextColor=0x0;
      redit.SetSelectionCharFormat(cv);
      sprintf(txt,"\tPSW=%2.2X,A=%2.2X,R0..R7=%2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X B=%2.2X,DPTR %2.2X.%2.2X,P2=%2.2X,SP=%2.2X\n"
                 ,rec[2],rec[3],rec[4],rec[5],rec[6],rec[7],rec[8],rec[9],rec[10],rec[11],rec[12],rec[13],rec[14],rec[15],rec[16]);  
      redit.ReplaceSel(txt);
    }
    else if(rectyp==TRACE_WATCH)
    {
      if(reclen>sizeof(rec))       
        readlen=tracefile.Read(rec,sizeof(rec));
      else
        readlen=tracefile.Read(rec,reclen);
      if(!readlen)
        break;
      rec[readlen]=0; //mit null abschlie�en
      sprintf(txt1,"%d\n",i);
      i++;
      cv.crTextColor=0xC0C0C0;
      redit.SetSelectionCharFormat(cv);
      redit.ReplaceSel(txt1);  
      cv.crTextColor=0xFF0000;
      redit.SetSelectionCharFormat(cv);
      redit.ReplaceSel((char*)rec);
    }    
  } while(readlen);
    
  redit.SetRedraw(TRUE);
  redit.Invalidate();  
}


