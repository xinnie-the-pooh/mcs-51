// ChangeTyp.cpp : implementation file
//

#include "stdafx.h"
#include "jstep.h"
#include "ChangeTyp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChangeTyp dialog


CChangeTyp::CChangeTyp(CWnd* pParent /*=NULL*/)
	: CDialog(CChangeTyp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChangeTyp)
	//}}AFX_DATA_INIT   
}


void CChangeTyp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChangeTyp)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChangeTyp, CDialog)
	//{{AFX_MSG_MAP(CChangeTyp)
	ON_BN_CLICKED(IDR_CODE, OnCode)
	ON_BN_CLICKED(IDR_DATA, OnData)	
	ON_BN_CLICKED(IDR_IDATA, OnIdata)
	ON_BN_CLICKED(IDR_PDATA, OnPdata)
	ON_BN_CLICKED(IDR_XDATA, OnXdata)
	ON_BN_CLICKED(IDC_POINTER, OnPointer)
	ON_BN_CLICKED(ID_DELETEWATCH, OnDeletewatch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChangeTyp message handlers

void CChangeTyp::OnCode() 
{
	// TODO: Add your control notification handler code here
	
}

void CChangeTyp::OnData() 
{
	// TODO: Add your control notification handler code here
	
}


void CChangeTyp::OnIdata() 
{
	// TODO: Add your control notification handler code here
	
}

void CChangeTyp::OnPdata() 
{
	// TODO: Add your control notification handler code here
	
}


void CChangeTyp::OnXdata() 
{
	// TODO: Add your control notification handler code here
	
}

void CChangeTyp::OnOK() 
{
  if(((CButton*)GetDlgItem(IDR_SCHAR))->GetCheck())
     acttyp=T_SCHAR;
  else if(((CButton*)GetDlgItem(IDR_UCHAR))->GetCheck())
     acttyp=T_UCHAR;
  else if(((CButton*)GetDlgItem(IDR_SSHORT))->GetCheck())
     acttyp=T_SINT;
	else if(((CButton*)GetDlgItem(IDR_USHORT))->GetCheck())
     acttyp=T_UINT;
  else if(((CButton*)GetDlgItem(IDR_SLONG))->GetCheck())
     acttyp=T_SLONG;
	else if(((CButton*)GetDlgItem(IDR_ULONG))->GetCheck())
     acttyp=T_ULONG;
  else if(((CButton*)GetDlgItem(IDR_FLOAT))->GetCheck())
     acttyp=T_FLOATL;
  else
     acttyp=0;
  if(((CButton*)GetDlgItem(IDC_POINTER))->GetCheck())
  {
    if(((CButton*)GetDlgItem(IDR_CODE))->GetCheck())
      acttyp |= MS_CODE <<8;
    else if(((CButton*)GetDlgItem(IDR_XDATA))->GetCheck())
      acttyp |= MS_XDATA <<8;
    else if(((CButton*)GetDlgItem(IDR_DATA))->GetCheck())
      acttyp |= MS_DATA <<8;
    else if(((CButton*)GetDlgItem(IDR_IDATA))->GetCheck())
      acttyp |= MS_IDATA <<8;
    else if(((CButton*)GetDlgItem(IDR_PDATA))->GetCheck())
      acttyp |= MS_PDATA <<8;
  }
  EndDialog(acttyp);
}

void CChangeTyp::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

void CChangeTyp::OnPointer() 
{	
	if(((CButton*)GetDlgItem(IDC_POINTER))->GetCheck())
  {
    ((CButton*)GetDlgItem(IDR_CODE))->SetCheck(TRUE);
    GetDlgItem(IDR_CODE)->EnableWindow(TRUE);
    GetDlgItem(IDR_XDATA)->EnableWindow(TRUE);
    GetDlgItem(IDR_DATA)->EnableWindow(TRUE);
    GetDlgItem(IDR_IDATA)->EnableWindow(TRUE);
    GetDlgItem(IDR_PDATA)->EnableWindow(TRUE);
  }
  else
  {
    GetDlgItem(IDR_CODE)->EnableWindow(FALSE);
    GetDlgItem(IDR_XDATA)->EnableWindow(FALSE);
    GetDlgItem(IDR_DATA)->EnableWindow(FALSE);
    GetDlgItem(IDR_IDATA)->EnableWindow(FALSE);
    GetDlgItem(IDR_PDATA)->EnableWindow(FALSE);
    ((CButton*)GetDlgItem(IDR_CODE))->SetCheck(FALSE);
    ((CButton*)GetDlgItem(IDR_XDATA))->SetCheck(FALSE);
    ((CButton*)GetDlgItem(IDR_DATA))->SetCheck(FALSE);
    ((CButton*)GetDlgItem(IDR_IDATA))->SetCheck(FALSE);
    ((CButton*)GetDlgItem(IDR_PDATA))->SetCheck(FALSE);
  }
}

BOOL CChangeTyp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	switch(acttyp &0xFF)
  {
    case T_SCHAR: ((CButton*)GetDlgItem(IDR_SCHAR))->SetCheck(TRUE);
                  break;
    case T_UCHAR: ((CButton*)GetDlgItem(IDR_UCHAR))->SetCheck(TRUE);
                  break;
    case T_SINT:  ((CButton*)GetDlgItem(IDR_SSHORT))->SetCheck(TRUE);
                  break;
    case T_UINT:  ((CButton*)GetDlgItem(IDR_USHORT))->SetCheck(TRUE);
                  break;
    case T_SLONG: ((CButton*)GetDlgItem(IDR_SLONG))->SetCheck(TRUE);
                  break;
    case T_ULONG: ((CButton*)GetDlgItem(IDR_ULONG))->SetCheck(TRUE);
                  break;
    case T_FLOATL: ((CButton*)GetDlgItem(IDR_FLOAT))->SetCheck(TRUE);
                  break;
  }
  if(acttyp & 0xFF00)
  {
    ((CButton*)GetDlgItem(IDC_POINTER))->SetCheck(TRUE);
    GetDlgItem(IDR_CODE)->EnableWindow(TRUE);
    GetDlgItem(IDR_XDATA)->EnableWindow(TRUE);
    GetDlgItem(IDR_DATA)->EnableWindow(TRUE);
    GetDlgItem(IDR_IDATA)->EnableWindow(TRUE);
    GetDlgItem(IDR_PDATA)->EnableWindow(TRUE);
    switch(acttyp >> 8)
    {
      case MS_IDATA: ((CButton*)GetDlgItem(IDR_IDATA))->SetCheck(TRUE);
                     break; 
      case MS_XDATA: ((CButton*)GetDlgItem(IDR_XDATA))->SetCheck(TRUE);
                     break; 
      case MS_PDATA: ((CButton*)GetDlgItem(IDR_PDATA))->SetCheck(TRUE);
                     break; 
      case MS_DATA:  ((CButton*)GetDlgItem(IDR_DATA))->SetCheck(TRUE);
                     break; 
      case MS_CODE:  ((CButton*)GetDlgItem(IDR_CODE))->SetCheck(TRUE);
                     break; 
    }
  }
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CChangeTyp::OnDeletewatch() 
{
  EndDialog(0x80000000);
}
