// McfgLst.h : header file
//

#ifndef _MCFGLST
#define _MCFGLST 
/////////////////////////////////////////////////////////////////////////////
// CMcfgLst window

class CMcfgLst : public CListCtrl
{
// Construction
public:
	BOOL DeleteColumn(int nCol);
	int InsertColumn(int nCol, const LV_COLUMN* pColumn);
    void MoveEdit(int row,int col,BOOL redraw=TRUE);
	CEditNotify edit;
	void Create();
	CMcfgLst();  
// Attributes
public:

// Operations
public:
  
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMcfgLst)
	protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMcfgLst();

	// Generated message map functions
protected:
	BOOL IsLineEmpty(int item);	
	int cols;
  void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
  GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc);
	int fwidth;
	CFont lfont;
	CPen bkpen;
	//{{AFX_MSG(CMcfgLst)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
    afx_msg long OnEditReturn(UINT wparam, LONG lparam);
    afx_msg long OnEditTab(UINT wparam, LONG lparam); 
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_MCFGLST
/////////////////////////////////////////////////////////////////////////////
