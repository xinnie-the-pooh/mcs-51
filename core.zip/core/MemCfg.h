// MemCfg.h : header file
//
#include "mcfglst.h"
/////////////////////////////////////////////////////////////////////////////
// CMemCfg dialog

class CMemCfg : public CDialog
{
// Construction
public:
	void OnOK();  

	CMemCfg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMemCfg)
	enum { IDD = IDD_MEMCFG };
	CMcfgLst	mcfglist;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemCfg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:  

	void UpdateMemcfg();
	// Generated message map functions
	//{{AFX_MSG(CMemCfg)
	virtual BOOL OnInitDialog();
	afx_msg void OnMok();
	afx_msg void OnDefaultmem();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
