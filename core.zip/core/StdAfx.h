// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT

#include <afxcmn.h>			// MFC support for Windows Common Controls
#include <afxcview.h>

#endif // _AFX_NO_AFXCMN_SUPPORT

#define _AFX_NO_OCC_SUPPORT
#define _MRCEXT_NOFORCELIBS

//#define MRCEXT_EXT_CLASS	AFX_CLASS_EXPORT	// classes will be EXPORTED

#include "afxpriv.h"
#include "mrcext.h"
#include "afxtempl.h"

#include "globals.h"