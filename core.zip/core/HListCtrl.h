// HListCtrl.h : header file
//
#ifndef _HLISTCTRL
#define _HLISTCTRL

/////////////////////////////////////////////////////////////////////////////
// CHListCtrl window
#include "EditNotify.h"
#include "typdesc.h"
#include "parser.h"

//Indizes der Bitmaps im Watchfenster

#define B_EMPTY    0
#define B_HORZLINE 1
#define B_LINE     2
#define B_SUBLINE  3
#define B_LINEEND  4
#define B_SUBOPEN  5
#define B_SUBROOT  6
#define B_SUB      7
#define B_ROOT     8
#define B_ERROR    9


//viewmodes
#define V_DEZ 1
#define V_HEX 2
#define V_BIN 4

typedef struct
{
  int level;
  int last;
  void* pparent;
  int image;
  CString subname;
  op_t wtyp;
  BOOL editable[2];
  BOOL changed;
  BOOL IsAddr;
  int  vtyp;
} item_t;

//globale Funktion
void GetWatchValString(char* txt, eval_t* eval,int txtlen,int viewmode);

class CHListCtrl : public CListCtrl
{

// Construction
public:
	BOOL ContextEn;
	BOOL AddWatchExpression(CString& expression,BOOL openSubStruct=FALSE,CModDef* pm=0,CProcDef* pp=0,int vmode=V_HEX);
	BOOL obext;
	void SetUCase(BOOL ucase);
  //void GetWatchValString(char* txt, eval_t* eval,int txtlen);
  void FollowPointer(int item, item_t* pi);
	void UpdateWatchWnd(BOOL checkChanges=TRUE);
	void OpenStruct(int item, item_t* pi);
	void CloseTree(int item, item_t* pi);
	void OpenArray(int item, item_t* pi,int dimension=0);
	CPen bkpen;	
	BOOL DeleteItem(int iItem);	
	void Create();
	CHListCtrl();
  

// Attributes
public:
  CEditNotify edit;

protected:
	int delItem;
	BOOL UpdateWatch(int item,BOOL checkChanges=TRUE);	
	int viewmode;
	BOOL GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc);
	int fwidth;  
  CFont lfont;
  CImageList imageList;
  int AddWatch(LPCSTR txt,int item=-1);
// Operations
public:

protected:
  void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHListCtrl)
	protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CHListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CHListCtrl)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
  afx_msg long OnEditReturn(UINT wparam, LONG lparam); 
	afx_msg void OnDestroy();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnDez();
  afx_msg void OnHex();
  afx_msg void OnBin(); 
  afx_msg void OnFloat();
  afx_msg void OnDock();   
  afx_msg void OnDelWatch();
  afx_msg void OnChangeWatch();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_HLISTCTRL
/////////////////////////////////////////////////////////////////////////////
