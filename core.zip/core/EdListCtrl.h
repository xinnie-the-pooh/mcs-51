// EdListCtrl.h : header file
//
#ifndef _EDLSTCTRL
#define _EDLSTCTRL

#include "EditNotify.h"

/////////////////////////////////////////////////////////////////////////////
// CEdListCtrl window
 

class CEdListCtrl : public CListCtrl
{
friend class CRegWnd;
// Construction
public:	
	int lastsel;
	void UpdateList();	
	void RedrawItemUnsel(int item, CDC* pDC);
	void Create();
	
	CEdListCtrl();

// Attributes
public:


protected:
	BOOL CheckValid(int item, CString& txt);
	int selitem;
	virtual void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
	BOOL GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc);
	CEditNotify edit;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEdListCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEdListCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEdListCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);	
  afx_msg long ProcessChanges(UINT wparam, LONG lparam);  
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	void SetItemValText(int regindex);
};

#endif //_EDLSTCTRL
/////////////////////////////////////////////////////////////////////////////
