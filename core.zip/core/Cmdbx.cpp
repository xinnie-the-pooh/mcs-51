// searchbx.cpp : implementation file
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1995 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "JSTEPDoc.h"
#include "cmdbx.h"
#include "dbgbar.h"
#include "RegWnd.h"
#include "MainFrm.h"



#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCmdBox

CCmdBox::~CCmdBox()
{
}

BEGIN_MESSAGE_MAP(CCmdBox, CComboBox)
	//{{AFX_MSG_MAP(CCmdBox)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCmdBox message handlers

BOOL CCmdBox::PreTranslateMessage(MSG* pMsg)
{
	if ((pMsg->message != WM_KEYDOWN) || (pMsg->wParam != VK_RETURN))
		return CComboBox::PreTranslateMessage(pMsg);

	// when the enter key is hit in the ComboBox we want to add the string
	// to the top of the list and hilight it.  We also want to limit the
	// list to the last 15 entries.

	if ((pMsg->lParam & 0x40000000) == 0)   // Not a repeat.
	{
	  CString strText;
	  GetWindowText(strText);
    if(strText.Left(3) != "***") // Fehlermeldungen werden nat�rlich nicht mit �bernommen
    { 
      int i= FindStringExact(0,strText);
      if(i==CB_ERR)
      {
	      InsertString(0, strText);			
	      if (GetCount() > 15)
	        DeleteString(GetCount()-1);
      }
    }
  }
  ((CMainFrame*)(AfxGetMainWnd()))->pDoc->OnSetCmd();
  return TRUE;
}
