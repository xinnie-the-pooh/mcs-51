// TPEdit.h : header file
//
#ifndef _TPEDIT
#define _TPEDIT

#include "tplist.h"
/////////////////////////////////////////////////////////////////////////////
// CTPEdit dialog

class CTPEdit : public CDialog
{
// Construction
public:
	CTPEdit(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTPEdit)
	enum { IDD = IDD_TRACEPOINT };
  CTPList tplist;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
  

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTPEdit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//CTPList tplist;
  
	// Generated message map functions
	//{{AFX_MSG(CTPEdit)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDelete();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif _TPEDIT