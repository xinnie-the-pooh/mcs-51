// ChangeTyp.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChangeTyp dialog

class CChangeTyp : public CDialog
{
// Construction
public:
	int acttyp;
	CChangeTyp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChangeTyp)
	enum { IDD = IDD_TYPEDEF };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChangeTyp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChangeTyp)
	afx_msg void OnCode();
	afx_msg void OnData();	
	afx_msg void OnIdata();
	afx_msg void OnPdata();
	afx_msg void OnXdata();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnPointer();
	virtual BOOL OnInitDialog();
	afx_msg void OnDeletewatch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
