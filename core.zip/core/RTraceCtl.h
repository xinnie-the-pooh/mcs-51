// RTraceCtl.h : header file
//
#ifndef _RTRACECTRL
#define _RTRACECTRL
/////////////////////////////////////////////////////////////////////////////
// CRTraceCtl window

class CRTraceCtl : public CRichEditCtrl
{
// Construction
public:
	CRTraceCtl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRTraceCtl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CRTraceCtl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CRTraceCtl)
	afx_msg void OnPaint();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
  afx_msg void OnFloat();
  afx_msg void OnDock();
  afx_msg void OnClear();
  afx_msg void OnReload();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_RTRACECTRL
/////////////////////////////////////////////////////////////////////////////
