#include "stdafx.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "Jstep.h"
#include "browswnd.h"
#include "mainfrm.h"
#include "globals.h"
#include <io.h>

extern CJSTEPApp theApp;



/////////////////////////////////////////////////////////////////////////////
// CMeasurePoint


CMeasurePoint::CMeasurePoint()
{
  addr=0;
  isValid=FALSE;
  enabled=FALSE;
  measures=0;
  cycles=0;
  MinCycles=0xFFFFFFFF;
  MaxCycles=0;
  item=-1;
  pv=0;
}

void CMeasurePoint::SetMeasurePoint(ULONG addr)
{
  CMeasurePoint::addr=addr;
  MinCycles=0xFFFFFFFF;
  MaxCycles=0;
  measures=0;
  cycles=0;
  if(enabled)
    prc->SetMeasurePoint(this);
  else
    prc->SetMeasurePoint(0);
}

void CMeasurePoint::ResetMeasure()
{
  MinCycles=0xFFFFFFFF;
  MaxCycles=0;
  measures=0;
  cycles=0;
}


// Implementierung der Klasse CObjInfo
// Funktionen zum Einlesen des OMF-51 Absolutfiles
// gibt den n�chsten Record zur�ck
/////////////////////////////////////////////////////////////////////////////
// CObjInfo
UCHAR* CObjInfo::GetSRec(CFile* fp,BYTE* rec)
{
  BYTE len,c;
  USHORT readlen;
  BYTE* hp;
  int r;
  int chk;

  r=fp->Read(rec,4);
  if(r!=4)
    return(0);
  if(rec[0]!='S') //so muss ein Record immer beginnen
    return 0;
  rec[4]=0;
  len=(BYTE)strtoul((char*)&rec[2],0,16);    //L�nge des Records
  rec[2]=len;
  readlen=(USHORT)fp->Read(&rec[4],(USHORT)(len*2+3)); //den ganzen Record lesen einschl CR+CR/LF
  if(rec[4+len*2+2] != 0x0A) //doch nur einfach CR/LF
    fp->Seek(-1,CFile::current);
  if(readlen!=len*2+3)
    return(0);  //konnte nicht die richtige Zeichenzahl lesen
  else
  {
    readlen-=3;
    hp=&rec[3];
    for(r=4; r<readlen+4;r+=2)
    {
      if(rec[r] > 0x39)
        c=(UCHAR)((rec[r] -0x37)<<4);
      else
        c=(UCHAR)((rec[r] -0x30)<<4);
      if(rec[r+1] > 0x39)
        c|=rec[r+1] -0x37;
      else
        c|=rec[r+1] -0x30;
      *hp=c;
      hp++;
    }
    hp=&rec[2];
    chk=0;     //Checksumme
    while(len--)
      chk+=*hp++;
    if((chk&0xFF) != ((~*hp)&0xFF) )
      return 0;
    return rec;
  }
}



UCHAR* CObjInfo::GetHexRec(CFile* fp,BYTE* rec,int bDos)
{
  BYTE len;
  USHORT readlen;
  BYTE* hp;
  int r;
  BYTE c;


  r=fp->Read(rec,3);
  if(r!=3)
    return(0);
  rec[3]=0;
  len=(BYTE)strtoul((char*)&rec[1],0,16);
  if(!len)
    return 0;
  rec[1]=len;
  readlen=(USHORT)fp->Read(&rec[2],(USHORT)(len*2+10+bDos));
  if(readlen!=len*2+10+bDos)
    return(0);
  else
  {
    readlen-=2;
    hp=&rec[2];
    for(r=2; r<readlen;r+=2)
    {
      if(rec[r] > 0x39)
        c=(UCHAR)((rec[r] -0x37)<<4);
      else
        c=(UCHAR)((rec[r] -0x30)<<4);
      if(rec[r+1] > 0x39)
        c|=rec[r+1] -0x37;
      else
        c|=rec[r+1] -0x30;
      *hp=c;
      hp++;
    }
  }
  return(rec);
}

UCHAR* CObjInfo::GetRec(CFile* fp)
{
  USHORT len;
  BYTE rectyp;
  USHORT readlen;
  int r;
  int chk;
  BYTE* hp;


  r=fp->Read(&rectyp,1);
  if(!r)
    return(0);
  fp->Read(&len,2);
  fp->Seek(-3,CFile::current);
  readlen=(USHORT)fp->Read(prec,(USHORT)(len+3));
  if(readlen!=len+3)
    return(0);
  chk=prec[readlen-1];
  hp=prec;
  readlen--;
  while(readlen--)
  {
    chk+=*hp++;
  }

  if(!(chk & 0xFF))
    return(prec);
  else
    return (UCHAR*)-1;
}


int CObjInfo::AddModuleInfo( LPCSTR modname, LPCSTR modpath)
{
  CBrowsWnd* pb;

  CModDef* newmod=new CModDef(modname,modpath);
  newmod->ModID=moduls.Add((void*)newmod);
  pb= &((CMainFrame*)AfxGetMainWnd())->m_browsWnd;
  pb->InsertModule(newmod);
  return(newmod->ModID);
}

CObjInfo::CObjInfo()
{
  ObExt=TRUE;
  objLoaded=FALSE;
  prec=new unsigned char[0x10000];
  tracetyp=0;
  globSrcPath="";
  orderHL=TRUE;  //variablen sind H->L abgelegt ,MSB zuerst (=Keil)
}

CObjInfo::~CObjInfo()
{
  delete prec;
  Clear();
}


int CObjInfo::GetModuleCnt()
{
  return(moduls.GetSize());
}

void CObjInfo::SetModuleName(int index, char* modname)
{
  CModDef* mp=(CModDef*)moduls.GetAt(index);
  if(mp)
    mp->modname=modname;
}

void CObjInfo::Clear()
{
CModDef* mp;
POSITION pos;
CPtrArray* pa;
CWordArray* pwa;
int s;
CString key;
ULONG addr;
CTypdesc* pt;

  int i=moduls.GetSize();
  while(i--)
  {
    mp=(CModDef*)moduls.GetAt(i);
    moduls.RemoveAt(i);
    delete mp;
  }
  moduls.RemoveAll();
  pos=labels.GetStartPosition();
  while(pos)
  {
    labels.GetNextAssoc(pos,key,pa);
    s=pa->GetSize();
    while(s--)
      delete (labeldef_t*)pa->GetAt(s); //alle labels l�schen
    delete pa;  //die Pointerliste l�schen
  }
  labels.RemoveAll();

  pos=a2lbl.GetStartPosition();
  while(pos)
  {
    a2lbl.GetNextAssoc(pos,addr,pa);
    delete pa;  //die Pointerliste l�schen
  }
  a2lbl.RemoveAll();

  pos=a2line.GetStartPosition();
  while(pos)
  {
    a2line.GetNextAssoc(pos,addr,pwa);
    delete pwa;  //die Pointerliste l�schen
  }
  a2line.RemoveAll();

  pos=typelist.GetHeadPosition();
  while(pos)
  {
    pt=(CTypdesc*)typelist.GetNext(pos);
    delete pt;
    //rekursiv alle Unterstrukturen l�schen
  }
  typelist.RemoveAll();
  ObExt=FALSE;
  objLoaded=FALSE;
}

int CObjInfo::AddDbgInfo (ULONG addr, char* label, int valrange,int memspec,int modid,CProcDef* pproc, CTypdesc* ptd)
{

  CPtrArray* pa;
  labeldef_t* pl;
  int n;

  TRACE("new Symbol: %s, %8.8X module: %d, pTyp: %8.8X\n",label,addr,modid,ptd);
  labeldef_t* lbl=new labeldef_t;
  lbl->addr=addr;
  lbl->valrange=valrange+1;
  lbl->memspec=memspec &0x07; //alles �ber dem Speicherspec. ausblenden
  lbl->ModID=modid;
  lbl->label=label;
  lbl->pproc=pproc;
  lbl->pTypdesc=ptd;

  pa=0;
  // Adresse->Labeldescriptor
  if(!a2lbl.Lookup(addr,pa)) //unter der Adresse ist noch kein Label abgelegt
  {
    pa=new CPtrArray;  // neues Array f�r das Label anlegen
    a2lbl.SetAt(addr,pa); // in der Hashtabelle ablegen
    pa->Add(lbl);
  }
  else  //test ob das gleiche Label mehrfach deklariert wurde
  {
    n=pa->GetSize();
    while(n--)
    {
      pl=(labeldef_t*)pa->GetAt(n);
      if(     pl->label==lbl->label
              && (pl->memspec == lbl->memspec)
              && (pl->valrange == lbl->valrange))  //Label wurde schon mal definiert
      {
        if(valrange & PUBSYM)
        {          
          pa->SetAt(n,lbl); //wenn das neue Label Public ist hat es Vorrang und ersetzt das alte
          labels.Lookup(label,pa);
          n=pa->GetSize();
          while(n--)
          {
            pl=(labeldef_t*)pa->GetAt(n);
            if(pl->valrange == lbl->valrange && pl->memspec==lbl->memspec)  //Label wurde schon mal definiert
            {
              pa->SetAt(n,lbl);
              break;
            }
          }
          delete pl;
          return pa->GetSize();
        }
      }
    }
    pa->Add(lbl);
  }
  //Labelname->Labeldescriptor
  if(!labels.Lookup(label,pa)) // ein Label dieses Namens gibts noch nicht
  {
    pa=new CPtrArray;  // neues Array f�r das Label anlegen
    labels.SetAt(label,pa);
  }
  pa->Add(lbl);
  return pa->GetSize();
}

void CObjInfo::AddDbgInfo(ULONG addr, ULONG lineno, int modid)
{
  CWordArray *pa;
  linedef_t *lp;
  int i;


  pa=0;
  if(modid==-1)
    return;
  CModDef* pm=(CModDef*)moduls.GetAt(modid);
  //suche ob es zu der Zeile schon eine Adresse gibt
  i=pm->alines.GetSize();
  while(i--)
  {
    lp=(linedef_t*)pm->alines.GetAt(i);
    if(lp->lineno==lineno)
    {
      if(lp->addr>addr)
        lp->addr=addr;  //die kleinere Adresse speichern
      return;
    }
  }

  if(!a2line.Lookup(addr,pa))
  {
    pa=new CWordArray;
    a2line.SetAt(addr,pa);
  }
  if(pa)
  {
    pa->Add((USHORT)lineno);
    lp=new linedef_t;
    lp->addr=addr;
    lp->lineno=(USHORT)lineno;
    pm->alines.Add(lp);
  }
  if(addr<pm->lowaddr)
    pm->lowaddr=addr;
  if(addr>pm->highaddr)
    pm->highaddr=addr;
}

// suche ob HLL-Module geladen sind
BOOL CObjInfo::IsHLL()
{
  if(a2line.GetCount())
    return(TRUE);
  return(FALSE);
}

//liefert einen Zeiger auf das Modul in der die Adresse am liegt
// oder 0 wenn nicht gefunden
CModDef* CObjInfo::GetModuleFromAddress(ULONG address)
{
  int n,i,j,l;
  CModDef   *mp;
  CProcDef  *pp;
  POSITION pos;
  int lines;
  linedef_t* lp;

  i=0;
  n=moduls.GetSize();
  if(!n)
    return(0);   // es sind gar keine Module geladen
  while(i<n)
  {
    mp=(CModDef*)moduls.GetAt(i++);
    j=0;
    pos=(mp->proclist.GetHeadPosition());
    while(pos)
    {
      pp=(CProcDef*)(mp->proclist.GetNext(pos));
      if(address >= pp->AnfAddr && address <= pp->EndAddr && pp->Procname!="LIB")
        return(mp);
    }

  }

  //kein ordentliches Keil-Format
  i=0;
  n=moduls.GetSize();
  if(!n)
    return(0);   // es sind gar keine Module geladen
  while(i<n)
  {
    mp=(CModDef*)moduls.GetAt(i++);
    j=0;
    //check ob in diesem Modul Zeilennummern auf die Adresse passen
    if(mp->lowaddr==-1 || !mp->highaddr)
    {
      lines=(ULONG)mp->alines.GetSize();
      l=0;
      while(l<lines)
      {
        lp=(linedef_t*)mp->alines.GetAt(l++);
        if(lp->addr<mp->lowaddr)
          mp->lowaddr=lp->addr;
        if(lp->addr>mp->highaddr)
          mp->highaddr=lp->addr;
      }
    }
    if(address >= mp->lowaddr && address <= mp->highaddr)
      return(mp);
  }
  return(0);
}

//sucht zu einem String das passende Label.Der String kann Angaben
//zum Modul und der Prozedur enthalten:  Modulname:Prozedurname:Label
labeldef_t* CObjInfo::FindLabel(CString* plabel)
{
int l,m,n,p;
int modID;
CModDef* pm;
CProcDef* pp;
CString modname;
CString procname;
CString labelname;
CPtrList* pl;
POSITION pos;
labeldef_t* lp;

  pp=0;
  modID=-1;
  lp=0;
  l=plabel->Find(':');
  if(l != -1)    //Modulname oder Prozedurname ist dabei
  {
    modname=plabel->Left(l);
    procname=plabel->Mid(l+1);
    p=procname.Find(':');
    if(p != -1)  //auch der Prozedurname ist angegeben
    {
      labelname=procname.Mid(p+1);
      procname=procname.Left(p);
      modID=FindModuleId(modname,&pm);
      if(!pm)
        return 0;
      pl=&(pm->proclist);
      pos=pl->GetHeadPosition();
      while(pos)
      {
        pp=(CProcDef*)pl->GetNext(pos);
        if(pp->Procname==procname)
        {
          goto w1;
        }
      }
      goto w1;
    }
    else  //nur der Modulname oder aber der Prozedurname ist angegeben
    {
      labelname=plabel->Mid(l+1); //Der Rest kann nur der Name des Labels sein
      modID=FindModuleId(modname,&pm);  // suche erst mal nach einem Modul das so hei�t
      if(modID==-1) // es gibt kein Modul mit dem Namen
      {
        m=0;
        n=moduls.GetSize();
        while(m<n)
        {
          pm=(CModDef*)moduls.GetAt(m++);
          pl=&(pm->proclist);
          pos=pl->GetHeadPosition();
          while(pos)
          {
            pp=(CProcDef*)pl->GetNext(pos);
            if(pp->Procname==modname)
            {
              modID=pm->ModID;
              goto w1;
            }
          }
        }
        goto w1;
      }
      else
      {
        pl=&(pm->proclist);
        pos=pl->GetHeadPosition();
        while(pos)
        {
          pp=(CProcDef*)pl->GetNext(pos);
          if(pp->Procname==modname)
          {
            goto w1;
          }
        }
        goto w1;
      }
    }
    labelname.TrimRight();
    labelname.TrimLeft();
w1:
    lp=FindLabelDesc(labelname,modID,pp);
    return lp;
  }
  lp=FindLabelDesc(*plabel,modID,pp);
  return lp;
}
// sucht ein Labelstring  zu einer Adresse in einem Speicherbereich
BOOL CObjInfo::FindLabel(ULONG addr, CString& lbl,int memspec,int valrange, int precision)
{
  labeldef_t* pl;
  char buffer[10];
  CPtrArray *pa;
  int s;


  pa=0;
  a2lbl.Lookup(addr,pa);
  if(!pa)
    goto f1;
  if(memspec==-1)  //der Speicherbereich ist egal
  {
    pl=(labeldef_t*)pa->GetAt(0);
    lbl=pl->label;  //gefunden
    return TRUE;
  }

  s=pa->GetSize();
  while(s--)
  {
    pl=(labeldef_t*)pa->GetAt(s);
    if(pl->memspec==memspec && pl->valrange&valrange) 
    {
      lbl=pl->label; //gefunden        
      return TRUE;
    }
  }
f1:

  if(!precision)
  {
    switch(prc->GetMemSize())
    {
      case S8:  precision=2;
        break;
      case S16: precision=4;
        break;
      case S32: precision=80;
        break;
      default:  precision=8;
        break;
    }
  }
  switch(precision)  //wenn kein Label gefunden wurde wird einfach der Adressstring zur�ck gegeben
  {

    case 2:
      sprintf(buffer,"%2.2X",addr);
      break;
    case 4:
      sprintf(buffer,"%4.4X",addr);
      break;
    case 80:
      sprintf(buffer,"%8.8X",addr);
      break;
    case 8:
      sprintf(buffer,"%8.4X",addr);
      break;
  }
  lbl=buffer;
  return FALSE;
}

// sucht ein Labelstring  zu einer Adresse in einem Speicherbereich
BOOL CObjInfo::FindLabel(ULONG addr, LPSTR lbl,int memspec,int valrange,int precision)
{
  labeldef_t* pl;
  CPtrArray *pa;
  int s;


  pa=0;
  a2lbl.Lookup(addr,pa);
  if(!pa)
    goto f1;
  if(memspec==-1)  //der Speicherbereich ist egal
  {
    pl=(labeldef_t*)pa->GetAt(0);
    strcpy(lbl,LPCSTR(pl->label));  //gefunden
    return TRUE;
  }
  s=pa->GetSize();
  while(s--)
  {
    pl=(labeldef_t*)pa->GetAt(s);
    if(pl->valrange&valrange && pl->memspec==memspec && pl->pTypdesc!=(CTypdesc*)T_BIT)
    {
      strcpy(lbl,LPCSTR(pl->label)); //gefunden
      return TRUE;
    }
  }
f1:

  if(!precision)
  {
    switch(prc->GetMemSize())
    {
      case S8:  precision=2;
        break;
      case S16: precision=4;
        break;
      case S32: precision=80;
        break;
      default:  precision=8;
        break;
    }
  }
  switch(precision)  //wenn kein Label gefunden wurde wird einfach der Adressstring zur�ck gegeben
  {

    case 2:
      sprintf(lbl,"%2.2X",addr);
      break;
    case 4:
      sprintf(lbl,"%4.4X",addr);
      break;
    case 80:
      sprintf(lbl,"%8.8X",addr);
      break;
    case 8:
      sprintf(lbl,"%8.4X",addr);
      break;
  }
  return FALSE;
}


// sucht ein Bit-Labelstring  zu einer Bitadresse in einem Speicherbereich
BOOL CObjInfo::FindBitLabel(ULONG addr, LPSTR lbl,int memspec,int valrange,int precision)
{
  labeldef_t* pl;
  CPtrArray *pa;
  int s;


  pa=0;
  a2lbl.Lookup(addr,pa);
  if(!pa)
    goto f1;
  if(memspec==-1)  //der Speicherbereich ist egal
  {
    pl=(labeldef_t*)pa->GetAt(0);
    strcpy(lbl,LPCSTR(pl->label));  //gefunden
    return TRUE;
  }
  s=pa->GetSize();
  while(s--)
  {
    pl=(labeldef_t*)pa->GetAt(s);
    if(pl->valrange&valrange && pl->memspec==memspec && pl->pTypdesc==(CTypdesc*)T_BIT)
    {
      strcpy(lbl,LPCSTR(pl->label)); //gefunden
      return TRUE;
    }
  }
f1:

  if(!precision)
  {
    switch(prc->GetMemSize())
    {
      case S8:  precision=2;
        break;
      case S16: precision=4;
        break;
      case S32: precision=80;
        break;
      default:  precision=8;
        break;
    }
  }
  switch(precision)  //wenn kein Label gefunden wurde wird einfach der Adressstring zur�ck gegeben
  {

    case 2:
      sprintf(lbl,"%2.2X",addr);
      break;
    case 4:
      sprintf(lbl,"%4.4X",addr);
      break;
    case 80:
      sprintf(lbl,"%8.8X",addr);
      break;
    case 8:
      sprintf(lbl,"%8.4X",addr);
      break;
  }
  return FALSE;
}

BOOL CObjInfo::IsHLLModule(int modid)
{
  if(modid==-1)
    return FALSE;
  CModDef* mp=(CModDef*)moduls.GetAt(modid);
  if(mp->alines.GetSize())
    return(TRUE);
  return(FALSE);
}

// sucht ein Modul zu einer Adresse die schon als Segmentmarke bekannt sein mu�
CModDef* CObjInfo::GetModuleFromSEGLblAddr(ULONG addr)
{
  int n,i;
  labeldef_t* pl;
  POSITION pos;
  CString seglbl;
  CPtrArray *pa;


  n=labels.GetCount();
  pos=labels.GetStartPosition();
  while(pos)
  {
    labels.GetNextAssoc(pos,seglbl,pa);
    i=pa->GetSize();
    while(i--)
    {
      pl=(labeldef_t*)pa->GetAt(i);
      if(pl->addr==addr && pl->valrange & SEGINFOLBL+PUBSYM)
        return((CModDef*)moduls.GetAt(pl->ModID));
    }
  }
  return((CModDef*)moduls.GetAt(0));  // kein Modul gefunden-> Librarycode
}

//sucht zu einer HLL-Zeile die passende Codeadresse, wenn gefunden=TRUE
BOOL CObjInfo::FindLineAddr(int lineno, int modID, ULONG* lineaddr)
{
  int i;
  linedef_t *lp;
  if(modID==-1)
    return FALSE;
  CModDef* pm=(CModDef*)moduls.GetAt(modID);
  i=pm->alines.GetSize();
  while(i--)
  {
    lp=(linedef_t*)pm->alines.GetAt(i);
    if(lp->lineno==lineno)
    {
      *lineaddr=lp->addr;
      return TRUE;
    }
  }
  *lineaddr=0;
  return FALSE;
}

// sucht zu einem Labelnamen in einem best.Modul die Adresse im Code
BOOL CObjInfo::FindLabelAddr( const CString& lbl, ULONG* addr, int modID, CProcDef* pproc)
{
  int n;
  labeldef_t* pl;
  CPtrArray* pa;

  pa=0;
  if(!labels.Lookup(lbl,pa))
  {
    *addr=0;
    return FALSE; //nicht gefunden
  }
  if(!pa)
    return FALSE;
  n=pa->GetSize();
  while(n--)
  {
    pl=(labeldef_t*)pa->GetAt(n);
    if(modID!= -1 && pl->ModID==modID)  // das modul passt
    {
      if((pproc && pproc==pl->pproc) || !pproc)
      {
        *addr=pl->addr;
        return TRUE;
      }
    }
    else   // das modul ist egal
    {
      if((pproc && pproc==pl->pproc) || !pproc)
      {
        *addr=pl->addr;
        return TRUE;
      }
    }
  }
  return FALSE; //nicht gefunden
}



int CObjInfo::FindModuleId(CString& modname,CModDef** pm)
{
  int n,i;
  CModDef  *mp;

  i=0;
  n=moduls.GetSize();
  if(!n)
    return(-1);   // es sind gar keine Module geladen
  while(i<n)
  {
    mp=(CModDef*)moduls.GetAt(i++);
    if(mp->modname==modname)
    {
      if(pm)
        *pm=mp;
      return(mp->ModID); //Anfangsadresse 0 gefunden
    }
  }
  mp=0;
  return(-1); //nicht gefunden
}

CModDef* CObjInfo::GetLibModule()
{
  return (CModDef*)moduls.GetAt(0);
}


// sucht ab einer bestimmten Adresse nach der n�chsten HLL-Zeile und
// liefert deren Adresse zu�ck
// wenn nicht gefunden ist der Returnwert 0
BOOL CObjInfo::FindNextHLLAddress(ULONG* addr, int modId)
{
  int i,n;
  CModDef *pm;
  linedef_t *lp;

  pm=(CModDef*)moduls.GetAt(modId);
  if( pm->lowaddr <= *addr && pm->highaddr>=*addr )  // liegt im Bereich
  {
    n=pm->alines.GetSize();
    for(i=0;i<n;i++)
    {
      lp=(linedef_t*)pm->alines.GetAt(i);
      if(lp->addr > *addr)
      {
        *addr=lp->addr;
        return TRUE;
      }
    }
  }
  return FALSE;
}

// sucht ab einer bestimmten Adresse nach der letzte  HLL-Zeile und
// liefert deren Adresse zu�ck
// wenn nicht gefunden ist der Returnwert 0
BOOL CObjInfo::FindPrevHLLAddress(ULONG* addr, int modId)
{
  CModDef *pm;
  linedef_t* pl;
  int n,i;
  ULONG lastaddr;

  if(modId==-1)
    pm=GetModuleFromAddress(*addr);
  else
    pm=(CModDef*)moduls.GetAt(modId);
  if(!IsHLLModule(pm->ModID))
    return FALSE;
  n=pm->alines.GetSize()-1;   // von oben nach unten suchen
  lastaddr=0;
  i=0;
  while(i<n)
  {
    pl=(linedef_t*)pm->alines.GetAt(i);
    if(pl->addr >= *addr && lastaddr <=pl->addr)
    {
      *addr=lastaddr;
      return TRUE;
    }
    i++;
    lastaddr=pl->addr;
  }
  return FALSE;
}


//testet ob sich an der Adresse eine HLL-Zeile befindet
BOOL CObjInfo::IsHLLLine(ULONG addr)
{
  CWordArray *pa;

  if(a2line.Lookup(addr,pa))
    return TRUE;
  return FALSE;
}

// liefert den Zeiger auf die Prozedurdefinitionsstruktur mit einem best Namen
CProcDef* CObjInfo::FindProc(CString& pname,CModDef* pmod)
{
  CProcDef  *pp;
  POSITION pos;
  int n,i;

  if(!pmod)
  {
    i=0;
    n=moduls.GetSize();
    while(i<n)
    {
      pmod=(CModDef*)moduls.GetAt(i++);
      pos=pmod->proclist.GetHeadPosition();
      while(pos)
      {
        pp=(CProcDef*)(pmod->proclist.GetNext(pos));
        if(pname == pp->Procname)
          return(pp);
      }

    }
    return(0);
  }
  else
  {
    pos=(pmod->proclist.GetHeadPosition());
    while(pos)
    {
      pp=(CProcDef*)(pmod->proclist.GetNext(pos));
      if(pname == pp->Procname)
        return(pp);
    }

    return(0);
  }
}


// liefert den Zeiger auf die Prozedurdefinitionsstruktur zu einer
// bestimmten Adresse und einem bestimmten Modul (wenn vorhanden)
CProcDef* CObjInfo::GetProcFromAddr( ULONG addr, CModDef* pmod)
{
  CProcDef  *pp;
  POSITION pos;

  if(!pmod)
    pmod=GetModuleFromAddress(addr);
  if(!pmod)
    return 0;
  pos=(pmod->proclist.GetHeadPosition());
  while(pos)
  {
    pp=(CProcDef*)(pmod->proclist.GetNext(pos));
    if(pp->AnfAddr!=-1 && pp->EndAddr)
    {
      if(addr >= pp->AnfAddr && addr <= pp->EndAddr)
        return(pp);
    }
    else
    {
      if(addr == pmod->GetLowAddr() && addr < pmod->GetHighAddr())
        return(pp);
    }
  }
  return(0);
}

// sucht zu einem Labelnamen in einem best.Modul den Label-Descriptor
labeldef_t* CObjInfo::FindLabelDesc(const CString& lbl,int modID,CProcDef* pp)
{
  int n;
  labeldef_t* pl;
  CPtrArray* pa;

  pa=0;
  if(!labels.Lookup(lbl,pa))
    return NULL; //nicht gefunden
  if(!pa)
    return 0;
  if(modID==-1 && !pp)
    return (labeldef_t*)pa->GetAt(0);  //das erste gefundene
  if(modID && !pp)
  {
    n=pa->GetSize();
    while(n--)
    {
      pl=(labeldef_t*)pa->GetAt(n);
      if(pl->ModID == modID)
        return pl;
    }
    return NULL ; //nicht gefunden
  }
  else if(!modID && pp)
  {
    n=pa->GetSize();
    while(n--)
    {
      pl=(labeldef_t*)pa->GetAt(n);
      if(pl->pproc == pp)
        return pl;
    }
    return NULL;  //nicht gefunden
  }
  else
  {
    n=pa->GetSize();
    while(n--)
    {
      pl=(labeldef_t*)pa->GetAt(n);
      if(pl->pproc == pp && pl->ModID == modID)
        return pl;
      else if(!pl->pproc && pp->AnfAddr==-1 && !pp->EndAddr)
        return pl;
    }
    return NULL;  //nicht gefunden
  }
}

int CObjInfo::ParseObjFile(LPCSTR filename)
{
  BYTE* bp;
  BYTE* sp;
  BYTE* hp;
  BYTE  rectype;
  UINT  recno;
  long  reclen;
  USHORT addr;
  int actmodule;
  int lineno;
  int deftyp;
  UCHAR* cp;
  char buffer1[50];
  CModDef* mp;
  CFile absfile;
  CString procname,lastlabel;
  CProcDef *pp,*libp;
  CTypdesc* ptd;
  POSITION pos;
  int typidx;
  ULONG progstate;
  CProgressCtrl* pb;
  CFileStatus fs;
  BOOL mObExt;
  int lastWasASMmodule;
  CString mtxt;
  CString ctxt;
  CString srcpath;

  lastlabel="";
  lastWasASMmodule=0;
  pp=0;
  libp=0;
  mObExt=FALSE;
  progstate=0;
  ObExt=FALSE;
  actmodule=-1;
  if(!absfile.Open(filename,CFile::modeRead))
  {
    return(-1);
  }
  srcpath=filename;
  reclen=srcpath.ReverseFind('\\');
  if(reclen != -1)
    srcpath=srcpath.Left(reclen+1);
  pb=&((CMainFrame*)AfxGetMainWnd())->m_progress;
  pb->SetRange(0,(USHORT)absfile.GetLength());

  AddModuleInfo("LIBRARY");
  TRACE("LIBRARY-MODULE erzeugt\n");

  recno=0;
  do
  {
    bp=GetRec(&absfile);
    if((int)bp==-1)
      return 0;
    else if(!bp)
      break;
    progstate+=bp[1]+256*bp[2]+3;//Typ, L�nge und SegmentID weg
    pb->SetPos(progstate);
    hp=bp;
    recno++;
    rectype=bp[0];
    switch(rectype)
    {
      case REC_CODE:
        bp++;
        reclen=(*(USHORT*)bp)-4; //L�nge und SegmentID weg
        bp+=3;
        addr=*(USHORT*)bp;
        if(actmodule !=-1 && pp) //Modul und Prozedur ge�ffnet
        {
          mp=(CModDef*)moduls.GetAt(actmodule);
          mp->SetAnfAddr(pp,addr);
          mp->SetEndAddr(pp,addr+reclen-1);
          TRACE("CODE in ge�ffnetem Modul %4.4X-%4.4X gelesen\n",addr,addr+reclen);
          lastWasASMmodule=FALSE;
        }
        else    // Code ohne Debuginfo= LIBRARY
        {
          if(actmodule==-1)   // kein Modul ge�ffnet
          {

            if(lastlabel == "" && !lastWasASMmodule)
            {
              mp=(CModDef*)moduls.GetAt(0);
              libp=mp->AddProc("LIB",addr,addr+reclen-1);  //f�gt zum Libmodule als blanken Code hinzu
              lastlabel="";
              TRACE("Librarycode %4.4X-%4.4X gelesen\n",addr,addr+reclen);
            }
            else if(lastlabel!="" && !lastWasASMmodule)
            {
              mp=(CModDef*)moduls.GetAt(0);
              libp=mp->AddProc(lastlabel,addr,addr+reclen-1,mp);  //f�gt zum Libmodule als Funktion hinzu
              TRACE("Librarycode %4.4X-%4.4X gelesen\n",addr,addr+reclen);
            }
            else
            {
              mp=(CModDef*)moduls.GetAt(lastWasASMmodule);  // f�gt zu letzten ge�ffneten Modul hinzu
              mp->AddProc("LIB",addr,addr+reclen-1);
              TRACE("Assemblercode %4.4X-%4.4X gelesen\n",addr,addr+reclen);
            }
          }
          else
          {

            mp=GetModuleFromSEGLblAddr(addr);  //sucht �ber die Adresse eines SegmentLabels das Modul
            // Modul ge�ffnet aber keine Prozedur
            if(lastlabel!="")
            {
              libp=mp->AddProc(lastlabel,addr,addr+reclen-1,mp);
              lastlabel="";
            }
            else
              libp=mp->AddProc("CONST",addr,addr+reclen-1);
            TRACE("Konstanten %4.4X-%4.4X gelesen\n",addr,addr+reclen);
          }
        }
        bp+=2;                   //Anfang Code
        prc->WriteMemBlock(addr,bp,(USHORT)reclen);
        break;
      case REC_TYPEDEF:
        TRACE("TypedefRecord gelesen\n");
        ProcessTypedefRec((LPCSTR)bp );
        break;
      case REC_SRCNAME:
      {
        if(globSrcPath!="")
        {
          reclen=bp[6];
          sp=(unsigned char*)buffer1;
          cp=&bp[7];
          while(reclen--)
            *sp++=*cp++;
          *sp=0;
          TRACE("SourceFile= %s\n",buffer1);
          ((CModDef*)(moduls.GetAt(actmodule)))->SrcPath=globSrcPath;
          ((CModDef*)(moduls.GetAt(actmodule)))->SrcPath+=buffer1;
        }
      }
      break;
      case REC_DEBUG_KEIL:
      mObExt=TRUE;
      ObExt=TRUE;
      TRACE("DebugNeu\n");
      ((CModDef*)(moduls.GetAt(actmodule)))->ObExt=TRUE;
      case REC_DEBUG:
        bp++;

        reclen=(*(USHORT*)bp)-2; //L�nge und SegmentID weg
        bp+=2;
        deftyp=*bp++;
        if(deftyp==3)  //Debugrecord enth�lt Zeileninformation
        {
          while(reclen)
          {
            bp++;            //SegmentID immer 0
            addr=(*(USHORT*)bp);
            bp+=2;
            lineno=(*(USHORT*)bp);
            bp+=2;
            AddDbgInfo(addr,lineno,actmodule);
            TRACE("Module=%s, LINE=%d, Adresse=0x%4.4X\n",((CModDef*)(moduls.GetAt(actmodule)))->modname,lineno,addr);
            reclen-=5;
          }
        }
        else if(deftyp<=1)  //Debugrecord enth�lt lokale oder public Symbole
        {
          while(reclen)
          {
            bp++;              //SegmentID immer 0
            int syminfo=*bp++;
            addr=(*(USHORT*)bp);
            bp+=2;
            typidx=*bp++;  //Typeindex
            if(typidx >= 0x20)
            {
              pos=pTmpList->FindIndex(typidx-0x20);
              ptd=(CTypdesc*)pTmpList->GetAt(pos);
            }
            else
            {
              if(mObExt)
                ptd=(CTypdesc*)typidx;
              else if(lastWasASMmodule)
                ptd=(CTypdesc*)T_UCHAR; //Standardtyp =UCHAR
              else
                ptd=(CTypdesc*)T_UINT; //Standardtyp =USHORT in C-Programmen
            }
            int ln=*bp++;
            strncpy(buffer1,(char*)bp,ln);
            bp+=ln;
            buffer1[ln]=0;
            if(actmodule)
              AddDbgInfo(addr,buffer1,deftyp,syminfo,actmodule,pp,ptd);
            else if(libp)
              AddDbgInfo(addr,buffer1,deftyp,syminfo,0,libp);
            reclen-=ln+6;
            TRACE("LABEL %s, MODULE %s,ADDR: %X, SYMINFO %X, Typeindex %X\n",buffer1,LPCSTR(((CModDef*)(moduls.GetAt(actmodule)))->modname),addr,syminfo,typidx);
          }
        }
        else  // 2 = record enth�lt SEGMENTINFO
        {
          while(reclen)
          {

            bp++;              //SegmentID immer 0
            int seginfo=*bp++;
            addr=(*(USHORT*)bp);
            bp+=2;
            typidx=*bp++;  //Typeindex
            if(typidx >= 0x20)
            {
              pos=pTmpList->FindIndex(typidx-0x20);
              ptd=(CTypdesc*)pTmpList->GetAt(pos);
            }
            else
            {
              ptd=(CTypdesc*)typidx;
            }
            int ln=*bp++;
            strncpy(buffer1,(char*)bp,ln);
            bp+=ln;
            buffer1[ln]=0;
            reclen-=ln+6;
            seginfo &=0x07; //nicht ben�tigte Informationen ausblenden
            if(!seginfo) // codelabel bei ASM-Files ausserhalb des ge�ffneten Moduls
            {
              AddDbgInfo(addr,buffer1,deftyp,0,actmodule,0,ptd);
              TRACE("SEGMENTINFOLABEL %s ADDR: %4.4X, MODULE %s\n",buffer1,addr,((CModDef*)(moduls.GetAt(actmodule)))->modname);
            }
            else
              TRACE("SEGMENTINFO %s, MODULE %s\n",buffer1,((CModDef*)(moduls.GetAt(actmodule)))->modname);
          }
        }
        delete pTmpList;
        pTmpList=0;
        break;
      case REC_SCOPE:
        switch(bp[3])
        {
          case 0:   //=Modulanfang
          {
            int ln=bp[4];
            strncpy(buffer1,(char*)(&bp[5]),ln);
            buffer1[ln]=0;
            if(buffer1[0]!='?'|| buffer1[1]!='C')  //keine Libraryfunktion
            {
              actmodule=AddModuleInfo(buffer1);
              lastWasASMmodule=actmodule;
              lastlabel="";
              TRACE("Module %d (%s) wurde ge�ffnet\n",actmodule,buffer1);
              strcat(buffer1,".c");
              mtxt=srcpath+buffer1;
              fs.m_size=0;
              CFile::GetStatus(mtxt,fs);
              if(!fs.m_size)
              {
                strcat(buffer1,"51");
                mtxt=srcpath+buffer1;
                CFile::GetStatus(mtxt,fs);
                if(!fs.m_size)
                  break;
              }
              if(fs.m_mtime > absfiletime)
              {
                mtxt.LoadString(IDS_SUSPECTSRCFILE);
                int l=mtxt.Find('%');
                ctxt=mtxt.Left(l)+" ";
                ctxt+=buffer1;
                ctxt+=mtxt.Mid(l+1);
                mtxt.LoadString(IDS_OPENABSFILE);
                theApp.pMainWnd->MessageBox(ctxt,mtxt,MB_ICONEXCLAMATION);
              }
            }
            else
            {
              actmodule=0;
              lastlabel=buffer1;
            }
            break;
          }
          case 1:   //DO-Block
          TRACE("DO-Block Anfang\n");
          break;

          case 2:   //Prozeduranfang
          {
            int ln=bp[4];
            strncpy(buffer1,(char*)(&bp[5]),ln);
            buffer1[ln]=0;
            mp=(CModDef*)moduls.GetAt(actmodule);
            pp=mp->AddProc(buffer1);
            TRACE("Prozeduranfang  (%s) gelesen\n",buffer1);
            break;
          }
          case 3:   //Modul wurde geschlossen
          TRACE("Module %d wurde geschlossen\n",actmodule);
          pp=0;
          mObExt=FALSE;
          mp=(CModDef*)moduls.GetAt(actmodule);
          actmodule=-1;
          mp->SortProcs();
          break;

          case 4:
            TRACE("DO-End\n");
            break;
          case 5:
            TRACE("Prozedurende\n");
            if(mObExt==TRUE)
            {
              procname="";
              pp=0;
            }
            break;
        }
        break;

      case REC_MODHEAD:
        TRACE("Modul-Header gelesen\n");
        break;
      case REC_MODEND:
        TRACE("Modul-end gelesen\n");
        break;
      case REC_START:
        TRACE("Header gelesen\n");
        break;
      default:
        TRACE("unbekannter Recordtyp: %2.2X\n",rectype);
        break;
    }
  }
  while(bp);
  return(1); //sp�ter hier die Anzahl der Module
}

#ifdef _DEBUG
  //liefert den Namen des Datentyps im Klartext nur zum Debuggen
  const char* GetTypeName(int ti)
  {
    switch(ti)
    {
      case 0: return("untyped");
      case 1: return("bit");
      case 2: return("schar");
      case 3: return("uchar");
      case 4: return("sshort");
      case 5: return("ushort");
      case 6: return("slong");
      case 7: return("ulong");
      case 8: return("float");
      case 9: return("double");
      case 0x0A: return("code label");
      case 0x0B: return("void");
      case 0x0D: return("lfloat");
      case 0x20: return("list descriptor");
      case 0x21: return("pointer descriptor");
      case 0x22: return("array descriptor");
      case 0x23: return("Function descriptor");
      case 0x24: return("type descriptor");
      case 0x25: return("struct descriptor");
      case 0x26: return("bit field descriptor");
      case 0x27: return("spaced pointer descriptor");
      case 0x28: return("generic pointer descriptor");
      default: return ("ung�ltiger Typ");
    }
  }
#endif //_DEBUG

//bearbeitet einen Typedef-Record
void CObjInfo::ProcessTypedefRec(LPCSTR bp)
{
LPSTR hp;
int i;
int ti;
int ti1;
int size;
int components;
USHORT offset;
int clen;
char cname[100];
int cnt;
CPtrList* pltyp;
CTypdesc* ptd1;
CTypdesc* ptd2;
POSITION pos,pos1,pos2;

  pltyp=new CPtrList;  //tempor�re Liste um die Typdescriptoren aufzunehmen
  TRACE("temp.ptrlist=%lX\n",pltyp);
  pTmpList=pltyp;
  cnt=0;
  bp++;
  int reclen=*(USHORT*)bp;
  TRACE("TypedefRecord gelesen len=%d\n",reclen);
  hp=(LPSTR)bp+reclen;
  bp+=2;
  while(bp<hp)
  {
    ti=*bp++;       // Typeindex
    if(ti>=0x20)        // zusammengesetzter Datentyp
    {

      ptd1=new CTypdesc(ti); //einen neuen Typdescriptor anlegen
      //TRACE("neuer typdesc=%lX\n",ptd1);
      pltyp->AddTail(ptd1);  //in der tempor�ren Liste sammeln
      //xxxIII
      typelist.AddTail(ptd1);
      switch(ti)
      {
        case T_LISTDESC:
          components=*(USHORT*)bp;
          bp+=2;
          TRACE("%d  List Desc. mit %d Komponenten\n",cnt++,components);
          ptd1->elements=components;
          if(!components)
            break;
          ptd1->pmem=new CPtrList;
          //TRACE("ti=0x20 + ptrlist->pmem=%lX\n",ptd1->pmem);
          while(components--)
          {
            offset=*(USHORT*)bp;
            bp+=2;
            ti=(UCHAR)*bp++;
            if(ti == 0x1F)  //Index �berlauf
            {
              ti=(UCHAR)*bp++;
              ti=ti*256+(UCHAR)*bp++;
            }
            clen=*bp++;
            strncpy(cname,bp,clen);
            cname[clen]=0;
            bp+=clen;
            ptd2=new CTypdesc(0);
            ptd2->tparent=ptd1;
            ptd2->pref=(CTypdesc*)ti;
            typelist.AddTail(ptd2);
            //xxxIII
            if(ti < 0x1F)
              ptd2->typ=ti;  //Standard Typ
            ptd2->offset=offset;
            ptd2->pname =new CString(cname);
            ptd1->pmem->AddTail(ptd2); // zur Liste der enthaltenen Typen hizuf�gen
            //TRACE("Inhalt von ptd1->pmem + typedesc ptd2=%lX\n",ptd2);
            //TRACE("Inhalt von ptd1->pname + string=%lX\n",ptd2->pname);
            #ifdef _DEBUG
              if(ti<0x20)
                TRACE("    Name=%s\n    Typ=%s\n    Offset=%d\n    ++++++++\n",cname,GetTypeName(ti),offset);
              else
                TRACE("    Name=%s\n    verweist auf descriptor %d\n    Offset=%d\n    ++++++++\n",cname,ti-0x20,offset);
            #endif
          }
          break;
        case T_POINTDESC:
          ti=(UCHAR)*bp++;
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }
          ptd1->pref=(CTypdesc*)ti; // Typ auf den der Pointer zeigt,wird zum schluss aufgel�st
          #ifdef _DEBUG
            if(ti>0x20)
              TRACE("%d  Pointer Desc. verweist auf %d. Typdefinition\n",cnt++,ti-0x20);
            else
              TRACE("%d  Pointer Desc. zeigt auf:%d= %s\n",cnt++,ti,GetTypeName(ti));
          #endif
          break;

        case T_ARRAYDESC:
          clen=*bp++; //Arraydimensionen
          TRACE("%d  Array Descriptor\n    Dimensionen=%d\n",cnt++,clen );
          i=0;
          while(i<clen)
          {
            ptd1->size=clen;  //Zahl der Dimensionen
            ptd1->offset=(USHORT)i;   //aktuelle Dimension
            ptd1->elements=*(USHORT*)bp; // Anzahl der Elemente der Dimension
            bp+=2;
            TRACE("  DIM%d , %d Elemente\n",i,ptd1->elements);
            i++;
            if(i<clen)
            {
              ptd1->pref=new CTypdesc;
              ptd1->typ=T_ARRAYDESC;
              typelist.AddTail(ptd1->pref);
              ptd1=ptd1->pref;
            }
          }
          ptd1->typ=T_ARRAYDESC;
          ti=(UCHAR)*bp++;
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }

          // ptd1->pref=(CTypdesc*)ti;
          if(ti>0x20)
          {
            pos=pltyp->FindIndex((int)ti-0x20);
            ptd1->pref=(CTypdesc* )pltyp->GetAt(pos); // Typ aus dem das Array besteht
          }
          else
            ptd1->pref=(CTypdesc*)ti;
          TRACE("  verweist auf=%d.typdefinition\n",ti-0x20);
          break;

        case T_FUNCDESC:
          ti=(UCHAR)*bp++;   // Function return parameter type
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }
          ti1=(UCHAR)*bp++;   // Function input paramlist
          if(ti1 == 0x1F)  //Index �berlauf
          {
            ti1=(UCHAR)*bp++;
            ti1=ti1*256+(UCHAR)*bp++;
          }
          ptd1->pref=(CTypdesc*)ti;  //Return Typ
          ptd1->ptag=(CTypdesc*)ti1; //b�ser Heck hier die Referenz auf die Parameterliste
          TRACE("%d  Function Desc.  Return=%d , Paramlist=%d \n",cnt++,ti-0x20,ti1-0x20);
          break;
        case T_TYPEDESC:
          ti=(UCHAR)*bp++;
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }
          if(ti)
            TRACE("%d  Type Desc. -typedefname= ",cnt++);
          else
            TRACE("%d  Type Desc. -structname= ",cnt++);
          clen=*bp++;
          strncpy(cname,bp,clen);
          cname[clen]=0;
          bp+=clen;
          ptd1->offset=(USHORT)ti; //Kenner ob typdef oder tag-name
          ptd1->pname=new CString(cname);
          TRACE("%s\n",cname);
          //TRACE("ti=0x24, string ptd1->pname=%lX\n",ptd1->pname);
          break;
        case T_STRUCTDESC:
          size=*(USHORT*)bp;  //gesamtgr��e der struktur
          bp+=2;
          ti=(UCHAR)*bp++; //memberlist ti
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }
          ti1=(UCHAR)*bp++; //tagname ti
          if(ti1 == 0x1F)  //Index �berlauf
          {
            ti1=(UCHAR)*bp++;
            ti1=ti1*256+(UCHAR)*bp++;
          }
          TRACE("%d  Struct Desc.  size=%d verweist auf: %d.typefinition tagname=%d\n",cnt++,size,ti-0x20,(ti1 ? ti1-0x20 :                               -1));
          ptd1->size=size; //Gesamtgr��e der Struktur
          ptd1->pref=(CTypdesc*)ti; //Referenz auf List-desc.
          ptd1->ptag=(CTypdesc*)ti1; //der Verweis auf Tagnamen
          break;
        case T_BITARRDESC:
          ti=(UCHAR)*bp++; //base 8/16Bit
          offset=*bp++; //offset von 0x20
          ti1=(UCHAR)*bp++; //field width
          ptd1->size=ti1;
          ptd1->offset=offset;
          ptd1->elements=ti; //base
          TRACE("%d  Bit Field Desc. base=%d offset=%d width=%d\n",cnt++,ti,offset,ti1);
          break;
        case T_SPACEDPTR:
          ti=(UCHAR)*bp++;
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }
          clen=(UCHAR)*bp++;  //pointer len 1,2
          ti1=(UCHAR)*bp++;  //memory space
          ptd1->pref=(CTypdesc*)ti;
          ptd1->size=clen;
          ptd1->offset=(USHORT)ti1;
          if(ti>=0x20)
            TRACE("%d  Spaced Pointer Desc. verweist auf %d. Typedefinition, len=%d mspace=%d\n",cnt++,ti-0x20,clen*8,ti1);
          else
            TRACE("%d  Spaced Pointer Desc. Type=%X len=%d mspace=%d\n",cnt++,ti,clen*8,ti1);
          break;
        case T_GENPTRDESC:
          ti1=(UCHAR)*bp++; //attribut
          clen=(UCHAR)*bp++; //pointer l�nge
          offset=(UCHAR)*bp++; //mspace
          size=(UCHAR)*bp; //zeiger auf was
          bp+=4;   //leer
          ti=(UCHAR)*bp++;  //referenced type
          if(ti == 0x1F)  //Index �berlauf
          {
            ti=(UCHAR)*bp++;
            ti=ti*256+(UCHAR)*bp++;
          }
          ptd1->pref=(CTypdesc*)ti;
          ptd1->size=clen;
          ptd1->offset=offset;
          ptd1->ptag=(CTypdesc*)size; //b�ser Heck, hier worauf der Pointer zeigt
          ptd1->elements=ti1;
          #ifdef _DEBUG
            TRACE("%d  GenericPointer  attr=%d len=%d mspace=%d  pspec=%d  reftyp=%s\n",cnt++,ti1,clen,offset,size,GetTypeName(ti));
          #endif
          break;
        default:
          TRACE("  ��� ung�ltiger Typ ���\n");
          break;
      }
    }
  }
  clen=pltyp->GetCount(); //L�nge der Templiste
  while(clen--)    //jetzt wird die Templiste verkn�pft
  {
    pos=pltyp->FindIndex(clen);
    ptd1=(CTypdesc*)(pltyp->GetAt(pos));
    if((ULONG)(ptd1->pref) >= 0x20 && ptd1->typ !=T_ARRAYDESC)
    {
      if((int)((ULONG)(ptd1->pref))-0x20 == clen)
        TRACE("Rekursiver Typindex %d\n",clen-0x20);
      else
      {
        pos=pltyp->FindIndex((int)((ULONG)(ptd1->pref))-0x20);
        ptd1->pref=(CTypdesc* )pltyp->GetAt(pos);
        ptd1->pref->tparent=ptd1;
      }
    }
    if(ptd1->pmem)
    {
      pos1=ptd1->pmem->GetHeadPosition();
      while(pos1)
      {
        CTypdesc* pt=(CTypdesc*)ptd1->pmem->GetAt(pos1);
        if((ULONG)(pt->pref) >= 0x20)
        {
          pos2=pltyp->FindIndex((int)((ULONG)(pt->pref))-0x20);
          if(!pos2)
          {
            TRACE("Types Step1 broken at dereferencing because error in typedef record\n");
            break;
          }
          pt->pref=(CTypdesc*)(pltyp->GetAt(pos2));
          if(!pt->typ)    // das ist eine Liste
          {
            pt->typ=pt->pref->typ;
            pt->pref->tparent=pt;
          }
        }

        ptd1->pmem->GetNext(pos1);
      }
    }
    if((ULONG)ptd1->ptag >= 0x20)
    {

      if((int)((ULONG)(ptd1->ptag))-0x20 == clen)
        TRACE("Rekursiver Typindex %d\n",clen-0x20);
      else
      {
        TRACE("tagindex=%d\n",((ULONG)(ptd1->ptag))-0x20);
        pos1=pltyp->FindIndex((int)((ULONG)(ptd1->ptag))-0x20);
        if(!pos1)
        {
          TRACE("Types Step1 broken at dereferencing because error in typedef record\n");
          break;
        }
        ptd1->ptag=(CTypdesc*)(pltyp->GetAt(pos1));
        ptd1->ptag->tparent=ptd1;
      }
    }
  }
  //Verkn�pfung rekursiver Strukturen

  pos=typelist.GetHeadPosition();
  while(pos)
  {
    ptd1=(CTypdesc*)(typelist.GetNext(pos));
    if(   ptd1->typ==T_STRUCTDESC
          && ptd1->pref->typ==T_LISTDESC
          && ptd1->pref->pmem==0)
    {
      ptd2=ptd1->tparent;
      while(ptd2->typ != T_LISTDESC && ptd2!=0)
        ptd2=ptd2->tparent;   //hangle nach oben
      ptd1->pref=ptd2;
    }

  }

  TRACE("Types Step1 successful dereferenced\n");
}


BOOL CObjInfo::LoadMotorolaHexfile(CString& hexfileName)
{
  BYTE* bp;
  int  reclen,recno,addlen;
  CProgressCtrl* pb;
  CFileStatus fs;
  ULONG progstate;
  ULONG loadaddr;
  CFile hexfile;
  BYTE* hp;
  BYTE rec[550];

  ObExt=FALSE;
  addlen=0;
  loadaddr=0;
  if(!hexfile.Open(hexfileName,CFile::modeRead))
  {
    hexfileName="";
    return(0);
  }
  TRACE("MOTOROLA-HEX-File ge�ffnet\n");
  progstate=0;
  pb=&((CMainFrame*)AfxGetMainWnd())->m_progress;
  pb->SetRange(0,(USHORT)hexfile.GetLength());
  recno=0;
  do
  {
    bp=GetSRec(&hexfile,rec);
    if(!bp)
      break;
    bp++;
    hp=bp;
    switch(*bp)
    {
      case '1':   //S1-Record
        addlen=2;
        break;
      case '2':   //S2-Record
        addlen=3;
        break;
      case '3':   //S3-Record
        addlen=4;
        break;
      case '0':
      case '5':
      case '7':
      case '8':
      case '9':
        break;
      default:   //ein anderer S-Record
        AfxMessageBox(IDS_INVALIDHEXFILE);
        hexfile.Close();
        return(0);
    }
    progstate+=(bp[2]+addlen)*2;  //l�nge
    pb->SetPos(progstate);
    bp++;
    reclen=*bp;
    bp++;
    switch(addlen)
    {
      case 2:
        loadaddr=(*bp++) << 8;
        loadaddr|=*bp++;
        reclen-=3;
        break;
      case 3:
        loadaddr=(*bp++) << 16;
        loadaddr|=(*bp++) << 8;
        loadaddr|=*bp++;
        reclen-=4;
        break;
      case 4:
        loadaddr=(*bp++) << 24;
        loadaddr|=(*bp++) << 16;
        loadaddr|=(*bp++) << 8;
        loadaddr|=*bp++;
        reclen-=5;
        break;
    }
    prc->WriteMemBlock(loadaddr,bp,(USHORT)reclen);
  }
  while(reclen);
  hexfile.Close();
  return TRUE;
}

//l�dt ein Hexfile wenn OK return=1 sonst 0
BOOL CObjInfo::LoadHexfile(CString& hexfileName)
{
  BYTE* bp;
  int  reclen,recno;
  CProgressCtrl* pb;
  CFileStatus fs;
  ULONG progstate;
  ULONG loadaddr;
  int rectyp;
  CFile hexfile;
  BYTE* hp;
  BYTE rec[550];
  int bDos;


  ObExt=FALSE;
  if(!hexfile.Open(hexfileName,CFile::modeRead))
  {
    hexfileName="";
    return(0);
  }
 

  // entscheiden ob Motorola oder IntelFormat geladen wird
  bp=GetSRec(&hexfile,rec);
  if(bp)
  {
    hexfile.Close(); //erst schliessen da das File wieder ge�ffnet wird
    return LoadMotorolaHexfile(hexfileName);
  }
  else
  { 
    bDos=0;
    reclen=hexfile.Read(prec,1000); 
    if(!memchr(prec,0x0D,reclen))
      bDos=-1;      
    hexfile.SeekToBegin();
    progstate=0;
    pb=&((CMainFrame*)AfxGetMainWnd())->m_progress;
    pb->SetRange(0,(USHORT)hexfile.GetLength());
    TRACE("INTEL-HEX-File ge�ffnet\n");
    recno=0;
    do
    {
      bp=GetHexRec(&hexfile,rec,bDos);
      if(!bp)
        break;
      if(*bp!=':')
      {
        AfxMessageBox(IDS_INVALIDHEXFILE);
        return(0); //der record muss  mit : anfangen
      }
      hp=bp;
      progstate+=(bp[1]+7)*2;//Typ
      pb->SetPos(progstate);
      bp++;
      reclen=*bp;
      bp++;
      loadaddr=(*bp++) << 8;
      loadaddr|=*bp++;
      rectyp=*bp++;
      if(!rectyp) //wenn nicht 0 ist es irgendwas anderes nur kein code
        prc->WriteMemBlock(loadaddr,bp,(USHORT)reclen);
      else if(rectyp==1)  //EOF
      {
        hexfile.Close();
        return TRUE;
      }
    }
    while(reclen);
    return TRUE;
  }
}

void CObjInfo::WriteCurrentTraceRecord(int tracetyp,ULONG pc)
{
  if(tracetyp == TRACE_WATCH)
  {
    if(tracelen==MAXTRACELEN)
    {
      traceptr->Flush();
      tracefile.SeekToBegin();
      tracelen=0;
    }
    CMainFrame* pm=(CMainFrame*)theApp.pMainWnd;
    if(pm->pDoc->tpt.isValid && pm->pDoc->tpt.IsTracePointAtAddr(pc))
    {
      WriteCurrentWatchTraceRecord(traceptr,&(pm->pDoc->tpt));
      tracelen++;
    }
  }
}

void CObjInfo::WriteCurrentWatchTraceRecord( CArchive* fp, CTracePoint* ptp)
{
  CString txt,*pexpr,txt1;
  char expr[200];
  int n,i,x;
  eval_t r;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  n=ptp->expressions.GetSize();
  if(!n)
    return;
  i=0;
  txt="000";
  while(i<n)
  {
    pexpr=(CString*)ptp->expressions.GetAt(i++);
    pexpr->TrimLeft();
    pexpr->TrimRight();
    strcpy(expr,LPCSTR(*pexpr));
    r.expression=expr;
    *(long*)r.lastop.op=0;
    x=Evaluate(&r);
    if(x)   //Ausdruck kann nicht berechnet werden
    {
      txt1.Format("\t%s=illegal expression\n",expr);
    }
    else
    {

      txt1.Format("\t%s=",*pexpr);
      if(r.retval.optyp==T_SCHAR)
        r.retval.optyp=T_UCHAR; // damit im Trace nicht der ganze dahinterliegende String aufgezeichnet wird
      GetWatchValString(expr,&r,sizeof(expr),V_HEX);
      txt1+=expr;
      txt1+="\n";
    }

    txt+=txt1;
  }
  //TRACE("%s\n",txt);
  if(txt=="")
    return;
  UCHAR t=TRACE_WATCH;
  USHORT len=(USHORT)(txt.GetLength()-3);
  txt.SetAt(0,TRACE_WATCH);
  txt.SetAt(1,(UCHAR)(len & 0xFF));
  txt.SetAt(2,(UCHAR)(len/256));
  fp->Write(LPCSTR(txt),len+3);
}

void CObjInfo::EnableTraceLog(LPCSTR logname,int tracetyp,ULONG addr)
{
  prc->EnableTraceLog(logname,tracetyp,addr);
  tracelen=0;
  if(logname && tracetyp==TRACE_WATCH)
  {
    tracefile.Open("temptrace.log",CFile::modeCreate | CFile::modeWrite);
    traceptr=new CArchive(&tracefile,CArchive::store);
    tracename="";
  }
  else
  {
    tracename=logname;
    delete traceptr;
    if(tracefile.m_hFile != -1)
      tracefile.Close();
    traceptr=0;
  }

}

BOOL CObjInfo::LoadSDCSymbolInfo(LPCSTR prjname)
{
CFile txtfile;
CString fname;
char *pmap;
char *pe;
char *pc;
char *pc1;
char *pc2;
char* pll;
ULONG l,lineno,i,addr,eaddr,endaddr;
CModDef* pm;
char modnamebuf[50];
char numbuf[15];
char symbuf[100];
CString lastmodname,actmodname,symname;
int modid;
CProgressCtrl* pb;
CString prjpath;
CString srcfile;
labeldef_t* lp;
BOOL b;


  //zuerst Mapfile nach Zeileninformationen durchsuchen
  fname=prjname;
  int r=fname.ReverseFind('\\');
  prjpath=fname.Left(r+1);
  fname+=".map";
  if(!txtfile.Open(fname,CFile::modeRead))
    return FALSE;
  l=txtfile.GetLength();
  pb=&((CMainFrame*)AfxGetMainWnd())->m_progress;
  pb->SetRange(0,100);

  AddModuleInfo("LIBRARY");
  TRACE("LIBRARY-MODULE erzeugt\n");
  lastmodname="";

  pmap=new char[l+100];
  pe=pmap+l;
  txtfile.Read((char*)pmap,l);
  txtfile.Close();
  
  pc=pmap;
  *pe=0;
  while(pc<pe)  //HLL module suchen C$filename$lineNo
  {
    pc=strstr(pc," C$");
    if(!pc)
      break;
    pc1=strchr(pc+3,'$');
    if(!pc1)
    {
      TRACE("inconsist map file\n");
      break;
    }
    memcpy(modnamebuf,pc+3,pc1-pc-3);
    modnamebuf[pc1-pc-3]=0;
    srcfile=modnamebuf;
    r=srcfile.Find('.');
    if(r!=-1)
    {
      actmodname=srcfile.Left(r);
      modnamebuf[r]=0;
    }
    else
      actmodname=srcfile;
    if(actmodname!=lastmodname)  //anders als der letzte Modulname
    {
      modid=FindModuleId(actmodname);
      if(modid==-1) //noch nicht geladen
      {
        actmodname=modnamebuf;
        srcfile=prjpath+srcfile;
        modid=AddModuleInfo(actmodname,srcfile);
        pm=(CModDef*)moduls.GetAt(modid);
        lastmodname=actmodname;
      }
    }
    pc1++;
    i=0;
    while(*pc1!='$') //bis Zeilennummer beendet
      numbuf[i++]=*pc1++;
    numbuf[i]=0;
    lineno=strtoul(numbuf,NULL,10);
    pc1=pc;
    while(*pc1!=':' && pc1>=pmap)
      pc1--;
    i=0;
    pc1++;
    while(*pc1!=' ') //bis adresse beendet
      numbuf[i++]=*pc1++;
    numbuf[i]=0;
    addr=strtoul(numbuf,NULL,16);
    TRACE("mod: %s, line: %d, addr %4.4X\n",actmodname,lineno,addr);
    AddDbgInfo(addr,lineno,modid);
    pc=strchr(pc,0x0A);
    pb->SetPos((pc-pmap)/(pe-pmap));
  }
  pb->SetPos(0);
  // das .cdb File  parsen und die Symbole einlesen-Adresse aus dem Map-file
  if(!ParseCDBFiles(pmap))
    return FALSE;

  //�brige globale Labels die nicht in HLL-modulen liegen einlesen
  pc=pmap;
  *pe=0;
  pm=GetLibModule();
  while(pc && pc<pe)  //HLL module suchen C$filename$lineNo
  {
searchagain:
    pc=strstr(pc," _");
    if(pc)
    {
      pc1=pc;
      while (*pc1!=0x0D && *pc1!=':' && *pc1!='[')
        pc1--;
      if(*pc1==':' && *(pc1-1)=='C') // label
      {
        pc1++;
        i=0;
        while(*pc1!=' ')
          numbuf[i++]=*pc1++;
        numbuf[i]=0;
        addr=strtoul(numbuf,0,16);
      } 
      else 
      {
        pc+=2;
        goto searchagain; 
      }       
      pc+=2;
      i=0;
      while(*pc!=' ' && *pc!=0x0A)
        symbuf[i++]=*pc++;
      symbuf[i]=0;
      symname=symbuf;
      lp=FindLabel(&symname);
      if(!lp)
      {
        AddDbgInfo(addr,symbuf,PUBSYM,CODEMEM,0,0,(CTypdesc*)T_CODELABEL);       
        //pm->AddProc(symbuf,addr,addr,pm); 
      }
    } 
  }

  //noch weitere ,ASM-Module im Map-File suchen
  pc=pmap;
  pll=strstr(pc,"Libraries Linked");  //Schluss
  if(!pll)
    pll=pe;
  pc=strstr(pc,"Files Linked");  
  if(!pc)
    goto nomoremods;  
  pc=strstr(pc,"[ module(s) ]");  //hier stehen alle Input-files
  if(!pc)
    goto nomoremods; 
  pc+=sizeof("[ module(s) ]");
  while(pc<pe)  //HLL module suchen C$filename$lineNo
  {  
    pc1=pc;
    pc=strstr(pc,"[ ");   // das erste
    if(!pc || pc>pll )
      break;    
    while(!isalpha(*pc))
      pc++;
    i=0;
    while(*pc!=' ' && *pc!=0x09 && *pc!=']')
      symbuf[i++]=*pc++;
    symbuf[i]=0;
    actmodname=symbuf;
    i=FindModuleId(actmodname);
    if(i==-1) //Das Modul existiert noch nicht
    {
      i=AddModuleInfo(symbuf);
      pm=(CModDef*)moduls.GetAt(i);
      //den Adressbereich suchen den das Modul belegt
      pc1=pmap;
      actmodname=actmodname+'.';
      pc1=strstr(pc1,actmodname);
      if(!pc1)
        continue;
      pc2=pc1;
      while(*pc2!=':' && *pc2!=0x0A)
        pc2--;
      if(*pc2 == ':')
        pc2++;
      else
        continue;
      i=0;
      while(isxdigit(*pc2))
        numbuf[i++]=*pc2++;
      numbuf[i]=0;
      addr=strtoul(numbuf,0,16);      
      endaddr=addr;
      while(pc1<pe)
      {
        pc1+=actmodname.GetLength();
        pc1=strstr(pc1,actmodname);
        if(!pc1)
          break;
        pc2=pc1;
        while(*pc2!=':' && *pc2!=0x0A)
          pc2--;
        if(*pc2 == ':')
          pc2++;
        else
          break;
        i=0;
        while(isxdigit(*pc2))
          numbuf[i++]=*pc2++;
        numbuf[i]=0;
        eaddr=strtoul(numbuf,0,16);
        if(eaddr>endaddr)
          endaddr=eaddr;
      }
      b=FindLabel(addr,symname,CODEMEM,PUBSYM);
      if(b)
        pm->AddProc(symname,addr,endaddr,pm);
      else
        pm->AddProc(symbuf,addr,endaddr,pm);  //dummy

    }
  }

nomoremods:    

  delete pmap;
  ObExt=TRUE;
  orderHL=FALSE;
  return TRUE;
}

BOOL CObjInfo::ParseCDBFiles(char* pmap)
{
CFile txtfile;
CString fname;
char *pcdb;
char *pe;
char *pc;
char *pc1;
char *pc2;
ULONG i,l,buflen,addr,eaddr;
CModDef* pm;
char symbuf[100];
char numbuf[15];
CString actmodname,procname;
int modid,n;
CProgressCtrl* pb;
CTypdesc* pt;
int memspec;
CProcDef* pp;

  pcdb=0;
  modid=1;
  n=GetModuleCnt();
  while(modid < n)
  {
    pm=(CModDef*)moduls.GetAt(modid);
    fname=pm->SrcPath; 
    i=fname.Find('.');
    if(i!=-1)
      fname=fname.Left(i);
    fname+=".cdb";
    if(!txtfile.Open(fname,CFile::modeRead))
    {
      modid++;
      continue;
    }
    l=txtfile.GetLength();
    pb=&((CMainFrame*)AfxGetMainWnd())->m_progress;
    pb->SetRange(0,100);
    if(!pcdb)
    {
      pcdb=new char[l+100];
      buflen=l;
    }
    else if(l>buflen)  //nur neu allokieren wenn die l�nge nicht reicht
    {
      delete pcdb;
      pcdb=new char[l+100];
      buflen=l;
    }    
    pe=pcdb+l;  
    txtfile.Read((char*)pcdb,l);
    txtfile.Close();
    actmodname=pm->modname;
    //alle Funktionen suchen
    pc=pcdb;
    sprintf(symbuf,"M:%s",pm->modname);  //nur innerhalb des jeweiligen Moduls suchen
    pc1=strstr(pc,symbuf);
    if(pc1)
    {
      pc=pc1;
      pc1=strstr(pc+strlen(symbuf),"\nM:");  
      if(!pc1)
        pc1=strstr(pc+strlen(symbuf),"\rM:");  
      if(pc1)
        pe=pc1;
    }
    *pe=0;
    while(pc<pe)
    {
      pc=strstr(pc,"F:");
      if(!pc)
        break;
      while(*pc!='$')
        pc++;
      pc++;
      i=3;
      while(*pc!='$')
        symbuf[i++]=*pc++;
      symbuf[i]=0;
      pc1=pmap;
      //Anfangsadresse
      symbuf[1]='G';
      symbuf[2]='$';
      pc1=strstr(pc1,&symbuf[1]);
      if(!pc1)
        continue; //nicht gefunden
      while(!isxdigit(*pc1))
        pc1--;
      pc2=pc1;
      while(isxdigit(*pc2))
        pc2--;
      memcpy(numbuf,pc2+1,pc1-pc2);
      numbuf[pc1-pc2+1]=0;
      addr=strtoul(numbuf,0,16);

      //endaddresse
      symbuf[0]='X';
      pc1=strstr(pc1,symbuf);
      if(!pc1)
        continue; //nicht gefunden
      while(!isxdigit(*pc1))
        pc1--;
      pc2=pc1;
      while(isxdigit(*pc2))
        pc2--;
      memcpy(numbuf,pc2+1,pc1-pc2);
      numbuf[pc1-pc2+1]=0;
      eaddr=strtoul(numbuf,0,16);
      pp=pm->AddProc(&symbuf[3],addr,eaddr,pm);
      AddDbgInfo(addr,&symbuf[3],PUBSYM,MS_CODE,modid,pp,(CTypdesc*)T_CODELABEL);
    }


    //alle globalen Symbole suchen  S:G$
    pc=pcdb;
    *pe=0;
    while(pc<pe)
    {
      pc=strstr(pc,"S:G$");
      if(!pc)
        break;
      pc+=4;
      i=0;
      while(*pc!='$')
        symbuf[i++]=*pc++;
      symbuf[i]=0;
      pc=strchr(pc,'}'); // ende sizeinfo
      if(!pc)
        break;
      pc++;
      pt=BuildTypeInfoFromCDBfile(pcdb,pc,NULL);
      if((long)pt==-1)
        continue;
      pc=strstr(pc,"),");
      pc+=2;
      memspec=GetMemSpecFromCDB(*pc);
      pc1=pmap;    //im Mapfile die Adresse suchen
fndaddr:
      pc1=strstr(pc1,symbuf);
      l=strlen(symbuf);
      if(pc1 && (*(pc1-1)!='_' || (*(pc1+l)!=' ' && *(pc1+l)!=0x0D)))
      {
        pc1+=l;
        goto fndaddr;
      }
      if(!pc1)
        continue; //nicht gefunden
      pc1-=2;
      while(*pc1==' ')
        pc1--;
      pc2=pc1;
      while(*pc2!=' ' && *pc2!=':')
        pc2--;
      pc2++;
      memcpy(numbuf,pc2,pc1-pc2+1);
      numbuf[pc1-pc2+1]=0;
      addr=strtoul(numbuf,0,16);
      AddDbgInfo(addr,symbuf,PUBSYM,memspec,modid,0,pt);
    }
    
    //alle lokalen Symbole suchen  S:Lmodname$
    pc=pcdb;    
    while(pc<pe)
    { 
      pc=strstr(pc,"S:L");
      if(!pc)
        break;
      pc1=strchr(pc+3, '$');
      if(!pc)
        break;
      
      memcpy(symbuf,pc+2,pc1-pc-1); 
      symbuf[pc1-pc-1]=0;
      actmodname=symbuf;
      procname=actmodname.Mid(1,actmodname.GetLength()-2);
      pp=FindProc(procname);
      pc=pc1+1;
      i=0;
      while(*pc!='$')
        symbuf[i++]=*pc++;
      symbuf[i]=0; 
      pc=strchr(pc,'}'); // ende sizeinfo
      if(!pc)
        break;
      pc++;
      pt=BuildTypeInfoFromCDBfile(pcdb,pc,NULL);
      if((long)pt==-1)
        continue;
      pc=strstr(pc,"),");
      pc+=2;
      memspec=GetMemSpecFromCDB(*pc);
      pc1=pmap;    //im Mapfile die Adresse suchen
    
      actmodname+=symbuf;
      actmodname+='$'; 
      pc1=strstr(pc1,actmodname);
      if(!pc1)
        continue; //nicht gefunden
      pc1--;
      while(*pc1==' ')
        pc1--;
      pc2=pc1;
      while(*pc2!=' ' && *pc2!=':' && *pc2!=0x0D)
        pc2--;
      pc2++;
      memcpy(numbuf,pc2,pc1-pc2+1);
      numbuf[pc1-pc2+1]=0;
      addr=strtoul(numbuf,0,16);            
      AddDbgInfo(addr,symbuf,LOCSYM,memspec,modid,pp,pt);       
    }
    modid++;
  }
  delete pcdb;
  return TRUE;
}

CTypdesc* CObjInfo::BuildTypeInfoFromCDBfile(char *pcdb, char *ptypstr, CTypdesc* pparent)
{
CTypdesc* pt;
CTypdesc* pt1; 
CTypdesc* ptRet;  
int i;
char typbuf[10];
char numbuf[15];
char structtag[30];
char symbuf[100];
char *pc;
char *pc1;
BOOL sgn;
static level;

  if(!pparent)
    level=0;
  else
    level++;
  i=0;
  pc=ptypstr;
  typbuf[0]=*pc++;
  typbuf[1]=*pc++;
  typbuf[2]=0;
  strlwr(typbuf);
  i=0;
  if(typbuf[0]=='d')
  {
    switch(typbuf[1])
    {
      case 'a':   //array
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_ARRAYDESC);
          typelist.AddTail(pt); 
          ptRet=pt;
          pt->tparent=pparent;
          pt->pref=new CTypdesc(T_ARRAYDESC);
          typelist.AddTail(pt->pref); 
          pt->pref->tparent=ptRet;   
          pt=pt->pref;      
        }
        else
        {
          pt=new CTypdesc(T_ARRAYDESC);
          typelist.AddTail(pt);
          pt->tparent=pparent;
          ptRet=pt;
        }
        while(*pc!=',')
          numbuf[i++]=*pc++;
        numbuf[i]=0;
        pt->elements=strtoul(numbuf,0,10);                 
        pt->tparent=pparent;     
        pt1=pt;
        while( pt1->tparent && pt1->tparent->typ== T_ARRAYDESC)
        {
          pt1=pt1->tparent;               
          pt->offset++;
        }        
        pc++;
        if(*pc=='S' || *pc=='D' || *pc=='s' || *pc=='d')
        {
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
          if(pt->pref>(CTypdesc*)0x20 &&pt->pref->typ==T_ARRAYDESC)
          {  //weitere dimensionen darunter
            pt->size=pt->pref->size+1;
          }
        }
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
      case 'f':   //function
        return (CTypdesc*)T_ULONG; //default
        break;
      case 'g':    //generic pointer
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_SDCGENPOINT);          
          pt->tparent=pparent;
          ptRet=pt;
          typelist.AddTail(pt);
          pt->offset=0;
          pt->pref=new CTypdesc(T_SDCGENPOINT);
          pt->pref->tparent=pt;
          typelist.AddTail(pt->pref); 
          pt=pt->pref;          
        }
        else
        {
          pt=new CTypdesc(T_SDCGENPOINT);
          typelist.AddTail(pt);
          pt->tparent=pparent;
          ptRet=pt;
        }                 
        pt->size=16;
        pt->elements=3;
        pc++;
        if(*pc=='S' || *pc=='D' || *pc=='s' || *pc=='d')
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
      case 'c':    //codepointer
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_SPACEDPTR);
          ptRet=pt;
          pt->tparent=pparent;
          typelist.AddTail(pt);
          pt->offset=0;
          pt->pref=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt->pref);
          pt->pref->tparent=pt;           
          pt=pt->pref;
        }
        else
        {
          pt=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt);
          pt->tparent=pparent;
          ptRet=pt;
        }               
        pt->size=2;
        pt->offset=MS_CODE;
        pc++;
        if(*pc=='S' || *pc=='D'|| *pc=='s' || *pc=='d')
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
      case 'x':    //xdatapointer
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_SPACEDPTR);
          pt->tparent=pparent; 
          ptRet=pt;
          typelist.AddTail(pt);          
          pt->offset=0;
          pt->pref=new CTypdesc(T_SPACEDPTR); 
          typelist.AddTail(pt->pref); 
          pt->pref->tparent=pt; 
          pt=pt->pref;
        }
        else
        { 
          pt=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt);
          pt->tparent=pparent; 
          ptRet=pt;
        }                          
        pt->size=2;
        pt->offset=MS_XDATA;
        pc++;
        if(*pc=='S' || *pc=='D'|| *pc=='s' || *pc=='d')
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
      case 'd':    //datapointer
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_SPACEDPTR);
          pt->tparent=pparent;
          ptRet=pt;
          typelist.AddTail(pt);
          pt->offset=0;
          pt->pref=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt->pref);
          pt->pref->tparent=pt; 
          pt=pt->pref;
        }
        else
        {
          pt=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt);
          pt->tparent=pparent;
          ptRet=pt;
        }                       
        pt->size=1;
        pt->offset=MS_DATA;
        pc++;
        if(*pc=='S' || *pc=='D'|| *pc=='s' || *pc=='d')
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
      case 'i':    //idatapointer
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_SPACEDPTR);
          pt->tparent=pparent;
          ptRet=pt;
          typelist.AddTail(pt);
          pt->offset=0;
          pt->pref=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt->pref);
          pt->pref->tparent=pt; 
          pt=pt->pref;
        }
        else
        {
          pt=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt); 
          pt->tparent=pparent;
          ptRet=pt;
        }               
        pt->size=1;
        pt->offset=MS_IDATA;
        pc++;
        if(*pc=='S' || *pc=='D'|| *pc=='s' || *pc=='d')
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
      case 'p':    //pdatapointer
        if(pparent && pparent->typ==T_LISTDESC)
        {
          pt=new CTypdesc(T_SPACEDPTR);
          pt->tparent=pparent;
          ptRet=pt;
          typelist.AddTail(pt);
          pt->offset=0;
          pt->pref=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt->pref);    
          pt->pref->tparent=pt; 
          pt=pt->pref;
        }
        else
        {
          pt=new CTypdesc(T_SPACEDPTR);
          typelist.AddTail(pt);    
          pt->tparent=pparent;
          ptRet=pt;
        }             
        pt->size=1;
        pt->offset=MS_PDATA;
        pc++;
        if(*pc=='S' || *pc=='D' || *pc=='s' || *pc=='d')
          pt->pref=BuildTypeInfoFromCDBfile(pcdb, pc, pt);
        else
          pt->pref=(CTypdesc*)T_ULONG; //default
        break;
    }
  }
  else if(typbuf[0]=='s')
  {
    if(*pc==':')
      pc++;
    
    if(*pc=='S' || *pc=='s')
      sgn=TRUE;
    else
      sgn=FALSE;
    if(!pparent || (pparent && pparent->typ!=T_LISTDESC))
    {
      switch(typbuf[1])
      {
        case 'l':   //long
          if(sgn)
            return (CTypdesc*)T_SLONG;
          else
            return (CTypdesc*)T_ULONG;
          break;
        case 'i':   //int        
          if(sgn)
            return (CTypdesc*)T_SINT;
          else
            return (CTypdesc*)T_UINT;
          break;
        case 'c':    //char
        case 's':    //short==char bei SDC
          if(sgn)
            return (CTypdesc*)T_SCHAR;
          else
            return (CTypdesc*)T_UCHAR;
          break;
        case 'v':    //void
          return (CTypdesc*)T_VOID;
        case 'f':    //float
          return (CTypdesc*)T_FLOATL;
          break;
        case 'x':    //bit
          return (CTypdesc*)-1;
          break;
        case 'b':    //bit field
          return (CTypdesc*)T_BIT;
          break;
        case 't':    //structure of name
          pt=new CTypdesc;
          typelist.AddTail(pt); 
          ptRet=pt; 
          pt->tparent=pparent;
          pt->typ=T_STRUCTDESC;
          pt->size=0;
          pt->offset=0; 
          pt->pref=new CTypdesc(T_LISTDESC);
          typelist.AddTail(pt->pref); 
          pt->pref->pmem=new CPtrList;       
          pc1=strchr(pc,':');
          memcpy(structtag,pc,pc1-pc);
          structtag[pc1-pc]=0;
          pc=strstr(pcdb,structtag);
          if(!pc)
            return(CTypdesc*)T_ULONG;
          pc1=strchr(pc,']');
          while(pc<=pc1)
          {
            pc=strstr(pc,"S:S$");
            if(!pc || pc>pc1 )
               break;
            pc+=4;
            i=0;
            while(*pc!='$')
              symbuf[i++]=*pc++;
            symbuf[i]=0;          
            pc=strchr(pc,'}');
            if(pc)           
            {
              pc++;            
              pt1=BuildTypeInfoFromCDBfile(pcdb,pc,pt->pref);                      
              pt1->pname=new CString(symbuf);
              pt1->offset=pt->size;
              pt->size+=CTypdesc::GetSizeOfTyp(pt1);                            
              pt->pref->pmem->AddTail(pt1);
              pt->pref->elements++;
            }                
          }        
          return ptRet;
          break;
      }
    }
    else if(pparent && pparent->typ==T_LISTDESC)
    {  
      switch(typbuf[1])
      {
        case 'l':   //long
          if(sgn)
            ptRet= new CTypdesc(T_SLONG);
          else
            ptRet= new CTypdesc(T_ULONG);          
          typelist.AddTail(ptRet); 
          ptRet->tparent=pparent;
          ptRet->pref=(CTypdesc*)ptRet->typ;                      
          break;
        case 'i':   //int
        case 's':    //short
          if(sgn)
            ptRet= new CTypdesc(T_SINT);
          else
            ptRet= new CTypdesc(T_UINT);          
          typelist.AddTail(ptRet);
          ptRet->tparent=pparent;
          ptRet->pref=(CTypdesc*)ptRet->typ;            
          break;
        case 'c':    //char
          if(sgn)         
            ptRet= new CTypdesc(T_SCHAR);         
          else
            ptRet= new CTypdesc(T_UCHAR);          
          typelist.AddTail(ptRet);
          ptRet->tparent=pparent;
          ptRet->pref=(CTypdesc*)ptRet->typ;            
          break;
        case 'v':    //void
          ptRet= new CTypdesc(T_VOID);          
          typelist.AddTail(ptRet);
          ptRet->tparent=pparent;
          ptRet->pref=(CTypdesc*)ptRet->typ;            
          break;
        case 'f':    //float
          ptRet= new CTypdesc(T_FLOATL);          
          ptRet->tparent=pparent;
          ptRet->pref=(CTypdesc*)ptRet->typ;            
          typelist.AddTail(ptRet);
          break;
        case 'x':    //bit
          ptRet= new CTypdesc(-1);          
          ptRet->tparent=pparent;
          ptRet->pref=(CTypdesc*)ptRet->typ;  
          typelist.AddTail(ptRet);          
          break;
        case 'b':    //bit field
          ptRet= new CTypdesc(T_UINT);      
          typelist.AddTail(ptRet);    
          ptRet->tparent=pparent;           
          ptRet->pref=(CTypdesc*)ptRet->typ;
          break;
        case 't':    //structure of name
          pt=new CTypdesc(T_STRUCTDESC);
          typelist.AddTail(pt);           
          pt->tparent=pparent;
          ptRet=pt;                                              
          pt->pref=new CTypdesc(T_STRUCTDESC);
          typelist.AddTail(pt->pref);
          pt->pref->tparent=ptRet;
          pt=pt->pref;
          pt->pref=new CTypdesc(T_LISTDESC);
          typelist.AddTail(pt->pref); 
          pt->pref->pmem=new CPtrList;       
          pc1=strchr(pc,':');
          memcpy(structtag,pc,pc1-pc);
          structtag[pc1-pc]=0;
          pc=strstr(pcdb,structtag);
          if(!pc)
            return(CTypdesc*)T_ULONG;
          pc1=strchr(pc,']');
          while(pc<=pc1)
          {
            pc=strstr(pc,"S:S$");
            if(!pc || pc>pc1 )
               break;
            pc+=4;
            i=0;
            while(*pc!='$')
              symbuf[i++]=*pc++;
            symbuf[i]=0;          
            pc=strchr(pc,'}');
            if(pc)           
            {
              pc++;            
              pt1=BuildTypeInfoFromCDBfile(pcdb,pc,pt->pref);                      
              pt1->pname=new CString(symbuf);
              pt1->offset=pt->size;
              pt->size+=CTypdesc::GetSizeOfTyp(pt1);    
              pt->pref->pmem->AddTail(pt1);
              pt->pref->elements++;
            }                
          }        
          return ptRet;
          break;
      }

    }
  }
  return ptRet;
}

int CObjInfo::GetMemSpecFromCDB(char mchar)
{
  switch(mchar)
  {
    case 'A':  return XDATAMEM;
    case 'B':  return IDATAMEM;
    case 'C':  return CODEMEM;
    case 'D':  return CODEMEM;
    case 'E':  return DATAMEM;
    case 'F':  return XDATAMEM;
    case 'G':  return IDATAMEM;
    case 'H':  return DATAMEM;
    case 'I':  return DATAMEM;
    case 'J':  return DATAMEM;
    default: return 0;
  }
}

#ifdef _DEBUG
void CObjInfo::DebugTypdesc(CTypdesc *ptd)
{
  typlevel=0;
  memset(levelbuf,' ',20);
  DebugTypdesc1(ptd);
}

void CObjInfo::DebugTypdesc1(CTypdesc *ptd)
{
CTypdesc *pt;
POSITION pos;
char typname[30];

  memset(levelbuf,'|',typlevel);
  levelbuf[typlevel]='-';
  typlevel++;
  levelbuf[typlevel]=0;
  TRACE("%s",levelbuf);
  if((ULONG)ptd>0x20 && ptd->pname)
    TRACE(" name: %s",*ptd->pname);
  if((ULONG)ptd<0x1E)
  { 
    GetTypname((ULONG)ptd,typname); 
    TRACE(" %s\n",typname);
  }
  else if(ptd->typ==T_STRUCTDESC)
  {
    TRACE(" STRUCT, size=%d,offset=%d\n",ptd->size,ptd->offset);
    DebugTypdesc1(ptd->pref);
  }
  else if(ptd->typ==T_LISTDESC)
  {
    TRACE(" LISTDESC, elemente=%d\n",ptd->elements,ptd->offset);
    pos=ptd->pmem->GetHeadPosition();
    while(pos)
    {
      pt=(CTypdesc*)ptd->pmem->GetNext(pos);   
      DebugTypdesc1(pt);   
    }
  }
  else if(ptd->typ==T_ARRAYDESC)
  {
    TRACE(" ARRAY | dim=%d : elemente=%d,offset=%d\n",ptd->size,ptd->elements,ptd->offset);    
    DebugTypdesc1(ptd->pref);
  }
  else if(   ptd->typ==T_POINTDESC
          || ptd->typ==T_SPACEDPTR 
          || ptd->typ==T_GENPTRDESC
          || ptd->typ==T_SDCGENPOINT)
  {
    TRACE(" POINTER >> ,offset=%d\n",ptd->offset);
    DebugTypdesc1(ptd->pref);
  }
  else if((ULONG)ptd->pref<0x1E)
  {    
    GetTypname((ULONG)ptd->pref,typname); 
    TRACE(" %s,offset=%d\n",typname,ptd->offset);
  }
  else
    TRACE(" anderer typ? %d\n",ptd->typ);
  typlevel--;
  levelbuf[typlevel]=0;
}

void CObjInfo::GetTypname(ULONG typindex,char* typbuf)
{
  switch(typindex)
  {
    case T_BIT:      strcpy(typbuf,"Bit");
                     break;
    case T_SCHAR:    strcpy(typbuf,"Char");
                     break;
    case T_UCHAR:    strcpy(typbuf,"UChar");
                     break;
    case T_SINT:     strcpy(typbuf,"Short");
                     break;
    case T_UINT:     strcpy(typbuf,"UShort");
                     break;
    case T_SLONG:    strcpy(typbuf,"Long");
                     break;
    case T_ULONG:    strcpy(typbuf,"ULong");
                     break;
    case T_FLOATL:   strcpy(typbuf,"Float");
                     break;
    case T_DOUBLE:   strcpy(typbuf,"Double");
                     break;
    case T_CODELABEL: strcpy(typbuf,"Label");
                      break;
    case T_FLOATB:   strcpy(typbuf,"FloatB");
                     break;
    default:         sprintf(typbuf,"??%d",typindex);
  }
  return;
}

#endif