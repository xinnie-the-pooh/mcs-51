// ViewUnknown.cpp : implementation file
//

#include "stdafx.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "DbgBar.h"
#include "JSTEP.h"
#include "JSTEPDoc.h"
#include "RegWnd.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "afxtempl.h"
#include "JSTEPView.h"
#include "ViewUnknown.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewUnknown

IMPLEMENT_DYNCREATE(CViewUnknown, CListView)

CViewUnknown::CViewUnknown()
{
  vmode=ASM;
  actaddr=(ULONG)-1;
  bkcolor=0xD0FFD0;
  anfaddr=0xFFFFFFFF;
  endaddr=0;
  setcols=FALSE;
}

CViewUnknown::~CViewUnknown()
{
  CJSTEPDoc* pdoc= (CJSTEPDoc*)GetDocument();
  pdoc->punknown=0;
}


BEGIN_MESSAGE_MAP(CViewUnknown, CListView)
	//{{AFX_MSG_MAP(CViewUnknown)
	ON_WM_VSCROLL()
	ON_WM_KEYDOWN()
	ON_WM_SYSKEYDOWN()
	ON_WM_LBUTTONDOWN()
  ON_WM_RBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
  ON_COMMAND(ID_SETPC,OnSetPC)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CViewUnknown diagnostics

#ifdef _DEBUG
void CViewUnknown::AssertValid() const
{
	CListView::AssertValid();
}

void CViewUnknown::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CViewUnknown message handlers


void CViewUnknown::OnInitialUpdate() 
{
CString txt;
  
  txt.LoadString(IDS_CODEUNKNOWN);
  GetListCtrl().SetBkColor(bkcolor);
  ((CMDIChildWnd*)GetParent())->SetWindowText(txt);
  GetListCtrl().SetImageList(&m_SmallImageList,LVSIL_SMALL);	
  lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier");	
  SetFont(&lfont);	
  CClientDC dc(this);
  dc.GetOutputCharWidth('0','0',&fwidth);	  	
  EnableToolTips();     
}

void CViewUnknown::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
CImageList* pImageList;
int nItem;
static char szBuff[MAX_PATH];
LV_ITEM lvi;
LV_COLUMN lvc;
BOOL bSelected;
UINT uiFlags;
CRect rcIcon,rcLabel;
int len;
CRect rcItem;
CDC* pDC;
CFont* oldfont; 
    
  if(selstart != selend)
    DrawSelection(bkcolor);  
  uiFlags=0 ; //=ILD_TRANSPARENT;
  CListCtrl& ListCtrl=GetListCtrl();
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);  
  oldfont=pDC->SelectObject(&lfont);
  rcItem=lpDrawItemStruct->rcItem;	
  nItem=lpDrawItemStruct->itemID;	

  len=ListCtrl.GetColumnWidth(0);
  if(len<40)
  {
    ListCtrl.SetColumnWidth(0,40);
    return;
  }
  // get item data
	// Icon in der ersten Spalte
  lvi.mask=LVIF_IMAGE | LVIF_STATE | LVIF_PARAM;
  lvi.iItem=nItem;
  lvi.iSubItem=0;
  lvi.stateMask=0xFFFF;		// get all state flags
  ListCtrl.GetItem(&lvi);  
  bSelected=lvi.state & LVIS_SELECTED;	
  
  if(lvi.lParam== (LONG)prc->GetProgramCounter())
  {
    
    if((lvi.iImage<4) && (vmode==ASM) )      //iImage=3 bedeutet die Adresse ist g�ltig
    {                                 
      uiFlags|=INDEXTOOVERLAYMASK(1);        //wenn der Eintrag die Adresse des
      if(nItem!=pcitem)                      //aktuelle PC besitzt wird ein gelber    
      {                                      //Pfeil, =1.Eintrag in der Overlayliste angezeigt      
        ListCtrl.RedrawItems(pcitem,pcitem);          
        pcitem=nItem;                        //Merken wer den gelben Pfeil jetzt hat
      }                                                                          
    } 
  }
  else if(bSelected)   //nur dann wird das Icon freigegeben
  {   
    ListCtrl.SetItemState(actitem,0,0);
    actitem=nItem;
    uiFlags|=INDEXTOOVERLAYMASK(2);  // wenn der Eintrag selektiert ist
                                     // wird ein grauer Pfeil angezeigt 
                                     // = 2.Eintrag in der Overlayliste
  }
  // Wenn der lParam des Eintrages auf eine g�ltige Adresse zeigt
  // und ein Breakpoint gesetzt ist
  ULONG bkptfmt=prc->IsBreakpointAtAddr(lvi.lParam);
  if(bkptfmt & BKPT_CODE)
  {
    if(bkptfmt & BKPT_DISABLED)
      lvi.iImage=6;
    else
      lvi.iImage=1;
  }

  //Tracepoint darstellen wenn vorhanden
  CJSTEPDoc* pdoc=((CMainFrame*)AfxGetMainWnd())->pDoc;
  if(pdoc->tpt.IsTracePointAtAddr(lvi.lParam) && pdoc->tpt.isValid)
  {
    if(lvi.iImage == 3) // wenn nicht gerade ein Breakpoint dargestellt wird
      lvi.iImage=8;
    else
      lvi.iImage=9;
    pdoc->tpt.pv=&ListCtrl;
    pdoc->tpt.item=nItem;       
  }

   //Messpunkt darstellen wenn vorhanden
  if(pdoc->mpt.addr==(ULONG)lvi.lParam  && pdoc->mpt.isValid)
  {
    lvi.iImage=10;
    pdoc->mpt.pv=&ListCtrl;
    pdoc->mpt.item=nItem;     
  }

  //Stimulationspunkt darstellen wenn vorhanden
  if(pdoc->stpt.addr==(ULONG)lvi.lParam  && pdoc->stpt.isValid)
  {     
    lvi.iImage=12;
    pdoc->stpt.pv=&ListCtrl;
    pdoc->stpt.item=nItem;     
  }

 // draw normal and overlay icon
  if(lvi.state & LVIS_CUT)
  {                         
    uiFlags|=INDEXTOOVERLAYMASK(4);
  }
  
  ListCtrl.GetItemRect(nItem,rcIcon,LVIR_ICON);
  pImageList=ListCtrl.GetImageList(LVSIL_SMALL);	
  if(pImageList)
  {		
	if(rcItem.left<rcItem.right-1)
    	ImageList_DrawEx(pImageList->m_hImageList
		                 ,lvi.iImage   //normal Icon 
				         ,pDC->m_hDC
						 ,rcIcon.left
						 ,rcIcon.top
						 ,16,16
						 ,CLR_DEFAULT
						 ,0
						 ,uiFlags);  //Mask
  }
  ListCtrl.GetItemRect(nItem,rcItem,LVIR_LABEL);
  len=ListCtrl.GetColumnWidth(1);
  if(len<80)
  {
    ListCtrl.SetColumnWidth(1,80);
    return;
  }
  // draw labels for column 1
  lvc.mask=LVCF_FMT | LVCF_WIDTH;
  ListCtrl.GetColumn(1,&lvc);		  
  rcItem.left=rcItem.right;
  rcItem.right+=lvc.cx;		
  len=ListCtrl.GetItemText(nItem,1,szBuff,sizeof(szBuff));	
  rcLabel=rcItem;
  rcLabel.left+=OFFSET_OTHER;

  if(isdigit(szBuff[0]) || szBuff[0]==' ')
  { 
    pDC->SetTextColor(0x808080);
 	pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);   
	pDC->SetTextColor(0);
  }
  else
    pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);

  // draw labels for column 2
  ListCtrl.GetColumn(2,&lvc);
  
  lvc.mask=LVCF_FMT | LVCF_WIDTH;
  rcItem.left=rcItem.right;
  rcItem.right+=lvc.cx;			
  len=ListCtrl.GetItemText(nItem,2,szBuff,sizeof(szBuff));	  	    		
  rcLabel=rcItem;
  rcLabel.left+=OFFSET_OTHER;	
  pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
    
  // draw labels for column 3
	ListCtrl.GetColumn(3,&lvc);    
	if(bselect && nItem==actitem  && selstart != selend)
  { 
  	  DrawSelection();  // Item ist selektiert
	}
	else
	{  	
	  lvc.mask=LVCF_FMT | LVCF_WIDTH;
    rcItem.left=rcItem.right;
	  rcItem.right+=lvc.cx;			
    len=ListCtrl.GetItemText(nItem,3,szBuff,sizeof(szBuff));	  	    		
	  rcLabel=rcItem;
	  rcLabel.left+=OFFSET_OTHER;
    pDC->SetTextColor(0);	 	
	  pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
  }  

  pDC->SelectObject(oldfont);
}

//ansonsten wird die Liste neu gebildet
void CViewUnknown::SetupUnknownList(ULONG anfaddr)
{
ULONG i=0;
int idx=0;
LV_ITEM lvi;
LV_COLUMN lvc;
int pageitems;
int r;
char recmd[200];
char buffer[100];
BOOL b;
ULONG cd;
int cdbyte;
CString codebytes;
   
  if(anfaddr==actaddr)
    return;  
  SetRedraw(FALSE);
  if(!setcols)
  {
    CListCtrl& lc=GetListCtrl();
    while(lc.DeleteColumn(i++)); //Alle Spalten L�schen 
	  lc.DeleteAllItems();
    // insert columns
    lvc.iSubItem=0;
    lvc.cx=40;
    lvc.pszText="BKPT";
    lvc.mask=LVCF_WIDTH | LVCF_TEXT;
    lc.InsertColumn(0,&lvc);
  
    lvc.iSubItem=1;
    lvc.cx=100;
    lvc.pszText="Adresse";
    lvc.mask=LVCF_WIDTH | LVCF_TEXT;
    lc.InsertColumn(1,&lvc);

    // neu Anzeige des Speicherinhaltes 21.4.98
    lvc.iSubItem=2;
    lvc.cx=100;
    lvc.pszText="Code";
    lvc.mask=LVCF_WIDTH | LVCF_TEXT |LVCF_SUBITEM;
    lc.InsertColumn(2,&lvc); 
    // ab hier wieder weiter wie bisher


    lvc.iSubItem=3;
    lvc.cx=1000;   //geht bis ins Unendliche
    lvc.pszText="Command";	
    lvc.mask=LVCF_WIDTH | LVCF_TEXT;//| LVCF_SUBITEM ;
    lc.InsertColumn(3,&lvc);
    setcols=TRUE;
  }  
  CListCtrl& lc=GetListCtrl();
  i=anfaddr;
  if(anfaddr>=CViewUnknown::anfaddr && anfaddr<=endaddr && anfaddr>actaddr)
  {   // nur einen Eintrag anf�gen
    
    if(anfaddr>endaddr-10)
    {
   
      if(b=prc->IsBreakpointAtAddr(i,BKPT_CODE))
        prc->RestoreOpcode(i);
      actaddr=anfaddr;
      idx=lc.GetItemCount();
      lvi.mask=LVIF_PARAM | LVIF_IMAGE;
	    lvi.iItem=idx;
	    lvi.iSubItem=0;
      lvi.iImage=3;       //leer aber g�ltige Adresse	
      lvi.lParam=endaddr;
	    lc.InsertItem(&lvi);      
	    r=prc->Reassemble(endaddr,recmd); 
      if(b)
        prc->RestoreBkpt(i);
      theApp.objinfo.FindLabel(endaddr,buffer,0,PUBSYM,8);

      //sprintf(buffer,"% 8.4X",endaddr);
      lc.SetItemText(idx,1,buffer);
      codebytes="";
      for(cdbyte=0;cdbyte<r;cdbyte++) 
      {
        prc->GetMemFromAddr(i+cdbyte,&cd,CODEMEM);
        sprintf(buffer,"%2.2X ",cd);
        codebytes+=buffer;
      }
      lc.SetItemText(idx,2,codebytes); 
      lc.SetItemText(idx,3,LPCSTR(recmd));
	    endaddr+=r;
    }
  }
  else 
  {   //eine neue Liste aufbauen      
    actaddr=anfaddr;
    CViewUnknown::anfaddr=anfaddr;  
    ResetSelection();     
    pageitems=lc.GetCountPerPage()+1;  
    lc.DeleteAllItems();          
    idx=0;
    ULONG mask=prc->GetMemSize(); 
    while (pageitems--)
    {
      i&=mask;
      b=prc->IsBreakpointAtAddr(i,BKPT_CODE); 
      if(b)
        prc->RestoreOpcode(i);
      lvi.mask=LVIF_PARAM | LVIF_IMAGE;
      lvi.iItem=idx;
      lvi.iSubItem=0;
      lvi.iImage=3;       //leer aber g�ltige Adresse
      lvi.lParam=i;
      lc.InsertItem(&lvi);         

      r=prc->Reassemble(i,recmd);
      if(b)
        prc->RestoreBkpt(i);
      theApp.objinfo.FindLabel(i,buffer,0,PUBSYM,8);          
      //sprintf(buffer,"% 8.4X",i);
      lc.SetItemText(idx,0,"X");
      lc.SetItemText(idx,1,buffer);
      codebytes="";
      for(cdbyte=0;cdbyte<r;cdbyte++) 
      {
        prc->GetMemFromAddr(i+cdbyte,&cd,CODEMEM);
        sprintf(buffer,"%2.2X ",cd);
        codebytes+=buffer;
      }
      lc.SetItemText(idx,2,codebytes);   
      lc.SetItemText(idx,3,LPCSTR(recmd));
      idx++;
      i+=r;      
    }
    endaddr=i;
  } 
  SetRedraw(TRUE);
}

void CViewUnknown::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{	
int r,i;
ULONG addr,cd;
char recmd[200];
BOOL b;
LV_ITEM lvi;
char buffer[15];
CString codebytes;
int cdbyte;
  
  CListCtrl& lc=GetListCtrl();  
  if( nSBCode==SB_LINEDOWN && (lc.GetTopIndex()+lc.GetCountPerPage()+1>=lc.GetItemCount()))
  {
    i=lc.GetItemCount();
    lvi.mask=LVIF_PARAM | LVIF_IMAGE;
    lvi.iItem=i;
    lvi.iSubItem=0;
    lvi.iImage=3;       //leer aber g�ltige Adresse	
    lvi.lParam=endaddr;
    lc.InsertItem(&lvi);
    addr=endaddr;
    b=prc->IsBreakpointAtAddr(addr,BKPT_CODE);
    if(b)
      prc->RestoreOpcode(addr);
	  r=prc->Reassemble(addr,recmd);     
    if(b)
      prc->RestoreBkpt(addr);
    //sprintf(buffer,"% 8.4X",addr);
    theApp.objinfo.FindLabel(addr,buffer,0,PUBSYM,8); 
    lc.SetItemText(i,1,buffer);
    codebytes="";
    for(cdbyte=0;cdbyte<r;cdbyte++) 
    {
      prc->GetMemFromAddr(endaddr+cdbyte,&cd,CODEMEM);
      sprintf(buffer,"%2.2X ",cd);
      codebytes+=buffer;
    }
    lc.SetItemText(i,2,codebytes); 
    lc.SetItemText(i,3,LPCSTR(recmd));
    endaddr+=r;	
  }   
  CListView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CViewUnknown::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CJSTEPView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CViewUnknown::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CJSTEPView::OnSysKeyDown(nChar, nRepCnt, nFlags);
}

void CViewUnknown::OnRButtonDown(UINT nFlags, CPoint point) 
{
   CJSTEPView::OnRButtonDown(nFlags,point);
}

void CViewUnknown::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CJSTEPView::OnLButtonDown(nFlags, point);
}

void CViewUnknown::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CJSTEPView::OnLButtonUp(nFlags, point);
}

void CViewUnknown::OnMouseMove(UINT nFlags, CPoint point) 
{
	CJSTEPView::OnMouseMove(nFlags, point);
}


void CViewUnknown::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	CJSTEPView::OnLButtonDblClk(nFlags, point);
}

void CViewUnknown::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
  if(!(GetStyle() & WS_VISIBLE))
    return;
	selectedText="";
	seltextlen=0;
	mcaptured=FALSE;
	bselect=FALSE;
	SetupUnknownList(anfaddr);	
	if(lHint && SETCURSOR)
  {
	  int item=ScrollToAddr(GetDocument()->actdisplayAddr);
    GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);
	  GetListCtrl().RedrawItems(item,item);
		GetListCtrl().UpdateWindow();
  }			
}

void CViewUnknown::OnSetPC()
{
    CMainFrame* pm= (CMainFrame*)AfxGetMainWnd();
    ULONG listaddr=GetListCtrl().GetItemData(actitem);
    prc->SetProgramCounter(listaddr);
    pm->UpdateAllWatches();
    GetListCtrl().RedrawItems(actitem,actitem);
}