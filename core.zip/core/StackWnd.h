// StackWnd.h : header file
//

#ifndef _STACKWND
#define _STACKWND 

#include "stacklist.h"
/////////////////////////////////////////////////////////////////////////////
// CStackWnd window
#define CBRS_ALIGN_STACKWND  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT |CBRS_ALIGN_BOTTOM

class CStackWnd : public CMRCSizeDialogBar
{
// Construction
public:
	void UpdateLevel0();
	void EnableUpdate(BOOL enable);
	void Clear();
	void RemoveFromCallStackWnd(ULONG returnAddr);
	void AddToCallStackWnd(ULONG callAddr,ULONG returnAddr);
	CStackList lbx;
	BOOL Create(CWnd* pParentWnd,BOOL visible=TRUE);
	CStackWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStackWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStackWnd();

	// Generated message map functions
protected:
	CProcDef* lastproc;
  	
	CObjInfo* pobj;
	int memsize;
	//{{AFX_MSG(CStackWnd)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif _STACKWND
/////////////////////////////////////////////////////////////////////////////
