// JSTEP.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "jstep.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "JSTEPView.h"
#include "ViewUnknown.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// The Processor

CProc* prc;
LPFNDLLFUNC1 HandleExtraWndUpdateCmd;
LPFNDLLFUNC2 HandleExtraWndCmd;
LPFNDLLFUNC3 HandleCommandLine;
LPFNDLLFUNC4 LoadFile;
LPFNDLLFUNC5 LoadWorkspaceFile;
LPFNDLLFUNC5 StoreWorkspaceFile;

/////////////////////////////////////////////////////////////////////////////
// CJSTEPApp

BEGIN_MESSAGE_MAP(CJSTEPApp, CWinApp)
	//{{AFX_MSG_MAP(CJSTEPApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands	
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJSTEPApp construction

CJSTEPApp::CJSTEPApp()
{  
  prc=0;
  h_rdll=0;
  pMainWnd=0; 
  dllname="";   
  hinstDLL=0;
  procname="";
  m_pszProfileName=NULL;
  ProcIsLoaded=FALSE;
}

CJSTEPApp::~CJSTEPApp()
{
	m_pszProfileName=0;
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CJSTEPApp object

CJSTEPApp theApp;
HINSTANCE hinstDLL;

/////////////////////////////////////////////////////////////////////////////
// CJSTEPApp initialization

BOOL CJSTEPApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need.
  // LoadLibrary("RICHED32.DLL");

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	GetCurrentDirectory(sizeof(exepath),exepath);
    strcat(exepath,"\\jsim.ini");
    theApp.m_pszProfileName=exepath;
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)
  
	// Register the application's document templates.  Document templates
	// serve as the connection between documents, frame windows and views.
    
     pDocTemplate
	 = new CMultiDocTemplate(
		IDR_JSTEPTYPE,
		RUNTIME_CLASS(CJSTEPDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CJSTEPView));
	AddDocTemplate(pDocTemplate);

    // die Sicht f�r Speicherbereiche die nicht �ber das Objektfile referenziert werden
    
    pDocTemplate1
	 = new CMultiDocTemplate(
		IDR_HEXFILE,
		RUNTIME_CLASS(CJSTEPDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CViewUnknown));
	AddDocTemplate(pDocTemplate1);

     pDocTemplate2
	 = new CMultiDocTemplate(
		IDR_WSPTYPE,
		RUNTIME_CLASS(CJSTEPDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CJSTEPView));
	AddDocTemplate(pDocTemplate2); 


     pDocTemplate3
	 = new CMultiDocTemplate(
		IDR_SDCTYPE,
		RUNTIME_CLASS(CJSTEPDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CJSTEPView));
	AddDocTemplate(pDocTemplate3);  
   	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
    
    
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;
   
    // Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
    if(cmdInfo.m_nShellCommand==CCommandLineInfo::FileNew)
       cmdInfo.m_nShellCommand=CCommandLineInfo::FileNothing;  // kein leeres Fenster �ffnen

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
    m_pMainWnd->DragAcceptFiles();
  	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();    
	return TRUE;
}

BOOL CJSTEPApp::IsIdleMessage( MSG* pMsg )
{
	if (!CWinApp::IsIdleMessage( pMsg ) || 
	    pMsg->message == WM_TIMER) 
		return FALSE;
	else
		return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

#define PICTOFFSET  6

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
    void OnOK(); 
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CString version;
	CBitmap bmp[4];
	int cycle;
	POINT actpoint;	

	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnGotohp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{ 
  cycle=0;
  version="JSIM, Version 4.05"; 
  //{{AFX_DATA_INIT(CAboutDlg)
  //}}AFX_DATA_INIT
}

void CAboutDlg::OnOK() 
{
  KillTimer(1);
  CDialog::OnOK();
}


void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_GOTOHP, OnGotohp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



void CALLBACK EXPORT TimerProc(
   HWND hWnd,      // handle of CWnd that called SetTimer
   UINT nMsg,      // WM_TIMER
   UINT nIDEvent,   // timer identification
   DWORD dwTime    // system time
)
{
  ::SendMessage(hWnd,nMsg,0,0);
}

BOOL CAboutDlg::OnInitDialog() 
{
  RECT rc;

  CDialog::OnInitDialog();
  GetClientRect(&rc);
  bmp[2].LoadBitmap(IDB_IMPULS1);
  bmp[1].LoadBitmap(IDB_IMPULS2);
  bmp[0].LoadBitmap(IDB_IMPULS3);
  bmp[3].LoadBitmap(IDB_IMPULS4);  
  actpoint.x=0;
  actpoint.y=65;
  SetTimer(1,20,TimerProc);
  SetDlgItemText(IDC_MKDATE,__DATE__);
  SetDlgItemText(IDC_VERSION,version);
  return TRUE; 
}



void CAboutDlg::OnTimer(UINT nIDEvent) 
{
 RECT rc;
   
   CClientDC dc(this);
   GetClientRect(&rc);
   actpoint.x+=PICTOFFSET;  
   if((actpoint.x-31)>rc.right)    
   {
     cycle++;
     if(cycle > 3)
        cycle=0; 
     actpoint.x=-31;
   }  
   
   CDC mdc;
   mdc.CreateCompatibleDC(&dc); 
   mdc.SelectObject(&bmp[cycle]); 
      
   dc.BitBlt(actpoint.x, actpoint.y, 32, 8,&mdc,0,0,SRCCOPY);    
}


// App command to run the dialog
void CJSTEPApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CJSTEPApp commands

CDocument* CJSTEPApp::OpenDocumentFile(LPCTSTR lpszFileName) 
{	
CString txt;

	CloseAllDocuments(FALSE);   
  txt=lpszFileName;
  if(txt.Find(".wsp")!=-1)
  {
    m_pszProfileName=lpszFileName;
    projectfile=theApp.GetProfileString("Project","Name",0);
    if(projectfile=="")
    {
      txt=GetProfileString("Project","Hexfile");
      if(txt != "") 
      {      
        strcpy((char*)lpszFileName,txt);
      }
    }
  }
  return CWinApp::OpenDocumentFile(lpszFileName);
}


int CJSTEPApp::ExitInstance() 
{
	if(h_rdll)
      ::FreeLibrary(h_rdll);  
    if(hinstDLL)
      ::FreeLibrary(hinstDLL); 
	return CWinApp::ExitInstance();
}


BOOL CJSTEPApp::AttachProcessor(LPCSTR dllname)
{
CString entry;
int loadsuccess; 
CProc** pprc;
    
    loadsuccess=0;
    HandleExtraWndUpdateCmd=0;
    HandleExtraWndCmd=0;
    HandleCommandLine=0;
    prc=0;  
    if(theApp.procname!="")
    {
      ::FreeLibrary(GetModuleHandle(theApp.procname));    
      theApp.procname="";
      theApp.ProcIsLoaded=FALSE;
    } 
	hinstDLL=::LoadLibrary(dllname);
    ASSERT(hinstDLL!=0);
    pprc=(CProc**)GetProcAddress(hinstDLL,"prc");
    if(pprc) 
    { 
      prc=*pprc;
      loadsuccess++;
    }
    HandleCommandLine =(LPFNDLLFUNC3)GetProcAddress(hinstDLL,"HandleCommandLine");    
    if(HandleCommandLine) 
      loadsuccess++;
    HandleExtraWndCmd =(LPFNDLLFUNC2)GetProcAddress(hinstDLL,"HandleExtraWndCmd");    
    if(HandleExtraWndCmd)  
      loadsuccess++;
    HandleExtraWndUpdateCmd =(LPFNDLLFUNC1)GetProcAddress(hinstDLL,"HandleExtraWndUpdateCmd");    
    if(HandleExtraWndUpdateCmd)  
      loadsuccess++;
    LoadFile =(LPFNDLLFUNC4)GetProcAddress(hinstDLL,"LoadFile");  
    if(LoadFile)
       loadsuccess++;  
    LoadWorkspaceFile =(LPFNDLLFUNC5)GetProcAddress(hinstDLL,"LoadWorkspaceFile");  
    if(LoadWorkspaceFile)
       loadsuccess++;
	StoreWorkspaceFile =(LPFNDLLFUNC5)GetProcAddress(hinstDLL,"StoreWorkspaceFile");  
    if(StoreWorkspaceFile)
       loadsuccess++;
    if(loadsuccess<7)  //keine g�ltige DLL
    {    
      ::FreeLibrary(hinstDLL);         
#ifdef _DEUTSCH    
      AfxGetMainWnd()->MessageBox("Das ist keine g�ltige Prozessor-DLL!","Fehler beim Laden", MB_ICONSTOP|MB_OK);
#else
      AfxGetMainWnd()->MessageBox("This is not a valid processor-DLL!","Error on load", MB_ICONSTOP|MB_OK);   
#endif      
      return FALSE;        
    }
    theApp.procname=dllname;  
    theApp.ProcIsLoaded=TRUE;     
    return TRUE;
}


void CAboutDlg::OnGotohp() 
{
	ShellExecute(m_hWnd,"open","http://home.t-online.de/home/Jens.Altmann",NULL,NULL,SW_SHOW);
}
