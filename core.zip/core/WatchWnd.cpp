// WatchWnd.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "objinfo.h"
#include "MainFrm.h"
#include "JSTEPView.h"
#include "WatchWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWatchWnd

CWatchWnd::CWatchWnd()
{
}

CWatchWnd::~CWatchWnd()
{
}


BEGIN_MESSAGE_MAP(CWatchWnd, CMRCSizeDialogBar)
	//{{AFX_MSG_MAP(CWatchWnd)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWatchWnd message handlers


BOOL CWatchWnd::Create( CWnd* pParentWnd,BOOL visible)
{
 
  BOOL b= CMRCSizeDialogBar::Create(pParentWnd, IDD_WATCH
		        ,CBRS_ALIGN_REGWND|CBRS_SIZE_DYNAMIC
						,IDD_WATCH);	  
  if(!visible)
    ModifyStyle(WS_VISIBLE,0,SWP_NOACTIVATE);
  if(b)
  {
    
	hlc.SubclassDlgItem(IDC_WATCHLST,this);
	hlc.Create();
    hlc.ContextEn=TRUE;
	SetBarStyle( GetBarStyle()			         
							 | CBRS_FLYBY 							 
							 | CBRS_BORDER_ANY 
							 | CBRS_BORDER_3D );	
    SetWindowText(_T("Watch"));
    EnableDocking(CBRS_ALIGN_WATCHWND);		
    
    RECT rd;
		GetDesktopWindow()->GetWindowRect(&rd);    		
		CPoint pt;
		pt.x=rd.right/2-50;
    pt.y=rd.bottom/2-50;	
    m_FloatingPosition=pt;  
  }  
  Created=b;
  return(b); 
}

void CWatchWnd::OnSize(UINT nType, int cx, int cy) 
{
RECT rc,re;
 
 
	CMRCSizeDialogBar::OnSize(nType, cx, cy);
	GetWindowRect(&rc);
	CHListCtrl* pe=(CHListCtrl*)GetDlgItem(IDC_WATCHLST);
	if(!pe)     
    return;
  pe->edit.ShowWindow(SW_HIDE);  
 	re.top=rc.top;
	re.left=rc.left;
  re.right=rc.right;
  re.bottom=rc.bottom;  
  ScreenToClient(&re);  	
  if(!IsFloating())
    re.top+=7;
  pe->MoveWindow(&re,TRUE);	 
  pe->GetClientRect(&rc);
  hlc.SetColumnWidth(1,rc.right-hlc.GetColumnWidth(0));  	  
}


void CWatchWnd::SizeWnd(RECT& rw,BOOL repaint)
{
RECT rc;
  
  rc=rw; 
  AfxGetMainWnd()->ScreenToClient(&rc);
  MoveWindow(&rc,repaint);
  //rc=rw;
  //rc.top=rc.top+7; 
  //hlc.MoveWindow(&rc,repaint);
  //hlc.GetClientRect(&rc);
  //hlc.SetColumnWidth(1,rc.right-hlc.GetColumnWidth(0)); 
  //if(repaint)
   // hlc.Invalidate(TRUE);
}

