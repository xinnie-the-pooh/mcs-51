// LocalWnd.h : header file
//
#ifndef _LOCALWND
#define _LOCALWND
/////////////////////////////////////////////////////////////////////////////
// CLocalWnd window

class CLocalWnd : public CWatchWnd
{
// Construction
public:	
	void UpdateLocals();
	BOOL Create( CWnd* pParentWnd ,BOOL visible=TRUE );
	CLocalWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocalWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CLocalWnd();

	// Generated message map functions
protected:
	CProcDef* pactproc;
	ULONG lowaddr;
  ULONG highaddr;
	//{{AFX_MSG(CLocalWnd)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_LOCALWND
/////////////////////////////////////////////////////////////////////////////
