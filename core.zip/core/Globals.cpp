// Globale Funktionen

#include "stdafx.h"
#include "Reginfo.h"
#include "globals.h"

// testet ob ein String eine g�ltige dezimal/hexadeziamal/bin�r Zahl- darstellt
BOOL IsNum(CString& nstr)
{
int l,i;
char c;

  nstr.MakeUpper();  //immer auf Gro�schreibung umstellen
  l=nstr.GetLength();
	i=0;	
  if(nstr.Left(2)=="0X")  //Hex
  {
		nstr.SetAt(1,'x');
		i=2;
    while(i<l)
    {
      c=nstr.GetAt(i++);
		  if( !isdigit(c) && (c<'A' || c>'F'))
       return FALSE;
    } 
  }
	else if(nstr.Right(1)!='B') //keine Bin�rzahl
  {
    while(i<l)
    {
      c=nstr.GetAt(i++);
		  if(c>'9' || c<'0')
        return FALSE;
    }
	} 	
	else  //Bin�rzahl
  {	
		l--;
		nstr.SetAt(l,'B');
    while(i<l)
    {
      c=nstr.GetAt(i++);
		  if(c>'1')
        return FALSE;
    }
	} 	
	return TRUE;
}


//liefert in dem �bergebenen String den wert der in ploc steht als
//Bin�rzahl mit der richtigen L�nge
void GetBinString(int fmt, void* ploc, CString& s)
{
char szBuff[33];
ULONG val;

  fmt &=BINARY; // allen m�glichen Mist ausblenden
  switch(fmt)
  {
		case LONG_BIN:
			val=*(ULONG*)ploc;
			break;
    case SHORT_BIN:
      val=*(USHORT*)ploc;
			break;
    case BYTE_BIN:
      val=*(UCHAR*)ploc;
			break;
    default:
			s="xxxERROR";
			return;
  } 
  int len= fmt>>5;
  szBuff[len]='B';
  szBuff[len+1]=0;
	int b=1;
  while(len--)
  {
		if(val & b)
      szBuff[len]='1';
		else
      szBuff[len]='0';
		b=b<<1;
  }
	s=szBuff;
}    

//testet ob ein String in hexzahl konvertierbar ist
BOOL IsHexString(CString& s)
{
int n,i;
 
  n=s.GetLength();
  if(s.Left(2)=="0x" || s.Left(2)=="0X")
    i=2;
  else
    i=0;
  while(i<n)
  {
		if(!isxdigit( s.GetAt(i++) ))
	    return FALSE;
  }
  return TRUE;
}

//testet ob ein String in hexzahl konvertierbar ist(Version f�r Standard strings)
BOOL IsHexString(LPCSTR s)
{
int i=0;
LPCSTR s1;
 
  s1=s;
  while(*s)
  {
		if(!isxdigit(*s) && *s !=' ')
		  return FALSE;
    if(*s==' ' &&  s>s1 )  //Leerzeichen beendet Scan wenn es nicht am Anfang steht
      return TRUE;
    s++;
  }
  return TRUE;
}

//testet ob ein String in Dezzahl konvertierbar ist
BOOL IsDezString(CString& s)
{
int n,i=0;
 
  n=s.GetLength();
  while(i<n)
  {
		if(!isdigit( s.GetAt(i++) ))
		  return FALSE;
  }
  return TRUE;
}

BOOL IsPointInRect(LPPOINT pp,RECT* pr)
{
  if(pp->x < pr->left || pp->x >pr->right)
    return FALSE;
  if(pp->y < pr->top || pp->y >pr->bottom)
    return FALSE;
  return TRUE;
}