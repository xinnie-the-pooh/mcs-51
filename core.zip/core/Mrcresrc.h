//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MRCEXT.RC
//
#define IDS_MRC_STARTDOCKING           1
//#define ID_MRC_ALLOWDOCKING            2
//#define ID_MRC_HIDE                    3
//#define ID_MRC_MDIFLOAT                4

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
