// QuickWatch.h : header file
//

#ifndef _QUICKWATCH
  #define _QUICKWATCH
#include "hlistctrl.h"
#include "resource.h"


/////////////////////////////////////////////////////////////////////////////
// CQuickWatch dialog

class CQuickWatch : public CDialog
{
// Construction
public:
	CString exprtxt;
	
	CHListCtrl hlc;
	CQuickWatch(LPCSTR expression,CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CQuickWatch)
	enum { IDD = IDD_QUICKWATCH };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQuickWatch)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CQuickWatch)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnRecalculate();
	afx_msg void OnClosequick();
	afx_msg void OnAddwatch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_QUICKWATCH