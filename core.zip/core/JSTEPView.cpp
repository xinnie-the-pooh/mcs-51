// JSTEPView.cpp : implementation of the CJSTEPView class
//

#include "stdafx.h"
#include "ModDef.h"
#include "ObjInfo.h"
#include "Proc.h"
#include "DbgBar.h"
#include "JSTEP.h"
#include "JSTEPDoc.h"
#include "JSTEPView.h"
#include "RegWnd.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "globals.h"
#include "afxtempl.h"
#include "parser.h"
#include "HListctrl.h"
#include "quickwatch.h"

#ifdef _DEBUG
  #define new DEBUG_NEW
  #undef THIS_FILE
  static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CJSTEPView

static POINT ttpoint;
static tooltipcount;

const COLORREF colortab[]=
{
  0,
  0xFF0000,
  0xFF00FF,   
  0x0000FF,
  RGB(0xD3,0x79,0x25),
  RGB(0x35,0xAE,0xCD)
};


const keydef_t keytab[]=
{
  {"void"     , 1},
  {"unsigned" , 1},
  {"signed"   , 1},
  {"char"     , 1},
  {"int"      , 1},
  {"short"    , 1},
  {"long"     , 1},
  {"return"   , 1},
  {"float"    , 1},
  {"extern"   , 1},
  {"#include" , 3},
  {"switch"   , 2},
  {"case"     , 2},
  {"default"  , 2},
  {"break"    , 1},
  {"while"    , 2},
  {"do"       , 2},
  {"if"       , 2},
  {"else"     , 2},
  {"for"      , 2},
  {"#else"    , 4},
  {"#if"      , 4},
  {"#endif"   , 4},
  {"#ifdef"   , 4},
  {"#pragma"  , 4},
  {"BYTE"     , 5}
};

#define KEYNO 26



IMPLEMENT_DYNCREATE(CJSTEPView, CListView)

BEGIN_MESSAGE_MAP(CJSTEPView, CListView)
//{{AFX_MSG_MAP(CJSTEPView)
ON_WM_MOUSEMOVE()
ON_WM_LBUTTONDOWN()
ON_WM_LBUTTONUP()
ON_WM_LBUTTONDBLCLK()
ON_WM_VSCROLL()
ON_WM_KEYDOWN()
ON_WM_SYSKEYDOWN()
ON_WM_RBUTTONDOWN()
ON_COMMAND(ID_ADDWATCH,OnAddWatch)  
ON_COMMAND(ID_SETPC,OnSetPC)  
	ON_WM_KILLFOCUS()
	//}}AFX_MSG_MAP
ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTA, 0, 0xFFFF, OnToolTipNotify)
ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTW, 0, 0xFFFF, OnToolTipNotify)
ON_MESSAGE(WM_SETFONT, OnSetFont)	
ON_WM_MEASUREITEM_REFLECT( )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJSTEPView construction/destruction
LRESULT CJSTEPView::OnSetFont(WPARAM wParam, LPARAM)
{
	LRESULT res =  Default();
	CRect rc;	
  GetWindowRect( &rc );	
  WINDOWPOS wp;	
  wp.hwnd = m_hWnd;
	wp.cx = rc.Width();
	wp.cy = rc.Height();
	wp.flags = SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER;
	SendMessage( WM_WINDOWPOSCHANGED, 0, (LPARAM)&wp );
	return res;
}

void CJSTEPView::MeasureItem ( LPMEASUREITEMSTRUCT lpMeasureItemStruct )
{
	LOGFONT lf;
	GetFont()->GetLogFont( &lf );
	if( lf.lfHeight < 0 )
		lpMeasureItemStruct->itemHeight = -lf.lfHeight+4;
 	else
		lpMeasureItemStruct->itemHeight = lf.lfHeight-4;
}

CJSTEPView::CJSTEPView(int viewmode)
{
  WNDCLASS wc;

  bkcolor=0xFFFFFF;
  actitem=-1;
  pcitem=-1;
  bselect=FALSE;
  selectedText="";
  seltextlen=0;
  mcaptured=FALSE;
  selrect.left=0;
  selrect.top=0;
  selrect.right=0;
  selrect.bottom=0;
  pmod=0;
  fwidth=0,
  m_SmallImageList.Create(IDB_SMALLTESTICO,16,1,RGB(255,255,255));
  m_SmallImageList.SetOverlayImage(0,1);
  m_SmallImageList.SetOverlayImage(5,2);
  m_SmallImageList.SetOverlayImage(6,3);
  m_SmallImageList.SetOverlayImage(7,4);
  m_clrBkgnd=::GetSysColor(COLOR_WINDOW);
  selstart=0;
  selend=0;
  enableHLL=FALSE;
  vmode=viewmode;
  // damit wird der Cursor dauerhaft umgestellt
  ::GetClassInfo(NULL,"SysListView32",&wc);
  wc.hCursor=AfxGetApp()->LoadStandardCursor(IDC_IBEAM);
  wc.lpszClassName="NList";
  wc.hInstance=AfxGetApp()->m_hInstance;
  m_strClass =wc.lpszClassName;
  AfxRegisterClass(&wc);
}

CJSTEPView::~CJSTEPView()
{
}

BOOL CJSTEPView::PreCreateWindow(CREATESTRUCT& cs)
{

  cs.style&=~LVS_TYPEMASK;
  cs.style|=LVS_REPORT | LVS_OWNERDRAWFIXED | LVS_SINGLESEL;
  return CListView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CJSTEPView diagnostics

#ifdef _DEBUG
  void CJSTEPView::AssertValid() const
  {
    CView::AssertValid();
  }
  
  void CJSTEPView::Dump(CDumpContext& dc) const
  {
    CView::Dump(dc);
  }
  
  CJSTEPDoc* CJSTEPView::GetDocument() // non-debug version is inline
  {
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CJSTEPDoc)));
    return (CJSTEPDoc*)m_pDocument;
  }
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJSTEPView message handlers

void CJSTEPView::OnInitialUpdate()
{
  if(!pmod)
    return;
  ((CMDIChildWnd*)GetParent())->SetWindowText(LPCSTR(pmod->modname));
  GetListCtrl().SetImageList(&m_SmallImageList,LVSIL_SMALL);

  lfont.CreateFont(-10,0,0,0,FW_REGULAR,
                   FALSE,FALSE,0,ANSI_CHARSET,
                   OUT_DEFAULT_PRECIS,
                   CLIP_DEFAULT_PRECIS,
                   DEFAULT_QUALITY,
                   FF_MODERN,"Courier");
  SetFont(&lfont);
  CClientDC dc(this);   
  dc.GetOutputCharWidth('0','0',&fwidth);
  EnableToolTips(TRUE);
}

void CJSTEPView::SetupList(CModDef* mp)
{
  pmod=mp;
  CObjInfo* poi=((CJSTEPDoc*)GetDocument())->pobjinfo;
  vmode=((CJSTEPDoc*)GetDocument())->GetViewMode();
  enableHLL=poi->IsHLLModule(pmod->ModID);
  ResetSelection();

  if(vmode==HLL)
  {
    SetupHLLList(mp);
  }
  else if(vmode==MIX)
  {
    SetupMIXList(mp);
  }
  else
    SetupASMList(mp);
}

void CJSTEPView::SetupASMList( CModDef* mp )
{
  ULONG i=0;
  ULONG cd;
  int r;
  int cdbyte;
  int idx=0;
  char buff[5];
  ULONG eadr;
  CString label,codebytes;
  LV_ITEM lvi;
  LV_COLUMN lvc;
  POSITION pos;
  CProcDef* pp;
  ULONG bkptfmt;
  char recmd[200];

  CWaitCursor wcur;
  SetRedraw(FALSE);
  ResetSelection();
  CListCtrl& lc=GetListCtrl();
  lc.DeleteAllItems();
  while(lc.DeleteColumn(i++)); //Alle Spalten L�schen

  // insert columns
  lvc.iSubItem=0;
  lvc.cx=40;
  lvc.pszText="BKPT";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT |LVCF_SUBITEM;
  lc.InsertColumn(0,&lvc);


  lvc.iSubItem=2;
  lvc.cx=100;
  lvc.pszText="Label";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT |LVCF_SUBITEM ;
  lc.InsertColumn(1,&lvc);

  // neu Anzeige des Speicherinhaltes 17.2.98
  lvc.iSubItem=2;
  lvc.cx=90;
  lvc.pszText="Code";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT |LVCF_SUBITEM;
  lc.InsertColumn(2,&lvc);
  // ab hier wieder weiter wie bisher

  lvc.iSubItem=3;
  lvc.cx=1000;   //geht bis ins Unendliche
  lvc.pszText="Command";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT |LVCF_SUBITEM;
  lc.InsertColumn(3,&lvc);

  CObjInfo* pobjinfo=((CJSTEPDoc*)GetDocument())->pobjinfo;
  label="";

  if(mp)
  {
    pos=mp->proclist.GetHeadPosition();
    if(!pos)
    {
       eadr=mp->GetHighAddr();
       i=mp->GetLowAddr();
       goto setupasm1;
    }
    while(pos)
    {
      pp=(CProcDef*)mp->proclist.GetNext(pos);
      if(pp->Procname !="CONST")
      {
        if(pp->AnfAddr!=-1 && pp->EndAddr)
        {
          i=pp->AnfAddr;
          eadr=pp->EndAddr;
        }
        else
        {
          labeldef_t* lp=pobjinfo->FindLabel(&pp->Procname);
          i=lp->addr;
          eadr=mp->GetHighAddr();
        }
setupasm1:
        while(i<=eadr)
        {
          bkptfmt=prc->IsBreakpointAtAddr(i);
          if(bkptfmt&BKPT_CODE  && !(bkptfmt & BKPT_DISABLED))
            prc->RestoreOpcode(i);
          lvi.mask=LVIF_PARAM | LVIF_IMAGE;
          lvi.iItem=idx;
          lvi.iSubItem=0;
          lvi.iImage=3;  //leer aber g�ltige Adresse
          lvi.lParam=i;
          lc.InsertItem(&lvi);
          pobjinfo->FindLabel(i,label,CODEMEM,LOCSYM|PUBSYM,8);
          lc.SetItemText(idx,1,LPCSTR(label));
          r=prc->Reassemble(i,recmd,(HANDLE)mp);
          codebytes="";
          for(cdbyte=0;cdbyte<r;cdbyte++)
          {
            prc->GetMemFromAddr(i+cdbyte,&cd,CODEMEM);
            sprintf(buff,"%2.2X ",cd);
            codebytes+=buff;
          }
          lc.SetItemText(idx,2,codebytes);

          if(bkptfmt&BKPT_CODE  && !(bkptfmt & BKPT_DISABLED))
            prc->RestoreBkpt(i);
          lc.SetItemText(idx,3,recmd);
          idx++;
          i+=r;
        }
      }
    }
  }
  SetRedraw(TRUE);
}

void CJSTEPView::SetupMIXList( CModDef* mp )
{
CStdioFile srcfile;
ULONG lineno;
CString srcline,label;
LV_ITEM lvi;
LV_COLUMN lvc;
ULONG i,n;
ULONG addr,eadr;
ULONG bkptfmt;
int r;
int idx=0;
int lastidx;
ULONG lastaddr;
char linestr[10];
char recmd[200];


  if(mp->SrcPath=="")
  {
    mp->SrcPath=mp->modname + ".c";
    srcline=GetDocument()->GetPathName();
    int i=srcline.ReverseFind('\\');
    mp->SrcPath=srcline.Left(i+1) + mp->SrcPath;
  }
  if(!srcfile.Open(mp->SrcPath,CFile::modeRead))
  {
    mp->SrcPath=mp->modname + ".c51";  //auch diese M�glichkeit soll funktionieren
    srcline=GetDocument()->GetPathName();
    int i=srcline.ReverseFind('\\');
    mp->SrcPath=srcline.Left(i+1) + mp->SrcPath;
    if(!srcfile.Open(mp->SrcPath,CFile::modeRead))
    {
      vmode=ASM;
      enableHLL=FALSE; //HLL-Info steht nicht zur Verf�gung
      SetupASMList( mp );  //Quellfile nicht gefunden -> ASM-laden
      return;
    }
  }
  CWaitCursor wcur;
  SetRedraw(FALSE);
  ResetSelection();
  CListCtrl& lc=GetListCtrl();
  i=0;
  while(lc.DeleteColumn(i++)); //Alle Spalten L�schen
  lc.DeleteAllItems();

  // insert columns
  lvc.iSubItem=0;
  lvc.cx=40;
  lvc.pszText="BKPT";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;
  lc.InsertColumn(0,&lvc);

  lvc.iSubItem=1;
  lvc.cx=100;
  lvc.pszText="Label";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;
  lc.InsertColumn(1,&lvc);

  lvc.iSubItem=2;
  lvc.cx=1000;   //geht bis ins Unendliche
  lvc.pszText="Command";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;//| LVCF_SUBITEM ;
  lc.InsertColumn(2,&lvc);

  CObjInfo* pobjinfo=((CJSTEPDoc*)GetDocument())->pobjinfo;
  lineno=0;

  //erst mal den HLL-code laden
  lvi.mask=LVIF_PARAM | LVIF_IMAGE;
  lvi.iSubItem=0;
  lastidx=-1;
  lastaddr=(ULONG)-1;
  while(srcfile.ReadString(srcline)) //bis das Fileende erreicht ist
  {
    lineno++;
    ReplaceTabs(srcline);
    if(!pobjinfo->FindLineAddr(lineno,pmod->ModID,&addr))
    {  //der Zeile ist kein Code zugeordnet
      lvi.iItem=idx;
      lvi.iImage=4;  //leer aber Kennung das Codebezug in LPARAM ung�ltig ist
      lvi.lParam=addr;
      lc.InsertItem(&lvi);
      lc.SetItemText(idx++,2,srcline);  //Src-line einf�gen
    }
    else
    {  //der Zeile ist Code zugeordnet
      if(lastaddr==addr)
      {
        lvi.iItem=lastidx;
        lvi.iImage=4;  //leer aber Kennung das Codebezug in LPARAM ung�ltig ist
        lvi.lParam=addr;
        lc.SetItem(&lvi);
      }
      lvi.iItem=idx;
      lvi.iImage=3;  //leer aber Kennung das Codebezug in LPARAM g�ltig ist#
      lvi.lParam=addr;
      lc.InsertItem(&lvi);
      sprintf(linestr,"L%d:",lineno);
      lastidx=idx;
      lc.SetItemText(idx,1,linestr);
      lc.SetItemText(idx++,2,srcline);  //Src-line einf�gen
      lastaddr=addr;

    }
  }
  
  n=lc.GetItemCount(); //die Anzahl der HLL-Zeilen
  ULONG fromline=0;
  r=0;
  while(fromline < n)   //beginne mit der ersten Zeile
  {
    lvi.iItem=fromline;
    lc.GetItem(&lvi);
    if(lvi.iImage!=3) // HLL-Codebezug ist nicht g�ltig
    {
      fromline++; 
      continue;        //weiter
    }
    addr=lvi.lParam;
    CProcDef* pp=theApp.objinfo.GetProcFromAddr(addr,pmod);
    if(!pp)
      eadr=pmod->GetHighAddr()+1;
    else
      eadr=pp->EndAddr+1;
    i=addr;
    BOOL b=pobjinfo->FindNextHLLAddress(&addr,mp->ModID);
    if(b && addr<eadr)
      eadr=addr;
    while(i<eadr)
    {
      //wenn auf die Addr.ein Breakpoint gesetzt ist wird er tempor�r entfernt
      bkptfmt=prc->IsBreakpointAtAddr(i);
      if(bkptfmt&BKPT_CODE  && !(bkptfmt & BKPT_DISABLED))
        prc->RestoreOpcode(i);
      lvi.mask=LVIF_PARAM | LVIF_IMAGE;
      fromline++; //schiebt sich nach hinten
      lvi.iItem=fromline;
      lvi.iSubItem=0;
      lvi.iImage=2;  //leer
      lvi.lParam=i;  //Adresse des Opcodes
      lc.InsertItem(&lvi);      
      label.Format("%8.4X",i);
      lc.SetItemText(fromline,1,LPCSTR(label));
      r=prc->Reassemble(i,recmd,(HANDLE)mp);
      if(bkptfmt&BKPT_CODE  && !(bkptfmt & BKPT_DISABLED))
        prc->RestoreBkpt(i);
      lc.SetItemText(fromline,2,recmd);      
      i+=r;
    }
    fromline++;
    n=lc.GetItemCount(); //die gesamtAnzahl der Zeilen
  }

  lineno=lc.GetItemCount();
  dispstate.SetSize(lineno);
  i=0;
  lvi.mask=LVIF_PARAM | LVIF_IMAGE;
  lvi.iSubItem=0;
  SetRedraw(TRUE);

  while(i<lineno)
  {
    lvi.iItem=i;
    lc.GetItem(&lvi);
    if(lvi.iImage==3) // HLL-Codebezug ist g�ltig
      dispstate.SetAt(i,(WORD)(LINEADDRVALID | ISHLLLINE));
    else if(lvi.iImage==4)
      dispstate.SetAt(i,(WORD)(ISHLLLINE));
    else
      dispstate.SetAt(i,(WORD)LINEADDRVALID);
    i++;
  }

}


void CJSTEPView::SetupHLLList( CModDef* mp )
{
CStdioFile srcfile;
ULONG lineno;
CString srcline;
LV_ITEM lvi;
LV_COLUMN lvc;
ULONG i=0;
ULONG addr,lastaddr;
WORD s;

  if(mp->SrcPath=="")
  {
    mp->SrcPath=mp->modname + ".c";
    srcline=GetDocument()->GetPathName();
    int i=srcline.ReverseFind('\\');
    mp->SrcPath=srcline.Left(i+1) + mp->SrcPath;
  }
  if(!srcfile.Open(mp->SrcPath,CFile::modeRead))
  {
    mp->SrcPath=mp->modname + ".c51";  //auch diese M�glichkeit soll funktionieren
    srcline=GetDocument()->GetPathName();
    int i=srcline.ReverseFind('\\');
    mp->SrcPath=srcline.Left(i+1) + mp->SrcPath;
    if(!srcfile.Open(mp->SrcPath,CFile::modeRead))
    {
      vmode=ASM;
      enableHLL=FALSE; //HLL-Info steht nicht zur Verf�gung
      SetupASMList( mp );  //Quellfile nicht gefunden -> ASM-laden
      return;
    }
  }
  CWaitCursor wcur;
  SetRedraw(FALSE);
  ResetSelection();
  CListCtrl& lc=GetListCtrl();
  while(lc.DeleteColumn(i++)); //Alle Spalten L�schen
  lc.DeleteAllItems();

  // insert columns
  lvc.iSubItem=0;
  lvc.cx=40;
  lvc.pszText="BKPT";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;
  lc.InsertColumn(0,&lvc);

  lvc.iSubItem=1;
  lvc.cx=1000;    //geht bis ins Unendliche
  lvc.pszText="SourceCode";
  lvc.mask=LVCF_WIDTH | LVCF_TEXT;
  lc.InsertColumn(1,&lvc);

  CObjInfo* pobjinfo=((CJSTEPDoc*)GetDocument())->pobjinfo;

  lineno=0;

  while(srcfile.ReadString(srcline))
  {
    lvi.iItem=lineno;
    lvi.mask=LVIF_PARAM | LVIF_IMAGE;
    lvi.iSubItem=0;
    if(pobjinfo->FindLineAddr(lineno+1,pmod->ModID, (ULONG*)&lvi.lParam))
      lvi.iImage=3;  //leer aber Kennung das Zeile g�ltigen Bezug zu einer CodeAdresse hat
    else
      lvi.iImage=4;  //leer und Kennung das Zeile keinen Bezug zu einer Code-adresse hat
    lc.InsertItem(&lvi);   //lParam der 1.Spalte enth�lt die zugeh.Adresse
    ReplaceTabs(srcline);
    lc.SetItemText(lineno,1,srcline);
    lineno++;
  }
  dispstate.SetSize(lineno);
  i=0;
  ULONG prevcomment=0;   //Zustand des Zeilenendes der vorangegangenen Zeile
  lvi.mask=LVIF_PARAM | LVIF_IMAGE ;
  lvi.iSubItem=0;
  while(i<lineno)
  {
    lvi.iItem=i;
    lc.GetItem(&lvi);
    srcline=lc.GetItemText(i,1);
    GetCommentState(srcline,&prevcomment);
    if(lvi.iImage==3)
      dispstate.SetAt(i,(WORD)(prevcomment | LINEADDRVALID)); //Zeile hat Referenz auf Code
    else if(lvi.iImage==4)
      dispstate.SetAt(i,(WORD)(prevcomment));
    i++;
  }

  SetRedraw(TRUE);
  lastaddr=0;
  while(i--)
  {
    s=dispstate.GetAt(i);
    if(s & LINEADDRVALID)
    {
      addr=lc.GetItemData(i);
      if(addr==lastaddr)
      {
        s &= ~LINEADDRVALID;   //damit wird verhindert das eine Zeile
        dispstate.SetAt(i,s);  //doppelt mit dem ASM-code verbunden wird
      }
      else
        lastaddr=addr;
    }
  }
}


void CJSTEPView::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
CImageList* pImageList;
int nItem;
static char szBuff[MAX_PATH];
LV_ITEM lvi;
LV_COLUMN lvc;
BOOL bSelected;
UINT uiFlags;
CRect rcIcon,rcLabel;
int len;
CRect rcItem;
CDC* pDC;
CFont* oldfont;
WORD s;
int bkptimage;

  s=0;
  if(selstart != selend)
    DrawSelection();
  uiFlags=0 ; //=ILD_TRANSPARENT;
  CListCtrl& ListCtrl=GetListCtrl();
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
  oldfont=pDC->SelectObject(&lfont);
  rcItem=lpDrawItemStruct->rcItem;
  nItem=lpDrawItemStruct->itemID;
  //TRACE("rdw: %d\n",nItem);
  len=ListCtrl.GetColumnWidth(0);
  if(len<40)
  {
    ListCtrl.SetColumnWidth(0,40);
    return;
  }
  // get item data
  // Icon in der ersten Spalte

  lvi.mask=LVIF_IMAGE | LVIF_STATE | LVIF_PARAM;
  lvi.iItem=nItem;
  lvi.iSubItem=0;
  lvi.stateMask=0xFFFF;   // get all state flags
  ListCtrl.GetItem(&lvi);
  bSelected=lvi.state & LVIS_SELECTED;
  if(vmode!=ASM)
    s=dispstate.GetAt(nItem);
  if((ULONG)lvi.lParam== prc->GetProgramCounter())
  {
    if((lvi.iImage<4) && (vmode==ASM) ) //iImage=3 bedeutet die Adresse ist g�ltig
    {
      uiFlags|=INDEXTOOVERLAYMASK(1);        //wenn der Eintrag die Adresse des
      if(nItem!=pcitem)                      //aktuellen PC besitzt wird ein gelber
      {                                      //Pfeil, =1.Eintrag in der Overlayliste angezeigt
        ListCtrl.RedrawItems(pcitem,pcitem);
        pcitem=nItem;                        //Merken wer den gelben Pfeil jetzt hat
      }
    }

    else if((lvi.iImage<4) && (vmode==MIX))
    {
      if(!(s & ISHLLLINE))              //im MIX-mode wird der aktuelle PC
      {
        uiFlags|=INDEXTOOVERLAYMASK(1); //nur in den ASM Zeilen angezeigt
        if(nItem!=pcitem)      // wenn vorher ein anderer den gelben Pfeil hatte
        {
          ListCtrl.RedrawItems(pcitem,pcitem);
          pcitem=nItem;                   //Merken wer den gelben Pfeil jetzt hat
        }
      }
    }
    else if(vmode==HLL)
    {
      if(s & LINEADDRVALID)             //im MIX-mode wird der aktuelle PC
      {
        uiFlags|=INDEXTOOVERLAYMASK(1); //nur in der letzten Zeile angezeigt
        if(nItem!=pcitem)      // wenn vorher ein anderer den gelben Pfeil hatte
        {
          ListCtrl.RedrawItems(pcitem,pcitem);
          pcitem=nItem;                   //Merken wer den gelben Pfeil jetzt hat
        }
      }
    }
  }

  else if(lvi.state & LVIS_CUT)
  {
    uiFlags|=INDEXTOOVERLAYMASK(4);
  }
  else if(bSelected)   //nur dann wird das Icon freigegeben
  {
    actitem=nItem;
    uiFlags|=INDEXTOOVERLAYMASK(2); // wenn der Eintrag selektiert ist
    // wird ein grauer Pfeil angezeigt
    // = 2.Eintrag in der Overlayliste
  }

  // Wenn der lParam des Eintrages auf eine g�ltige Adresse zeigt
  // und ein Breakpoint gesetzt ist
  bkptimage=-1;
  ULONG bkptfmt=prc->IsBreakpointAtAddr(lvi.lParam);
  if(bkptfmt & BKPT_CODE)
  {
    if(! (bkptfmt & BKPT_DISABLED))
      bkptimage=1;    //Breakpointsymbol ,wird nur auf asm-Zeilen angezeigt
    else
      bkptimage=6;

    if((lvi.iImage<4) && (vmode==MIX))
    {
      if(!(s & ISHLLLINE))
        lvi.iImage=bkptimage;
    }
    else if(vmode==ASM)
      lvi.iImage=bkptimage;       //Breakpointsymbol
    else if((vmode==HLL) && (s & LINEADDRVALID))
      lvi.iImage=bkptimage;   //Breakpointsymbol ,wird nur auf der letzen LINE
    //des Adressbezugs angezeigt wenn mehre existieren
  }

  //Tracepoint darstellen wenn vorhanden
  CJSTEPDoc* pdoc=((CMainFrame*)AfxGetMainWnd())->pDoc;
  if(pdoc->tpt.IsTracePointAtAddr(lvi.lParam) && pdoc->tpt.isValid)
  {
    if(   (vmode==MIX && !(s & ISHLLLINE))
          || (vmode==HLL && (s & LINEADDRVALID))
          ||  vmode==ASM )
    {
      if(bkptimage == -1) // wenn nicht gerade ein Breakpoint dargestellt wird
        lvi.iImage=8;
      else
        lvi.iImage=9;
      pdoc->tpt.pv=&ListCtrl;
      pdoc->tpt.item=nItem;
    }
  }

  //Messpunkt darstellen wenn vorhanden
  if(pdoc->mpt.addr==(ULONG)lvi.lParam  && pdoc->mpt.isValid)
  {
    if(   (vmode==MIX && !(s & ISHLLLINE))
          || (vmode==HLL && (s & LINEADDRVALID))
          ||  vmode==ASM )
    {
      lvi.iImage=10;
      pdoc->mpt.pv=&ListCtrl;
      pdoc->mpt.item=nItem;
    }
  }

  //Stimulationspunkt darstellen wenn vorhanden
  if(pdoc->stpt.addr==(ULONG)lvi.lParam  && pdoc->stpt.isValid)
  {
    if(   (vmode==MIX && !(s & ISHLLLINE))
          || (vmode==HLL && (s & LINEADDRVALID))
          ||  vmode==ASM )
    {
      lvi.iImage=12;
      pdoc->stpt.pv=&ListCtrl;
      pdoc->stpt.item=nItem;
    }
  }


  // draw normal and overlay icon

  ListCtrl.GetItemRect(nItem,rcIcon,LVIR_ICON);
  pImageList=ListCtrl.GetImageList(LVSIL_SMALL);
  if(pImageList)
  {
    if(rcItem.left<rcItem.right-1)
      ImageList_DrawEx(pImageList->m_hImageList
                       ,lvi.iImage   //normal Icon
                       ,pDC->m_hDC
                       ,rcIcon.left
                       ,rcIcon.top
                       ,16,16
                       ,CLR_DEFAULT
                       ,0
                       ,uiFlags);  //Mask
  }
  ListCtrl.GetItemRect(nItem,rcItem,LVIR_LABEL);

  //write Text
  if(vmode==ASM )
  {
    len=ListCtrl.GetColumnWidth(1);
    if(len<80)
    {
      ListCtrl.SetColumnWidth(1,80);
      return;
    }
    // draw labels for column 1
    lvc.mask=LVCF_FMT | LVCF_WIDTH;
    ListCtrl.GetColumn(1,&lvc);
    rcItem.left=rcItem.right;
    rcItem.right+=lvc.cx;
    len=ListCtrl.GetItemText(nItem,1,szBuff,sizeof(szBuff));
    rcLabel=rcItem;
    rcLabel.left+=OFFSET_OTHER;

    if(isdigit(szBuff[0]) || szBuff[0]==' ')
    {
      pDC->SetTextColor(0x808080);
      pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
      pDC->SetTextColor(0);
    }
    else
      pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);

    //draw labels for column 2
    pDC->SetTextColor(0xC00000L);
    ListCtrl.GetColumn(2,&lvc);
    rcItem.left=rcItem.right;
    rcItem.right+=lvc.cx;
    len=ListCtrl.GetItemText(nItem,2,szBuff,sizeof(szBuff));
    rcLabel=rcItem;
    rcLabel.left+=OFFSET_OTHER;
    pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);

    // draw labels for column 3
    ListCtrl.GetColumn(3,&lvc);
    if(bselect && nItem==actitem  && selstart != selend)
    {
      DrawSelection();  // Item ist selektiert
    }
    else
    {
      lvc.mask=LVCF_FMT | LVCF_WIDTH;
      rcItem.left=rcItem.right;
      rcItem.right+=lvc.cx;
      len=ListCtrl.GetItemText(nItem,3,szBuff,sizeof(szBuff));
      rcLabel=rcItem;
      rcLabel.left+=OFFSET_OTHER;
      pDC->SetTextColor(0);
      pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
    }
    pDC->SelectObject(oldfont);
  }
  else if(vmode==MIX)
  {
    len=ListCtrl.GetColumnWidth(1);
    if(len<80)
    {
      ListCtrl.SetColumnWidth(1,80);
      return;
    }
    // draw labels for column 1
    lvc.mask=LVCF_FMT | LVCF_WIDTH;
    ListCtrl.GetColumn(1,&lvc);
    rcItem.left=rcItem.right;
    rcItem.right+=lvc.cx;

    lvi.mask=LVIF_IMAGE | LVIF_TEXT | LVIF_PARAM;
    lvi.iItem=nItem;
    lvi.iSubItem=1;
    lvi.cchTextMax=sizeof(szBuff);
    lvi.pszText=szBuff;
    ListCtrl.GetItem(&lvi);
    ULONG s=dispstate.GetAt(nItem);  // Info �ber Zeileninhalt
    rcLabel=rcItem;
    rcLabel.left+=OFFSET_OTHER;

    if(s & ISHLLLINE)  //HLL-Linien
    {
      pDC->SetTextColor(0xC00000L);
      pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW | DT_NOCLIP);
    }
    else
    {

      if(isdigit(szBuff[0]) || szBuff[0]==' ')  //Adressen
      {
        pDC->SetTextColor(0x808080);
        pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
        pDC->SetTextColor(0);
      }
      else       //ASM- Labels
        pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
    }

    // draw labels for column 2
    ListCtrl.GetColumn(2,&lvc);
    if(bselect && nItem==actitem && selstart != selend)
    {
      DrawSelection();  // Item ist selektiert
    }
    else
    {
      if(s & ISHLLLINE)  //HLL-Linien
        pDC->SetTextColor(0xC00000L);
      lvc.mask=LVCF_FMT | LVCF_WIDTH;
      rcItem.left=rcItem.right;
      rcItem.right+=lvc.cx;
      len=ListCtrl.GetItemText(nItem,2,szBuff,sizeof(szBuff));
      rcLabel=rcItem;
      rcLabel.left+=OFFSET_OTHER;
      pDC->DrawText(szBuff,-1,rcLabel,DEFAULT_TEXTDRAW);
    }
    pDC->SetTextColor(0);
    pDC->SelectObject(oldfont);
  }
  else if(vmode==HLL)
  {
    CString txt;
    // draw labels for column 1
    lvc.mask=LVCF_FMT | LVCF_WIDTH;
    ListCtrl.GetColumn(1,&lvc);
    rcItem.left=rcItem.right;
    rcItem.right+=lvc.cx;
    rcLabel=rcItem;
    rcLabel.left+=OFFSET_OTHER;
    txt=ListCtrl.GetItemText(nItem,1);
    if(nItem)
    {
      if( dispstate.GetAt(nItem-1) & COMMENTOPEN ) // offener Kommentar von der vergangenen Zeile
      {
        DrawCommentFromPos(pDC,txt,rcLabel);
        while(txt.GetLength())
          DrawCodeFromPos(pDC,txt,rcLabel);
      }
      else
      {
        while(txt.GetLength())
          DrawCodeFromPos(pDC,txt,rcLabel);
      }
    }
    else
    {
      while(txt.GetLength())
        DrawCodeFromPos(pDC,txt,rcLabel);
    }
    return;
  }
}

void CJSTEPView::SetIcon(int Icoidx, int nitem)
{
  LV_ITEM lvi;

  CListCtrl& ListCtrl=GetListCtrl();
  lvi.mask=LVIF_IMAGE | LVIF_STATE;
  lvi.iSubItem=0;
  lvi.iItem=nitem;
  if(ListCtrl.GetItem(&lvi))
  {
    lvi.mask=LVIF_IMAGE;
    lvi.iImage=Icoidx;
    ListCtrl.SetItem(&lvi);
  }
}

void CJSTEPView::OnMouseMove(UINT nFlags, CPoint point)
{
  if(!(nFlags & MK_LBUTTON))
  {
    ReleaseCapture();
    mcaptured=FALSE;
  }
  if(mcaptured)
  {
    if(point.x > selrect.right)
      selend=seltextlen  ;    //Anschlag rechts
    else if(point.x < selrect.left)
      selend=0;               //Anschlag links
    else
    {
      int l=(point.x-selrect.left)/fwidth;
      selend=l + 2*((point.x-selrect.left)%fwidth)/fwidth;
    }
    if(selstart==selend)
    {
      CListView::OnMouseMove(nFlags, point);
      return;
    }
    DrawSelection(bkcolor);
  }
  CListView::OnMouseMove(nFlags, point);
}

void CJSTEPView::OnLButtonDown(UINT nFlags, CPoint point)
{
  LV_HITTESTINFO lvh;
  int nItem;

  if(nFlags & MK_LBUTTON)
  {
    ReleaseCapture();
    CListCtrl& listCtrl=GetListCtrl();
    selectedText="";
    seltextlen=0;
    selend=selstart;
    listCtrl.RedrawItems(actitem,actitem);
    if(bselect)
    {
      //TRACE("MD, beselect=TRUE\n");  //TRACE
      bselect=FALSE;
      actitem=-1;
    }
    else
    {
      lvh.pt=point;
      nItem=listCtrl.HitTest(&lvh);
      if(nItem!=-1)
      {
        actitem=nItem;
        ULONG listaddr=GetListCtrl().GetItemData(nItem);
        if(vmode != ASM)
        {
          ULONG linestate= dispstate.GetAt(nItem);
          if(linestate & LINEADDRVALID)
            GetDocument()->actdisplayAddr=listaddr;
        }
        else
          GetDocument()->actdisplayAddr=listaddr;
        RecalcSelrect(actitem);
        if(::PtInRect(&selrect,point)) //szBuff
        {
          mcaptured=TRUE;
          bselect=TRUE;
          selstart=(point.x-selrect.left)/fwidth;
          selend=selstart;
          SetCapture();
          //TRACE("MD, beselect=FALSE, StartCapture, item=%d\n",nItem);  //TRACE
        }
        else
        {
          //TRACE("MD, beselect=FALSE, nicht in selrect , item=%d\n",nItem);  //TRACE
          selend=selstart;
        }
      }
    }
  }
  CListView::OnLButtonDown(nFlags, point);
}

void CJSTEPView::OnLButtonUp(UINT nFlags, CPoint point)
{
  ReleaseCapture();
  if(mcaptured==TRUE)
  {
    //TRACE("MU, StopCapture, capture=TRUE\n"); //TRACE
    selectedText=szBuff;
    if(selend>selstart)
      selectedText=selectedText.Mid(selstart,selend-selstart);
    else
      selectedText=selectedText.Mid(selend,selstart-selend);
    mcaptured=FALSE;
  }

  else
  {
    //TRACE("MU, StopCapture, capture=FALSE\n"); //TRACE
  }
  CListView::OnLButtonUp(nFlags, point);
}

void CJSTEPView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
  ULONG addr;
  //TRACE("MDC\n"); //TRACE

  ReleaseCapture();
  mcaptured=FALSE;

  if(actitem!=-1)
  {
    RecalcSelrect(actitem);
    if(::PtInRect(&selrect,point))
    {
      selstart=(point.x-selrect.left)/fwidth;
      selend=selstart;
      while(isalnum(szBuff[selend]))
        selend++;
      while(isalnum(szBuff[selstart]) && selstart>-1)
        selstart--;
      if(selend-selstart)
      {
        selstart++;
        selectedText=szBuff;
        selectedText=selectedText.Mid(selstart,selend-selstart);
        addr=GetListCtrl().GetItemData(actitem);
        CObjInfo* pobjinfo=&(((CJSTEPApp*)AfxGetApp())->objinfo);
        CProcDef* pp=pobjinfo->GetProcFromAddr(addr);
        if(pp)
        {
          if(pp->Procname == "LIB") //eine globale Variable ausserhalb eine Prozedur
            selectedText=pmod->modname + ":" + selectedText;
          else
            selectedText=pmod->modname + ":" +pp->Procname + ":" + selectedText;
        }
        DrawSelection();
      }
    }
  }

  CListView::OnLButtonDblClk(nFlags, point);
}

void CJSTEPView::DrawSelection(COLORREF bkcolor)
{
  COLORREF oldtxtcolor,oldbkcolor;
  int colright;
  RECT rc;

  if(actitem==-1)
    return;
  CClientDC dc(this);
  dc.SetBkColor(bkcolor);
  GetClientRect(&rc);
  colright=rc.right-OFFSET_OTHER;
  CListCtrl& listCtrl=GetListCtrl();
  listCtrl.GetItemRect(actitem,&selrect,LVIR_LABEL);
  selrect.left=selrect.right;
  selrect.left+=OFFSET_OTHER;
  if(vmode==MIX)
  {
    selrect.left+=listCtrl.GetColumnWidth(1);
    seltextlen=listCtrl.GetItemText(actitem,2,szBuff,sizeof(szBuff));
    if(dispstate.GetAt(actitem) & ISHLLLINE)
      dc.SetTextColor(0xC00000L);
  }
  if(vmode==ASM )
  {
    selrect.left+=listCtrl.GetColumnWidth(1);
    selrect.left+=listCtrl.GetColumnWidth(2);
    seltextlen=listCtrl.GetItemText(actitem,3,szBuff,sizeof(szBuff));

  }
  else if(vmode==HLL)
  {
    seltextlen=listCtrl.GetItemText(actitem,1,szBuff,sizeof(szBuff));
  }
  int textwidth=(seltextlen+1)*fwidth;
  selrect.right=selrect.left+textwidth-OFFSET_OTHER;
  if(selrect.right>colright)
    selrect.right=colright;

  CRect rcdraw(selrect);
  CFont* oldfont=dc.SelectObject(&lfont);
  if(selstart<selend)
    rcdraw.right=rcdraw.left+selstart*fwidth;
  else
    rcdraw.right=rcdraw.left+selend*fwidth;
  if(rcdraw.right>colright)
    rcdraw.right=colright;
  if(selstart<selend)
    dc.DrawText(szBuff,selstart,LPRECT(rcdraw),DEFAULT_TEXTDRAW);
  else
    dc.DrawText(szBuff,selend,LPRECT(rcdraw),DEFAULT_TEXTDRAW);
  rcdraw.left=rcdraw.right;
  rcdraw.right+=(abs(selend-selstart))*fwidth;
  if(rcdraw.right>colright)
    rcdraw.right=colright;
  oldtxtcolor=dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
  oldbkcolor=dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
  if(selstart<selend)
    dc.DrawText(&szBuff[selstart],abs(selend-selstart),LPRECT(rcdraw),DEFAULT_TEXTDRAW);
  else
    dc.DrawText(&szBuff[selend],abs(selend-selstart),LPRECT(rcdraw),DEFAULT_TEXTDRAW);
  dc.SetTextColor(oldtxtcolor);
  dc.SetBkColor(oldbkcolor);
  rcdraw.left=rcdraw.right;
  rcdraw.right=selrect.right;

  if(selstart<selend)
    dc.DrawText(&szBuff[selend],strlen(&szBuff[selend]),LPRECT(rcdraw),DEFAULT_TEXTDRAW);
  else
    dc.DrawText(&szBuff[selstart],strlen(&szBuff[selstart]),LPRECT(rcdraw),DEFAULT_TEXTDRAW);
  dc.SelectObject(oldfont);
}

void CJSTEPView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
  if(bActivate) //nur bei Aktivierung
  {
    ReleaseCapture();
    CMainFrame* pmainwnd=(CMainFrame*)AfxGetMainWnd();
  }
  CListView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}


void CJSTEPView::RecalcSelrect(int item)
{
  int colright=0;
  int textwidth=0;

  CListCtrl& listCtrl=GetListCtrl();
  listCtrl.GetItemRect(item,&selrect,LVIR_LABEL);
  selrect.left=selrect.right;
  if(vmode==MIX)  // Quelltext steht in der 3.Spalte
  {
    selrect.left+=listCtrl.GetColumnWidth(1);
    colright=selrect.left+listCtrl.GetColumnWidth(2);
    selrect.left+=OFFSET_OTHER;
    if(seltextlen)
    {
      textwidth=(seltextlen+1)*fwidth;
    }
    else
    {
      seltextlen=listCtrl.GetItemText(item,2,szBuff,sizeof(szBuff));
      textwidth=(seltextlen+1)*fwidth;
    }
  }
  else if(vmode==ASM)  // Quelltext steht in der 4.Spalte
  {
    selrect.left+=listCtrl.GetColumnWidth(1)+listCtrl.GetColumnWidth(2);
    colright=selrect.left+listCtrl.GetColumnWidth(3);
    selrect.left+=OFFSET_OTHER;
    if(seltextlen)
    {
      textwidth=(seltextlen+1)*fwidth;
    }
    else
    {
      seltextlen=listCtrl.GetItemText(item,3,szBuff,sizeof(szBuff));
      textwidth=(seltextlen+1)*fwidth;
    }
  }

  else if(vmode==HLL)  // Quelltext steht in der 2.Spalte
  {
    seltextlen=listCtrl.GetItemText(item,1,szBuff,sizeof(szBuff));
    textwidth=(seltextlen+1)*fwidth;
    selrect.left+=OFFSET_OTHER;
    colright=selrect.left+listCtrl.GetColumnWidth(1);
  }

  selrect.right=selrect.left+textwidth+2;
  if(selrect.right>colright)
    selrect.right=colright;
}

void CJSTEPView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
  if(actitem!=-1)
    RecalcSelrect(actitem);
  CListView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CJSTEPView::SetViewMode(int viewmode)
{
  if(pmod &&  vmode!=vmode) // wenn das Modul schon definiert ist -> Liste neu aufbauen
  {
    if(vmode==HLL)
    {
      if(GetDocument()->pobjinfo->IsHLLModule(pmod->ModID))
      {
        viewmode=HLL;
        SetupHLLList(pmod);
      }
      else
      {
        viewmode=ASM;   // viewmode wird auf ASM zur�ckgestellt weil
        // das SRC-File nicht gefunden wurde
        SetupASMList(pmod);
      }
    }

    else if(vmode==MIX)
    {
      if(GetDocument()->pobjinfo->IsHLLModule(pmod->ModID))
      {
        viewmode=MIX;
        SetupMIXList(pmod);
      }
      else
      {
        viewmode=ASM;   // viewmode wird auf ASM zur�ckgestellt weil
        // das SRC-File nicht gefunden wurde
        SetupASMList(pmod);
      }
    }
    else
      SetupASMList(pmod);
  }
}

ULONG CJSTEPView::GetCommentState(CString& srcline, ULONG* prevcomment)
{
  int c,c0;

  if(*prevcomment & COMMENTOPEN)  // die vorangegangene Zeile hat den Kommentar nicht geschlossen
  {
    c=srcline.Find("*/");
    if( c == -1 )  //Zeile beendet den Kommentar nicht
    {
      return(COMMENTOPEN);
    }
    else  //der Kommentar wird in der Zeile geschlossen
    {
      c=srcline.ReverseFind('*'); //sucht ob die Zeile einen neuen Kommentar �ffnet
      c0=srcline.ReverseFind('/');
      if(c != -1 && c0 !=-1 && c-c0==1 )  //Zeile �ffnet einen neuen Kommentar
      {
        return(COMMENTOPEN);
      }
      else       //Zeile endet ohne offenem Kommentar
      {
        *prevcomment &= ~COMMENTOPEN;
        return(0);
      }
    }
  }
  else
  {
    c=srcline.Find("/*");  // suche ob die Zeile einen neuen Kommentar �ffnet
    c0=srcline.Find("/**");
    if( c != -1  && c0==-1)  //Zeile �ffnet einen Kommentar
    {
      c=srcline.ReverseFind('/'); //sucht ob die Zeile den Kommentar auch wieder schlie�t
      c0=srcline.ReverseFind('*');
      if(c != -1 && c0 !=-1 && c-c0==1  )  //Zeile schlie�t den Kommentar
      {
        return(0);
      }
      else          //Zeile beendet den Kommentar nicht
      {
        *prevcomment |= COMMENTOPEN;
        return(COMMENTOPEN);
      }
    }
    else
    {
      return(0); // Zeile enth�lt keinen Kommentar
    }
  }
}


//schreibt Code und wenn vorhanden den folgenden Kommentar
int CJSTEPView::DrawCodeFromPos(CDC* pDC,CString& txt,RECT& rcLabel)
{
CString txt1;
RECT rc;
  
  int pos=txt.Find("//");  //suche nach Kommentar
  if(pos != -1)  // Kommentar gefunden
  {
    txt1=txt.Left(pos);   //Code
    txt=txt.Mid(pos);       //Kommentar
    //pDC->DrawText(txt1,&rcLabel,DEFAULT_TEXTDRAW);
    DrawColoredText(txt1,pDC,rcLabel); 
    rcLabel.left+=txt1.GetLength()*fwidth;
    pDC->SetTextColor(0x008000);  //Kommentar wird gr�n
    pDC->DrawText(txt,&rcLabel,DEFAULT_TEXTDRAW);
    pDC->SetTextColor(0);  //wieder scharz
    txt="";
    return(0);
  }
  pos=txt.Find("/*");  //suche nach Kommentaranfang
  if(pos != -1)  // Kommentaranfang gefunden
  {
    txt1=txt.Left(pos);
    txt=txt.Mid(pos);
    //pDC->DrawText(txt1,&rcLabel,DEFAULT_TEXTDRAW); // Code =sw
    rc=rcLabel;
    DrawColoredText(txt1,pDC,rc);
    rcLabel.left+=txt1.GetLength()*fwidth;

    pos=txt.Find("*/"); //suche das Kommentarende
    if(pos != -1)  //Kommentarende vorhanden
    {
      txt1=txt.Left(pos+2);
      pDC->SetTextColor(0x008000);  //Kommentar =gn
      pDC->DrawText(txt1,&rcLabel,DEFAULT_TEXTDRAW);                
      rcLabel.left+=txt1.GetLength()*fwidth;
      pDC->SetTextColor(0);
      txt=txt.Mid(pos+2);
      return(0);
    }
    else  //der ganze Rest ist Kommentar
    {
      pDC->SetTextColor(0x008000);  //Kommentar =gn
      pDC->DrawText(txt,&rcLabel,DEFAULT_TEXTDRAW);
      pDC->SetTextColor(0);
      txt="";
      return(COMMENTOPEN);
    }
  }
  else
  { 
    pDC->SetBkColor(bkcolor);     
    //pDC->DrawText(txt,&rcLabel,DEFAULT_TEXTDRAW); //kein kommentar in der Zeile
    DrawColoredText(txt,pDC,rcLabel);
    txt="";
    return(0);
  }
}

//schreibt Kommentar bis zum Zeilenende oder bis zum Schlie�en des Kommentars
int CJSTEPView::DrawCommentFromPos(CDC* pDC,CString& txt,RECT& rcLabel)
{
  CString txt1;

  int pos=txt.Find("*/");  //suche nach Kommentarende
  if(pos != -1)            // Kommentarende gefunden
  {
    txt1=txt.Left(pos+2);
    pDC->SetTextColor(0x008000);  //Kommentar =gn
    pDC->DrawText(txt,&rcLabel,DEFAULT_TEXTDRAW);
    rcLabel.left+=txt1.GetLength()*fwidth;
    pDC->SetTextColor(0);
    if(txt.GetLength()>(pos+3))
      txt=txt.Mid(pos+3);
    return(0);
  }
  else  //der Kommentar geht bis zum Ende der Zeile
  {
    pDC->SetTextColor(0x008000);  //Kommentar =gn
    pDC->DrawText(txt,&rcLabel,DEFAULT_TEXTDRAW);
    rcLabel.left+=txt1.GetLength()*fwidth;
    pDC->SetTextColor(0);
    txt="";
    return(COMMENTOPEN);
  }
}

void CJSTEPView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
  if(!(GetStyle() & WS_VISIBLE))
    return;
  selectedText="";
  seltextlen=0;
  mcaptured=FALSE;
  bselect=FALSE;
  if((lHint & UPDATEMODE_HLL)==UPDATEMODE_HLL && vmode!=HLL)
  {
    if(((CJSTEPDoc*)GetDocument())->pobjinfo->IsHLLModule(pmod->ModID))
    {  // nur wenn sich die Sicht umschalten l��t
      vmode=HLL;
      SetupHLLList(pmod);
    }
  }
  else if((lHint & UPDATEMODE_ASM)==UPDATEMODE_ASM && vmode!=ASM)
  {
    vmode=ASM;
    SetupASMList(pmod);
  }
  else if((lHint & UPDATEMODE_MIX)==UPDATEMODE_MIX && vmode!=MIX)
  {
    SetupMIXList(pmod);
    vmode=MIX;
  }
  else
  {
    switch(vmode)
    {
      case HLL: SetupHLLList(pmod);
        break;
      case MIX: SetupMIXList(pmod);
        break;
      case ASM: SetupASMList(pmod);
        break;
    }
  }
  if(lHint && SETCURSOR)
  {
    int item=ScrollToAddr(GetDocument()->actdisplayAddr);
    GetListCtrl().SetItemState(item,LVIS_SELECTED,LVIS_SELECTED);
    GetListCtrl().RedrawItems(item,item);
    GetListCtrl().UpdateWindow();
  }
}

//l�scht beim Umschalten der Ansichten die Selektion
void CJSTEPView::ResetSelection()
{
  selectedText="";
  seltextlen=0;
  selstart=0;
  selend=0;
  mcaptured=FALSE;
  bselect=FALSE;
}

//scrollt die Sicht bis zu der gew�nschten Adresse
//oder wenn die Adresse nicht direkt gefunden wird
//zur n�chsten Anweisung danach
//liefert den Index des gefundenen Items

int CJSTEPView::ScrollToAddr(ULONG addr)
{
  int n,i;
  ULONG listaddr,linestate,lastaddr;
  int lastvaliditem;
  BOOL found;

  i=0;
  lastvaliditem=-1;
  lastaddr=0;
  found=FALSE;
  CListCtrl& lc=GetListCtrl();
  n=lc.GetItemCount();
  if(vmode==ASM)
  {
    while(i<n)
    {
      if(addr<=lc.GetItemData(i))
      {
        found=TRUE;
        break;         //gefunden
      }
      i++;
    }
  }
  else
  {
    while(i<n)
    {
      listaddr=lc.GetItemData(i);
      if(dispstate.GetSize())
        linestate= dispstate.GetAt(i);
      else
        linestate=0;
      if((linestate & LINEADDRVALID) && (listaddr<addr) && (lastaddr<listaddr))
      {
        lastvaliditem=i;
        lastaddr=listaddr;
      }
      if(addr==listaddr && (LINEADDRVALID & linestate) ) // || (listaddr>addr))
      {
        if(vmode != MIX)
        {
          found=TRUE;
          break;  //gefunden wenn entweder die Adresse stimmt und g�ltig ist oder
          //kurz danach
        }
        else if(linestate==LINEADDRVALID)
        {
          found=TRUE;
          break;
        }
      }
      i++;
    }

  }
  if(found==TRUE)
  {
    lc.EnsureVisible(i,FALSE);
    actitem=i;
  }
  else
  {
    lc.EnsureVisible(lastvaliditem,FALSE);
    actitem=lastvaliditem;
  }
  return (actitem);
}



void CJSTEPView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
  ULONG addr;
  WORD s;
  int ks,kc;
  ULONG fmt;

  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  ks= 0x80 & GetKeyState(VK_SHIFT);
  kc= 0x80 & GetKeyState(VK_CONTROL);
  if(nChar==0x78 && ks &&  selectedText != "") //SHIFT-F9 -> Quickwatch
  {
    OpenQuickWatch();
  }

  if(nChar==0x74 && nRepCnt==1 && !ks)  // F5 -> Run
    GetDocument()->OnRun();
  else if(nChar==0x74 && nRepCnt==1 && ks)  // SHIFT-F5 -> Stop
  {
    if(selend!=selstart)
    {
      selectedText="";
      selend=selstart;
      InvalidateRect(&selrect);
    }
    GetDocument()->b_DbgRun=FALSE;
  }
  else if(nChar==0x7A && nRepCnt==1)  // F11 -> StepIn
  {
    if(selend!=selstart)
    {
      selectedText="";
      selend=selstart;
      InvalidateRect(&selrect);
    }
    GetDocument()->StepIn();
  }
  else if(nChar==0x7B && nRepCnt==1)  // F12 -> StepOut
  {
    if(selend!=selstart)
    {
      selectedText="";
      selend=selstart;
      InvalidateRect(&selrect);
    }
    GetDocument()->StepOut();
  }
  else if(nChar==0x77 && nRepCnt==1)  // F8 -> RunToCursor
  {
    if(selend!=selstart)
    {
      selectedText="";
      selend=selstart;
      InvalidateRect(&selrect);
    }
    GetDocument()->RunToCursor();
  }
  else if(nChar==0x72 && !ks && nRepCnt==1)  // F3 -> Toggle MeasurePoint
  {
    CMeasurePoint& mpt= pm->pDoc->mpt;
    CListCtrl& lc=GetListCtrl();
    if(actitem==-1)
      actitem=lc.GetNextItem(-1,LVNI_SELECTED);
    if(vmode==ASM)
    {
      addr=lc.GetItemData(actitem);
      if(!mpt.isValid || (mpt.addr != addr))
      {
        mpt.isValid=TRUE;
        if(mpt.pv && (mpt.item!=-1))
          ((CListCtrl*)mpt.pv)->RedrawItems(mpt.item,mpt.item);
        mpt.SetMeasurePoint( addr );
        mpt.item=actitem;
        mpt.pv=&lc;
      }
      else
      {
        prc->SetMeasurePoint(0);
        mpt.isValid=FALSE;
      }
      lc.RedrawItems(actitem,actitem);
    }
    else if(vmode==MIX)
    {
      s=dispstate.GetAt(actitem);
      if( !(s & ISHLLLINE)) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
      {
        addr=lc.GetItemData(actitem);
        if(!mpt.isValid || (mpt.addr != addr))
        {
          mpt.isValid=TRUE;
          if(mpt.pv  && (mpt.item!=-1))
            ((CListCtrl*)mpt.pv)->RedrawItems(mpt.item,mpt.item);
          mpt.SetMeasurePoint( addr );
          mpt.item=actitem;
          mpt.pv=&lc;
        }
        else
        {
          prc->SetMeasurePoint(0);
          mpt.isValid=FALSE;
        }
        lc.RedrawItems(actitem,actitem);
      }
    }
    else if(vmode==HLL)
    {
      s=dispstate.GetAt(actitem);
      if(s & LINEADDRVALID)
      {
        addr=lc.GetItemData(actitem);
        if(!mpt.isValid || (mpt.addr != addr))
        {
          if(mpt.isValid)
            prc->SetMeasurePoint(0);
          mpt.isValid=TRUE;
          if(mpt.pv  && (mpt.item!=-1))
            ((CListCtrl*)mpt.pv)->RedrawItems(mpt.item,mpt.item);
          mpt.SetMeasurePoint(addr);
          mpt.item=actitem;
          mpt.pv=&lc;
        }
        else
        {
          prc->SetMeasurePoint(0);
          mpt.isValid=FALSE;
        }
        lc.RedrawItems(actitem,actitem);
      }
      else
      {
        int i=actitem;
        int c=lc.GetItemCount();
        while(i < c)   //sucht die n�chste Zeile mit einem g�ltigen Codebezug
        {
          s=dispstate.GetAt(i);
          if(s & LINEADDRVALID)
          {
            addr=lc.GetItemData(i);
            if(!mpt.isValid || (mpt.addr != addr))
            {
              mpt.isValid=TRUE;
              if(mpt.pv && (mpt.item!=-1))
                ((CListCtrl*)mpt.pv)->RedrawItems(mpt.item,mpt.item);
              mpt.SetMeasurePoint(addr);
              mpt.item=actitem;
              mpt.pv=&lc;
            }
            else
            {
              prc->SetMeasurePoint(0);
              mpt.isValid=FALSE;
            }
            lc.RedrawItems(i,i);
            break;
          }
          i++;
        }
      }
    }
    if(pm->m_wndAnalyser.m_hWnd && pm->m_wndAnalyser.GetStyle() & WS_VISIBLE)
      pm->m_wndAnalyser.UpdateAnalyser();
  }
  else if(nChar==0x73 && !ks && nRepCnt==1)  // F4 -> Toggle TracePoint
  {
    CTracePoint& tpt= pm->pDoc->tpt;
    CListCtrl& lc=GetListCtrl();
    if(actitem==-1)
      actitem=lc.GetNextItem(-1,LVNI_SELECTED);
    if(vmode==ASM)
    {
      addr=lc.GetItemData(actitem);
      if(!tpt.isValid || !tpt.IsTracePointAtAddr(addr))
      {
        tpt.isValid=TRUE;
        if(tpt.pv && (tpt.item!=-1))
          ((CListCtrl*)tpt.pv)->RedrawItems(tpt.item,tpt.item);
        tpt.SetTracePoint( addr );
        tpt.item=actitem;
        tpt.pv=&lc;
      }
      else
        tpt.isValid=FALSE;
      lc.RedrawItems(actitem,actitem);
    }
    else if(vmode==MIX)
    {
      s=dispstate.GetAt(actitem);
      if( !(s & ISHLLLINE)) //Tracepoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
      {
        addr=lc.GetItemData(actitem);
        if(!tpt.isValid || !tpt.IsTracePointAtAddr(addr))
        {
          tpt.isValid=TRUE;
          if(tpt.pv  && (tpt.item!=-1))
            ((CListCtrl*)tpt.pv)->RedrawItems(tpt.item,tpt.item);
          tpt.SetTracePoint( addr );
          tpt.item=actitem;
          tpt.pv=&lc;
        }
        else
          tpt.isValid=FALSE;
        lc.RedrawItems(actitem,actitem);
      }
    }
    else if(vmode==HLL)
    {
      s=dispstate.GetAt(actitem);
      if(s & LINEADDRVALID)
      {
        addr=lc.GetItemData(actitem);
        if(!tpt.isValid || !tpt.IsTracePointAtAddr(addr))
        {
          tpt.isValid=TRUE;
          if(tpt.pv  && (tpt.item!=-1))
            ((CListCtrl*)tpt.pv)->RedrawItems(tpt.item,tpt.item);
          tpt.SetTracePoint(addr);
          tpt.item=actitem;
          tpt.pv=&lc;
        }
        else
          tpt.isValid=FALSE;
        lc.RedrawItems(actitem,actitem);
      }
      else
      {
        int i=actitem;
        int c=lc.GetItemCount();
        while(i < c)   //sucht die n�chste Zeile mit einem g�ltigen Codebezug
        {
          s=dispstate.GetAt(i);
          if(s & LINEADDRVALID)
          {
            addr=lc.GetItemData(i);
            if(!tpt.isValid || tpt.IsTracePointAtAddr(addr))
            {
              tpt.isValid=TRUE;
              if(tpt.pv && (tpt.item!=-1))
                ((CListCtrl*)tpt.pv)->RedrawItems(tpt.item,tpt.item);
              tpt.SetTracePoint(addr);
              tpt.item=actitem;
              tpt.pv=&lc;
            }
            else
              tpt.isValid=FALSE;
            lc.RedrawItems(i,i);
            break;
          }
          i++;
        }
      }
    }
  }
  else if(nChar==0x78 && !ks && nRepCnt==1 && !kc && !ks)  // F9 -> Toggle Breakpoint
  {
    CListCtrl& lc=GetListCtrl();
    if(actitem==-1)
      actitem=lc.GetNextItem(-1,LVNI_SELECTED);
    if(vmode==ASM)
    {
      addr=lc.GetItemData(actitem);
      if(!prc->IsBreakpointAtAddr(addr,BKPT_CODE))
        prc->SetBreakpoint(addr,BKPT_CODE);
      else
        prc->RemoveBreakpoint(addr);
      lc.RedrawItems(actitem,actitem);
    }
    else if(vmode==MIX)
    {
      s=dispstate.GetAt(actitem);
      if( !(s & ISHLLLINE)) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
      {
        addr=lc.GetItemData(actitem);
        if(!prc->IsBreakpointAtAddr(addr,BKPT_CODE))
          prc->SetBreakpoint(addr,BKPT_CODE);
        else
          prc->RemoveBreakpoint(addr);
        lc.RedrawItems(actitem,actitem);
      }
      else
      {
        CString msg;
        msg.LoadString(IDS_BKONLYATASM);
        pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);
      }
    }
    else if(vmode==HLL && actitem!=-1)
    {
      s=dispstate.GetAt(actitem);
      if(s & LINEADDRVALID)
      {
        addr=lc.GetItemData(actitem);
        if(!prc->IsBreakpointAtAddr(addr,BKPT_CODE))
          prc->SetBreakpoint(addr,BKPT_CODE);
        else
          prc->RemoveBreakpoint(addr);
        lc.RedrawItems(actitem,actitem);
      }
      else
      {
        int i=actitem;
        int c=lc.GetItemCount();
        while(i < c)   //sucht die n�chste Zeile mit einem g�ltigen Codebezug
        {
          s=dispstate.GetAt(i);
          if(s & LINEADDRVALID)
          {
            addr=lc.GetItemData(i);
            prc->SetBreakpoint(addr,BKPT_CODE);
            lc.RedrawItems(i,i);
            CString msg;
            msg.LoadString(IDS_BKATNEXTLINE);
            pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);
            break;
          }
          i++;
        }
      }
    }
  }
  else if(nChar==0x78 && kc && nRepCnt==1 )  // CTRL-F9 -> Deaktiviert Breakpoint
  {
    CListCtrl& lc=GetListCtrl();
    if(actitem==-1)
      actitem=lc.GetNextItem(-1,LVNI_SELECTED);
    if(vmode==ASM)
    {
      addr=lc.GetItemData(actitem);
      fmt=prc->IsBreakpointAtAddr(addr,BKPT_CODE);
      if((fmt & (BKPT_CODE|BKPT_DISABLED))== BKPT_CODE)
        prc->SetBreakpoint(addr,BKPT_CODE|BKPT_DISABLED);
      else
        prc->SetBreakpoint(addr,BKPT_CODE);
      lc.RedrawItems(actitem,actitem);
    }
    else if(vmode==MIX)
    {
      s=dispstate.GetAt(actitem);
      if( !(s & ISHLLLINE)) //Breakpoint k�nnen bei MIX nur auf die asm -Zeilen gesetzt werden
      {
        addr=lc.GetItemData(actitem);
        fmt=prc->IsBreakpointAtAddr(addr,BKPT_CODE);
        if((fmt & (BKPT_CODE|BKPT_DISABLED))== BKPT_CODE)
          prc->SetBreakpoint(addr,BKPT_CODE|BKPT_DISABLED);
        else
          prc->SetBreakpoint(addr,BKPT_CODE);
        lc.RedrawItems(actitem,actitem);
      }
      else
      {
        CString msg;
        msg.LoadString(IDS_BKONLYATASM);
        pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);
      }
    }
    else if(vmode==HLL)
    {
      s=dispstate.GetAt(actitem);
      if(s & LINEADDRVALID)
      {
        addr=lc.GetItemData(actitem);
        fmt=prc->IsBreakpointAtAddr(addr,BKPT_CODE|BKPT_DISABLED);
        if((fmt & (BKPT_CODE|BKPT_DISABLED)) == (BKPT_CODE|BKPT_DISABLED))
          prc->SetBreakpoint(addr,BKPT_CODE);
        else if((fmt & (BKPT_CODE|BKPT_DISABLED))== BKPT_CODE)
          prc->SetBreakpoint(addr,BKPT_CODE|BKPT_DISABLED);
        else
          prc->SetBreakpoint(addr,BKPT_CODE|BKPT_DISABLED);
        lc.RedrawItems(actitem,actitem);
      }
      else
      {
        int i=actitem;
        int c=lc.GetItemCount();
        while(i < c)   //sucht die n�chste Zeile mit einem g�ltigen Codebezug
        {
          s=dispstate.GetAt(i);
          if(s & LINEADDRVALID)
          {
            addr=lc.GetItemData(i);
            prc->SetBreakpoint(addr,BKPT_CODE);
            lc.RedrawItems(i,i);
            CString msg;
            msg.LoadString(IDS_BKATNEXTLINE);
            pm->m_DbgBar.SetDlgItemText(IDC_DBCMDBOX,msg);
            break;
          }
          i++;
        }
      }
    }
  }
  CListView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CJSTEPView::OnSysKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
  if(nChar==0x79 && nRepCnt==1)  // F10 -> StepOver
  {
    if(selend!=selstart)
    {
      selectedText="";
      selend=selstart;
      InvalidateRect(&selrect);
    }
    GetDocument()->StepOver();
    return;
  }
  CListView::OnSysKeyDown(nChar, nRepCnt, nFlags);
}

//koopiert in Clipboard
void CJSTEPView::Copy()
{
  char* cp;

  if(GetSeltextLen())
  {
    if(!OpenClipboard())
      return; // kann nicht kopieren
    if(!EmptyClipboard())
    {
      CloseClipboard();
      return;
    }
    if(selectedText == "")
      return;
    int l=selectedText.GetLength()+1;
    HGLOBAL htxt=::GlobalAlloc(GMEM_MOVEABLE|GMEM_DDESHARE,l);
    cp=(char*)::GlobalLock(htxt);
    strcpy(cp,LPCSTR(selectedText));
    GlobalUnlock(htxt);
    SetClipboardData(CF_TEXT,htxt);
    CloseClipboard();
  }
}


int CJSTEPView::OnToolHitTest( CPoint point, TOOLINFO* pTI )const
{
  CString txt;
  int x;

  if(!pTI)
    return -1;
  // workout which grid square the mouse is in...
  // if there were any area's that are not hits, then we could return -1
  // immiediately, but in this example, every grid square fires.

  if(point.x != ttpoint.x || point.y != ttpoint.y)
  {
    tooltipcount++;
    ttpoint.x=point.x;
    ttpoint.y=point.y;
  }

  CListCtrl& edlc=GetListCtrl();
  if(selectedText == "")
  {
    pTI->hwnd = edlc.m_hWnd;  // window where TTN_NEEDTEXT will be sent.
    pTI->uFlags = TTF_ALWAYSTIP;
    pTI->cbSize = sizeof TOOLINFO;
    pTI->uId = (UINT)-2;
    pTI->lpszText=LPSTR_TEXTCALLBACK;
    pTI->rect.top=point.y;
    pTI->rect.left=point.x;
    pTI->rect.bottom=point.y+10;
    pTI->rect.right=point.x+fwidth;
  }
  else
  {
    if(!IsPointInRect(&point,(RECT*)&selrect))
      return -1;
    txt=selectedText;
    x=GetToolTipString(txt);
    if(!x)
      return -1;
    pTI->lpszText=new char[x+1];
    strcpy(pTI->lpszText,LPCSTR(txt));
    pTI->rect=selrect;
  }

  // set up the rest of the flags. Not all of these are required, but it seems
  // safer to supply them.

  pTI->hwnd = edlc.m_hWnd;        // window where TTN_NEEDTEXT will be sent.
  pTI->uFlags = TTF_ALWAYSTIP;
  pTI->cbSize = sizeof TOOLINFO;
  pTI->uId = (UINT)-2;       // dummy id, so we can tell it's not a standard command

  // need a return value that is different for every grid square

  if(tooltipcount==0xFFFE)
    tooltipcount=0;
  return (tooltipcount);
}


int CJSTEPView::GetToolTipString(CString& wtxt) const
{
  eval_t r;
  ULONG v;
  char c;
  ULONG mem;
  int memsize,l;
  CTypdesc *pt;
  op_t* pval;
  char lop;
  int i;
  char txt[200];
  const char* memstr;
  CString modname,procname;

  strcpy(txt,LPCSTR(wtxt));
  if(pmod && !pmod->ObExt)
    strupr(txt);
  r.expression=txt;
  *(long*)r.lastop.op=0;
  i=Evaluate(&r);
  if(i)
  {  //kann nicht berechnet werden probier es noch mal mit einer globalen Variable
    i=wtxt.ReverseFind(':');
    strcpy(txt,LPCSTR(wtxt)+i+1);
    r.expression=txt;
    i=Evaluate(&r); //zweiter Versuch
    if(i)
      return(0);
    else
    {
      CObjInfo* poi=((CMainFrame*)AfxGetMainWnd())->pDoc->pobjinfo;
      labeldef_t* lp=poi->FindLabelDesc(CString(txt));
      if(!lp)
        return 0;
      else if(lp->ModID!=-1)
      {
        wtxt=((CModDef*)(poi->moduls.GetAt(lp->ModID)))->modname;
        wtxt+=':';
        if(lp->pproc && lp->pproc->Procname != "" )
        {
          wtxt+=lp->pproc->Procname;
          wtxt+=':';
        }
        wtxt+=txt;
      }
      else
        wtxt=txt;
    }
  }
  lop=r.lastop.op[0];
  pval=&(r.retval);
  v=*(unsigned long*)(pval->op);
  pt=(CTypdesc*)(pval->optyp);

  CString t=txt;
  if(!pt && IsNum(t))  //ein typ=0 kann nur eine einfache Zahl sein
    return 0;
  if((ULONG)pt < 0x1E && lop!= '&') //StandardTyp und es wurde nicht die Adresse gesucht
  {
    switch(pval->optyp)
    {
      case T_BIT:
        if(v)
          strcpy(txt,"= TRUE");
        else
          strcpy(txt,"= FALSE");
        break;
      case T_SCHAR:
        l=sprintf(txt," = 0x%2.2X ",v);
        i=0;
        txt[l++]='"';
        while(l<sizeof(txt)-3)
        {
          prc->GetMemFromAddr(r.retval.addr+i,&v,(r.retval.memspec));
          c=(char)(v&0xFF);
          if(c)
            txt[l]=c;
          else
          {
            txt[l]='"';
            txt[l+1]=0;
            break;
          }
          l++;
          i++;
        }
        break;
      case T_UCHAR:
        sprintf(txt," = 0x%2.2X",v);
        break;
      case T_SINT:
        sprintf(txt," = 0x%4.4X",v);                                                      break;
      case T_UINT:
      case T_CODELABEL:
        sprintf(txt," = 0x%4.4X",v);
        break;
      case T_SLONG:
        sprintf(txt," = 0x%8.8X",v);
        break;
      case T_ULONG:
      case T_VOID:
        sprintf(txt," = 0x%8.8X",v);
        break;
      case T_FLOATL:
      case T_DOUBLE:
      case T_FLOATB:
        sprintf(txt," = %G",*(float*)(pval->op));
        break;
      case T_UNTYPED:
        sprintf(txt," =%d",v);
        break;
    }

  }
  else if(lop=='&') //die Adressse wurde gesucht
  {
    memsize=prc->GetMemSize(pval->memspec);
    const char* memstr=0;
    switch(pval->memspec)
    {
      case CODEMEM: memstr="CD:";
        break;
      case XDATAMEM:memstr="XD:";
        break;
      case DATAMEM: memstr="D: ";
        break;
      case IDATAMEM:memstr="ID:";
        break;
      case PDATAMEM:memstr="PD:";
        break;
    }
    switch(memsize)
    {
      case S8: sprintf(txt," = %s{0x%2.2X}",memstr,v);
        break;
      case S16:sprintf(txt," = %s{0x%4.4X}",memstr,v);
        break;
      default:
      case S32:sprintf(txt," = %s{0x%8.8X}",memstr,v);
        break;
    }
  }
  else //es wurde kein Standardtyp und auch nicht die Adresse gesucht
  {
    if(   pt->typ == T_POINTDESC
          || pt->typ == T_SPACEDPTR
          || pt->typ == T_GENPTRDESC)  //der gesuchte Typ ist ein Zeiger
    {

      if((ULONG)(pt->pref)>0x1E && pt->pref->typ==pt->typ)  // Zeiger ist Element einer Liste
        pt=pt->pref;
      if(pt->typ == T_POINTDESC)
      {
        BOOL b=prc->GetMemFromAddr(pval->addr,&mem,pval->memspec>>0x10);
        if(!b)
        {
          return 0;
        }
      }
      else
        mem=pt->offset;
      switch(mem)
      {
        default:
        case MS_CODE:  memstr="CD:";
          memsize=prc->GetMemSize(CODEMEM);
          break;
        case MS_XDATA: memstr="XD:";
          memsize=prc->GetMemSize(XDATAMEM);
          break;
        case MS_DATA:  memstr="D: ";
          memsize=prc->GetMemSize(DATAMEM);
          break;
        case MS_IDATA: memstr="ID:";
          memsize=prc->GetMemSize(IDATAMEM);
          break;
        case MS_PDATA: memstr="PD:";
          memsize=prc->GetMemSize(PDATAMEM);
          break;
      }
      switch(memsize)
      {
        case S8: sprintf(txt," = (->%s0x%2.2X)",memstr,v);
          break;
        case S16:sprintf(txt," = (->%s0x%4.4X)",memstr,v);
          break;
        default:
        case S32:sprintf(txt," = (->%s0x%8.8X)",memstr,v);
          break;
      }
    }
    else  // der Typ ist ein anderer (Struct oder Array)
    {
      memsize=prc->GetMemSize(pval->memspec);
      switch(pval->memspec)
      {
        default:
        case CODEMEM: memstr="CD:";
          break;
        case XDATAMEM:memstr="XD:";
          break;
        case DATAMEM: memstr="D: ";
          break;
        case IDATAMEM:memstr="ID:";
          break;
        case PDATAMEM:memstr="PD:";
          break;
      }
      switch(memsize)
      {
        case S8: sprintf(txt," = %s{0x%2.2X}",memstr,v);
          break;
        case S16:sprintf(txt," = %s{0x%4.4X}",memstr,v);
          break;
        default:
        case S32:sprintf(txt," = %s{0x%8.8X}",memstr,v);
          break;
      }
    }
  }
  wtxt+=txt;
  return (wtxt.GetLength());
}


BOOL CJSTEPView::OnToolTipNotify( UINT id, NMHDR * pNMHDR, LRESULT * pResult )
{
  int sstart,send,ttitem,x;
  CString sText;
  ULONG addr;

  TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pNMHDR;

  if (pNMHDR->idFrom == (UINT)-2)
  {
    // call the helper function to supply the text
    ttitem=GetListCtrl().HitTest(ttpoint);
    RecalcSelrect(ttitem);
    if(::PtInRect(&selrect,ttpoint))
    {
      if(vmode==ASM || vmode==MIX)
        GetListCtrl().GetItemText(ttitem,2,szBuff,sizeof(szBuff));
      else if(vmode==HLL)
        GetListCtrl().GetItemText(ttitem,1,szBuff,sizeof(szBuff));
      sstart=(ttpoint.x-selrect.left)/fwidth;
      send=sstart;
      while(isalnum(szBuff[send]))
        send++;
      while(isalnum(szBuff[sstart]) && sstart>-1)
        sstart--;
      if(send-sstart)
      {
        sstart++;
        sText=szBuff;
        if(sText.GetLength()>=send)
          sText=sText.Mid(sstart,send-sstart);
        addr=GetListCtrl().GetItemData(ttitem);
        CObjInfo* pobjinfo=&(((CJSTEPApp*)AfxGetApp())->objinfo);
        CProcDef* pp=pobjinfo->GetProcFromAddr(addr);
        if(!pp)
          return FALSE;
        if(pp->Procname == "LIB" && pmod->modname!= "LIBRARY") //eine globale Variable ausserhalb eine Prozedur
          sText=pmod->modname + ":" + sText;
        else if(pp->Procname != "LIB" || pmod->modname != "LIBRARY")
          sText=pmod->modname + ":" +pp->Procname + ":" + sText;
        x=GetToolTipString(sText);
        if(!x)
        {
          pTTT->lpszText=0;
          return FALSE;
        }
        if(pNMHDR->code == TTN_NEEDTEXTW)
          MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,LPCSTR(sText),-1,(USHORT*)pTTT->szText,40);
        else
        {
          strcpy(ttptxt,sText);
          pTTT->lpszText=ttptxt;
        }
        return (TRUE);
      }

    }

    return(FALSE);
  }
  else
    return FALSE;   // so message processing continues
}

void CJSTEPView::OnRButtonDown(UINT nFlags, CPoint point)
{
  CMenu  Popup;
  LV_HITTESTINFO lvh;
  int nItem;
  ULONG linestate;

  Popup.LoadMenu (IDR_CODEVIEW);
  if(!enableHLL)
  {
    Popup.EnableMenuItem(IDC_HLL, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
    Popup.EnableMenuItem(IDC_MIX, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
  }
  if(vmode==HLL)
    Popup.CheckMenuItem(IDC_HLL, MF_CHECKED|MF_BYCOMMAND);
  if(vmode==MIX)
    Popup.CheckMenuItem(IDC_MIX, MF_CHECKED|MF_BYCOMMAND);
  if(vmode==ASM)
    Popup.CheckMenuItem(IDC_ASM, MF_CHECKED|MF_BYCOMMAND);
  if(GetDocument()->b_DbgRun)
  {
    Popup.EnableMenuItem(ID_DEBUG_RUN, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
    Popup.EnableMenuItem(ID_DEBUG_RUNTOCURSOR,MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
    Popup.EnableMenuItem(IDC_MIX, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
    Popup.EnableMenuItem(IDC_ASM, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
    Popup.EnableMenuItem(IDC_HLL, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
  }
  else
  {
    Popup.EnableMenuItem(ID_DEBUG_STOPDEBUGGING, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
  }
  lvh.pt=point;
  nItem=GetListCtrl().HitTest(&lvh);
  if(nItem!=-1)
  {
    linestate=LINEADDRVALID;
    if(vmode!=ASM)
      linestate= dispstate.GetAt(nItem) & LINEADDRVALID;
    if(linestate)
    {
      Popup.EnableMenuItem(ID_DEBUG_RUNTOCURSOR, MF_ENABLED|MF_BYCOMMAND);
      Popup.EnableMenuItem(ID_SEBRKATLOC, MF_ENABLED|MF_BYCOMMAND);
      actitem=nItem;
    }
    else
    {
      Popup.EnableMenuItem(ID_DEBUG_RUNTOCURSOR, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
      Popup.EnableMenuItem(ID_SEBRKATLOC, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);
      Popup.EnableMenuItem(ID_SETPC, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND); 
    }  
  }
  if(selectedText=="")
    Popup.EnableMenuItem(ID_ADDWATCH, MF_DISABLED|MF_GRAYED|MF_BYCOMMAND);     
  ClientToScreen(&point);
  Popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
                                       point.x,point.y,this);

}

void CJSTEPView::OpenQuickWatch()
{
  CMainFrame* pm =(CMainFrame*)AfxGetMainWnd();
  pm->pquick= new CQuickWatch(LPCSTR(selectedText),NULL);
  pm->pquick->DoModal();
  delete pm->pquick;
  pm->pquick=NULL;
}

void CJSTEPView::ResetStackCursor()
{
  int i;

  CListCtrl& lc=GetListCtrl();
  int n=lc.GetItemCount();
  i=0;
  while(i<n)
  {
    if(lc.GetItemState(i,LVIS_CUT))
    {
      lc.SetItemState(i,0,LVIS_CUT);
      lc.RedrawItems(i,i);
      return;
    }
    i++;
  }
}

//addr enth�lt die Adresse ab der gesucht wird!
int CJSTEPView::GetNextValidHllLine(CListCtrl& lc,int fromline, ULONG* addr,BOOL checkProc)
{
  LV_ITEM lvi;
  int i,cnt;
  CProcDef  *pp1,*pp2;
  POSITION pos;
  ULONG startaddr;

  pp1=0;
  pp2=0;
  if(checkProc)
  {
    pos=(pmod->proclist.GetHeadPosition());
    while(pos)
    {
      pp1=(CProcDef*)(pmod->proclist.GetNext(pos));
      if(*addr >= pp1->AnfAddr && *addr <= pp1->EndAddr)
        break;
      pp1=0;
    }
  }
  cnt=lc.GetItemCount();
  lvi.mask=LVIF_PARAM | LVIF_IMAGE;
  lvi.iSubItem=0;
  lvi.iItem=fromline;
  lc.GetItem(&lvi);
  startaddr=lvi.lParam;
  i=fromline;
  while(i<cnt)
  {
    lvi.iItem=i;
    lc.GetItem(&lvi);
    if(lvi.iImage==3)  //g�ltiger CodeBezug
    {
      *addr=lvi.lParam;
w1:
      if(pp1 && (*addr> pp1->EndAddr || *addr<pp1->AnfAddr))  //26.3.98
      {
        *addr=pp1->EndAddr+1;
        return -1;
      }
      i++;
      lvi.iItem=i;
      if(!lc.GetItem(&lvi))
        return i-1;
      if( lvi.iImage==4) //ung�ltiger HLL-Bezug
      {
        return i-1;
      }
      else if( lvi.iImage==3 && *addr==(ULONG)lvi.lParam)
        goto w1;
      else if( lvi.iImage==3 && *addr!=(ULONG)lvi.lParam)
      {
        if(checkProc)
        {
          pos=(pmod->proclist.GetHeadPosition());
          while(pos)
          {
            pp2=(CProcDef*)(pmod->proclist.GetNext(pos));
            if(*addr >= pp2->AnfAddr && *addr <= pp2->EndAddr)
            {
              if(pp1==pp2)
                return i-1;  //die n�chste HLL-Zeile liegt in der gleichen Prozedur
              else
              {
                //*addr=startaddr;
                *addr=pp1->EndAddr+1;
                return -1;
              }
            }
          }
          if(pp1==pp2)
            return i-1;  //die n�chste HLL-Zeile liegt in der gleichen Prozedur
          else
          {
            if(pp1)  
              *addr=pp1->EndAddr+1;
            //*addr=startaddr;
            return -1;
          }
        }
        else
          return i-1;
      }
    }
    i++;
  }
  return -1;
}

ULONG CJSTEPView::GetDispState(int index)
{
  return dispstate.GetAt(index);
}

int CJSTEPView::ReplaceTabs(CString& s, int spaces)
{
  int l,i,r;

  r=0;
  if(spaces==1)
  {
    do
    {
      l=s.Find('\t');
      if(l!=-1)
      {
        s.SetAt(l,' ');
        r++;
      }
    }
    while(l!=-1);
  }
  else if(spaces >1)
  {
    CString s1;
    do
    {
      l=s.Find('\t');
      if(l!=-1)
      {
        s1=s.Left(l-1);
        for(i=0;i<spaces;i++)
          s1+= ' ';
        s1+=s.Mid(l+1);
        s=s1;
        r++;
      }
    }
    while(l!=-1);
  }
  return r;
}

void CJSTEPView::OnAddWatch()
{
  CMainFrame* pm= (CMainFrame*)AfxGetMainWnd();
  if(pm->m_wndWatch.Created)
    pm->m_wndWatch.hlc.AddWatchExpression(selectedText);	
  else
  {
    pm->m_wndWatch.Create( pm ); 
    pm->m_wndWatch.barIsInitialised=TRUE;
    pm->FloatControlBar(&pm->m_wndWatch,pm->m_wndWatch.m_FloatingPosition);
    pm->m_wndWatch.hlc.AddWatchExpression(selectedText);    
  }
  pm->ShowControlBar(&pm->m_wndWatch,TRUE,FALSE);
}

void CJSTEPView::OnKillFocus(CWnd* pNewWnd) 
{
	CListView::OnKillFocus(pNewWnd);	
  if(selstart != selend)
  {
	  selstart = selend;
    GetListCtrl().RedrawItems(actitem,actitem);
	}
}


void CJSTEPView::OnSetPC()
{
ULONG linestate;
   
  if(vmode==ASM ) 
    linestate = LINEADDRVALID ;
  else if(dispstate.GetSize() > actitem)
    linestate= dispstate.GetAt(actitem);
  else 
     return;
  if(linestate & LINEADDRVALID)
  {
    CMainFrame* pm= (CMainFrame*)AfxGetMainWnd();
    ULONG listaddr=GetListCtrl().GetItemData(actitem);
    prc->SetProgramCounter(listaddr);
    pm->UpdateAllWatches();
    GetListCtrl().RedrawItems(actitem,actitem);
  }
}


void CJSTEPView::CalcColorText(LPCSTR txt, BYTE *colorbuf)
{
int i,l;
const keydef_t *pk;
const char *pc;

  
  memset(colorbuf,0,strlen(txt)); //Farben l�schen
  for(i=0 ; i<KEYNO; i++)
  {
    pk=&keytab[i];
    l=strlen(keytab[i].key);
    pc=txt;
    while(pc)
    {
      pc=strstr(pc,keytab[i].key);
      if(pc && !isalnum(*(pc-1)) && !isalnum(*(pc+l)) && *(pc+l)!='_' && *(pc-1)!='_')
      { 
        memset(colorbuf+(pc-txt),keytab[i].coloridx,l);
        pc+=l;
      }
      else if(pc)
        pc+=l;         
    }
  }   
}

void CJSTEPView::DrawColoredText(LPCSTR text, CDC *pDC, RECT &rcLabel)
{
int i,coloridx;
LPCSTR pc;
BYTE txtcolor[500];

  CalcColorText(text,txtcolor); 
  i=0;
  coloridx=-1;
  pc=text; 
  //pDC->SetTextColor(0);
  while(*pc)
  {
    if(coloridx!=txtcolor[i])
    {
      coloridx=txtcolor[i];
      pDC->SetTextColor(colortab[coloridx]);
    }       
    pDC->DrawText(pc,1,&rcLabel,DEFAULT_TEXTDRAW);
    rcLabel.left+=fwidth;
    pc++;
    i++;  
  }   
}
