// EdMemLstCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "proc.h"
#include "JSTEP.h"
#include "EdMemLstCtrl.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEdMemLstCtrl

CEdMemLstCtrl::CEdMemLstCtrl(ULONG startaddr)
{  
  lfont.CreateFont(-10,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Courier"); 
  selitem=-1;
  selsubitem=-1;
  rowentries=0;
  CEdMemLstCtrl::startaddr=startaddr;
}

CEdMemLstCtrl::~CEdMemLstCtrl()
{
}


BEGIN_MESSAGE_MAP(CEdMemLstCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CEdMemLstCtrl)
  ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_KILLFOCUS()
	ON_WM_VSCROLL()
	ON_WM_RBUTTONDOWN()  
  ON_COMMAND(ID_MEM1,OnByte)
  ON_COMMAND(ID_MEM2,OnShort)
  ON_COMMAND(ID_MEM3,OnLong)
  ON_COMMAND(ID_MEM4,OnAscii) 
  ON_COMMAND(ID_MEMPASTE,OnPaste) 
  ON_COMMAND(ID_FLOAT,OnFloat)
  ON_COMMAND(ID_DOCK,OnDock)
  ON_MESSAGE(UM_ENTER,OnEnter) 
  ON_MESSAGE(UM_CURSORKEY,OnCursorKey)  
  ON_MESSAGE(UM_CTRLKEY,OnCtlKey)
  ON_MESSAGE(UM_PASTE,OnEdPaste) 
  ON_MESSAGE(UM_GETMENUSTATE,OnGetMenuState)
  ON_COMMAND(ID_SETREADBRK,OnToggleReadBreak)
  ON_COMMAND(ID_SETWRBRK,OnToggleWriteBreak)
  
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEdMemLstCtrl message handlers
void CEdMemLstCtrl::OnFloat()
{
RECT rd;

  GetDesktopWindow()->GetWindowRect(&rd);
	POINT pt;
	pt.x=rd.right/2-50;
  pt.y=rd.bottom/2-50;
  ((CFrameWnd*)AfxGetMainWnd())->FloatControlBar(((CControlBar*)GetParent()),pt,0);	
}

void CEdMemLstCtrl::OnDock()
{
  CMDIFrameWnd* pm=(CMDIFrameWnd*)AfxGetMainWnd(); 
  pm->DockControlBar(((CControlBar*)GetParent()),AFX_IDW_DOCKBAR_RIGHT);
}

void CEdMemLstCtrl::Create() 
{
RECT rc={0,0,10,10};
RECT rp;


	edit.Create( WS_CHILD|WS_BORDER|WS_OVERLAPPED
              |ES_NOHIDESEL|ES_MULTILINE|ES_WANTRETURN,
               rc,this,0); 
  
	edit.SetFont(&lfont,FALSE);	
  
  CClientDC dc(this);
	dc.GetOutputCharWidth('0','0',&fwidth);	
  GetParent()->GetClientRect(&rp);
  GetParent()->ClientToScreen(&rp);
  GetWindowRect(&rc);
  loff=rc.left-rp.left;
  roff=rc.right-rp.right;
  toff=rc.top-rp.top;
  boff=rc.bottom-rp.bottom; 
}



// �ndert die Anzahl der Spalten, die erste Spalte bleibt aber immer erhalten  
// wenn viewtyp==-1 wird der aktuell eingestellte Wert verwendet
void CEdMemLstCtrl::SetCols(int viewtyp, int memspec, ULONG startaddr)
{
LV_COLUMN lvc;
LV_ITEM lvi;
RECT rc;
int r,c,i;
int lines;
CString sval;
ULONG val;
BOOL b;

  
  SetRedraw(FALSE);
  selitem=-1;
  edit.ShowWindow(SW_HIDE);
  edit.act=-1;
  CEdMemLstCtrl::startaddr=startaddr;
  if(viewtyp != -1)
    CEdMemLstCtrl::viewtyp=viewtyp; 
  else
    viewtyp=CEdMemLstCtrl::viewtyp;
  CEdMemLstCtrl::memspec=memspec;  
  if(rowentries >0)
  {
    for(i=rowentries;i!=-1;i--)
      DeleteColumn(i); //Alle Spalten L�schen 	
  }
  DeleteAllItems();
  
  // zuerst alle Spalten anlegen
  // Spalte0    
  addlen=prc->GetMemSize(memspec);
  switch(addlen)
  {
    case S8:
         lvc.cx=6*fwidth;
         break;
    case S16:
         lvc.cx=8*fwidth;
         break;
    case S32:
    default:
         lvc.cx=12*fwidth;
         break;  	
  }
  firstcolwidth=lvc.cx;
  lvc.mask=LVCF_WIDTH;
  lvc.iSubItem=0;
  InsertColumn(0,&lvc); 

  // und die anderen
  switch(viewtyp)
  { 
    case V_ASCII:
        lvc.cx =fwidth; // +1 Leerzeichen 
        itemlen=1;
        break;
    case V_BYTE:   
        lvc.cx =fwidth*3; // +1 Leerzeichen 
        itemlen=1;
        break;
    case V_SHORT:
    case V_INV_SHORT:
        lvc.cx =fwidth*5; // +1 Leerzeichen 
        itemlen=2;
        break;
    case V_LONG:
    case V_INV_LONG:      
    default:
        lvc.cx =fwidth*9; // +1 Leerzeichen 
        itemlen=4;
        break;
  }
  GetClientRect(&rc);
  int sb=GetSystemMetrics(SM_CXVSCROLL); //Scrollbarbreite
  rowentries=(rc.right - firstcolwidth-sb )/lvc.cx;   // erste Spalte immer fest 15=Scrollbarbreite
  for(i=1;i<=rowentries;i++)
  {
    lvc.iSubItem=i;
    lvc.mask=LVCF_WIDTH;
    InsertColumn(i,&lvc);
  }
  // als zweites die Adressen in die erste Spalte schreiben
  lines=GetCountPerPage();
  for(r=0;r<lines+1;r++)
  {
    if((startaddr + rowentries * r *itemlen) > addlen)
      break; //Aufh�ren wenn das Ende erreicht ist
    lvi.iItem=r;
 	lvi.iSubItem=0;
    lvi.mask=LVIF_TEXT;
    switch(addlen)
    {
      case S8:
           sval.Format("0x%2.2X", startaddr + rowentries * r *itemlen);
           break;
      case S16:
           sval.Format("0x%4.4X", startaddr + rowentries * r * itemlen);
           break;
      case S32:
      default:
           sval.Format("0x%8.8X", startaddr + rowentries * r * itemlen );
           break;
    }
    lvi.pszText=(char*)LPCSTR(sval);    
    InsertItem(&lvi); 
    for(c=0;c<rowentries;c++)
    { 
      b=GetMemVal(r,c+1,&val);      
      if(b)
      {        
        SetItemValText(&val,viewtyp,sval);
        sval="u" + sval;  //Initial auf nicht ge�ndert setzen        
      }
      else
        sval="u  ";
      SetItemText(r,c+1,sval);		       
    }
  }
  SetRedraw(TRUE);
}

#define DEFAULT_TEXTDRAW  DT_LEFT | DT_SINGLELINE | DT_NOPREFIX | DT_VCENTER
#define TEXTOFFSET 2

void CEdMemLstCtrl::DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct )
{
CDC* pDC;
CRect rcItem;
int nItem;
LV_COLUMN lvc;
char szBuff[100];
COLORREF txtcolor;
RECT rc;
CBrush br((COLORREF)0);
CString txt;
int l,i;
ULONG addr;


  lvc.mask=LVCF_WIDTH;
	GetClientRect(&rc);   
  rcItem=lpDrawItemStruct->rcItem;	
	nItem=lpDrawItemStruct->itemID;	
  pDC=CDC::FromHandle(lpDrawItemStruct->hDC);
  CFont* oldfont=pDC->SelectObject(&lfont);

  //Draw label in the first Column
  GetItemText(nItem,0,szBuff,sizeof(szBuff)); 
  rcItem.right=firstcolwidth;
  txtcolor=pDC->SetTextColor(0x808080); //text dunkelgrau
	pDC->DrawText(szBuff,-1,&rcItem,DEFAULT_TEXTDRAW);
  pDC->SetTextColor(txtcolor);

  //Draw all other labels
  i=1;  
     
  addr=startaddr+nItem*rowentries-1;
  l=GetItemText(nItem,i,szBuff,sizeof(szBuff));
  while(l)
  {    
    if(selitem!=nItem || selsubitem!=i)
    {  //nicht selektiert ->> normal zeichnen
      rcItem.left=GetColumnWidth(0)+(i-1)*GetColumnWidth(1);
      rcItem.right=rcItem.left+GetColumnWidth(1);
      //top und bottom kenne ich schon
      GetItemText(nItem,i,szBuff,sizeof(szBuff));
      
      if(*szBuff=='c')
      {
        pDC->SetTextColor(0x0000FF); //rot
        pDC->DrawText(szBuff+1,-1,&rcItem,DEFAULT_TEXTDRAW);
        pDC->SetTextColor(txtcolor); //alter Wert  
        //*szBuff='u';
        //SetItemText(nItem,i,szBuff);
        //ValidateRect(&rcItem);
      }
      else
      {          
        if(viewtyp==V_BYTE || viewtyp==V_ASCII)
        { 
          if(prc->IsBreakpointAtAddr(addr+i,BKPT_READ|BKPT_WRITE,memspec))
          {
            pDC->FillSolidRect(&rcItem,RGB(0xFF,0xC0,0x00));
            pDC->SetBkColor(RGB(0xFF,0xC0,0x00));
          }            
          else
          { 
            pDC->FillSolidRect(&rcItem,GetBkColor());         
            pDC->SetBkColor(GetBkColor());
          }
        }
        pDC->DrawText(szBuff+1,-1,&rcItem,DEFAULT_TEXTDRAW);        
      } 
      i++;
      l=GetItemText(nItem,i,szBuff,sizeof(szBuff));
    }   
    else  // ist selektiert ->> das EDIT-Control steht drauf
    {
      i++;
    }
  } 
  pDC->SelectObject(oldfont);
}

void CEdMemLstCtrl::SetItemValText(ULONG* val, int fmt, CString& sval)
{
    if(fmt & V_BYTE)                //ein Byte hexadezimal
      sval.Format("%2.2X",*(UCHAR*)val);
    else if(fmt & V_ASCII)
    { 
      char c=*(BYTE*)val;
      if(isprint(c))    
        sval=c;
      else
        sval='.';
    }
    else if(fmt & V_SHORT)          //zwei Byte hexadezimal HIGH-LOW
      sval.Format("%4.4X",*(USHORT*)val);
	  else if(fmt & V_LONG)           //vier Byte hexadezimal HIGH-LOW
      sval.Format("%8.8X",*(ULONG*)val);
    else if(fmt & V_INV_SHORT)   //zwei Byte low-High
    {
      UCHAR* ph=&(*(UCHAR*)val);
      sval.Format("%2.2X%2.2X",*(ph+1),*ph);
    }
    else if(fmt & V_INV_LONG)   //zwei Byte low-High
    {
      UCHAR* ph=(UCHAR*)val;
      sval.Format("%2.2X%2.2X%2.2X%2.2X",*(ph+3),*(ph+2),*(ph+1),*ph);
    }
}

//setzt den neuen Wert in Liste und Speicher
void CEdMemLstCtrl::UpdateList(ULONG newval)
{
CString txt;

  SetItemValText(&newval,viewtyp,txt);
  SetMemVal(edit.act,edit.actsub,newval);
  txt="c" + txt; //�nderungsmerker anf�gen
  SetItemText(edit.act,edit.actsub,LPCSTR(txt)); 
  
}

// schaltet auf Byte Anzeige
void CEdMemLstCtrl::OnByte()
{
  SetCols(V_BYTE,memspec,startaddr);
}

// schaltet auf 16-Bit Anzeige
void CEdMemLstCtrl::OnShort()
{
  SetCols(V_SHORT,memspec,startaddr);
}

// schaltet auf 32-Bit Anzeige
void CEdMemLstCtrl::OnLong()
{
  SetCols(V_LONG,memspec,startaddr);
}

// schaltet auf Ascii-Anzeige
void CEdMemLstCtrl::OnAscii()
{
  SetCols(V_ASCII,memspec,startaddr);
}

void CEdMemLstCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
LV_ITEM lvi;
RECT rc;
CString txt; 

 
	BOOL b=GetItemRectFromPoint(point,&lvi,&rc);	  
  if(!b)
    return;
  if(!lvi.iSubItem)
  {
    edit.ShowWindow(SW_HIDE);
    selitem=-1;
    RedrawItems(edit.act,edit.act);    
    SetFocus();
    return;
  } 
 
  txt=GetItemText(lvi.iItem,lvi.iSubItem);	 
  edit.SetWindowText(txt.Mid(1));
  GetItemRect(lvi.iItem,&rc,LVIR_BOUNDS);
  rc.left=firstcolwidth+(lvi.iSubItem-1)*GetColumnWidth(1);
  if(viewtyp != V_ASCII)
  {
    edit.SetWindowPos(&wndTop,
	                  rc.left,
	    						  rc.top,
			  					  GetColumnWidth(1),
				  				  rc.bottom-rc.top,
					  			  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
  }
  else
  {
    edit.SetWindowPos(&wndTop,
	                  rc.left,
	    						  rc.top,
			  					  GetColumnWidth(1)+fwidth,
				  				  rc.bottom-rc.top,
					  			  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
  }
  edit.Invalidate(FALSE);
  edit.ShowWindow(SW_SHOW);
  edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols    
  edit.SetFocus();  
  selitem=lvi.iItem;
  selsubitem=lvi.iSubItem;
  if(edit.act !=-1)
    RedrawItems(edit.act,edit.act);    
  edit.act=selitem;
  edit.actsub=selsubitem;
}

//pr�ft die G�ltigkeit des eingegebenen Wertes. Wenn OK  wird der wert auf 
// *txtval geschrieben,return=TRUE

BOOL CEdMemLstCtrl::CheckValid(int item,int subitem, CString& txt, ULONG* txtval)
{
ULONG val, v1;


  if(item==-1)
		return FALSE;
  if(viewtyp != V_ASCII)
  {
	  if(!IsHexString(txt))
      return FALSE;
    val=strtoul(txt,NULL,16);      
  }
  else
  {
    val=(BYTE)txt[0];
  }
  *txtval=val;
  GetMemVal(item,subitem,&v1);
	if(v1 != val)
  {      
	  return(TRUE);
  }		  
	return FALSE;
}

// liefert zu einem Punkt das zugeh�rige Rechteck ,Index und SubIndex
BOOL CEdMemLstCtrl::GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc)
{
BOOL b;
int ncol;
int w;
LV_COLUMN lvc;
int x;

  
  UINT flags=LVHT_ONITEM |LVHT_TORIGHT ;
  lvi->iItem=HitTest(point,&flags);  //finde den Index des Items zum Punkt
	GetItemRect(lvi->iItem,rc,LVIR_LABEL);
  x=point.x;
  point.x=rc->left;
  if( lvi->iItem == -1) //item nicht gefunden
	  return FALSE;	
	lvc.mask=LVCF_WIDTH ;
	ncol=0;
	w=0;
  do
	{
    b=GetColumn(ncol,&lvc);
		if(b)                 
    {
			rc->left=w;
      w+=lvc.cx;
			if(x <=w)
      {   // die Spalte haben wir gesucht        
				rc->right=w;
				lvi->iSubItem=ncol;
				return TRUE;
      }
    } 
		ncol++;
	}while(b);
	return FALSE;
}

void CEdMemLstCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	edit.SetFocus();
	edit.SetSel(0,-1);	
	CListCtrl::OnLButtonDblClk(nFlags, point);
}

void CEdMemLstCtrl::OnKillFocus(CWnd* pNewWnd) 
{
CString txt;
 	 
  if(pNewWnd!=this && pNewWnd!=&edit || selsubitem==0) // das fenster hat den Focus nicht mehr
  {
    edit.ShowWindow(SW_HIDE); 
    selitem=-1;    
  }
}


// liefert den akztuellen Inhalt des Speicher entsprechend eingestellter
// startaddresse, viewmode,speicherbereich, Spalte ,Zeile
// Spalte ist ab 1 indiziert!!
BOOL CEdMemLstCtrl::GetMemVal(int r,int c,ULONG* mval)
{
ULONG v0,v1,v2,v3;
BOOL b;
ULONG addr;
  
  c--; 
  b=FALSE; 
  switch(viewtyp)
  { 
    case V_ASCII:
    case V_BYTE:  addr=startaddr+r*rowentries+c;
                  break;
    case V_INV_SHORT:
    case V_SHORT: addr=startaddr+(r*rowentries+c)*2;
                  break;
    case V_INV_LONG:
    case V_LONG:  addr=startaddr+(r*rowentries+c)*4;
                  break;
    default:
           return FALSE;
  }  
  addr &= prc->GetMemSize(memspec);
  switch(viewtyp)
  {
     case V_ASCII:
     case V_BYTE:
          b=prc->GetMemFromAddr(addr,mval,memspec);
          break;
     case V_SHORT: //HL-Format
          prc->GetMemFromAddr(addr,&v0,memspec);
          b=prc->GetMemFromAddr(addr+1,&v1,memspec);
          *mval=(v0<<8) | v1;
          break;
     case V_LONG:
          prc->GetMemFromAddr(addr,&v0,memspec);
          prc->GetMemFromAddr(addr +1,&v1,memspec);
          prc->GetMemFromAddr(addr +2,&v2,memspec);
          b= prc->GetMemFromAddr(addr +3,&v3,memspec);
          *mval=(v0<<24) | (v1<<16) | (v2<<8) | v3;
          break;
     case V_INV_SHORT:
          prc->GetMemFromAddr(addr+1,&v0,memspec);
          b=prc->GetMemFromAddr(addr,&v1,memspec);
          *mval=(v0<<8) | v1;
          break;
     case V_INV_LONG:
          prc->GetMemFromAddr(addr+3,&v0,memspec);
          prc->GetMemFromAddr(addr+2,&v1,memspec);
          prc->GetMemFromAddr(addr+1,&v2,memspec);
          b=prc->GetMemFromAddr(addr,&v3,memspec);
          *mval=(v0<<24) | (v1<<16) | (v2<<8) | v3;
          break;
  }
  return(b);
}

void CEdMemLstCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
RECT rc;

	if(nSBCode==SB_LINEDOWN && (GetTopIndex()+GetCountPerPage()>=GetItemCount()))
  {
    InsertOneLine();
  }
  CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar); 
  
  if(selitem!=-1)
  {
    UpdateWindow();
    GetItemRect(edit.act,&rc,LVIR_BOUNDS);
    rc.left=firstcolwidth+(edit.actsub-1)*GetColumnWidth(1);
    edit.ShowWindow(SW_HIDE);
    edit.SetWindowPos(&wndTop,
	                    rc.left,
	    						    rc.top,
			  					    GetColumnWidth(1)-TEXTOFFSET,
				  				    rc.bottom-rc.top,
					  			    SWP_DRAWFRAME |SWP_SHOWWINDOW);      
    edit.UpdateWindow();//erzwingt ein sofortiges Neuzeichnen des Editcontrols
    edit.ShowWindow(SW_SHOW);
  }  
}


void CEdMemLstCtrl::InsertOneLine()
{
int c;
LV_ITEM lvi;
CString sval;
ULONG val;

  lvi.iItem=GetItemCount();
	lvi.iSubItem=0;
  lvi.mask=LVIF_TEXT;
  switch(addlen)
  {
    case S8:
        sval.Format("0x%2.2X", (startaddr + lvi.iItem*itemlen*rowentries) & addlen);
        break;
    case S16:
         sval.Format("0x%4.4X", (startaddr + lvi.iItem*itemlen*rowentries) & addlen);
           break;
    case S32:
    default:
         sval.Format("0x%8.8X", (startaddr + lvi.iItem*itemlen*rowentries) & addlen );
         break;
  }
  lvi.pszText=(char*)LPCSTR(sval);
  if(!GetMemVal(lvi.iItem,0,&val))  //wenn auf der Adresse kein Speicher existiert 
  {                                 //ist Schluss        
    return;                         
  }
  InsertItem(&lvi); 
  for(c=0;c<rowentries;c++)
  {  
    if(GetMemVal(lvi.iItem,c+1,&val))      
    {
      SetItemValText(&val,viewtyp,sval);
      sval="u" + sval;  //Initial auf nicht ge�ndert setzen
    } 
    else
      sval="u  ";
    SetItemText(lvi.iItem,c+1,sval);		       
  }    
}

void CEdMemLstCtrl::OnRButtonDown(UINT nFlags, CPoint point) 
{	
  CMenu  Popup;
  
    ClientToScreen(&point);
    Popup.LoadMenu (IDR_MEMMENU);
    OpenClipboard();
    HANDLE hclp=GetClipboardData(CF_TEXT);
    CloseClipboard();
    if(hclp && (viewtyp==V_ASCII || viewtyp==V_BYTE))
      Popup.EnableMenuItem(ID_MEMPASTE, MF_ENABLED|MF_BYCOMMAND);
    else
      Popup.EnableMenuItem(ID_MEMPASTE, MF_GRAYED|MF_BYCOMMAND);
    Popup.GetSubMenu(0)->TrackPopupMenu ((TPM_LEFTALIGN | TPM_RIGHTBUTTON),
        point.x,point.y,this);

    //CListCtrl::OnRButtonDown(nFlags, point);
}



BOOL CEdMemLstCtrl::SetMemVal(int r,int c,ULONG val)
{
ULONG addr;
ULONG oldval;
ULONG v1,v;

  c--;
  switch(viewtyp)
  { 
    case V_ASCII:
    case V_BYTE:  addr=startaddr+r*rowentries+c;
                  break;
    case V_INV_SHORT:
    case V_SHORT: addr=startaddr+(r*rowentries+c)*2;
                  break;
    case V_INV_LONG:
    case V_LONG:  addr=startaddr+(r*rowentries+c)*4;
                  break;
    default:
           return FALSE;
  }  
  addr &= prc->GetMemSize(memspec);
  oldval=0;
  switch(viewtyp)
  {
     case V_ASCII:
     case V_BYTE:
          oldval=prc->SetMemAtAddr(addr,&val,memspec);
          break;
     case V_INV_SHORT:
     case V_SHORT: //HL-Format
          v1=val>>8;
          v=prc->SetMemAtAddr(addr,&v1,memspec);
          v=v<<8;
          v1=val&0xFF;
          oldval=prc->SetMemAtAddr(addr+1,&v1,memspec);          
          v+=oldval;
          break;
     case V_LONG:
     case V_INV_LONG:
          v1=val>>24;
          v=prc->SetMemAtAddr(addr,&v1,memspec);
          v=v<<24;
          v1=(val>>16)&0xFF;
          oldval=prc->SetMemAtAddr(addr+1,&v1,memspec);
          v=v | (oldval<<16);
          v1=(val>>8)&0xFF;
          oldval=prc->SetMemAtAddr(addr+2,&v1,memspec);
          v=v | (oldval<<8); 
          v1=val&0xFF;
          oldval=prc->SetMemAtAddr(addr+3,&v1,memspec);
          v=v | oldval;           
          break;
        
  }
  return(oldval);
}

void CEdMemLstCtrl::ReEvaluate()
{
ULONG actval;
CString sval;
int r,c;
BOOL b;
       
  int lines=GetItemCount();

  for(r=0;r<lines+1;r++)
  {    
    for(c=0;c<rowentries;c++)
    { 
      b=GetMemVal(r,c+1,&actval);      
      if(b)
      {                
        SetItemValText(&actval,viewtyp,sval);
        CString acttxt=GetItemText(r,c+1);            
        if(acttxt!="" && sval != acttxt.Mid(1))
        {
          sval="c" + sval;  //Initial auf nicht ge�ndert setzen        
          SetItemText(r,c+1,sval);          
        }
        else if(acttxt!="" && acttxt[0]=='c')
        {
          acttxt.SetAt(0,'u');
          SetItemText(r,c+1,acttxt); 
        }
      }
      else 
      {
        sval="u  ";
        SetItemText(r,c+1,sval);		       
      }
    }
  }
}


long CEdMemLstCtrl::OnEnter(UINT wparam, LONG lparam)
{
CString txt;
ULONG val;
RECT rc;

  edit.ShowWindow(SW_HIDE); 
  selitem=-1;    
  edit.GetWindowText(txt);    
  if(edit.GetModify())
  {
    if(CheckValid(edit.act,edit.actsub,txt,&val))
    {
      SetMemVal(edit.act,edit.actsub,val);
      ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches(); 
	  return 0;
	}   
  } 
  edit.GetWindowRect(&rc);
  ScreenToClient(&rc);
  InvalidateRect(&rc,FALSE); 
  return 0;
}

long CEdMemLstCtrl::OnCtlKey(UINT wparam, LONG lparam)
{
  if(wparam=='r' || wparam=='R')  //toggle Lese Break  
    OnToggleReadBreak();  
  else if(wparam=='w' || wparam=='W')  //toggle Schreib Break  
    OnToggleWriteBreak(); 
  return 0;
} 

long CEdMemLstCtrl::OnCursorKey(UINT wparam, LONG lparam)
{
RECT rc;
CString txt;
int actold;  
  
  actold=edit.act;
  switch(wparam)
  {
    case 0x27:  // ->
      if(edit.actsub < rowentries)              
        edit.actsub++;
      else
      {
        edit.actsub=1;
        edit.act++;
        if(edit.act == (GetTopIndex()+GetCountPerPage()))
        {
          InsertOneLine();
          GetItemRect(edit.act,&rc,LVIR_BOUNDS);
          Scroll(CSize(0,rc.bottom-rc.top));
        }
      }
      break;
    case 0x25: // <-
      if(edit.actsub > 1)              
        edit.actsub--;
      else
      {        
        if(edit.act>0)
        {
          edit.actsub=rowentries;
          edit.act--;
          if(edit.act<GetTopIndex())
          {
            GetItemRect(actold,&rc,LVIR_BOUNDS);
            Scroll(CSize(0,-rc.bottom));
          } 
        }
        else
          return 0;
      }
      break;
      
    case 0x28:
       edit.act++;
       if(edit.act == (GetTopIndex()+GetCountPerPage()))
       {
         InsertOneLine();
         GetItemRect(edit.act,&rc,LVIR_BOUNDS);
         Scroll(CSize(0,rc.bottom-rc.top));
       }
       break;
    case 0x26: // ^
        if(edit.act>0)
        {          
          edit.act--;
          if(edit.act<GetTopIndex())
          {
            GetItemRect(actold,&rc,LVIR_BOUNDS);
            Scroll(CSize(0,-rc.bottom));
          } 
        }
        else
          return 0; 
        break;  
    default: 
      return 0;
  }

  txt=GetItemText(edit.act,edit.actsub);	 
  edit.SetWindowText(txt.Mid(1));
  GetItemRect(edit.act,&rc,LVIR_BOUNDS);
  rc.left=firstcolwidth+(edit.actsub-1)*GetColumnWidth(1);
  if(viewtyp != V_ASCII)
  {
    edit.SetWindowPos(&wndTop,
	                  rc.left,
	    						  rc.top,
			  					  GetColumnWidth(1),
				  				  rc.bottom-rc.top,
					  			  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
  }
  else
  {
    edit.SetWindowPos(&wndTop,
	                  rc.left,
	    						  rc.top,
			  					  GetColumnWidth(1)+fwidth,
				  				  rc.bottom-rc.top,
					  			  SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOREDRAW);	
  }
  edit.Invalidate(FALSE);
  edit.ShowWindow(SW_SHOW);
  edit.UpdateWindow(); //erzwingt ein sofortiges Neuzeichnen des Editcontrols    
  edit.SetFocus();  
  selitem=edit.act;
  selsubitem=edit.actsub;
  if(edit.act !=-1)
    RedrawItems(actold,actold);    
 
  return 0;
}


BOOL CEdMemLstCtrl::PreTranslateMessage(MSG* pMsg) 
{	
	if(    pMsg->message == WM_KEYDOWN &&
     (  (pMsg->wParam=='V' && GetKeyState(VK_CONTROL) & 0x8000)
      ||(pMsg->wParam==VK_INSERT && GetKeyState(VK_SHIFT) & 0x8000))) 
  {    
    if(GetFocus()==this)
    {
      OnPaste();
    }
  }
	return CListCtrl::PreTranslateMessage(pMsg);
}

long CEdMemLstCtrl::OnEdPaste(UINT wparam, LONG lparam)
{
int l;
ULONG addr=0;
   
   OpenClipboard();
   HANDLE hclp=GetClipboardData(CF_TEXT);
   if(!hclp)
   {
     CloseClipboard();
     return 0;
   }
   char* cp=(char*)::GlobalLock(hclp);
   l=strlen((char*)cp);
   GlobalUnlock(hclp);
   CloseClipboard();
   switch(viewtyp)
   {
     case V_BYTE:
     case V_ASCII:
               if(l<3)
                 return 0;
               else               
                 addr=startaddr+edit.act*rowentries+(edit.actsub-1);               
               break;

     case V_SHORT:
     case V_INV_SHORT:
     case V_LONG:
     case V_INV_LONG:
               return 0;
               break;  
   }     
   edit.ModifyStyle(WS_VISIBLE,0);
   selitem=-1;
   selsubitem=-1;
   Paste(addr);   
   return 1;
}

void CEdMemLstCtrl::OnPaste()
{
  Paste(startaddr);
}

void CEdMemLstCtrl::Paste(ULONG addr) 
{
ULONG v;
int l;
char* cp;
char buff[4];

  if(viewtyp==V_ASCII || viewtyp==V_BYTE)
  {
    OpenClipboard();
    HANDLE hclp=GetClipboardData(CF_TEXT);
    if(hclp)
    {
      cp=(char*)::GlobalLock(hclp);
      l=strlen(cp);      
      if(viewtyp==V_ASCII)
      {
        while(l--)
        {
          v=*cp++;
          prc->SetMemAtAddr(addr++,&v,memspec); 
        }
        v=0;
        prc->SetMemAtAddr(addr,&v,memspec);
      }
      else if(viewtyp==V_BYTE)
      {   // die Daten m�ssen im Format "00 AA 12" vorliegen 
        while(l>=2)
        {
          strncpy(buff,cp,3); 
          cp+=3; 
          if(!IsHexString(buff))
            break;
          v=strtoul(buff,0,16);          
          l-=3;
          v&=0x000000FF;
          prc->SetMemAtAddr(addr++,&v,memspec);
        }
      }
      GlobalUnlock(hclp);
    }
    CloseClipboard();
  }
  ((CMainFrame*)AfxGetMainWnd())->UpdateAllWatches();
}


void CEdMemLstCtrl::OnToggleReadBreak()
{
ULONG addr;  
USHORT fmt;
  addr=startaddr+edit.act*rowentries+edit.actsub-1;
  fmt=prc->GetBkptFormat(addr,memspec);
  if(fmt & BKPT_READ)        
    fmt &=~BKPT_READ;   //Read Breakpoint l�schen  
  else        
    fmt |=BKPT_READ;  //Read Breakpoint setzen
  if(!fmt)
    prc->RemoveBreakpoint(addr,memspec); 
  else
    prc->SetBreakpoint(addr,fmt,memspec); 
  edit.ShowWindow(SW_HIDE);
  selitem=-1;
  selsubitem=-1;
  RedrawItems(edit.act,edit.act);
  ((CMainFrame*)AfxGetMainWnd())->UpdateAllMemWnds((CMemWnd*)GetParent(),TRUE);
}

void CEdMemLstCtrl::OnToggleWriteBreak()
{
ULONG addr;  
USHORT fmt;
 
  addr=startaddr+edit.act*rowentries+edit.actsub-1;
  fmt=prc->GetBkptFormat(addr,memspec);
  if(fmt & BKPT_WRITE) 
    fmt &=~BKPT_WRITE;  //Write Breakpoint l�schen
  else      
    fmt |=BKPT_WRITE;   //Write Breakpoint setzen
  if(!fmt)
    prc->RemoveBreakpoint(addr,memspec); 
  else
    prc->SetBreakpoint(addr,fmt,memspec); 
  edit.ShowWindow(SW_HIDE);
  selitem=-1;
  selsubitem=-1;
  RedrawItems(edit.act,edit.act);
  ((CMainFrame*)AfxGetMainWnd())->UpdateAllMemWnds((CMemWnd*)GetParent(),TRUE);
}

long CEdMemLstCtrl::OnGetMenuState(UINT menuID, LONG lparam) 
{
USHORT fmt;
ULONG addr; 

  addr=startaddr+edit.act*rowentries+edit.actsub-1;
  fmt=prc->GetBkptFormat(addr,memspec);  
  if(menuID==ID_SETREADBRK)
  {
    if(fmt&BKPT_READ)
      return 1;
  }
  else if(menuID==ID_SETWRBRK)    
  {
    if(fmt&BKPT_WRITE)
      return 1;
  }  
  return 0;
}   

