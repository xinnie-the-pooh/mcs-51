// Template f�r die Prozessor-Klassen
#ifndef _PROC
#define _PROC

#include "typdesc.h"
#include "measpt.h"

// user defined messages
#define UM_UPDATEWATCHES   WM_USER+0x30
#define UM_GETSTATUSTXT    WM_USER+0x31
#define UM_UPDATESERINT    WM_USER+0x32

class CRegdef
{
public:
	ULONG GetRegVal();
	CRegdef();
	BOOL  bchanged;
	ULONG SetRegVal(ULONG val);
	void  SetRegLoc(void* loc,BOOL vloc=FALSE);
	void* GetRegPtr();
	char  regname[10];;	
	int   regfmt; 
 	BOOL  varloc;
protected:
	void* pcurval;
};


typedef struct
{
  ULONG opcode;  
  ULONG addr;
  ULONG fmt;
  ULONG memspec;  
}bkpt_t;


typedef struct
{
  int memspec;
  ULONG startaddr;
  ULONG endaddr;
  BOOL editable;
  BYTE* pmem;
} mcfg_t;

//Commands for extra windows

#define CMD_CHECKED  0x0001
#define CMD_ENABLED  0x0002


// Speicher-Spezifizierer (nur 8051!!)

#define M_CODE  0
#define M_XDATA 1
#define M_DATA  2
#define M_IDATA 3
#define M_PDATA 4

// Breakpointdefinitionen
#define BKPT_CODE      0x0100
#define BKPT_READ      0x0200 
#define BKPT_WRITE     0x0400
#define BKPT_TMP       0x0800
#define BKPT_DISABLED  0x1000
#define TRACEPOINT     0x2000
#define RUNTIMEMPT     0x4000 
#define STIMUPT        0x8000


// Speicherausrichtung L/H oder H/L
#define NORMAL   0  // =H/L
#define INVERS   1  // =L/H

//Speichergr��e
#define  S8      0xFF
#define  S16     0xFFFF
#define  S32     0xFFFFFFFF

#define TRACE_WATCH 1
#define TRACE_ASM   2
#define TRACE_HLL   4


#define MAXTRACELEN 1000

//Speicherbereichsbeschreibung+Typ  (8051 spezifisch)
 
#define CODEMEM     0x00
#define XDATAMEM    0x01
#define DATAMEM     0x02 
#define IDATAMEM    0x03
#define BITMEM      0x04
#define NUMBER      0x05
#define SEGINFOLBL  0x06
#define PDATAMEM    0x08


//G�ltigkeitsbereich
#define LOCSYM  0x01
#define PUBSYM  0x02
#define HLLINE  0x04

//Recordtypdefinitionen

#define REC_CODE         0x06
#define REC_DEBUG        0x12
#define REC_SRCNAME      0x24
#define REC_DEBUG_KEIL   0x22
#define REC_TYPEDEF      0x20 
#define REC_SCOPE        0x10
#define REC_MODHEAD      0x02
#define REC_MODEND       0x04
#define REC_START        0x70


//Language required  
#define _ENG  0
#define _GER  1

class CProc
{
public:	
  
  virtual const char* GetProcessorName()=0;
  virtual void Init(HWND hMainWnd,int language=_ENG)=0;
  virtual void ResetCPU()=0; 
  virtual BOOL GetPointer(ULONG* pointeraddr,ULONG* pointerval,
                        CTypdesc* pointtyp=NULL,
                        USHORT pointmem=0, ULONG* pointtomem=0,BOOL orderHL=TRUE)=0;
  
  virtual UINT Reassemble( ULONG code,LPSTR pms, HANDLE hMod=0)=0;
  virtual int ExecNextCmd( )=0;
  virtual void SetProgramCounter(ULONG pc)=0;
  virtual ULONG GetProgramCounter()=0; 
  virtual ULONG GetStartUpAddress()=0;

  //memory mapping
  
  virtual ULONG GetMemSize(ULONG mempec=0)=0;  
  virtual int GetMemAlignment()=0;
  virtual BOOL IsMemAtAddress(ULONG addr, ULONG memspec=0)=0;
  virtual int CreateMemInRange(ULONG memspec=0,ULONG startaddr=0, ULONG endaddr=0)=0;
  virtual BOOL DeleteMem(int blockindex=0,char memspec=0)=0;
  virtual int GetNextMemMapping(mcfg_t* pMemCfg,int blockindex=-1)=0;
  virtual ULONG GetDestinationAddress(ULONG addr,ULONG memspec=0)=0;

  // Register access
  virtual CRegdef* GetNextRegister(int index=0)=0;  
  virtual ULONG GetRegOffset(int index=0)=0;

  // Breakpoint functions
  virtual BOOL SetBreakpoint(ULONG addrc,USHORT fmt=BKPT_CODE,int memspec=0)=0;
  virtual BOOL RemoveBreakpoint(ULONG addr,int memspec=0)=0;
  virtual ULONG IsBreakpointAtAddr(ULONG addr,ULONG fmt=0,int memspec=0)=0;
  virtual USHORT GetBkptFormat(ULONG addr,int memspec=0)=0; 
  virtual void RestoreOpcode(ULONG addr)=0;
  virtual void RestoreBkpt(ULONG addr)=0;
  virtual BOOL ClrTempBkpt(ULONG addr)=0;
  virtual ULONG GetStepOverAddr(ULONG addr)=0;
  virtual BOOL IsReturn(ULONG addr)=0;
  virtual BOOL GetNextBreakpoint(POSITION& pos, bkpt_t* bkpt)=0;  

  // Memory access
  virtual BOOL GetMemFromAddr(ULONG addr,ULONG* valp,ULONG memspec=0)=0;
  virtual ULONG SetMemAtAddr(ULONG addr,ULONG* pval,ULONG memspec)=0;
  virtual BOOL WriteMemBlock(ULONG addr,UCHAR* bp,USHORT len,ULONG memspec=0)=0;

  //Analyser functions
  virtual ULONG GetCyclCnt(BOOL bDelete=FALSE)=0;
  virtual void EnableTraceLog(LPCSTR logname=NULL,int tracetype=0,ULONG addr=0)=0;
  virtual void SetMeasurePoint(CMeasurePoint* pmpt)=0; 
};

#endif // _PROC