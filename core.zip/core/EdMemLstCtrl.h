// EdMemLstCtrl.h : header file
//

#ifndef _EDMEMLSTCTRL
  #define _EDMEMLSTCTRL

#include "editnotify.h"
/////////////////////////////////////////////////////////////////////////////
// CEdMemLstCtrl window

//Darstellungstypen
#define V_BYTE            1
#define V_SHORT           2
#define V_LONG            4
#define V_INV_SHORT       8
#define V_INV_LONG     0x10
#define V_ASCII        0x20


//Breite der ersten Spalte
#define FIRSTCOL      43

class CEdMemLstCtrl : public CListCtrl
{
friend class CMemWnd;
// Construction
public:	
	void Paste(ULONG addr);	
	void ReEvaluate();
	BOOL SetMemVal(int r,int c,ULONG val);
	int selsubitem;
	BOOL GetItemRectFromPoint(POINT point,LV_ITEM* lvi,LPRECT rc);
	int viewtyp;
	int rowentries;
  int fwidth;
	int firstcolwidth;
	ULONG startaddr;
	void UpdateList(ULONG newval);
	int selitem;
	int lastsel;
	void SetItemValText(ULONG* val, int fmt, CString& sval);
	void DrawItem( LPDRAWITEMSTRUCT lpDrawItemStruct );
	void SetCols(int viewtyp, int memspec=0, ULONG startaddr=0);
  BOOL CheckValid(int item, int subitem, CString& txt, ULONG* txtval);
	CEdMemLstCtrl(ULONG startaddr=0);
  
  void Create();
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEdMemLstCtrl)  
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL
  
// Implementation
public:
  virtual ~CEdMemLstCtrl();

	// Generated message map functions
protected:
  int boff;
  int toff;
  int roff;
  int loff;
  ULONG addlen;
  int itemlen;
  void InsertOneLine();
  BOOL GetMemVal(int r,int c,ULONG* mval);
  int memspec;
  CFont lfont;	
  CEditNotify edit;
  //{{AFX_MSG(CEdMemLstCtrl)
  afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
  afx_msg void OnKillFocus(CWnd* pNewWnd);
  afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
  afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnByte();
  afx_msg void OnShort();
  afx_msg void OnLong();
  afx_msg void OnAscii();  
  afx_msg void OnFloat();
  afx_msg void OnDock(); 
  afx_msg void OnPaste();
  afx_msg long OnEdPaste(UINT wparam, LONG lparam);
  afx_msg long OnGetMenuState(UINT menuID, LONG lparam);
  afx_msg long OnEnter(UINT wparam, LONG lparam);
  afx_msg long OnCursorKey(UINT wparam, LONG lparam);  
  afx_msg long OnCtlKey(UINT wparam, LONG lparam);
  afx_msg void OnToggleReadBreak();
  afx_msg void OnToggleWriteBreak();
   
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

#endif //_EDMEMLSTCTRL
/////////////////////////////////////////////////////////////////////////////
