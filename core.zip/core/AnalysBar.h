// AnalysBar.h : header file
//
#ifndef _ANALYSBAR
#define _ANALYSBAR
/////////////////////////////////////////////////////////////////////////////
// CAnalysBar window

#define STDBUTTONS 14

class CAnalysBar : public CFlatToolBar
//class CAnalysBar : public CToolBarEx
{
// Construction
public:
	BOOL Created;
	BOOL Init(CWnd* pParentWnd);
	CAnalysBar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnalysBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	void ResetAnalysBar();
	int AddButton(UINT idcmd,UINT idbmp);
	virtual ~CAnalysBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnalysBar)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
    BOOL afx_msg OnTTPtext( UINT id, NMHDR * pTTTStruct, LRESULT * pResult );     
	DECLARE_MESSAGE_MAP()
};

#endif //_ANALYSBAR
/////////////////////////////////////////////////////////////////////////////
