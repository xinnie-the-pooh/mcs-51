//Imlementierung Klasse CModDef 

#include "stdafx.h"
#include "jstep.h"
#include "objinfo.h"
#include "ModDef.h"
#include "mainfrm.h"



CModDef::CModDef(LPCSTR pmodulname,LPCSTR psrcpath)
{
  if(psrcpath)
    SrcPath=psrcpath;
	else
     SrcPath="";
  modname=pmodulname;
  highaddr=0;
  lowaddr=0xFFFFFFFF;
  ObExt=FALSE;
}

//Destruktor
CModDef::~CModDef()
{
POSITION pos;
int i;
CProcDef* pp;
  i=alines.GetSize();
  while(i--)
    delete (linedef_t*)alines.GetAt(i);
  alines.RemoveAll();
  
  pos=proclist.GetHeadPosition();
  while(pos)
  {     
    pp=(CProcDef*)proclist.GetNext(pos);
  	delete pp;	  
  }
  proclist.RemoveAll();
}

//f�gt eine neue Prozedurdefinition an

CProcDef* CModDef::AddProc(LPCSTR procname,ULONG AnfAddr,ULONG EndAddr,CModDef* pmod)
{
POSITION pos;
CProcDef* pc;
char buff[100];

  
  pos=proclist.GetHeadPosition();
  while(pos)
  {  
    pc=(CProcDef*)proclist.GetNext(pos);
    if(pc->Procname==procname) 
    {    
      if(!(EndAddr<=pc->AnfAddr || AnfAddr >= pc->EndAddr))
       return pc;
      else
      {
        if(theApp.objinfo.FindLabel(AnfAddr,buff))
          procname=buff;
      }
    }
  }
  CProcDef* pp=new CProcDef;
  pp->AnfAddr=AnfAddr;
  pp->EndAddr=EndAddr;
  pp->Procname=procname;
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  pm->m_browsWnd.AddProc(pp,pmod);
  TRACE("%s new proc: %s AnfAddr: %8.8X, EndAddr: %8.8X\n",modname,procname,AnfAddr,EndAddr);

  
  if(AnfAddr<=lowaddr)
  { 
    lowaddr=AnfAddr;
    proclist.AddHead(pp);
    if(EndAddr>highaddr)
      highaddr=EndAddr;
    return pp;
  }
  if(EndAddr>=highaddr)
  {
    highaddr=EndAddr;
    proclist.AddTail(pp);
    return pp;
  }     
  pos=proclist.GetHeadPosition();
  while(pos)
  {
    pc=(CProcDef*)proclist.GetAt(pos);
    if(pc->AnfAddr>AnfAddr)
    {
      proclist.InsertBefore(pos,pp);
      return pp;
    }
    proclist.GetNext(pos);
  } 
  pos=proclist.GetHeadPosition();
  while(pos)
  {
    pc=(CProcDef*)proclist.GetAt(pos);
    if(AnfAddr>pc->EndAddr)
    {
      proclist.InsertAfter(pos,pp);
      return pp;
    }
    proclist.GetNext(pos);
  } 
  return 0;
}

CProcDef* CModDef::AddProc(LPCSTR procname)
{

  CProcDef* pp=new CProcDef;  
  pp->AnfAddr=0xFFFFFFFF;
  pp->EndAddr=0;
  pp->Procname=procname;
  CMainFrame* pm=(CMainFrame*)AfxGetMainWnd();
  pm->m_browsWnd.AddProc(pp,this);
  proclist.AddTail(pp);
  TRACE("%s new proc: %s\n",modname,procname);
  return pp;
}

//liefert die Anzahl der registrierten Prozeduren
int CModDef::GetProcCnt()
{
  return(proclist.GetCount());
}


void CModDef::SetAnfAddr(CProcDef* pp, ULONG addr)
{  
  if(addr<pp->AnfAddr)
    pp->AnfAddr=addr;
  if(addr<lowaddr)       
    lowaddr=addr;  
}

void CModDef::SetEndAddr(CProcDef* pp, ULONG addr)
{ 
  if(addr>pp->EndAddr)
		pp->EndAddr=addr;
  if(addr>highaddr)	
    highaddr=addr;
}

void CModDef::SortProcs()
{

POSITION pos;
CProcDef* pp;
ULONG anfaddr;
 

  CPtrList* ptmp=new CPtrList(proclist.GetCount()+1);
  anfaddr=0xFFFFFFFF;
  pos=proclist.GetHeadPosition();    
  while(pos)
  {
    pp=(CProcDef*)proclist.GetNext(pos); 
    if(pp->AnfAddr<anfaddr)
    {
      ptmp->AddHead(pp);
      anfaddr=pp->AnfAddr;
    } 
    else
      ptmp->AddTail(pp);       
  }
  proclist.RemoveAll();
  pos=ptmp->GetHeadPosition();  
  while(pos)
  {    
    pp=(CProcDef*)ptmp->GetNext(pos);
    proclist.AddTail(pp); 
  }  
  ptmp->RemoveAll(); 
  delete ptmp;
}
