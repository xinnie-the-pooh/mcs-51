// AnaWnd.h : header file
//
#ifndef _ANALYSERWND
#define _ANALYSERWND

#include "ndlgbar.h"
/////////////////////////////////////////////////////////////////////////////
// CAnaWnd window

class CAnaWnd : public CNDlgBar
{
// Construction
public:
	void SetClockVal(LPCSTR clk);
	BOOL traceEnabled;
	time_t t0,t1;
	void StartCnt();
	void UpdateAnalyser();		
	BOOL Create( CWnd* pParentWnd );
	CAnaWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnaWnd)  
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAnaWnd();

	// Generated message map functions
protected:	
	void DisplayMeasureResult();
	float clockval;
	CEditNotify editclock;
  BOOL docking;
public:
	CString* GetNextCommand();
	CString cmdbuff;
	CString stimfilename;
	CStdioFile stimfile;
 
  //{{AFX_MSG(CAnaWnd)
  afx_msg void OnCntReset(); 
  afx_msg void OnUpdateCntReset(CCmdUI* pCmdUI);  
  afx_msg long OnEditReturn(UINT wparam, LONG lparam);
  afx_msg void OnTraceEnable();
  afx_msg void OnTraceTyp();
  afx_msg void OnMesEnable();
  afx_msg void OnStimEnable();  
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
  afx_msg void OnDock();
  afx_msg void OnHide();
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

#endif _ANALYSERWND

/////////////////////////////////////////////////////////////////////////////
