// NEdit.h : header file
//
#ifndef _NEDIT
#define _NEDIT
/////////////////////////////////////////////////////////////////////////////
// CNEdit window

class CNEdit : public CEdit
{
// Construction
public:
	BOOL localecho;
  BOOL binstr;
  unsigned char hexval; 
	CNEdit();
  

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNEdit)
	//}}AFX_VIRTUAL

// Implementation
public:
		// Generated message map functions
protected:
	int charno;
	
	//{{AFX_MSG(CNEdit)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

#endif //_NEDIT
/////////////////////////////////////////////////////////////////////////////
