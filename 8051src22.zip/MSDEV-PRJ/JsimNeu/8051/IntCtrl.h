// IntCtrl.h : header file
//

#ifndef _INTCTRL
#define _INTCTRL

#include "dlldlgBar.h"

/////////////////////////////////////////////////////////////////////////////
// CIntCtrl window

#define iIE0 0
#define iIE1 1
#define iIE2 2
#define iIE3 3
#define iIE4 4
#define iINTENABLE 5
#define iIP0 6
#define iIP1 7
#define iIP2 8
#define iIP3 9
#define iIP4 10
#define iINT0 11
#define iINT1 12
#define iINT2 13
#define iINT3 14
#define iINTTX4 15
#define iINTRX4 16


class CIntCtrl : public CDllDlgBar
{
// Construction
public:
	void UpdateDlgBar();	
	BOOL Create(HWND hWndMain,CDialogBar* pd);
	CIntCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CIntCtrl();

	// Generated message map functions
protected:

  int id[17];     
  
	//{{AFX_MSG(CIntCtrl)
    afx_msg LONG OnUpdateSerInt( UINT, LONG ); 
    afx_msg void OnEnable0();    
    afx_msg void OnEnable1();    
    afx_msg void OnEnable2();    
    afx_msg void OnEnable3();    
    afx_msg void OnEnable4();        
    afx_msg void OnPrioInt0();    
    afx_msg void OnPrioInt1();    
    afx_msg void OnPrioInt2();    
    afx_msg void OnPrioInt3();    
    afx_msg void OnPrioInt4();
    afx_msg void OnInt0();
    afx_msg void OnUpdateInt0(CCmdUI* pCmdUI);
    afx_msg void OnInt1();
    afx_msg void OnUpdateInt1(CCmdUI* pCmdUI);
    afx_msg void OnInt2();
    afx_msg void OnUpdateInt2(CCmdUI* pCmdUI);
    afx_msg void OnInt3();
    afx_msg void OnUpdateInt3(CCmdUI* pCmdUI);
    afx_msg void OnIntRx4();
    afx_msg void OnUpdateIntRx4(CCmdUI* pCmdUI);
    afx_msg void OnIntTx4();
    afx_msg void OnUpdateIntTx4(CCmdUI* pCmdUI);
    afx_msg void OnIntEnable();
    afx_msg void OnUpdateIntEnable(CCmdUI* pCmdUI);   
	//}}AFX_MSG
    
	DECLARE_MESSAGE_MAP()
};

#endif //_INTCTRL
/////////////////////////////////////////////////////////////////////////////
