// DllDlgBar.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "..\core\Proc.h"
#include "DllDlgBar.h"
//#include "resource.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDllDlgBar


CDllDlgBar::CDllDlgBar()
{
  Created=FALSE;
}

CDllDlgBar::~CDllDlgBar()
{
}

LONG CDllDlgBar::OnGetMessageText(UINT nID, LONG dummy)
{
CString ttp;
int l;

  ttp.LoadString(nID);
  if(ttp=="")
    return 0;
  l=ttp.Find('\n');
  ttp=ttp.Left(l);
  strcpy(ttptxt,LPCSTR(ttp));
  return (long)ttptxt;  
}

LONG CDllDlgBar::OnUpdateWatches(UINT, LONG)
{
  if(GetStyle() & WS_VISIBLE)
    UpdateDlgBar();
  return 0;
} 

BOOL CDllDlgBar::OnTtpNotify( UINT id, NMHDR * pNMHDR, LRESULT * pResult)
{
CString ttp;
int l;

  TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pNMHDR;
  UINT nID =pNMHDR->idFrom;
  if (pTTT->uFlags & TTF_IDISHWND)
  {
    // idFrom ist der HWND des Werkzeugs
    nID = ::GetDlgCtrlID((HWND)nID);
    if(nID)
    {
      ttp.LoadString(nID);
      l=ttp.Find('\n');
      ttp=ttp.Mid(l+1);
      strcpy(ttptxt,LPCSTR(ttp));
      pTTT->lpszText =ttptxt; 
      pTTT->hinst = AfxGetResourceHandle();
      return(TRUE);
    }
  }
  return(FALSE);
}


BEGIN_MESSAGE_MAP(CDllDlgBar, CWnd)
	//{{AFX_MSG_MAP(CDllDlgBar)
	  ON_WM_DESTROY()
    ON_MESSAGE( UM_UPDATEWATCHES , OnUpdateWatches)
    ON_MESSAGE( UM_GETSTATUSTXT , OnGetMessageText)
    ON_NOTIFY_EX(TTN_NEEDTEXT,0,OnTtpNotify)    
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CDllDlgBar 

BOOL CDllDlgBar::IsFloating()
{
  return pdlg->IsFloating();
}

BOOL CDllDlgBar::Create(HWND hwndParent, CDialogBar* dlgbar)
{
RECT rd;

  SubclassWindow(dlgbar->m_hWnd);
  pdlg=dlgbar;
  GetDesktopWindow()->GetWindowRect(&rd);
  CPoint pt;
  pt.x=rd.right/2-50;
  pt.y=rd.bottom/2-50;
  m_FloatingPosition=pt;
  EnableToolTips(TRUE);
  Created=TRUE;
  return Created;
}

void CDllDlgBar::OnDestroy() 
{
  CWnd::OnDestroy();
  Created=FALSE;
}

void CDllDlgBar::UpdateDlgBar()
{
}


