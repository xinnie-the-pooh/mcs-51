// TimCtrl.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "proc51.h"
#include "procdll.h"
#include "..\core\coreexport.h"
#include "TimCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTimCtrl

extern unsigned char datamem[256];
extern BOOL extTick0;
extern BOOL extTick1;

CTimCtrl::CTimCtrl()
{
  txtIsChanging=FALSE; 
  extTick0=FALSE;
  extTick1=FALSE; 
}

CTimCtrl::~CTimCtrl()
{
}


BEGIN_MESSAGE_MAP(CTimCtrl, CDllDlgBar)
	//{{AFX_MSG_MAP(CTimCtrl)
		// HINWEIS - Der Klassen-Assistent f�gt hier Zuordnungsmakros ein und entfernt diese.
    ON_COMMAND(IDC_EXTT0,OnTim0)
    ON_COMMAND(IDC_EXTT1,OnTim1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CTimCtrl::Create(HWND hWndMain,CDialogBar* pd)   
{

  CDllDlgBar::Create(hWndMain,pd);
	SetWindowText(_T("Timer"));
    
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TL0)))->SetRange(0,255);  
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TH0)))->SetRange(0,255);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TL1)))->SetRange(0,255);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TH1)))->SetRange(0,255);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TL0)))->SetPos(datamem[TL0]);  
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TH0)))->SetPos(datamem[TH0]);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TL1)))->SetPos(datamem[TL1]);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TH1)))->SetPos(datamem[TH1]);
  SetDlgItemInt(IDC_EDITTL0,datamem[TL0]);
  SetDlgItemInt(IDC_EDITTL1,datamem[TL1]);
  SetDlgItemInt(IDC_EDITTH1,datamem[TH1]);
  SetDlgItemInt(IDC_EDITTH0,datamem[TH0]);

  return(TRUE); 

}

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CTimCtrl 


void CTimCtrl::UpdateDlgBar()
{

  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TL0)))->SetPos(datamem[TL0]);  
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TH0)))->SetPos(datamem[TH0]);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TL1)))->SetPos(datamem[TL1]);
  ((CProgressCtrl*)(GetDlgItem(IDC_PRG_TH1)))->SetPos(datamem[TH1]);  
   if(txtIsChanging)
    return;

  CButton* pb=(CButton*)GetDlgItem(IDC_EXTT0);
  if(!(datamem[PORT3]&0x10))   //datamem[0xB0]
    pb->SetCheck(TRUE); 
  else
    pb->SetCheck(FALSE);  
  
  pb=(CButton*)GetDlgItem(IDC_EXTT1);
  if(!(datamem[PORT3]&0x20))
    pb->SetCheck(TRUE);
  else
    pb->SetCheck(FALSE);
 
  ((CEdit*)GetDlgItem(IDC_EDITTL0))->LimitText(3);
  ((CEdit*)GetDlgItem(IDC_EDITTL1))->LimitText(3);
  ((CEdit*)GetDlgItem(IDC_EDITTH0))->LimitText(3);
  ((CEdit*)GetDlgItem(IDC_EDITTH1))->LimitText(3);
  if(GetDlgItemInt(IDC_EDITTL0)!=datamem[TL0])      //datamem[0x8A]
    SetDlgItemInt(IDC_EDITTL0,datamem[TL0]);
  if(GetDlgItemInt(IDC_EDITTL1)!=datamem[TL1])
    SetDlgItemInt(IDC_EDITTL1,datamem[TL1]);
  if(GetDlgItemInt(IDC_EDITTH1)!=datamem[TH1])
    SetDlgItemInt(IDC_EDITTH1,datamem[TH1]);
  if(GetDlgItemInt(IDC_EDITTH0)!=datamem[TH0])
    SetDlgItemInt(IDC_EDITTH0,datamem[TH0]);
}

extern BOOL extTick0;
extern BOOL extTick1;

void CTimCtrl::OnTim0()
{
  CButton* pb=(CButton*)GetDlgItem(IDC_EXTT0);
  if(pb->GetCheck()) //gedr�ckt
  { 
    datamem[PORT3]&=~0x10;
    extTick0=TRUE;
  }
  else
  {
    datamem[PORT3]|=0x10;
    extTick0=FALSE;
  }
  txtIsChanging=TRUE;
  UpdateAllWatches();
  txtIsChanging=FALSE;
}


void CTimCtrl::OnTim1()
{ 
  CButton* pb=(CButton*)GetDlgItem(IDC_EXTT1);
  if(pb->GetCheck()) //gedr�ckt
  {
    datamem[PORT3]&=~0x20;
    extTick1=TRUE;
  }
  else
  {
    datamem[PORT3]|=0x20;
    extTick1=FALSE;
  }
  txtIsChanging=TRUE;
  UpdateAllWatches();
  txtIsChanging=FALSE;
}



BOOL CTimCtrl::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
int n;
	if(nCode!=EN_UPDATE)	
	  return CDllDlgBar::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
  txtIsChanging=TRUE;
  switch(nID)
  {
    case IDC_EDITTL0:
         n=GetDlgItemInt(IDC_EDITTL0);
         if(n>0xFF)
           SetDlgItemInt(IDC_EDITTL0,0xFF);
         datamem[TL0]=GetDlgItemInt(IDC_EDITTL0);          
         UpdateAllWatches();          
         break;
    case IDC_EDITTH0:
         n=GetDlgItemInt(IDC_EDITTH0);
         if(n>0xFF)
           SetDlgItemInt(IDC_EDITTH0,0xFF);
         datamem[TH0]=GetDlgItemInt(IDC_EDITTH0);    
         UpdateAllWatches();
         break;
    case IDC_EDITTL1:
         n=GetDlgItemInt(IDC_EDITTL1);
         if(n>0xFF)
           SetDlgItemInt(IDC_EDITTL1,0xFF);
         datamem[TL1]=GetDlgItemInt(IDC_EDITTL1);    
         UpdateAllWatches();
         break;
    case IDC_EDITTH1:
         n=GetDlgItemInt(IDC_EDITTH1);
         if(n>0xFF)
           SetDlgItemInt(IDC_EDITTH1,0xFF);
         datamem[TH1]=GetDlgItemInt(IDC_EDITTH1);    
         UpdateAllWatches();
         break;

  }
  txtIsChanging=FALSE;  
  return CDllDlgBar::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}
