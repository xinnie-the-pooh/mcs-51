//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by proc.rc
//
#define IDC_STATIC3                     3
#define IDD_SERSIM_E                    220
#define IDD_SERSIM                      221
#define IDD_INTERRUPT_E                 222
#define IDD_INTERRUPT                   223
#define IDB_TERMINAL                    223
#define IDD_ACCESS_E                    224
#define IDD_ACCESS                      225
#define IDD_TIMER                       226
#define IDB_INTERRUPT                   229
#define IDB_TIMER                       239
#define IDC_IP0_E                       2000
#define IDC_IP1_E                       2001
#define IDC_IP2_E                       2002
#define IDC_IP3_E                       2003
#define IDC_IP4_E                       2004
#define IDC_INTENABLE_E                 2005
#define IDC_IE4_E                       2006
#define IDC_IE3_E                       2007
#define IDC_IE2_E                       2008
#define IDC_IE1_E                       2009
#define IDC_IE0_E                       2010
#define IDC_INT0_E                      2011
#define IDC_INT1_E                      2012
#define IDC_INT2_E                      2013
#define IDC_INT3_E                      2014
#define IDC_INTTX4_E                    2015
#define IDC_INTRX4_E                    2016
#define IDC_ECHO_E                      2017
#define IDC_BINSTRING_E                 2018
#define IDC_TERMCLR_E                   2020
#define IDC_TERMINAL_E                  2021
#define IDC_INT0                        2060
#define IDC_INT1                        2061
#define IDC_INT2                        2062
#define IDC_INT3                        2063
#define IDC_INTTX4                      2064
#define IDC_PRIO                        2066
#define IDC_IP0                         2067
#define IDC_IP1                         2068
#define IDC_IP2                         2069
#define IDC_IP3                         2070
#define IDC_IP4                         2071
#define IDC_INTENABLE                   2072
#define IDC_INTRX4                      2073
#define IDC_IE0                         2074
#define IDC_IE1                         2075
#define IDC_IE2                         2076
#define IDC_IE3                         2077
#define IDC_IERX4                       2078
#define IDC_IE4                         2079
#define IDC_IETX4                       2079
#define IDC_PRIO_E                      2084
#define IDC_ECHO                        2088
#define IDC_TERMCLR                     2089
#define IDC_IERX4_E                     2096
#define IDC_BINSTRING                   2097
#define IDC_IETX4_E                     2098
#define IDC_EDITTL0                     2100
#define IDC_EDITTH0                     2101
#define IDC_EDITTL1                     2102
#define IDC_EDITTH1                     2103
#define IDC_ACCESSMEM                   2105
#define IDC_ACCESSADDR                  2106
#define IDC_ACCESSPC                    2107
#define IDC_PRG_TL0                     2108
#define IDC_PRG_TH0                     2109
#define IDC_EXTT0                       2110
#define IDC_PRG_TL1                     2111
#define IDC_PRG_TH1                     2112
#define IDC_EXTT1                       2113
#define IDC_TERMINAL                    0xA001
#define ID_MRC_ALLOWDOCKING             0xF06F
#define ID_MRC_MDIFLOAT                 0xF070
#define ID_MRC_HIDE                     0xF071
#define IDS_MEMACCESS                   0xF303
#define IDS_READACCESS                  0xF304
#define IDS_WRITEACCESS                 0xF305
#define IDS_NOMEMACCESS                 0xF306
#define IDS_MRC_STARTDOCKING            0xF307
#define IDS_MEMACCESS_E                 0xF308
#define IDS_READACCESS_E                0xF309
#define IDS_WRITEACCESS_E               0xF30A
#define IDS_NOMEMACCESS_E               0xF30B

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
