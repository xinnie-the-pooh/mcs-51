// NEdit.cpp : implementation file
//

#include "stdafx.h"
#include "proc51.h"
#include "procdll.h"
#include "NEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNEdit

CNEdit::CNEdit()
{
  localecho=TRUE;
  binstr=FALSE;
  charno=0;
}



BEGIN_MESSAGE_MAP(CNEdit, CEdit)
	//{{AFX_MSG_MAP(CNEdit)
	ON_WM_CHAR()	
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNEdit message handlers


void CNEdit::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
ULONG ip0,scon;
	
  if(!binstr)
  {
    if(localecho)
    	CEdit::OnChar(nChar, nRepCnt, nFlags);    
    prc51.SetMemAtAddr(S0BUF,(ULONG*)&nChar,'d'); 
    prc51.GetMemFromAddr(IP0,&ip0,'d'); 
    if(ip0 & 0x10==0)
      prc51.intReq |= 0x1000;
    else
      prc51.intReq |= 0x0010;
    prc51.GetMemFromAddr(SCON,&scon,'d'); 
    scon|=0x01;
    prc51.SetMemAtAddr(SCON,&scon,'d'); //serial-Rx-Interrupt    
  }
  else
  {
    if( nChar==0x08  && charno==1)
    {
      hexval=0;
      charno=0;
      if(localecho)
    	  CEdit::OnChar(nChar, nRepCnt, nFlags);
    }
    if( nChar>='0' && nChar<='9' || nChar>='A' && nChar<='F' || nChar>='a' && nChar<='f')
    {      
      if(!charno)
      {
        if(nChar>='a')        
          hexval=(nChar-0x57)*16;       
        else if(nChar>='A')
          hexval=(nChar-0x37)*16;
        else
          hexval=(nChar-0x30)*16;
        charno++;
      } 
      else
      {
        if(nChar>='a')       
          hexval|=nChar-0x57;      
        else if(nChar>='A')
          hexval|=nChar-0x37;
        else
          hexval|=nChar-0x30;
        charno=0;
        prc51.SetMemAtAddr(S0BUF,(ULONG*)&hexval,'d');  
        prc51.GetMemFromAddr(IP0,&ip0,'d');  
        if(ip0 & 0x10==0)
          prc51.intReq |= 0x1000;
        else
          prc51.intReq |= 0x0010;
        prc51.GetMemFromAddr(SCON,&scon,'d'); 
        scon|=0x01;
        prc51.SetMemAtAddr(SCON,&scon,'d'); //serial-Rx-Interrupt          
        hexval=0;
      }
      if(localecho)
    	  CEdit::OnChar(nChar, nRepCnt, nFlags);
    }
  }
}

