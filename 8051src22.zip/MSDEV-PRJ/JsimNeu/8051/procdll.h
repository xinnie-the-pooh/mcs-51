// proc.h : Haupt-Header-Datei f�r die DLL PROC
//

#if !defined(AFX_PROC_H__36A000C4_B774_11D1_AF60_444553540000__INCLUDED_)
#define AFX_PROC_H__36A000C4_B774_11D1_AF60_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole
#include "proc51.h"
#include "intctrl.h"
#include "sersim.h"
#include "TimCtrl.h"	// Hinzugef�gt von ClassView

 
/////////////////////////////////////////////////////////////////////////////
// CProcApp
// Siehe proc.cpp f�r die Implementierung dieser Klasse
//

class CProcDll : public CWinApp
{
public:	
	CTimCtrl m_wndTimers;
	CIntCtrl m_wndInterrupt;
  CSersim m_wndTerminal;
	HWND hMainWnd;                
	CProcDll();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CProcDll)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CProcApp)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern int language;
extern CProcDll theApp;
extern __declspec(dllexport) CProc* prc;
extern CProc51 prc51;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // !defined(AFX_PROC_H__36A000C4_B774_11D1_AF60_444553540000__INCLUDED_)
