// Sersim.cpp : implementation file
//

#include "stdafx.h"
#include "procdll.h"
#include "Sersim.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern unsigned char datamem[256];

CString txt;

//simuliert den Empfang �ber die COM-Sst.
UINT ComWaitThread( LPVOID tp)
{
char buff[4];
ULONG scon,sbuf,ip0;
CEdit* pe;
BOOL* simrun;


  simrun=((comThreadPar_t*)tp)->b_pSimRun;
  pe=((comThreadPar_t*)tp)->pedit;
  buff[3]=0;
  pe->SetSel(-1,-1);
  int t=0;
  while((volatile BOOL)(*simrun))
  {
    //TRACE("%d\n",t++&0xF);
    scon=datamem[SCON];    
    if(prc51.IsSerChar) // && !(scon & 0x03)) //Zeichen neu in S0BUF und alle Interrupts bearbeitet
    {             
      sbuf=datamem[S0BUF];      
      pe->GetWindowText(txt);
      if(!*(((comThreadPar_t*)tp)->pbinstr))
      {  
        buff[0]=(CHAR)sbuf;
        buff[1]=0;                  
      } 
      else
      {        
        int c;
        c=sbuf>>4;        
        if(c<0xA) 
          buff[0]=c+0x30;
        else
          buff[0]=c+0x37; 
        sbuf&=0x0F;
        if(sbuf<0x0A) 
          buff[1]=(char)sbuf+0x30;
        else
          buff[1]=(char)sbuf+0x37;
        buff[2]=' ';                      
        txt+=buff;
      }
     //if(pe->m_hWnd)
        pe->ReplaceSel(buff); 
      ip0=datamem[IP0];       
      datamem[SCON]|=0x02;  //datamem[0x98]        
      if(ip0 & 0x10 == 0)
        prc51.intReq |= 0x1000;
      else
        prc51.intReq |= 0x0010;      
      prc51.IsSerChar=FALSE;  
      if(theApp.m_wndInterrupt.m_hWnd) 
        theApp.m_wndInterrupt.SendMessage(UM_UPDATESERINT);
    }
  }
  return 0;
}


/////////////////////////////////////////////////////////////////////////////
// CSersim

CSersim::CSersim()
{  
  simRun=FALSE;
  pthread=0;  
}

CSersim::~CSersim()
{
}


BEGIN_MESSAGE_MAP(CSersim, CDllDlgBar)
//{{AFX_MSG_MAP(CSersim)
  ON_WM_SIZE()
  ON_WM_CTLCOLOR()
  ON_COMMAND(IDC_ECHO, OnEcho)	
  ON_COMMAND(IDC_BINSTRING, OnBinary)	
  ON_WM_DESTROY()
  ON_UPDATE_COMMAND_UI(IDC_TERMCLR, OnUpdateClear)
  ON_COMMAND(IDC_ECHO_E, OnEcho)	
  ON_COMMAND(IDC_BINSTRING_E, OnBinary)	
  ON_COMMAND(IDC_TERMCLR, OnClear)
  ON_COMMAND(IDC_TERMCLR_E, OnClear)
  ON_UPDATE_COMMAND_UI(IDC_TERMCLR_E, OnUpdateClear) 
//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CSersim message handlers

BOOL CSersim::Create(HWND hWndMain,CDialogBar* pd)
{  
int termid ;

    if(language==_GER)
    {
      id[iCLEAR]=IDC_TERMCLR;
      id[iECHO]=IDC_ECHO;
      id[iBINSTRING]=IDC_BINSTRING;
      termid=IDC_TERMINAL;
    }
    else
    {
      id[iCLEAR]=IDC_TERMCLR_E;
      id[iECHO]=IDC_ECHO_E;
      id[iBINSTRING]=IDC_BINSTRING_E; 
      termid=IDC_TERMINAL_E;
    }        	
    CDllDlgBar::Create(hWndMain,pd);

    prc51.IsSerChar=FALSE; 
    GetDlgItem(IDC_STATIC3)->ModifyStyle(WS_VISIBLE,0,FALSE);
    ((CButton*)GetDlgItem(id[iECHO]))->SetCheck(TRUE);   
    ((CButton*)GetDlgItem(id[iBINSTRING]))->SetCheck(FALSE);   
    editbrush.CreateSolidBrush(EDITBKCOLOR);
    terminal.SubclassDlgItem(termid,this);	
    lfont.CreateFont(-12,0,0,0,FW_REGULAR,
					 FALSE,FALSE,0,ANSI_CHARSET,
					 OUT_DEFAULT_PRECIS,
					 CLIP_DEFAULT_PRECIS,
					 DEFAULT_QUALITY,
					 FF_MODERN,"Arial");
    terminal.SetFont(&lfont,TRUE);    	
    SetWindowText(_T("Terminal Simulation"));
    terminal.SetWindowText("");	
    StartComThread();  		
    return TRUE;
}

void CSersim::OnSize(UINT nType, int cx, int cy) 
{
RECT rc;
 
  if(Created)
  {
    GetWindowRect(&rc);         
    rc.top+=40;
    ScreenToClient(&rc);
    if(IsFloating())
      GetDlgItem(IDC_STATIC3)->ModifyStyle(WS_VISIBLE,0,FALSE);
    else    
      GetDlgItem(IDC_STATIC3)->ModifyStyle(0,WS_VISIBLE,FALSE);     
    terminal.MoveWindow(&rc,TRUE);	     
  }
}

HBRUSH CSersim::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
  if(nCtlColor==CTLCOLOR_EDIT || nCtlColor==CTLCOLOR_MSGBOX)
  {
    pDC->SetBkColor(EDITBKCOLOR);
    pDC->SetTextColor(0xFFFFFF);
    return (HBRUSH(editbrush));
  }
  return CWnd::OnCtlColor(pDC, pWnd, nCtlColor);  
}

void CSersim::OnEcho()
{
  if(((CButton*)GetDlgItem(id[iECHO]))->GetCheck())
    terminal.localecho=TRUE;
  else
    terminal.localecho=FALSE;
}

void CSersim::OnBinary()
{
  if(((CButton*)GetDlgItem(id[iBINSTRING]))->GetCheck())
  {
    terminal.binstr=TRUE;
    terminal.ModifyStyle(0,ES_UPPERCASE);
  }
  else
  {
    terminal.binstr=FALSE;
    terminal.ModifyStyle(ES_UPPERCASE,0);
  }
}

void CSersim::OnClear()
{
  terminal.SetWindowText("");
  ((CButton*)GetDlgItem(IDC_TERMCLR))->SetCheck(0);
}

void CSersim::OnUpdateClear(CCmdUI* pCmdUI)
{
  pCmdUI->Enable(TRUE);
}

BOOL CSersim::EndComThread()
{
ULONG waitret;

  if(simRun && pthread)
  {
    simRun=FALSE;    //beendet noch laufenden Thread  
    waitret=WaitForSingleObject(pthread->m_hThread,1000);
    if(waitret!=WAIT_OBJECT_0) // der l��t sich nicht beenden    
      TerminateThread(pthread->m_hThread,0);     
  } 
  pthread=0;
  return 0;
}
//WAIT_OBJECT_0 

void CSersim::StartComThread()
{
  if(simRun)
    return;
  simRun=TRUE;    
  tpar.pedit=&terminal;
  tpar.b_pSimRun=&simRun;
  tpar.pbinstr=&terminal.binstr;   
  pthread=AfxBeginThread(ComWaitThread,(LPVOID)&tpar,THREAD_PRIORITY_BELOW_NORMAL);
  prc51.IsSerChar=FALSE;
}

void CSersim::OnDestroy() 
{

  EndComThread();
  CWnd::OnDestroy();  
  editbrush.DeleteObject();
  terminal.binstr=FALSE;
  lfont.DeleteObject();
  Created=FALSE;
}
