// AccessDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "resource.h"
#include "AccessDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CAccessDlg 


CAccessDlg::CAccessDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAccessDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAccessDlg)
		// HINWEIS: Der Klassen-Assistent f�gt hier Elementinitialisierung ein
	//}}AFX_DATA_INIT  
}


void CAccessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAccessDlg)
		// HINWEIS: Der Klassen-Assistent f�gt hier DDX- und DDV-Aufrufe ein
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAccessDlg, CDialog)
	//{{AFX_MSG_MAP(CAccessDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CAccessDlg 

BOOL CAccessDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
  SetDlgItemText(IDC_ACCESSMEM,memtxt);
  SetDlgItemText(IDC_ACCESSPC,pctxt);
  SetDlgItemText(IDC_ACCESSADDR,addrtxt); 
  SetWindowPos(&wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE); 	
 	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CAccessDlg::OnOK() 
{
  EndDialog(0);
}

void CAccessDlg::OnCancel() 
{
  EndDialog(-1);
}
