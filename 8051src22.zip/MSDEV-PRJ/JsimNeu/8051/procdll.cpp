// procdll.cpp : Legt die Initialisierungsroutinen f�r die DLL fest.
//

#include "stdafx.h"
#include "..\core\reginfo.h"
#include "..\core\Proc.h"
#include "proc51.h"
#include "procdll.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CProcDll

BEGIN_MESSAGE_MAP(CProcDll, CWinApp)
	//{{AFX_MSG_MAP(CProcDll)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProcApp Konstruktion

CProcDll theApp;
CProc51  prc51;
int language;

__declspec(dllexport) CProc* prc;


// Load the specified File or return the required
// file format
// return values:
//  0 - File format should be detected and loaded by the core application
//  1 - File was loaded by the processor DLL             

__declspec(dllexport) int LoadFile(LPCSTR file)
{
  return 0;  
}

// gives the application the opportunity to load
// settings from the workspace file 
__declspec(dllexport) void LoadWorkspaceFile(LPCSTR wspfile)
{
}

// gives the application the opportunity to store
// settings into the workspace file 
__declspec(dllexport) void StoreWorkspaceFile(LPCSTR wspfile)
{
}
//    Terminal Window
//    Interrupt Window

__declspec(dllexport) UINT HandleCommandLine(LPCSTR cmd)
{
BYTE memspec;
USHORT address;
ULONG newval,r;

   if(cmd[0]=='w' || cmd[0]=='W')  //window create
   {
     if(cmd[2]=='i' || cmd[2]=='I')  //Interrupt-Window
     {
       if(language==_GER) 
         return IDD_INTERRUPT;
       else
         return IDD_INTERRUPT_E;
     }
     else if(cmd[2]=='c' || cmd[2]=='C')  //Terminal-Window
     {
       if(language==_GER) 
         return IDD_SERSIM;
       else
         return IDD_SERSIM_E;
     }
     else if((cmd[2]=='t' || cmd[2]=='T') && (cmd[3]=='m' || cmd[3]=='M'))  //Timer-Window
     {       
       return IDD_TIMER;
     }
   }
   else if(cmd[0]=='$' && cmd[1]=='m' || cmd[1]=='M') //set memory command
   {

     r=sscanf(&cmd[3],"%c %x %i",&memspec,&address,&newval);
     if(r==3) //3 werte 
     {
       switch(memspec)
       {
	       case 'x':
         case 'X':
         case 'd':                   
         case 'D':
         case 'i':
         case 'I':
         case 'c':
		     case 'C':		 
                  prc51.SetMemAtAddr(address,&newval,memspec);
                  break;
       }
	 }
   }	 
   return 0;
}


__declspec(dllexport) UINT HandleExtraWndCmd(UINT cmdID,HWND hWnd,CDialogBar* pd)
{ 
  if(cmdID==IDD_INTERRUPT || cmdID==IDD_INTERRUPT_E)
  {     
    theApp.m_wndInterrupt.Create(theApp.hMainWnd,pd);
    return((UINT)&theApp.m_wndInterrupt);    
  }
  else if(cmdID==IDD_SERSIM || cmdID==IDD_SERSIM_E)
  {  
    theApp.m_wndTerminal.Create(theApp.hMainWnd,pd);    
    return((UINT)&theApp.m_wndTerminal);    
  }  
  else if(cmdID==IDD_TIMER)
  {  
    theApp.m_wndTimers.Create(theApp.hMainWnd,pd);    
    return((UINT)&theApp.m_wndTimers);    
  }  
  return 0;
}


__declspec(dllexport) int HandleExtraWndUpdateCmd(UINT cmdID)
{  
BOOL mbvis;

  if(cmdID==IDD_INTERRUPT || cmdID==IDD_INTERRUPT_E)
  { 
    if(theApp.m_wndInterrupt.Created)
    {
	    mbvis=theApp.m_wndInterrupt.GetStyle() & WS_VISIBLE;
      if(mbvis)
	    return CMD_CHECKED|CMD_ENABLED;
    }
    else
      return CMD_ENABLED; // noch gar nicht erzeugt 
  }
  else if(cmdID==IDD_SERSIM || cmdID==IDD_SERSIM_E)
  { 
    if(theApp.m_wndTerminal.Created)
    {
      BOOL mbvis=theApp.m_wndTerminal.GetStyle() & WS_VISIBLE;
      if(mbvis)
      { 
        theApp.m_wndTerminal.StartComThread();
        return CMD_CHECKED|CMD_ENABLED;
      }
      else
      {
        theApp.m_wndTerminal.EndComThread();
      }
    }
  }
  else if(cmdID==IDD_TIMER)
  { 
    if(theApp.m_wndTimers.Created)
    {
	    mbvis=theApp.m_wndTimers.GetStyle() & WS_VISIBLE;
      if(mbvis)
	      return CMD_CHECKED|CMD_ENABLED;
    }
    else
      return CMD_ENABLED; // noch gar nicht erzeugt 
  }
  else
    return CMD_ENABLED; // noch gar nicht erzeugt  
  return(CMD_ENABLED);
}

CProcDll::CProcDll() 
{
   prc=&prc51;
   language=_ENG; 
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen
	// Alle wichtigen Initialisierungen in InitInstance platzieren
}

/////////////////////////////////////////////////////////////////////////////
// Das einzige CProcApp-Objekt



BOOL CProcDll::InitInstance() 
{
  return CWinApp::InitInstance();
}

int CProcDll::ExitInstance() 
{
  theApp.m_pszProfileName=0;
	return CWinApp::ExitInstance();
}

