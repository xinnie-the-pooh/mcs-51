// Sersim.h : header file
//
#ifndef _SERSIM
#define _SERSIM
/////////////////////////////////////////////////////////////////////////////
// CSersim window
#include "nedit.h"
#include "dlldlgbar.h"

#define iCLEAR 0
#define iECHO 1
#define iBINSTRING 2

typedef struct
{
  CEdit* pedit;
  BOOL*  b_pSimRun;
  BOOL*  pbinstr;  
} comThreadPar_t;

#define CBRS_ALIGN_SERWND  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT |CBRS_ALIGN_BOTTOM
#define EDITBKCOLOR 0x808000

class CSersim : public CDllDlgBar
{
// Construction
public:
	void StartComThread();
	BOOL EndComThread();
	CBrush editbrush;
	BOOL Create(HWND hWndMain,CDialogBar* pd);
	CSersim();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSersim)
	//}}AFX_VIRTUAL

// Implementation
public:
  virtual ~CSersim();
  void OnClear();

	// Generated message map functions
protected:
  int id[3];
  BOOL simRun;
  CFont lfont;
  CNEdit terminal;
  CWinThread* pthread;
  comThreadPar_t tpar; 
	//{{AFX_MSG(CSersim)
  afx_msg void OnSize(UINT nType, int cx, int cy);
  afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
  afx_msg void OnEcho();  
  afx_msg void OnBinary();
  afx_msg void OnDestroy();
  afx_msg void OnUpdateClear(CCmdUI* pCmdUI);
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

#endif //_SERSIM
/////////////////////////////////////////////////////////////////////////////
