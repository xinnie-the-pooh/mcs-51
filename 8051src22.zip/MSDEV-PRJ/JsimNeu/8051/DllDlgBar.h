#ifndef AFX_DLLDLGBAR_H__6201FF01_D3BE_11D1_AF60_444553540000__INCLUDED_
#define AFX_DLLDLGBAR_H__6201FF01_D3BE_11D1_AF60_444553540000__INCLUDED_

// DllDlgBar.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Fenster CDllDlgBar 

class CDllDlgBar : public CWnd
{
// Konstruktion
public:
	CDllDlgBar();

// Attribute
public:

// Operationen
public:

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CDllDlgBar)
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual void UpdateDlgBar();
	BOOL Create(HWND hwndParent, CDialogBar* dlgbar);
	BOOL IsFloating();
	BOOL Created;    
  CDialogBar* pdlg;
	virtual ~CDllDlgBar();

protected:
    POINT m_FloatingPosition;
    char ttptxt[200];
	// Generierte Nachrichtenzuordnungsfunktionen
protected:	
	//{{AFX_MSG(CDllDlgBar)
	afx_msg void OnDestroy();    
    afx_msg LONG OnUpdateWatches( UINT, LONG ); 
    afx_msg LONG OnGetMessageText( UINT nID, LONG dummy); 
    afx_msg BOOL OnTtpNotify( UINT id, NMHDR * pNMHDR, LRESULT * pResult );	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // AFX_DLLDLGBAR_H__6201FF01_D3BE_11D1_AF60_444553540000__INCLUDED_
