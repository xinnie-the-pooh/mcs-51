// IntCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "proc51.h"
#include "IntCtrl.h"
#include "procdll.h"
#include "..\core\coreexport.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIntCtrl


extern unsigned char datamem[256];


CIntCtrl::CIntCtrl()
{
}

CIntCtrl::~CIntCtrl()
{
}

BEGIN_MESSAGE_MAP(CIntCtrl, CDllDlgBar)
	//{{AFX_MSG_MAP(CIntCtrl)
    ON_COMMAND(IDC_IE0, OnEnable0)	    
    ON_COMMAND(IDC_IE1, OnEnable1)	    
    ON_COMMAND(IDC_IE2, OnEnable2)	    
    ON_COMMAND(IDC_IE3, OnEnable3)	    
    ON_COMMAND(IDC_IE4, OnEnable4)	        
    ON_COMMAND(IDC_IP0, OnPrioInt0)	
    ON_COMMAND(IDC_IP1, OnPrioInt1)	    
    ON_COMMAND(IDC_IP2, OnPrioInt2)	    
    ON_COMMAND(IDC_IP3, OnPrioInt3)	    
    ON_COMMAND(IDC_IP4, OnPrioInt4)	    
    ON_COMMAND(IDC_INT0, OnInt0)	
    ON_UPDATE_COMMAND_UI(IDC_INT0, OnUpdateInt0)
    ON_COMMAND(IDC_INT1, OnInt1)	
    ON_UPDATE_COMMAND_UI(IDC_INT1, OnUpdateInt1)
    ON_COMMAND(IDC_INT2, OnInt2)	
    ON_UPDATE_COMMAND_UI(IDC_INT2, OnUpdateInt2)
    ON_COMMAND(IDC_INT3, OnInt3)	
    ON_UPDATE_COMMAND_UI(IDC_INT3, OnUpdateInt3)
    ON_COMMAND(IDC_INTRX4, OnIntRx4)	
    ON_UPDATE_COMMAND_UI(IDC_INTRX4, OnUpdateIntRx4)
    ON_COMMAND(IDC_INTTX4, OnIntTx4)	
    ON_UPDATE_COMMAND_UI(IDC_INTTX4, OnUpdateIntTx4)    
    ON_COMMAND(IDC_INTENABLE, OnIntEnable)	
    ON_UPDATE_COMMAND_UI(IDC_INTENABLE, OnUpdateIntEnable)
    ON_COMMAND(IDC_IE0_E, OnEnable0)	    
    ON_COMMAND(IDC_IE1_E, OnEnable1)	    
    ON_COMMAND(IDC_IE2_E, OnEnable2)	    
    ON_COMMAND(IDC_IE3_E, OnEnable3)	    
    ON_COMMAND(IDC_IE4_E, OnEnable4)	        
    ON_COMMAND(IDC_IP0_E, OnPrioInt0)	
    ON_COMMAND(IDC_IP1_E, OnPrioInt1)	    
    ON_COMMAND(IDC_IP2_E, OnPrioInt2)	    
    ON_COMMAND(IDC_IP3_E, OnPrioInt3)	    
    ON_COMMAND(IDC_IP4_E, OnPrioInt4)	    
    ON_COMMAND(IDC_INT0_E, OnInt0)	
    ON_UPDATE_COMMAND_UI(IDC_INT0_E, OnUpdateInt0)
    ON_COMMAND(IDC_INT1_E, OnInt1)	
    ON_UPDATE_COMMAND_UI(IDC_INT1_E, OnUpdateInt1)
    ON_COMMAND(IDC_INT2_E, OnInt2)	
    ON_UPDATE_COMMAND_UI(IDC_INT2_E, OnUpdateInt2)
    ON_COMMAND(IDC_INT3_E, OnInt3)	
    ON_UPDATE_COMMAND_UI(IDC_INT3_E, OnUpdateInt3)
    ON_COMMAND(IDC_INTRX4_E, OnIntRx4)	
    ON_UPDATE_COMMAND_UI(IDC_INTRX4_E, OnUpdateIntRx4)
    ON_COMMAND(IDC_INTTX4_E, OnIntTx4)	
    ON_UPDATE_COMMAND_UI(IDC_INTTX4_E, OnUpdateIntTx4)    
    ON_COMMAND(IDC_INTENABLE_E, OnIntEnable)	
    ON_UPDATE_COMMAND_UI(IDC_INTENABLE_E, OnUpdateIntEnable)
    ON_MESSAGE( UM_UPDATESERINT , OnUpdateSerInt)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CIntCtrl message handlers

LONG CIntCtrl::OnUpdateSerInt(UINT, LONG)
{
  if(Created && GetStyle()&WS_VISIBLE)
  {
     int scon=datamem[SCON];
     if(prc51.intReq & 0x1010 && (scon & 0x02))
      ((CButton*)GetDlgItem(id[iINTTX4]))->SetCheck(TRUE);
     else 
      ((CButton*)GetDlgItem(id[iINTTX4]))->SetCheck(FALSE); 
     if(prc51.intReq & 0x1010 && (scon & 0x01))
      ((CButton*)GetDlgItem(id[iINTRX4]))->SetCheck(TRUE);
     else 
      ((CButton*)GetDlgItem(id[iINTRX4]))->SetCheck(FALSE);    
  }
  return 0; 
}


#define CBRS_ALIGN_INTERRUPT  CBRS_ALIGN_RIGHT | CBRS_ALIGN_LEFT | CBRS_ALIGN_BOTTOM | CBRS_ALIGN_TOP  

BOOL CIntCtrl::Create(HWND hWndMain,CDialogBar* pd)
{
ULONG b8,a8;
   if(language==_GER)
   {
     id[iIE0]=IDC_IE0;
     id[iIE1]=IDC_IE1;
     id[iIE2]=IDC_IE2;
     id[iIE3]=IDC_IE3;
     id[iIE4]=IDC_IE4;
     id[iINTENABLE]=IDC_INTENABLE;
     id[iIP0]=IDC_IP0;
     id[iIP1]=IDC_IP1;
     id[iIP2]=IDC_IP2;
     id[iIP3]=IDC_IP3;
     id[iIP4]=IDC_IP4;
     id[iINT0]=IDC_INT0;
     id[iINT1]=IDC_INT1;
     id[iINT2]=IDC_INT2;
     id[iINT3]=IDC_INT3;
     id[iINTTX4]=IDC_INTTX4;
     id[iINTRX4]=IDC_INTRX4; 
   }
   else
   {
     id[iIE0]=IDC_IE0_E;
     id[iIE1]=IDC_IE1_E;
     id[iIE2]=IDC_IE2_E;
     id[iIE3]=IDC_IE3_E;
     id[iIE4]=IDC_IE4_E;
     id[iINTENABLE]=IDC_INTENABLE_E;
     id[iIP0]=IDC_IP0_E;
     id[iIP1]=IDC_IP1_E;
     id[iIP2]=IDC_IP2_E;
     id[iIP3]=IDC_IP3_E;
     id[iIP4]=IDC_IP4_E; 
     id[iINT0]=IDC_INT0_E;
     id[iINT1]=IDC_INT1_E;
     id[iINT2]=IDC_INT2_E;
     id[iINT3]=IDC_INT3_E;
     id[iINTTX4]=IDC_INTTX4_E;
     id[iINTRX4]=IDC_INTRX4_E;   
   }     

    CDllDlgBar::Create(hWndMain,pd);
	  SetWindowText(_T("Interrupts"));
    
    prc51.GetMemFromAddr(0xB8,&b8,'d');    
    prc51.GetMemFromAddr(0xA8,&a8,'d');  
    ((CButton*)GetDlgItem(id[iIP0]))->SetCheck(b8 & 0x01);  
    ((CButton*)GetDlgItem(id[iIP1]))->SetCheck(b8 & 0x02); 
    ((CButton*)GetDlgItem(id[iIP2]))->SetCheck(b8 & 0x04); 
    ((CButton*)GetDlgItem(id[iIP3]))->SetCheck(b8 & 0x08);
    ((CButton*)GetDlgItem(id[iIP4]))->SetCheck(b8 & 0x10);
    ((CButton*)GetDlgItem(id[iINTENABLE] ))->SetCheck(a8 & 0x80);       
    return(TRUE); 
}

void CIntCtrl::OnEnable0()
{
ULONG ie0;
  
  prc51.GetMemFromAddr(IE0,&ie0,'d');
  
  if(((CButton*)GetDlgItem(id[iIE0]))->GetCheck())     
    ie0|=0x01;               
  else  
    ie0 &= ~0x01;           
  prc->SetMemAtAddr(IE0,&ie0,'d');    
  UpdateAllWatches();
}

void CIntCtrl::OnEnable1()
{
ULONG ie0;
  
  prc51.GetMemFromAddr(IE0,&ie0,'d');
  if(((CButton*)GetDlgItem(id[iIE1]))->GetCheck())
    ie0|=0x02;  
  else
    ie0 &= ~0x02;
  prc51.SetMemAtAddr(IE0,&ie0,'d');      
  UpdateAllWatches();
}


void CIntCtrl::OnEnable2()
{
ULONG ie0;
  
  prc51.GetMemFromAddr(IE0,&ie0,'d');
  if(((CButton*)GetDlgItem(id[iIE2]))->GetCheck())
    ie0|=0x04;  
  else
    ie0 &= ~0x04;
  prc51.SetMemAtAddr(IE0,&ie0,'d'); 
  UpdateAllWatches();
}


void CIntCtrl::OnEnable3()
{
ULONG ie0;
  
  prc51.GetMemFromAddr(IE0,&ie0,'d');
  if(((CButton*)GetDlgItem(id[iIE3]))->GetCheck())
    ie0|=0x08;  
  else
    ie0 &= ~0x08;
  prc51.SetMemAtAddr(IE0,&ie0,'d'); 
  UpdateAllWatches();
}


void CIntCtrl::OnEnable4()
{
ULONG ie0;
  
  prc51.GetMemFromAddr(IE0,&ie0,'d');
  if(((CButton*)GetDlgItem(id[iIE4]))->GetCheck())
    ie0|=0x10;  
  else
    ie0 &= ~0x10;
  prc51.SetMemAtAddr(IE0,&ie0,'d'); 
  UpdateAllWatches();
}


// Priorit�t
void CIntCtrl::OnPrioInt0()
{
ULONG ip0;
   
  prc51.GetMemFromAddr(IP0,&ip0,'d');
  if(((CButton*)GetDlgItem(id[iIP0]))->GetCheck())
    ip0|=0x01; 
  else
    ip0&=~0x01; 
  prc51.SetMemAtAddr(IP0,&ip0,'d');  
  UpdateAllWatches();
}


void CIntCtrl::OnPrioInt1()
{
ULONG ip0;
  
  prc51.GetMemFromAddr(IP0,&ip0,'d');
  if(((CButton*)GetDlgItem(id[iIP1]))->GetCheck())
    ip0|=0x02;     
  else
    ip0&=~0x02;   
  prc51.SetMemAtAddr(IP0,&ip0,'d'); 
  UpdateAllWatches();
}

void CIntCtrl::OnPrioInt2()
{
ULONG ip0;
  
  prc51.GetMemFromAddr(IP0,&ip0,'d');
  if(((CButton*)GetDlgItem(id[iIP2]))->GetCheck())
    ip0|=0x04;     
  else
    ip0&=~0x04;   
  prc51.SetMemAtAddr(IP0,&ip0,'d'); 
  UpdateAllWatches();
}


void CIntCtrl::OnPrioInt3()
{
ULONG ip0;
  
  prc51.GetMemFromAddr(IP0,&ip0,'d');
  if(((CButton*)GetDlgItem(id[iIP3]))->GetCheck())
    ip0|=0x08;     
  else
    ip0&=~0x08;   
  prc51.SetMemAtAddr(IP0,&ip0,'d'); 
  UpdateAllWatches();
}

void CIntCtrl::OnPrioInt4()
{
ULONG ip0;
  
  prc51.GetMemFromAddr(IP0,&ip0,'d');
  if(((CButton*)GetDlgItem(id[iIP4]))->GetCheck())
    ip0|=0x10;     
  else
    ip0&=~0x10;   
  prc51.SetMemAtAddr(IP0,&ip0,'d'); 
  UpdateAllWatches();
}


// Interrupt Buttons
void CIntCtrl::OnInt0() //Ext0
{
ULONG tcon;

  int prio=((CButton*)GetDlgItem(id[iIP0]))->GetCheck();
  prc51.GetMemFromAddr(TCON,&tcon,'d');
  if(((CButton*)GetDlgItem(id[iINT0]))->GetCheck())
  {
    if(!prio)
      prc51.intReq |= 0x0100;
    else
      prc51.intReq |= 0x0001;    
    tcon|=0x02;
    prc51.SetMemAtAddr(TCON,&tcon,'d');      
  }
  else
  {
    prc51.intReq &= ~0x0101;
    tcon&= ~0x02;
    prc51.SetMemAtAddr(TCON,&tcon,'d');          
  }
  UpdateAllWatches();
}


void CIntCtrl::OnUpdateInt0(CCmdUI* pCmdUI)
{
  if(prc51.intReq & 0x0101)
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::OnInt1() //Timer0
{
ULONG tcon;

  int prio=((CButton*)GetDlgItem(id[iIP1]))->GetCheck();
  prc51.GetMemFromAddr(TCON,&tcon,'d');
  if(((CButton*)GetDlgItem(id[iINT1]))->GetCheck())
  {
    if(!prio)
      prc51.intReq |= 0x0200;
    else
      prc51.intReq |= 0x0002;
    tcon|=0x20;
    prc51.SetMemAtAddr(TCON,&tcon,'d');    
  }
  else
  {
    prc51.intReq &= ~0x0202;
    tcon&= ~0x20;
    prc51.SetMemAtAddr(TCON,&tcon,'d');    
  }
  UpdateAllWatches();
}

void CIntCtrl::OnUpdateInt1(CCmdUI* pCmdUI)
{
  if(prc51.intReq & 0x0202)
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::OnInt2() //Ext2
{
ULONG tcon;
  
  prc51.GetMemFromAddr(TCON,&tcon,'d');
  int prio=((CButton*)GetDlgItem(id[iIP2]))->GetCheck();
  if(((CButton*)GetDlgItem(id[iINT2]))->GetCheck())
  {
    if(!prio)
      prc51.intReq |= 0x0400;
    else
      prc51.intReq |= 0x0004;
    tcon|=0x08;
    prc51.SetMemAtAddr(TCON,&tcon,'d');     
  }
  else
  {
    prc51.intReq &= ~0x0404;
    tcon&= ~0x08;
    prc51.SetMemAtAddr(TCON,&tcon,'d');  
  }
  UpdateAllWatches();
}

void CIntCtrl::OnUpdateInt2(CCmdUI* pCmdUI)
{
  if(prc51.intReq & 0x0404)
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::OnInt3() //Timer1
{
ULONG tcon;
  
  prc51.GetMemFromAddr(TCON,&tcon,'d');
  int prio=((CButton*)GetDlgItem(id[iIP3]))->GetCheck();
  if(((CButton*)GetDlgItem(id[iINT3]))->GetCheck())
  {
    if(!prio)
      prc51.intReq |= 0x0800;
    else
      prc51.intReq |= 0x0008;
    tcon|=0x80;
    prc51.SetMemAtAddr(TCON,&tcon,'d');
  }
  else
  {
    prc51.intReq &= ~0x0808;
    tcon&= ~0x80;
    prc51.SetMemAtAddr(TCON,&tcon,'d');
  }
  UpdateAllWatches();
}

void CIntCtrl::OnUpdateInt3(CCmdUI* pCmdUI)
{
  if(prc51.intReq & 0x0808)
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::OnIntRx4()
{
ULONG scon;

  prc51.GetMemFromAddr(SCON,&scon,'d');
  int prio=((CButton*)GetDlgItem(id[iIP4]))->GetCheck();
  if(((CButton*)GetDlgItem(id[iINTRX4]))->GetCheck())
  {
    if(scon & 0x10)  // REN gesetzt
    {
      if(!prio)
        prc51.intReq |= 0x1000;
      else
        prc51.intReq |= 0x0010;
      scon|=0x01;
      prc51.SetMemAtAddr(SCON,&scon,'d');
    }
    else
      ((CButton*)GetDlgItem(id[iINTRX4]))->SetCheck(FALSE);
  }
  else
  {
    prc51.intReq &= ~0x1010;
    scon&= ~0x01;
    prc51.SetMemAtAddr(SCON,&scon,'d');
  }
  UpdateAllWatches();
}

void CIntCtrl::OnUpdateIntRx4(CCmdUI* pCmdUI)
{
ULONG scon;
  prc51.GetMemFromAddr(SCON,&scon,'d');
  if( prc51.intReq & 0x1010 && (scon & 0x01))
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::OnIntTx4()
{
ULONG scon;

  
  prc51.GetMemFromAddr(SCON,&scon,'d');
  int prio=((CButton*)GetDlgItem(id[iIP4]))->GetCheck();
  if(((CButton*)GetDlgItem(id[iINTTX4]))->GetCheck())
  {
    if(!prio)
      prc51.intReq |= 0x1000;
    else
      prc51.intReq |= 0x0010;
    scon|=0x02;
    prc51.SetMemAtAddr(SCON,&scon,'d');
  }
  else
  {
    prc51.intReq &= ~0x1010;
    scon&= ~0x02;
    prc51.SetMemAtAddr(SCON,&scon,'d');
  }
  UpdateAllWatches();
}

void CIntCtrl::OnUpdateIntTx4(CCmdUI* pCmdUI)
{
ULONG scon;

  prc51.GetMemFromAddr(SCON,&scon,'d');
  if(prc51.intReq & 0x1010  && (scon & 0x02))
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::OnIntEnable()
{
ULONG ie0;

  prc51.GetMemFromAddr(IE0,&ie0,'d');
  if(((CButton*)GetDlgItem(id[iINTENABLE]))->GetCheck())
    ie0|=0x80;        
  else
    ie0&= ~0x80;
  prc51.SetMemAtAddr(IE0,&ie0,'d'); 
  UpdateAllWatches();
}

void CIntCtrl::OnUpdateIntEnable(CCmdUI* pCmdUI)
{
ULONG ie0;

  prc51.GetMemFromAddr(IE0,&ie0,'d');
  if(ie0 & 0x80)
    pCmdUI->SetCheck(TRUE);
  else
    pCmdUI->SetCheck(FALSE);
}

void CIntCtrl::UpdateDlgBar()
{
ULONG intEnable;
ULONG intPrio;
int actReq;
ULONG scon;


   prc51.GetMemFromAddr(IE0,&intEnable,'d');   
   prc51.GetMemFromAddr(IP0,&intPrio,'d'); 
   actReq=prc51.intReq;   

   if(intEnable & 0x01)
     ((CButton*)GetDlgItem(id[iIE0]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIE0]))->SetCheck(FALSE);
   if(intEnable & 0x02)
     ((CButton*)GetDlgItem(id[iIE1]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIE1]))->SetCheck(FALSE); 
   if(intEnable & 0x04)
     ((CButton*)GetDlgItem(id[iIE2]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIE2]))->SetCheck(FALSE);
   if(intEnable & 0x08)
     ((CButton*)GetDlgItem(id[iIE3]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIE3]))->SetCheck(FALSE); 
   if(intEnable & 0x10)
     ((CButton*)GetDlgItem(id[iIE4]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIE4]))->SetCheck(FALSE); 
   if(intEnable & 0x80)
     ((CButton*)GetDlgItem(id[iINTENABLE]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINTENABLE]))->SetCheck(FALSE); 

   if(intPrio & 0x01)
     ((CButton*)GetDlgItem(id[iIP0]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIP0]))->SetCheck(FALSE);
   if(intPrio & 0x02)
     ((CButton*)GetDlgItem(id[iIP1]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIP1]))->SetCheck(FALSE); 
   if(intPrio & 0x04)
     ((CButton*)GetDlgItem(id[iIP2]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIP2]))->SetCheck(FALSE);
   if(intPrio & 0x08)
     ((CButton*)GetDlgItem(id[iIP3]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIP3]))->SetCheck(FALSE); 
   if(intPrio & 0x10)
     ((CButton*)GetDlgItem(id[iIP4]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iIP4]))->SetCheck(FALSE);
   
   if(actReq & 0x101)
     ((CButton*)GetDlgItem(id[iINT0]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINT0]))->SetCheck(FALSE);
   if(actReq & 0x202)
     ((CButton*)GetDlgItem(id[iINT1]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINT1]))->SetCheck(FALSE); 
   if(actReq & 0x404)
     ((CButton*)GetDlgItem(id[iINT2]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINT2]))->SetCheck(FALSE);
   if(actReq & 0x808)
     ((CButton*)GetDlgItem(id[iINT3]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINT3]))->SetCheck(FALSE); 
   //prc51.GetMemFromAddr(SCON,&scon,'d'); 
   scon=datamem[SCON];
   if(actReq & 0x1010 && (scon & 0x02))
     ((CButton*)GetDlgItem(id[iINTTX4]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINTTX4]))->SetCheck(FALSE); 
   if(actReq & 0x1010 && (scon & 0x01))
     ((CButton*)GetDlgItem(id[iINTRX4]))->SetCheck(TRUE);
   else 
     ((CButton*)GetDlgItem(id[iINTRX4]))->SetCheck(FALSE);    
}

