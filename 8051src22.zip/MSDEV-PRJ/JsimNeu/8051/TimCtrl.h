#ifndef AFX_TIMCTRL_H__B0B86921_45AD_11D2_B6D0_444553540000__INCLUDED_
#define AFX_TIMCTRL_H__B0B86921_45AD_11D2_B6D0_444553540000__INCLUDED_

// TimCtrl.h : Header-Datei
//

#include "dlldlgBar.h"
/////////////////////////////////////////////////////////////////////////////
// Fenster CTimCtrl 

class CTimCtrl : public CDllDlgBar
{
// Konstruktion
public:
	CTimCtrl();

// Attribute
public:

// Operationen
public:
   BOOL Create(HWND hWndMain,CDialogBar* pd);    

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CTimCtrl)
	public:
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementierung
public:
	void UpdateDlgBar();
	virtual ~CTimCtrl();

	// Generierte Nachrichtenzuordnungsfunktionen
protected:
     
	//{{AFX_MSG(CTimCtrl)
		// HINWEIS - Der Klassen-Assistent f�gt hier Member-Funktionen ein und entfernt diese.
    afx_msg void OnTim0();  
    afx_msg void OnTim1();  
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL txtIsChanging;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // AFX_TIMCTRL_H__B0B86921_45AD_11D2_B6D0_444553540000__INCLUDED_
