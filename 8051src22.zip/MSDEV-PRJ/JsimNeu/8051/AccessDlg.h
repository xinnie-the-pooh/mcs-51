#ifndef AFX_ACCESSDLG_H__D534AA81_BC27_11D1_AF60_444553540000__INCLUDED_
#define AFX_ACCESSDLG_H__D534AA81_BC27_11D1_AF60_444553540000__INCLUDED_

// AccessDlg.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CAccessDlg 

class CAccessDlg : public CDialog
{
// Konstruktion
public:
	CAccessDlg(CWnd* pParent = NULL);   // Standardkonstruktor
    CString memtxt;
    CString pctxt;
    CString addrtxt;    
// Dialogfelddaten
	//{{AFX_DATA(CAccessDlg)
	enum { IDD = IDD_ACCESS };
		// HINWEIS: Der Klassen-Assistent f�gt hier Datenelemente ein
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CAccessDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	
	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CAccessDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // AFX_ACCESSDLG_H__D534AA81_BC27_11D1_AF60_444553540000__INCLUDED_
